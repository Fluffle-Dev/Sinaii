# python3 tools/qa.py final.mp4
# EMPTY a-b = stretch of >= 0.5 s with almost nothing on screen.  POP t = one-frame brightness jump (a background dissolving into itself).
# The final fade to black at the very end is expected.
import subprocess, numpy as np, sys
W, H = 320, 180
p = subprocess.run(['ffmpeg', '-loglevel', 'error', '-i', sys.argv[1], '-vf', f'fps=6,scale={W}:{H},format=gray', '-f', 'rawvideo', '-'], capture_output=True)
a = np.frombuffer(p.stdout, np.uint8).reshape(-1, H, W).astype(np.int16)
edges = (np.abs(np.diff(a, axis=2)) > 12).sum(axis=(1, 2)); diff = np.abs(np.diff(a, axis=0)).mean(axis=(1, 2))
run = 0
for i, e in enumerate(edges):
    if e < 570: run += 1
    else:
        if run >= 3: print('EMPTY %.1f-%.1f' % ((i - run) / 6, i / 6))
        run = 0
if run >= 3: print('EMPTY tail %.1f' % ((len(edges) - run) / 6))
med = np.median(diff)
for i in range(1, len(diff) - 1):
    if diff[i] > max(3 * med, 4) and diff[i - 1] < diff[i] / 2.5 and diff[i + 1] < diff[i] / 2.5: print('POP %.1f %.2f' % ((i + 1) / 6, diff[i]))
print('frames', len(a), 'median diff', round(med, 2))
