# python3 tools/chk.py app/src/scenes/new1.tsx app/src/scenes/new2.tsx
# Reports at('phrase') anchors that are MISSING from words.json, or DUP (appear more than once: pass nth).
import json, re, sys
w = json.load(open('app/src/words.json')); ns = [x['n'] for x in w]
def nz(p): return [re.sub(r'[^a-z0-9]', '', t) for t in p.lower().replace("’", "").replace("'", "").split() if re.sub(r'[^a-z0-9]', '', t)]
def hits(q): return [i for i in range(len(ns) - len(q) + 1) if ns[i:i + len(q)] == q]
bad = 0
for fn in sys.argv[1:]:
    for m in re.finditer(r"at(?:End)?\('((?:[^'\\]|\\.)*)'(?:,\s*(\d+))?\)", open(fn).read()):
        p, n = m.group(1), int(m.group(2) or 1); h = hits(nz(p))
        if len(h) < n: print('MISSING', fn, p, n); bad += 1
        elif len(h) > 1 and m.group(2) is None: print('DUP', fn, p, len(h), [round(w[i]['s'], 1) for i in h])
print('bad', bad)
