#!/bin/bash
# bash tools/thumb.sh 1 out.jpg -> renders Thumb composition (variant v) to 1280x720 jpg
set -e; cd app
BFLAG=""
if [ -n "$BROWSER" ] && [ -x "$BROWSER" ]; then
  BFLAG="--browser-executable=$BROWSER"
fi
npx remotion still src/index.ts Thumb ../thumb_tmp.png --props="{\"v\":$1}" --gl=swangle $BFLAG --log=error
cd .. && python3 -c "from PIL import Image; Image.open('thumb_tmp.png').convert('RGB').resize((1280,720),Image.LANCZOS).save('$2',quality=93)"
echo "thumbnail: $2"
