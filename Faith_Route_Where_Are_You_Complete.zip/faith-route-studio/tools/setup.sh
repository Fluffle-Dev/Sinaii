#!/bin/bash
# Run once per fresh machine/container, from the faith-route-studio folder.
set -e
cd app && npm install --no-audit --no-fund
mkdir -p public/fonts
for f in cinzel/files/cinzel-latin-500-normal.woff2 cinzel/files/cinzel-latin-700-normal.woff2 cormorant-garamond/files/cormorant-garamond-latin-500-italic.woff2 noto-serif-hebrew/files/noto-serif-hebrew-hebrew-500-normal.woff2 noto-serif/files/noto-serif-greek-500-normal.woff2 noto-serif/files/noto-serif-greek-400-italic.woff2; do cp node_modules/@fontsource/$f public/fonts/; done
cd ..
pip install -q faster-whisper scipy numpy pillow 2>/dev/null || pip install --break-system-packages -q faster-whisper scipy numpy pillow
mkdir -p voice stills chunks
echo SETUP DONE
