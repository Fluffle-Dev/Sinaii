# python3 tools/tr.py -> words_raw.json (supports single p1_16.wav OR two-part p1_16.wav + p2_16.wav)
import json, os, numpy as np
from scipy.io import wavfile
from faster_whisper import WhisperModel

m = WhisperModel("small.en", device="cpu", compute_type="int8")
out = []
sr, p1 = wavfile.read('voice/p1_16.wav')
parts = ['p1', 'p2'] if os.path.exists('voice/p2_16.wav') else ['p1']
for name in parts:
    sr, a = wavfile.read(f'voice/{name}_16.wav')
    a = a.astype(np.float32) / 32768
    off = 0 if name == 'p1' else len(p1) / sr + 0.5
    segs, _ = m.transcribe(a, word_timestamps=True, vad_filter=False, language='en')
    for s in segs:
        for w in s.words:
            out.append({'w': w.word.strip(), 's': round(w.start + off, 3), 'e': round(w.end + off, 3)})
json.dump(out, open('words_raw.json', 'w'))
print(len(out), 'words')
