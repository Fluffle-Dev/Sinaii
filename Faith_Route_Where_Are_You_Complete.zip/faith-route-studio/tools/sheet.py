# python3 tools/sheet.py PREFIX out.jpg [start]  -> 3x4 contact sheet of stills/PREFIX*.jpg
import sys, glob
from PIL import Image, ImageDraw
pfx, out = sys.argv[1], sys.argv[2]; start = int(sys.argv[3]) if len(sys.argv) > 3 else 0
fs = sorted(glob.glob(f'stills/{pfx}*.jpg'))[start:start + 12]
s = Image.new('RGB', (1440, 1080)); d = ImageDraw.Draw(s)
for i, fn in enumerate(fs):
    s.paste(Image.open(fn).resize((480, 270)), ((i % 3) * 480, (i // 3) * 270))
    d.text(((i % 3) * 480 + 6, (i // 3) * 270 + 4), f'{int(fn[-9:-4]) / 30:.0f}s', fill=(255, 80, 80))
s.save(out)
