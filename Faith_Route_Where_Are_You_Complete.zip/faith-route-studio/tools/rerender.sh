#!/bin/bash
# bash tools/rerender.sh 4 8 10   -> re-renders chunk numbers into chunks/rNN.mp4 (never deletes; final.sh prefers rNN over cNN)
cd app
T=$(node -e "const w=require('./src/words.json');console.log(Math.ceil((w[w.length-1].e+2.4)*30))")
B=${BROWSER:-/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell}
for n in "$@"; do
  s=$((n*1800)); e=$((s+1799)); [ $e -ge $T ] && e=$((T-1)); nm=$(printf "r%02d" $n)
  npx remotion render src/index.ts Main ../chunks/tmp_r.mp4 --frames=$s-$e --muted --codec=h264 --crf=15 --x264-preset=medium --pixel-format=yuv420p --image-format=png --concurrency=2 --gl=swangle --browser-executable=$B --log=error \
    && mv ../chunks/tmp_r.mp4 ../chunks/$nm.mp4 && echo "done $nm $(date +%T)"
done
echo ALLDONE
