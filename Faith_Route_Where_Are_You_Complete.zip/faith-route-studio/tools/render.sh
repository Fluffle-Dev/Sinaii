#!/bin/bash
# Renders 1800-frame chunks into chunks/cNN.mp4, skipping chunks that already exist.
set -e
mkdir -p chunks
cd app
T=$(node -e "const w=require('./src/words.json');console.log(Math.ceil((w[w.length-1].e+2.4)*30))")
CONC=${CONCURRENCY:-$(nproc 2>/dev/null || echo 2)}
BFLAG=""
if [ -n "$BROWSER" ] && [ -x "$BROWSER" ]; then
  BFLAG="--browser-executable=$BROWSER"
fi
C=1800; i=0
for ((s=0; s<T; s+=C)); do
  e=$((s+C-1)); [ $e -ge $T ] && e=$((T-1))
  n=$(printf "c%02d" $i); out=../chunks/$n.mp4
  if [ ! -f "$out" ] && [ -n "$BACKUP" ] && [ -f "$BACKUP/$n.mp4" ]; then cp "$BACKUP/$n.mp4" "$out"; fi
  if [ ! -f "$out" ]; then
    npx remotion render src/index.ts Main ../chunks/tmp_$n.mp4 --frames=$s-$e --muted --codec=h264 --crf=16 --x264-preset=veryfast --pixel-format=yuv420p --image-format=jpeg --jpeg-quality=88 --concurrency=$CONC --gl=swangle $BFLAG --log=error       && mv ../chunks/tmp_$n.mp4 "$out" && { [ -n "$BACKUP" ] && mkdir -p "$BACKUP" && cp "$out" "$BACKUP/"; true; } && echo "done $n ($s-$e / $T) $(date +%T)"
  fi
  i=$((i+1))
done
echo "ALLDONE frames=$T"
