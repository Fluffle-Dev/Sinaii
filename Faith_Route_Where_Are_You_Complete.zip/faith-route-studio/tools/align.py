# python3 tools/align.py  -> app/src/words.json  {t, n, s, e, p}  (p = paragraph index)
import json, re, difflib, sys
script = open("script.txt").read()
raw = json.load(open("words_raw.json"))

def norm(w):
    return re.sub(r"[^a-z0-9]", "", w.lower().replace("’", "'"))

# script tokens keep their original text (with punctuation) for captions
toks = re.findall(r"\S+", script)
paras = []  # paragraph index per token
pi = 0; pos = 0
for para_i, para in enumerate(script.split("\n\n")):
    for t in re.findall(r"\S+", para):
        paras.append(para_i)
sn = [norm(t) for t in toks]
rn = [norm(w["w"]) for w in raw]
sm = difflib.SequenceMatcher(a=sn, b=rn, autojunk=False)
times = [None] * len(toks)
for a, b, n in sm.get_matching_blocks():
    for k in range(n):
        times[a + k] = (raw[b + k]["s"], raw[b + k]["e"])
# interpolate gaps
known = [i for i, t in enumerate(times) if t]
matched = len(known)
for i in range(len(toks)):
    if times[i] is None:
        prev = max([k for k in known if k < i], default=None)
        nxt = min([k for k in known if k > i], default=None)
        s0 = times[prev][1] if prev is not None else 0
        s1 = times[nxt][0] if nxt is not None else s0 + 0.4
        gap = [j for j in range(prev + 1 if prev is not None else 0, nxt if nxt is not None else len(toks))]
        idx = gap.index(i); m = len(gap)
        st = s0 + (s1 - s0) * idx / m; en = s0 + (s1 - s0) * (idx + 1) / m
        times[i] = (round(st, 3), round(en, 3))
out = [{"t": toks[i], "n": sn[i], "s": times[i][0], "e": times[i][1], "p": paras[i]} for i in range(len(toks))]
json.dump(out, open("app/src/words.json", "w"))
print("script tokens", len(toks), "whisper words", len(raw), "matched", matched, f"({matched/len(toks):.1%})")
print("last", out[-1])
