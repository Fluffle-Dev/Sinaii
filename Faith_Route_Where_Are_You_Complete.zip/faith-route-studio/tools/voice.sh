#!/bin/bash
# tools/voice.sh single.mp3   OR   tools/voice.sh part1.mp3 part2.mp3
set -e; mkdir -p voice app/public
rm -f voice/p1.wav voice/p2.wav voice/p1_16.wav voice/p2_16.wav
if [ -z "$2" ]; then
  ffmpeg -loglevel error -y -i "$1" -ac 1 -ar 44100 voice/p1.wav
  ffmpeg -loglevel error -y -i voice/p1.wav -ar 16000 voice/p1_16.wav
  cp voice/p1.wav app/public/voice.wav
else
  ffmpeg -loglevel error -y -i "$1" -ac 1 -ar 44100 voice/p1.wav
  ffmpeg -loglevel error -y -i "$2" -ac 1 -ar 44100 voice/p2.wav
  ffmpeg -loglevel error -y -i voice/p1.wav -ar 16000 voice/p1_16.wav
  ffmpeg -loglevel error -y -i voice/p2.wav -ar 16000 voice/p2_16.wav
  ffmpeg -loglevel error -y -i voice/p1.wav -f lavfi -t 0.5 -i anullsrc=r=44100:cl=mono -i voice/p2.wav -filter_complex "[0][1][2]concat=n=3:v=0:a=1" app/public/voice.wav
fi
echo "voice.wav built: $(ffprobe -v error -show_entries format=duration -of csv=p=0 app/public/voice.wav)s"
