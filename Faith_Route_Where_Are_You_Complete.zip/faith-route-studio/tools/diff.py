# python3 tools/diff.py  -> shows where the recording differs from script.txt. Edit script.txt to match, then align.
import json, re, difflib
raw = json.load(open('words_raw.json')); sc = open('script.txt').read()
n = lambda w: re.sub(r"[^a-z0-9]", "", w.lower().replace("’", "'").replace("'", ""))
st = [n(t) for t in sc.split()]; rt = [n(w['w']) for w in raw]
sm = difflib.SequenceMatcher(a=st, b=rt, autojunk=False)
print('match ratio', round(sm.ratio(), 3), len(st), len(rt))
for op, a1, a2, b1, b2 in sm.get_opcodes():
    if op != 'equal': print(f"{raw[min(b1, len(raw)-1)]['s']:7.1f}s {op:8} SCRIPT: {' '.join(st[a1:a2])[:90]}  |  SAID: {' '.join(rt[b1:b2])[:90]}")
