# python3 tools/paras.py  -> start time of every paragraph (use for planning scenes and YouTube chapters)
import json
w = json.load(open('app/src/words.json')); last = -1
for x in w:
    if x['p'] != last:
        last = x['p']; s = int(x['s'])
        print(f"{s//60}:{s%60:02d}  [{x['p']}]", ' '.join(y['t'] for y in w if y['p'] == x['p'])[:80])
