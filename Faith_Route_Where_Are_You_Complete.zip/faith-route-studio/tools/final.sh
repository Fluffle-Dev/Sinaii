#!/bin/bash
# bash tools/final.sh out_name.mp4   -> concat chunks (rNN wins over cNN), mux voice, write final video
set -e; cd chunks; : > list.txt
for c in $(ls c[0-9][0-9].mp4 | sort); do n=${c:1:2}; if [ -f r$n.mp4 ]; then echo "file '$PWD/r$n.mp4'" >> list.txt; else echo "file '$PWD/$c'" >> list.txt; fi; done
ffmpeg -loglevel error -y -f concat -safe 0 -i list.txt -c copy v.mp4
ffmpeg -loglevel error -y -i v.mp4 -i ../app/public/voice.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 256k -shortest "../$1"
echo "final: $1  $(ffprobe -v error -show_entries format=duration -of csv=p=0 ../$1)s"
