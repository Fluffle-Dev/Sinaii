import {JP, BP} from './kit';
export {JP};
export const PPL_ = (x: number, o: any = {}) => BP(x, {sc: 0.27, ...o});
