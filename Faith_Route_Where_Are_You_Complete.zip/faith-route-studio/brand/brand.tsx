import React from 'react';
import {AbsoluteFill, staticFile} from 'remotion';
import {Defs, Fig} from './fig';
import {JP, PPL_} from './brandkit';

const FONT = <style>{`@font-face{font-family:CinzelB;src:url(${staticFile('fonts/cinzel-latin-700-normal.woff2')}) format('woff2')}`}</style>;

export const Banner: React.FC = () => (
  <AbsoluteFill style={{background: 'radial-gradient(ellipse 60% 55% at 50% 50%, #5c3d17 0%, #2a1b0b 50%, #0d0905 100%)'}}>
    {FONT}
    <svg width={0} height={0} style={{position: 'absolute'}}><Defs /></svg>
    <svg width={2560} height={1440} viewBox="0 0 2560 1440" style={{position: 'absolute'}}>
      <defs>
        <linearGradient id="bm" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F3D9A0" stopOpacity="0.32" /><stop offset="1" stopColor="#F3D9A0" stopOpacity="0" /></linearGradient>
      </defs>
      <path d="M1180,0 L1380,0 L1560,1440 L1000,1440 Z" fill="url(#bm)" />
      {/* faint walking figures across the full width (decoration, outside the safe zone is fine) */}
      {[220, 420, 2140, 2340].map((x, i) => <Fig key={i} {...PPL_(x, {y: 900, sc: 0.2, flip: i < 2 ? false : true, o: 0.35})} />)}
      <line x1={420} y1={900} x2={2140} y2={900} stroke="#E3B465" strokeOpacity={0.25} strokeWidth={2} />
      <line x1={760} y1={580} x2={1800} y2={580} stroke="#E3B465" strokeOpacity={0.6} strokeWidth={2} />
      <line x1={760} y1={860} x2={1800} y2={860} stroke="#E3B465" strokeOpacity={0.6} strokeWidth={2} />
    </svg>
    <div style={{position: 'absolute', left: 0, right: 0, top: 640, textAlign: 'center', fontFamily: 'CinzelB', fontSize: 170, color: '#E9BE6E', letterSpacing: '0.12em', lineHeight: 1, textShadow: '0 6px 30px rgba(0,0,0,0.8)'}}>SUBSCRIBE</div>
  </AbsoluteFill>
);

export const Avatar: React.FC<{sc?: number; ex?: number; ey?: number}> = ({sc = 1.5, ex = 430, ey = 330}) => {
  const x = ex - 45 * sc, y = ey + 1405 * sc;
  return (
    <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 40%, #6b4719 0%, #2a1b0b 55%, #0d0905 100%)'}}>
      <svg width={0} height={0} style={{position: 'absolute'}}><Defs /></svg>
      <svg width={800} height={800} viewBox="0 0 800 800" style={{position: 'absolute'}}>
        <defs><linearGradient id="bm2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F3D9A0" stopOpacity="0.45" /><stop offset="1" stopColor="#F3D9A0" stopOpacity="0.05" /></linearGradient></defs>
        <path d="M300,0 L560,0 L640,800 L220,800 Z" fill="url(#bm2)" />
        <Fig {...JP(x, {y, sc, head: 0})} />
        <ellipse cx={ex} cy={ey} rx={11 * sc} ry={5.5 * sc} fill="#140e08" />
        <path d={`M${ex - 8 * sc},${ey} Q${ex},${ey - 3 * sc} ${ex + 8 * sc},${ey + 0.5 * sc}`} stroke="#E9BE6E" strokeWidth={2.2} fill="none" opacity={0.85} />
      </svg>
    </AbsoluteFill>
  );
};

export const HebAvatar: React.FC<{t: string; size?: number; dy?: number}> = ({t, size = 330, dy = 0}) => (
  <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 42%, #6b4719 0%, #2a1b0b 58%, #0d0905 100%)'}}>
    <style>{`@font-face{font-family:Heb;src:url(${staticFile('fonts/noto-serif-hebrew-hebrew-500-normal.woff2')}) format('woff2')}`}</style>
    <svg width={800} height={800} viewBox="0 0 800 800" style={{position: 'absolute'}}>
      <defs><linearGradient id="bm3" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F3D9A0" stopOpacity="0.35" /><stop offset="1" stopColor="#F3D9A0" stopOpacity="0.03" /></linearGradient></defs>
      <path d="M320,0 L480,0 L560,800 L240,800 Z" fill="url(#bm3)" />
    </svg>
    <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', direction: 'rtl', fontFamily: 'Heb', fontSize: size, color: '#E9BE6E', marginTop: dy, textShadow: '0 0 40px rgba(233,190,110,0.35), 0 8px 24px rgba(0,0,0,0.7)'}}>{t}</div>
  </AbsoluteFill>
);
