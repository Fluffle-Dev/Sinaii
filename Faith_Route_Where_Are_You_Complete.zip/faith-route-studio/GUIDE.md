# Faith Route Studio Guide

How the Faith Route "Why" videos are written, built, rendered and published. Hand this file and the project zip to any new chat and say: "Read GUIDE.md first."

---

## 1. The channel

- **Name:** Faith Route (keep it; do not rename to anything close to "Ink of Sinai").
- **Profile picture:** דֶּרֶךְ (derek, "the way"). Banner and profile options are in `brand/`.
- **Niche:** 8–15 minute 16:9 Bible explainers with "why" titles. They explain and encourage without being cheesy.
- **Competitor for reference only:** Ink of Sinai (gold silhouettes, warm dark backgrounds). Take inspiration, never copy titles or trace figures.

### Finished videos (in the old chat's outputs)
1. Why Shepherds Become Leaders (11:02)
2. Why Everyone Goes Through the Wilderness First (12:28)
3. Why John Wrote This Word 98 Times (15:30)
4. Why Jesus Cursed the Fig Tree (9:20)
5. The Family Curse in Genesis Most Christians Miss (11:21), thumbnail "SHE'S MY SISTER."
6. Every Covenant God Made, Explained in Order (14:38)
7. Why the Temple Curtain Tore from Top to Bottom (8:23)
8. Why Michael Fought the Devil Over Moses' Body (10:50)
9. Why the Devil Never Finished Psalm 91 (12:00), thumbnail "HE SKIPPED A VERSE."
10. Jezebel Eventually Killed Elijah, Well Kinda (11:37), thumbnail "BEHEAD HIM." / "SHE FINALLY GOT HIM."

### Posting plan
Psalm 91 → Jezebel → Temple Curtain → Michael → Covenants → then Fig Tree, Family Curse, John, Shepherds, Wilderness. Post 2–3 a week at the same time of day. Judge results after 5–6 uploads, not after one day.

### Next video idea
"The Bible Stories Your Pastor Skips (And Why They're There)": the siege of Samaria (2 Kings 6), Achan (Joshua 7), Dinah (Genesis 34), the Levite's concubine (Judges 19), plus Elisha's bears, Uzzah, and God nearly killing Moses (Exodus 4). The thread is Judges' "everyone did as they saw fit". The Bible records these stories without approving them, and every one points to the God who came Himself. Tell the sexual-violence stories plainly, never graphically (ad safety).

---

## 2. Working with the creator

- Never ask multiple-choice clarifying questions. Ask in plain words if truly needed, otherwise make the call.
- Keep non-script reply text as short as possible.
- When a video is finished, say what is in it in a few lines; no step recaps.

---

## 3. Script rules

- **Open with the title as a spoken question** ("Did Jezebel eventually kill Elijah?"), then a strong cold-open hook (Orca-style: drop the viewer into a scene). Never open with "Most people…".
- **NIV quotes only**, checked word for word against BibleGateway. Biblically accurate and researched; say plainly when something is an observation or tradition rather than Scripture (the creator likes a "walk with me" honesty line when the idea is his own reading).
- Call God **"God"** (never "Our God", never "the Christian God").
- **No AI tells:** no em dashes, colons or semicolons outside quotes; no "not X but Y"; no reflexive lists of three; no staccato fragment stacks.
- Explain, then encourage. Land on Jesus. Not cheesy.
- **Outro:** like, subscribe and share, then "And always remember, Jesus loves you." then "See you on the next one." Never mention the previous or next video.
- Length: about 1,900–2,100 words ≈ 11–12 min (he reads about 180–190 wpm).
- **Deliver pre-split into two code blocks** (Part 1, Part 2) so he can copy each in one click. He records in two parts because of a character limit.
- He often ad-libs a few lines while recording. Always diff the transcript against the script and make `script.txt` match what he actually said before aligning.

---

## 4. Visual style (non-negotiable)

- Gold silhouette figures with a thin rim, warm dark brown background, soft spotlight.
- **Metals:** gold = God's chosen, silver = kings and power, bronze = everyone else, shadow/ember = the devil.
- Mitten hands, no fingers. Arms rest **at the side** with a thin outline (default arm `[-5, -36]`), standing and walking.
- **Nothing that twinkles:** no dust, no grain.
- **No empty screens.** Something must be on screen from the first word of every beat.
- Text is large (Notes 46–50 px, Bigs 54–80 px).
- God's presence = a soft **vertical beam of light** (`Beam`), never round halos.
- **People first.** Show the characters doing the story; use objects and cards sparingly. No tacky gimmicks.
- **Period-accurate props:** scrolls (not books for ancient scenes), clay oil lamps, lamp stands, stone altars, sealed scroll letters, jars, bread.
- Fewer elements held longer; slow push-in on every scene (automatic in `Main.tsx`).
- Smooth motion: walk cycles (`walkX`/`WK`), eased gestures (`ezArm`), turns. Robe changes (stand↔seat/kneel) can't ease, so dissolve them.
- One **recurring device** per video that builds through it (Psalm 91 column, case file, covenant arch, split screen).
- Violence is implied, never shown (shadow at the door, a covered platter).

### Thumbnails
Competitor vibe: dark warm-gold background, 2–4 word bold Cinzel line on the left (first line ivory, second gold or ember), silhouettes in a light beam on the right. The text must not repeat the title. Render with `tools/thumb.sh`. Edit `app/src/thumb.tsx` for each video (`v` = text variant).

---

## 5. Project layout

```
faith-route-studio/
  GUIDE.md
  script.txt            the recorded script (example: Jezebel)
  brand/                banner, profile pictures
  tools/                setup, voice, transcribe, align, check, render, QA, thumbnail
  app/                  Remotion project
    src/
      Main.tsx          imports the two scene files for the current video
      Root.tsx          compositions: Main, Thumb
      words.json        word timings for the current recording
      lib.ts            at(), atEnd(), win, fi, fo, ramp, eio, eout, kf, lerp, rng, clamp, END
      fig.tsx           the rig: Fig, Cut, Line, Defs, metals, Throne, Table, Bed, Fire, Lion, Wolf, Sun, Moon, Sheep...
      kit.tsx           presets JP (Jesus) DP (gold) BP (bronze) SP (silver); F, Gp, pr, ez, ezArm, turn, walkX
      stage.tsx         Scene type, Spot, Ground, GY = 860
      text.tsx          HTML text: Note, Big, Ref, Name, Fonts
      props.tsx extra.tsx figprops.tsx famprops.tsx    general props (Scroll, Book, Stars, Tomb, CrossHill, Olive, Window, Mountain, River, Dove, Bread, Jar, Stones, Vine...)
      covprops.tsx      Beam, Card, Q (verse quote with *gold* key words), City, Arch, Rainbow...
      tcprops.tsx       Temple, Curtain, Ark, Lampstand, Incense, LifeTree, CherubFig...
      mmprops.tsx       Michael (winged), Devil, Dragon, Bush, Rock, Clouds, CaseFile...
      psprops.tsx       Pinnacle, LookDown, PsalmCol, Serpent, DotGrid, Shield, Legions, Qumran...
      jzprops.tsx       Palace, LampStand, ClayLamp, Pillar, Cave, StoneAltar, Cell, Chariot, Whirl, Cloak, Fortress, Platter, Letter, Coast, Split
      thumb.tsx         thumbnail composition
      scenes/           one pair of scene files per video. new1/new2 are the template.
                        jz1/jz2 (Jezebel) are the newest and best reference.
```

`Main.tsx` currently imports `scenes/jz1` and `scenes/jz2` with the matching `words.json`, so the project renders the Jezebel video out of the box. Old scene files are **reference only**: their `at()` anchors belong to old recordings, so never import them with a new `words.json`.

### Rig essentials
- Drawing space 600×1560, ground at y = 1545; figures stand on `GY = 860` on screen.
- `Fig` props: `x, y, m (metal), sc, flip, face, lit, o, hair ('cloth'|'long'|'cap'|'helmet'|'veil'|'bare'), beard ('none'|'short'|'long'), crown, prop ('crook'|'staff'|'spear'), mantle, robe ('stand'|'seat'|'kneel'|'stoop'|'short'), bench, head, bend, arm, arm2, reach, walk, wa, wide, tall, dim`.
- Cast helpers (in `scenes/jz1.tsx`, copy into new scenes): `ELI`/`JOHN` (gold prophet), `JEZ`/`HDIAS` (silver veiled crowned queen), `AHAB`/`HEROD` (silver king), `GIRL`, `PPL` (bronze crowd), `Night`, `WK` (walking figure), `Court` (palace set), `Wild` (wilderness set).
- `kf` keys: movement starts at the later key. `Sheep` takes `graze`/`lamb`, not `f`.

### Scene pattern
```tsx
{
  const a0 = at('first words of beat'), aB = at('words of sub beat'), aEnd = at('first words of next scene');
  push(a0, (f) => ({
    svg: <>
      <Gp o={win(f, a0, aB + 4)}> ...first picture... </Gp>
      <Gp o={fi(f, aB)}> ...second picture... </Gp>
    </>,
    html: <>
      <Note f={f} a={a0 + 6} b={aB} y={90} size={48}>short caption</Note>
      <Q f={f} a={aB} b={aEnd} refText="MARK 6:18" eng="“…*key words* …”" keys={[at('key words')]} y={50} />
    </>,
  }));
}
```
`at('phrase', nth)` matches normalised words (lowercase, punctuation and apostrophes removed). Use `nth` when a phrase repeats.

---

## 6. Pipeline for a new video

Run everything from `faith-route-studio/`.

1. **Setup (each fresh machine):** `bash tools/setup.sh`
2. **Script:** write it, deliver in two parts, save the final text as `script.txt`.
3. **Voice:** `bash tools/voice.sh part1.mp3 part2.mp3` (builds `app/public/voice.wav` with 0.5 s between parts).
4. **Transcribe:** `python3 tools/tr.py` → `words_raw.json`.
5. **Diff:** `python3 tools/diff.py`, then edit `script.txt` so it matches what he said (intro/outro often change).
6. **Align:** `python3 tools/align.py` → `app/src/words.json`. Then `python3 tools/paras.py` lists paragraph start times.
7. **Build scenes:** write any new props in a new `xxprops.tsx`, then `scenes/new1.tsx` + `new2.tsx` (rename freely), and point `Main.tsx` at them. Test new props first in a small test composition.
8. **Check anchors:** `python3 tools/chk.py app/src/scenes/new1.tsx app/src/scenes/new2.tsx` until `bad 0`.
9. **Stills:** `cd app && PFX=a node stills.mjs $(seq 60 300 <END>)`, then `python3 tools/sheet.py a sheet.jpg 0` (and 12, 24...). Look at every sheet. Fix empty areas, overlaps, text over figures, figures off screen.
10. **Render:** `nohup bash tools/render.sh > render.log 2>&1 &`, poll `grep -E "done|ALLDONE|rror" render.log`. About 6–9 min per 1800-frame chunk on 2 CPUs. Set `BACKUP=/some/folder` to copy chunks somewhere safe.
11. **Assemble:** `bash tools/final.sh video_name.mp4`.
12. **QA:** `python3 tools/qa.py video_name.mp4`. Any `EMPTY` or `POP` must be fixed (the last-second fade is fine). Fix the scene, `bash tools/rerender.sh <chunk numbers>` (chunk = frame // 1800), then `final.sh` again (rNN replaces cNN automatically).
13. **Publish kit:** thumbnail (`tools/thumb.sh`), title, description with chapters (from `paras.py`), tags.

---

## 7. Known gotchas

- A perfectly horizontal or vertical `Line` with the default gradient stroke renders blank (zero-size bounding box). Pass a solid colour, e.g. `c="#E3B465"`, or use `u`.
- Filters on zero-width/height paths are invisible: use the `Line u` prop.
- **Brightness dip/pop:** if two cross-fading `Gp` windows each draw their own full-screen background, the frame dips mid-fade. Draw the shared background once in its own `Gp`, or fade the incoming group in fully *before* the outgoing one fades out (`fi(f, t - 16, 16)` placed underneath), and cross-fade only the foreground.
- Old scene files must not be imported with a new `words.json` (missing anchors crash the render).
- Duplicate anchor phrases: pass `nth`.
- Don't `rm` globs in working folders (blocked by the sandbox); overwrite or use new filename prefixes.
- The shell's working directory may reset; use absolute paths or `cd` each time.
- Containers get replaced: keep source and finished chunks backed up to the outputs folder as you go.
- whisper: feed it a numpy array from `scipy.io.wavfile` (decoding through av can fail); `vad_filter=False`.
- When one caption replaces another in the same spot they overlap for about half a second during the cross-fade (known, accepted).

---

## 8. Stack

Remotion 4.0.380, React 18.3.1, TypeScript 5.6.3, fonts from @fontsource (Cinzel 500/700, Cormorant Garamond italic, Noto Serif Hebrew, Noto Serif Greek). Rendered with headless Chromium using `--gl=swangle`, 1920×1080, 30 fps, h264 CRF 15. If the Chromium path differs on a new machine, set `BROWSER=/path/to/chrome-headless-shell`.

## 9. Expressive character motion

Open the **Handoff** composition for a 13-second example of two people passing a water jar. From the project root, use:

```sh
cd app
npm ci
npx remotion studio src/index.ts
# Render this composition directly.
npx remotion render src/index.ts Handoff handoff.mp4
```

For new scenes, use the shared figure entry point `<Fig acting={pose}/>`. See `app/src/acting.tsx` for the pose type and `app/src/handoff.tsx` for a complete example. Legacy figure poses still use the existing props. The sample has its own sound file in `app/public/handoff.wav`.

- Set `x`, `floor`, `scale` and `facing` for each performer. The sample uses a 960 by 540 drawing space at 1920 by 1080 output. Feet use absolute stage x and vertical displacement from the floor. A foot in contact with the ground has a displacement of zero.
- Use `plantedWalk(frame, from, to, start, end, steps)` to place the feet for an approach. Use a positive integer step count. `kneel` ranges from 0 standing to 1 fully lowered. A brief backward step gives the robe and knee room to settle.
- The `look` control adjusts foreshortening and the far shoulder as the head turns toward its full profile. `nod` rotates the head independently. `lean` and `shoulder` shift the upper body horizontally in facing-local drawing units. The mantle and veil are starting presets. The acting rig now uses the original studio face, beard, hair, sleeve, robe and shoe paths. Set the optional costume override to use another studio hairstyle, beard, crown or mantle. All four metals are available.
- Give each hand a stage contact point and a wrist angle in facing-local degrees. The arm bends to reach it. Keep contacts within reach. For exchanges, compute the prop position once per frame and derive each grip from it. Give both people a few frames of shared contact before the giver lets go.
- For a quiet exchange, frame the approach wide and settle the camera before contact. Let the hands and the listener's response carry the close shot.


### Character lighting

Use the original `Defs` once at the scene root. Both static and acting figures share the same `Cut` silhouette filter. The studio offset masks produce a broad directional rim, a narrow hot core and a dim hairline on the opposite contour. This also keeps seams inside the robe quiet. On an acting pose, `lightSide: 1` lights the right contour in screen space and `-1` lights the left, independently of which way the figure faces. In a 1920-wide scene set `stageWidth: 1920`; the Handoff example uses a 960-wide viewBox. Choose the light side according to the scene lighting and keep it stable through an action.
