// node stills.mjs 60 360 660 ...   ->  ../stills/<PFX><frame>.jpg at half size
// env: PFX (file prefix, default f), COMP (composition id, default Main), BROWSER (chrome path)
import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import path from 'path'; import fs from 'fs';
const frames = process.argv.slice(2).map(Number);
const out = path.resolve('../stills'); fs.mkdirSync(out, {recursive: true});
const serveUrl = await bundle({entryPoint: path.resolve('src/index.ts')});
const browserExecutable = process.env.BROWSER || '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const composition = await selectComposition({serveUrl, id: process.env.COMP || 'Main', browserExecutable});
for (const fr of frames) {
  await renderStill({composition, serveUrl, frame: fr, output: `${out}/${process.env.PFX || 'f'}${String(fr).padStart(5, '0')}.jpg`, imageFormat: 'jpeg', jpegQuality: 85, scale: 0.5, browserExecutable, chromiumOptions: {gl: 'swangle'}});
}
console.log('stills ok');
