import React from 'react';
import {Fig, FigP, Line, Cut, TXT} from './fig';
import {win, fi, ramp, eio, eout, rng, clamp} from './lib';
import {GY} from './stage';

const G = (x: number, y: number, s = 1) => `translate(${x} ${y}) scale(${s})`;

/* ---------- embroidered cherub (line art), facing right, origin at feet ---------- */
const CHERUB_D = [
  'M-30,0 L-22,-196 C-20,-226 20,-226 22,-196 L30,0 Z',
  'M8,-196 C60,-300 150,-380 250,-404 C214,-360 186,-322 166,-282 C130,-246 70,-216 8,-196 Z',
  'M60,-262 L150,-330 M90,-238 L176,-292 M40,-230 L120,-268',
  'M-8,-196 C-60,-276 -112,-330 -160,-344 C-124,-300 -84,-248 -8,-196 Z',
  'M14,-150 C40,-140 60,-120 70,-100',
  'M-22,-60 L22,-60 M-26,-120 L26,-120',
];
export const CherubArt: React.FC<{x: number; y: number; s?: number; flip?: boolean; o?: number; p?: number; w?: number; c?: string; plain?: boolean}> = ({x, y, s = 1, flip = false, o = 1, p = 1, w = 3, c, plain = false}) => (
  <g opacity={o} transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
    {CHERUB_D.map((d, i) => plain ? <path key={i} d={d} fill="none" stroke={c || '#E2B568'} strokeWidth={(w + 0.6) / s} opacity={i === 2 || i >= 4 ? 0.7 : 1} strokeLinejoin="round" /> : <Line key={i} d={d} w={w / s} p={p} c={c} o={i === 2 || i >= 4 ? 0.7 : 1} />)}
    <circle cx={0} cy={-250} r={26} fill="none" stroke={c || 'url(#goldLine)'} strokeWidth={w / s} opacity={p > 0.6 ? 1 : 0} />
  </g>
);

/* ---------- the curtain ---------- */
export type CurtainP = {
  id: string; f: number; x?: number; top?: number; bottom?: number; w?: number;
  /** tear tip progress 0..1 (top to bottom) */ tear?: number;
  /** how wide the torn halves pull apart 0..1 */ open?: number;
  /** extra uniform parting 0..1 (halves slide apart) */ part?: number;
  cher?: number; stars?: number; light?: number; o?: number; draw?: number; motif?: number;
};
export const Curtain: React.FC<CurtainP> = ({id, f, x = 960, top = 300, bottom = GY, w = 640, tear = 0, open = 0, part = 0, cher = 1, stars = 0, light = 1, o = 1, draw = 1, motif = 1}) => {
  if (o <= 0.001) return null;
  const H = bottom - top, L = x - w / 2, R = x + w / 2;
  const r = rng(7);
  const seam: [number, number][] = [];
  for (let y = top; y <= bottom + 0.1; y += H / 26) seam.push([x + (y === top || y >= bottom - 1 ? 0 : (r() - 0.5) * 16), y]);
  const yt = top + clamp(tear) * H;
  const G2 = (open * 270 + 4) * (tear > 0 ? 1 : 0);
  const PT = part * 520;
  const NS = 56;
  const seamD = seam.map(([sx, sy]) => `L${sx},${sy}`).join(' ');
  const leftPoly = `M${L - 400},${top - 50} L${seam[0][0]},${top - 50} ${seamD} L${seam[seam.length - 1][0]},${bottom + 50} L${L - 400},${bottom + 50} Z`;
  const rightPoly = `M${R + 400},${top - 50} L${seam[0][0]},${top - 50} ${seamD} L${seam[seam.length - 1][0]},${bottom + 50} L${R + 400},${bottom + 50} Z`;
  const sway = Math.sin(f / 40) * 0.6;
  // cloth content (unclipped)
  const folds = Array.from({length: 13}, (_, i) => L + (i + 0.5) * (w / 13));
  const mk = (plain: boolean) => (
    <g>
      <rect x={L} y={top} width={w} height={H} fill={`url(#${id}cl)`} />
      {folds.map((fx, i) => <rect key={i} x={fx - w / 52} y={top} width={w / 26} height={H} fill="#000" opacity={0.18} />)}
      {[0, 1, 2].map((k) => <rect key={'b' + k} x={L} y={top + 40 + k * 26} width={w} height={14} fill={['#1f3046', '#3a1d3e', '#5a1c14'][k]} opacity={0.7} />)}
      {[0, 1, 2].map((k) => <rect key={'c' + k} x={L} y={bottom - 120 + k * 26} width={w} height={14} fill={['#5a1c14', '#3a1d3e', '#1f3046'][k]} opacity={0.7} />)}
      {stars > 0 ? <g opacity={stars}>{Array.from({length: 46}, (_, i) => { const rr = rng(100 + i); const sx = L + 30 + rr() * (w - 60), sy = top + 130 + rr() * (H - 300); return <circle key={i} cx={sx} cy={sy} r={1.5 + rr() * 2.2} fill="#F1D9A4" opacity={0.75} />; })}</g> : null}
      <g opacity={cher * motif}>
        <CherubArt x={x - w * 0.22} y={top + H * 0.74} s={(H / 750) * 0.95} p={draw} plain={plain} />
        <CherubArt x={x + w * 0.22} y={top + H * 0.74} s={(H / 750) * 0.95} flip p={draw} plain={plain} />
      </g>
      <Line d={`M${L},${top} L${L},${bottom} M${R},${top} L${R},${bottom}`} w={2.6} p={draw} />
      <Line u w={2} d={`M${L},${top + 34} L${R},${top + 34} M${L},${bottom - 6} L${R},${bottom - 6}`} c="#C99A4A" o={0.8 * draw} />
    </g>
  );
  const cloth = mk(false), clothP = mk(true);
  return (
    <g opacity={o}>
      <defs>
        <linearGradient id={`${id}cl`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#3b1612" />
          <stop offset="0.55" stopColor="#2c1210" />
          <stop offset="1" stopColor="#1a0c09" />
        </linearGradient>
        <clipPath id={`${id}L`}><path d={leftPoly} /></clipPath>
        <clipPath id={`${id}R`}><path d={rightPoly} /></clipPath>
        <clipPath id={`${id}U`}><rect x={L - 900} y={top - 60} width={w + 1800} height={yt - top + 60} /></clipPath>
        <clipPath id={`${id}D`}><rect x={L - 900} y={yt} width={w + 1800} height={bottom - yt + 60} /></clipPath>
      </defs>
      {/* light behind */}
      <g opacity={light}>
        <rect x={x - 340} y={top} width={680} height={H} fill="url(#halo)" opacity={1} />
        <path d={`M${x - 70},${top} L${x + 70},${top} L${x + 200},${bottom} L${x - 200},${bottom} Z`} fill="#FFE7B0" opacity={0.55 * clamp(open + part + tear * 0.3)} filter="url(#soft)" />
        <path d={`M${x - 24},${top} L${x + 24},${top} L${x + 70},${bottom} L${x - 70},${bottom} Z`} fill="#FFF5DC" opacity={0.7 * clamp(open + part)} filter="url(#soft)" />
      </g>
      <g transform={`rotate(${sway} ${x} ${top})`}>
        {/* below the tear tip: whole cloth */}
        <g clipPath={`url(#${id}D)`}>{cloth}</g>
        {/* above the tip: two halves leaning apart */}
        {tear > 0 ? <>
          {Array.from({length: NS}, (_, k) => {
            const ya = top + ((yt - top) * k) / NS - 1, yb = top + ((yt - top) * (k + 1)) / NS + 1;
            if (yb <= ya + 1.5) return null;
            const ym = (ya + yb) / 2;
            const g = G2 * clamp((yt - ym) / Math.max(1, yt - top)) ;
            const sxL = Math.max(0.05, (x - L - g) / (x - L)), sxR = Math.max(0.05, (R - x - g) / (R - x));
            const cid = `${id}s${k}`;
            return (
              <g key={k}>
                <defs><clipPath id={cid}><rect x={L - 900} y={k === 0 ? top - 60 : ya} width={w + 1800} height={yb - (k === 0 ? top - 60 : ya)} /></clipPath></defs>
                <g clipPath={`url(#${cid})`}>
                  <g transform={`translate(${-PT} 0) translate(${L} 0) scale(${sxL} 1) translate(${-L} 0)`}><g clipPath={`url(#${id}L)`}>{clothP}</g></g>
                  <g transform={`translate(${PT} 0) translate(${R} 0) scale(${sxR} 1) translate(${-R} 0)`}><g clipPath={`url(#${id}R)`}>{clothP}</g></g>
                </g>
              </g>
            );
          })}
          <circle cx={x} cy={yt} r={70} fill="url(#halo)" opacity={tear < 1 ? 1 : 0} />
          <circle cx={x} cy={yt} r={10} fill="#FFF0C8" opacity={tear < 1 ? 0.9 : 0} filter="url(#soft3)" />
        </> : <g clipPath={`url(#${id}U)`}>{cloth}</g>}
        {/* rod with rings */}
        <rect x={L - 50} y={top - 14} width={w + 100} height={12} rx={6} fill="#0c0905" />
        <Line u w={2.4} d={`M${L - 50},${top - 14} L${R + 50},${top - 14}`} c="#E3B465" p={draw} />
        {Array.from({length: 12}, (_, i) => <circle key={i} cx={L + 20 + (i * (w - 40)) / 11} cy={top - 4} r={9} fill="none" stroke="#C99A4A" strokeWidth={2} opacity={draw} />)}
      </g>
    </g>
  );
};

/* ---------- ark of the covenant (side view), x = centre, y = ground ---------- */
export const Ark: React.FC<{x: number; y: number; s?: number; o?: number; glow?: number}> = ({x, y, s = 1, o = 1, glow = 0}) => (
  <g opacity={o}>
    {glow > 0 ? <ellipse cx={x} cy={y - 200 * s} rx={300 * s} ry={240 * s} fill="url(#halo)" opacity={glow} /> : null}
    <Cut m="gold" lit={1} tf={G(x, y, s)}>
      <path d="M-150,-20 L-150,-150 L150,-150 L150,-20 Z M-140,-20 L-136,0 L-118,0 L-120,-20 Z M120,-20 L118,0 L136,0 L140,-20 Z M-160,-160 L160,-160 L160,-150 L-160,-150 Z M-190,-96 L190,-96 L190,-84 L-190,-84 Z" />
      <path d="M-120,-160 C-120,-200 -100,-214 -84,-214 L-72,-232 C-60,-250 -40,-250 -36,-230 C-60,-226 -60,-200 -40,-190 C-20,-200 0,-260 -6,-300 C-40,-290 -80,-260 -96,-226 Z" />
      <path d="M120,-160 C120,-200 100,-214 84,-214 L72,-232 C60,-250 40,-250 36,-230 C60,-226 60,-200 40,-190 C20,-200 0,-260 6,-300 C40,-290 80,-260 96,-226 Z" />
    </Cut>
    <Line u w={1.6} c="#E3B465" o={0.6} d={`M${x - 130 * s},${y - 130 * s} L${x + 130 * s},${y - 130 * s} M${x - 130 * s},${y - 40 * s} L${x + 130 * s},${y - 40 * s}`} />
  </g>
);

/* ---------- lampstand (menorah) ---------- */
export const Lampstand: React.FC<{x: number; y: number; s?: number; o?: number; f?: number}> = ({x, y, s = 1, o = 1, f = 0}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <Line w={3 / s} d="M0,0 L0,-260 M-60,0 L60,0 M0,-120 C-30,-120 -60,-150 -60,-200 L-60,-260 M0,-120 C30,-120 60,-150 60,-200 L60,-260 M0,-80 C-60,-80 -110,-130 -110,-200 L-110,-260 M0,-80 C60,-80 110,-130 110,-200 L110,-260 M0,-40 C-90,-40 -160,-110 -160,-200 L-160,-260 M0,-40 C90,-40 160,-110 160,-200 L160,-260" />
    {[-160, -110, -60, 0, 60, 110, 160].map((lx, i) => <path key={i} d={`M${lx - 7},-262 C${lx - 8},-276 ${lx},-286 ${lx + Math.sin(f / 7 + i) * 2},-296 C${lx + 6},-284 ${lx + 8},-274 ${lx + 7},-262 Z`} fill="#F6C46E" filter="url(#lglow)" />)}
  </g>
);

/* ---------- incense cloud ---------- */
export const Incense: React.FC<{x: number; y: number; f: number; amt: number; w?: number}> = ({x, y, f, amt, w = 520}) => {
  if (amt <= 0.001) return null;
  return (
    <g opacity={amt}>
      {Array.from({length: 9}, (_, i) => {
        const rr = rng(300 + i);
        const cx = x + (rr() - 0.5) * w + Math.sin(f / 70 + i) * 24, cy = y - rr() * 300 - Math.cos(f / 80 + i) * 16;
        return <ellipse key={i} cx={cx} cy={cy} rx={120 + rr() * 90} ry={60 + rr() * 40} fill="#B9A588" opacity={0.18} filter="url(#soft)" />;
      })}
    </g>
  );
};

/* ---------- cherub figure (winged guardian standing) ---------- */
export const CherubFig: React.FC<{x: number; y?: number; s?: number; flip?: boolean; o?: number; f?: number}> = ({x, y = GY, s = 0.32, flip = false, o = 1, f = 0}) => {
  const k = flip ? -1 : 1;
  const wv = Math.sin(f / 30) * 2;
  return (
    <g opacity={o}>
      <Cut m="gold" lit={k} tf={`translate(${x} ${y}) scale(${k * s} ${s})`}>
        <path d="M-40,-1090 C-130,-1250 -290,-1390 -470,-1450 C-450,-1372 -412,-1316 -372,-1278 C-412,-1270 -440,-1250 -458,-1222 C-400,-1192 -350,-1174 -310,-1164 C-338,-1142 -356,-1114 -364,-1086 C-286,-1064 -186,-1044 -70,-1000 Z" />
        <path d="M40,-1090 C130,-1250 290,-1390 470,-1450 C450,-1372 412,-1316 372,-1278 C412,-1270 440,-1250 458,-1222 C400,-1192 350,-1174 310,-1164 C338,-1142 356,-1114 364,-1086 C286,-1064 186,-1044 70,-1000 Z" />
      </Cut>
      <Fig x={x} y={y} sc={s} m="gold" hair="bare" beard="none" face={k} arm={[-40, -60]} />
    </g>
  );
};

/* ---------- flaming sword, swinging ---------- */
export const FlameSword: React.FC<{x: number; y: number; f: number; s?: number; o?: number; amp?: number}> = ({x, y, f, s = 1, o = 1, amp = 28}) => {
  const a = Math.sin(f / 14) * amp;
  return (
    <g opacity={o} transform={`translate(${x} ${y}) rotate(${a}) scale(${s})`}>
      <ellipse cx={0} cy={-170} rx={90} ry={220} fill="url(#halo)" opacity={0.9} />
      <path d={`M-10,-20 C-30,-120 -20,-240 ${Math.sin(f / 4) * 8},-360 C24,-250 30,-120 10,-20 Z`} fill="#F6C46E" opacity={0.85} filter="url(#lglow)" />
      <Line w={3.4 / s} d="M0,-20 L0,-330 M-36,-20 L36,-20" c="#FFF0C8" />
      <Line w={3 / s} d="M0,-20 L0,30" c="#C99A4A" />
    </g>
  );
};

/* ---------- glowing tree (tree of life) ---------- */
export const LifeTree: React.FC<{x: number; y: number; s?: number; o?: number; p?: number; glow?: number}> = ({x, y, s = 1, o = 1, p = 1, glow = 1}) => {
  const rr = rng(77);
  const leaves = Array.from({length: 26}, () => [(rr() - 0.5) * 380, -300 - rr() * 260, 30 + rr() * 34]);
  return (
    <g opacity={o} transform={G(x, y, s)}>
      <ellipse cx={0} cy={-420} rx={320} ry={260} fill="url(#halo)" opacity={glow} />
      <Line w={3.2 / s} p={p} d="M-20,0 C-14,-120 -18,-220 0,-320 M10,0 C14,-120 20,-220 0,-320 M0,-260 C-60,-300 -120,-330 -170,-380 M0,-300 C60,-330 120,-360 160,-420 M0,-320 C-10,-380 10,-440 0,-520" />
      {leaves.map(([lx, ly, r], i) => (
        <g key={i} opacity={eout(clamp(p * 1.6 - i / 40))}>
          <ellipse cx={lx} cy={ly} rx={r} ry={r * 0.7} fill="#120d07" />
          <ellipse cx={lx} cy={ly} rx={r} ry={r * 0.7} fill="none" stroke="url(#goldLine)" strokeWidth={2 / s} />
          {i % 4 === 0 ? <circle cx={lx + 6} cy={ly + 6} r={7} fill="#F6C46E" opacity={glow} filter="url(#lglow)" /> : null}
        </g>
      ))}
    </g>
  );
};

/* ---------- Herod's temple facade (line art), x = centre, y = ground ---------- */
export const Temple: React.FC<{x: number; y: number; s?: number; o?: number; p?: number; door?: number}> = ({x, y, s = 1, o = 1, p = 1, door = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <rect x={-360} y={-560} width={720} height={500} fill="#0e0a06" opacity={0.92} />
    <rect x={-110} y={-470} width={220} height={410} fill="#2c1210" opacity={door} />
    {[0, 1, 2].map((k) => <rect key={k} x={-110} y={-440 + k * 20} width={220} height={10} fill={['#1f3046', '#3a1d3e', '#5a1c14'][k]} opacity={0.7 * door} />)}
    <Line w={2.6 / s} p={p} d="M-420,0 L420,0 M-400,-20 L400,-20 M-380,-40 L380,-40 M-360,-60 L-360,-560 L360,-560 L360,-60 M-390,-560 L390,-560 M-390,-590 L390,-590 L390,-560 M-390,-590 L-390,-560 M-110,-60 L-110,-470 L110,-470 L110,-60 M-300,-100 L-300,-500 M-220,-100 L-220,-500 M220,-100 L220,-500 M300,-100 L300,-500 M-360,-520 L360,-520" />
    <Line w={1.6 / s} p={p} o={0.6} d="M-60,-470 L-60,-60 M0,-470 L0,-60 M60,-470 L60,-60" c="#C99A4A" />
  </g>
);

/* ---------- 365 day calendar of dots, one lit ---------- */
export const YearDots: React.FC<{f: number; a: number; b?: number; x?: number; y?: number; lit?: number; hl?: number}> = ({f, a, b, x = 960, y = 560, lit = 0, hl = 190}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const cols = 37, gap = 26;
  return (
    <g opacity={o}>
      {Array.from({length: 365}, (_, i) => {
        const cx = x + ((i % cols) - (cols - 1) / 2) * gap, cy = y + (Math.floor(i / cols) - 4.5) * gap;
        const on = i === hl;
        const ap = fi(f, a + (i % cols) * 0.6 + Math.floor(i / cols) * 2, 10);
        return on ? (
          <g key={i}><circle cx={cx} cy={cy} r={60} fill="url(#halo)" opacity={lit} /><circle cx={cx} cy={cy} r={9} fill="#FFE2A0" opacity={ap} filter="url(#lglow)" /></g>
        ) : <circle key={i} cx={cx} cy={cy} r={5} fill="#7A6040" opacity={ap * (1 - 0.5 * lit)} />;
      })}
    </g>
  );
};

/* ---------- tabernacle floor plan (top-down), east to the right ---------- */
export const Plan: React.FC<{f: number; p?: number; o?: number; hl?: 'mhp' | 'hp' | 'court' | null; walker?: number; curtainGlow?: number; torn?: number; items?: number; labels?: number; eden?: number}> = ({f, p = 1, o = 1, hl = null, walker = -1, curtainGlow = 0, torn = 0, items = 1, labels = 1, eden = 0}) => {
  if (o <= 0.001) return null;
  const cx0 = 300, cx1 = 1500, cy0 = 380, cy1 = 820;
  const t0 = 420, t1 = 940, ty0 = 500, ty1 = 700, cur = 580;
  const lab = (x: number, y: number, t: string, s = 28, c = TXT.ivory, k = 0) => <text x={x} y={y} textAnchor="middle" fill={c} fontFamily="Cinzel" fontSize={s} letterSpacing={3} opacity={labels * fi(f, 0, 1) * (k ? k : 1)}>{t}</text>;
  const wx = walker >= 0 ? 1560 - walker * (1560 - cur - 30) : -999;
  return (
    <g opacity={o}>
      {hl === 'mhp' ? <rect x={t0} y={ty0} width={cur - t0} height={ty1 - ty0} fill="#C99A4A" opacity={0.18} /> : null}
      {hl === 'hp' ? <rect x={cur} y={ty0} width={t1 - cur} height={ty1 - ty0} fill="#C99A4A" opacity={0.14} /> : null}
      <path d={`M${cx1},${cy0} L${cx0},${cy0} L${cx0},${cy1} L${cx1},${cy1} L${cx1},${660} M${cx1},${540} L${cx1},${cy0}`} fill="none" stroke="url(#goldLine)" strokeWidth={2.4} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - p} filter="url(#lglow)" />
      <rect x={t0} y={ty0} width={t1 - t0} height={ty1 - ty0} fill="#0e0a06" stroke="url(#goldLine)" strokeWidth={2.6} opacity={eout(clamp(p * 1.4 - 0.2))} />
      {/* the curtain line */}
      <g opacity={eout(clamp(p * 1.4 - 0.3))}>
        <rect x={cur - 6} y={ty0 - 30} width={12} height={(ty1 - ty0) + 60} fill="#FFE2A0" opacity={0.35 * curtainGlow} filter="url(#soft)" />
        {torn > 0 ? <>
          <rect x={cur - 3} y={ty0} width={6} height={(ty1 - ty0) / 2 - 60 * torn} fill="#E8B455" />
          <rect x={cur - 3} y={ty0 + (ty1 - ty0) / 2 + 60 * torn} width={6} height={(ty1 - ty0) / 2 - 60 * torn} fill="#E8B455" />
        </> : <rect x={cur - 3} y={ty0} width={6} height={ty1 - ty0} fill="#E8B455" />}
      </g>
      {/* furniture */}
      <g opacity={items * eout(clamp(p * 1.4 - 0.4))}>
        <rect x={485} y={575} width={50} height={50} fill="none" stroke="#F1CD86" strokeWidth={2.4} />
        <circle cx={510} cy={600} r={60} fill="url(#halo)" opacity={0.8} />
        <rect x={610} y={588} width={22} height={24} fill="none" stroke="#C99A4A" strokeWidth={2} />
        <path d="M720,520 L720,548 M706,534 L734,534" stroke="#C99A4A" strokeWidth={2} />
        <rect x={700} y={660} width={60} height={26} fill="none" stroke="#C99A4A" strokeWidth={2} />
        <circle cx={1110} cy={600} r={22} fill="none" stroke="#C99A4A" strokeWidth={2} />
        <rect x={1250} y={570} width={60} height={60} fill="none" stroke="#C99A4A" strokeWidth={2} />
      </g>
      {lab(500, ty0 - 18, 'MOST HOLY', 26, TXT.gold)}
      {lab(760, ty0 - 18, 'HOLY PLACE', 26)}
      {lab(1280, cy0 + 50, 'COURTYARD', 26)}
      {lab(1280, 690, 'ALTAR', 22, TXT.gold, 0.8)}
      {lab(1110, 660, 'BASIN', 22, TXT.gold, 0.8)}
      {lab(cur, ty1 + 44, 'THE CURTAIN', 30, TXT.gold)}
      <g opacity={labels}>
        <Line u w={2.4} c="#E3B465" d={`M1560,600 L1700,600 M1680,586 L1700,600 L1680,614`} />
        <text x={1730} y={610} fill={TXT.gold} fontFamily="Cinzel" fontSize={30} letterSpacing={3}>E</text>
        <text x={1620} y={640} textAnchor="middle" fill={TXT.ivory} fontFamily="Cinzel" fontSize={22} letterSpacing={3}>ENTRANCE</text>
      </g>
      {walker >= 0 ? <g><circle cx={wx} cy={600} r={34} fill="url(#halo)" /><circle cx={wx} cy={600} r={9} fill="#FFE2A0" filter="url(#lglow)" /></g> : null}
      {eden > 0 ? <g opacity={eden}>{lab(150, 470, 'EDEN', 34, TXT.gold)}{lab(150, 510, 'GATE · EAST', 20, TXT.ivory)}</g> : null}
    </g>
  );
};

/* ---------- torn sky: ragged horizontal opening with light, t = open ---------- */
export const SkyTear: React.FC<{x: number; y: number; w?: number; t: number; o?: number}> = ({x, y, w = 700, t, o = 1}) => {
  if (o <= 0.001 || t <= 0) return null;
  const r = rng(19);
  const n = 20;
  const pts = Array.from({length: n + 1}, (_, i) => [x - w / 2 + (i * w) / n, (r() - 0.5) * 12]);
  const env = (i: number) => Math.sin((i / n) * Math.PI);
  const up = pts.map(([px, py], i) => `${px},${y + py - 34 * t * env(i)}`).join(' L');
  const dn = pts.slice().reverse().map(([px, py], j) => { const i = n - j; return `${px},${y + py * 0.6 + 30 * t * env(i)}`; }).join(' L');
  return (
    <g opacity={o}>
      <path d={`M${x - 200 * t},${y} L${x + 200 * t},${y} L${x + 330 * t},${GY} L${x - 330 * t},${GY} Z`} fill="#FFE7B0" opacity={0.28 * t} filter="url(#soft)" />
      <ellipse cx={x} cy={y} rx={w * 0.6} ry={120 * t} fill="url(#halo)" opacity={1} />
      <path d={`M${up} L${dn} Z`} fill="#FFF3D6" opacity={0.9} filter="url(#soft3)" />
    </g>
  );
};

/* ---------- flames along a base (temple burning) ---------- */
export const Flames: React.FC<{x0: number; x1: number; y: number; f: number; h?: number; o?: number}> = ({x0, x1, y, f, h = 160, o = 1}) => {
  if (o <= 0.001) return null;
  const n = Math.round((x1 - x0) / 60);
  return (
    <g opacity={o}>
      <rect x={x0 - 60} y={y - h * 1.6} width={x1 - x0 + 120} height={h * 1.8} fill="url(#halo)" opacity={0.9} />
      {Array.from({length: n}, (_, i) => {
        const fx = x0 + (i + 0.5) * ((x1 - x0) / n), hh = h * (0.6 + 0.4 * Math.abs(Math.sin(i * 1.7))) * (0.9 + 0.1 * Math.sin(f / 6 + i));
        return <path key={i} d={`M${fx - 26},${y} C${fx - 34},${y - hh * 0.5} ${fx - 10},${y - hh * 0.7} ${fx + Math.sin(f / 8 + i) * 8},${y - hh} C${fx + 16},${y - hh * 0.65} ${fx + 34},${y - hh * 0.45} ${fx + 26},${y} Z`} fill={i % 2 ? '#F6C46E' : '#E39A4A'} opacity={0.75} filter="url(#lglow)" />;
      })}
    </g>
  );
};
