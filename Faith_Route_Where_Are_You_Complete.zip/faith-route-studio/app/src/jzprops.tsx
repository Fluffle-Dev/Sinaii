import React from 'react';
import {Line, Cut, Fire, TXT} from './fig';
import {fi, ramp, eio, rng, clamp} from './lib';

const G = (x: number, y: number, s = 1) => `translate(${x} ${y}) scale(${s})`;

/* ============ palace hall: columns, a raised dais, hanging cloth, standing lamps ============ */
export const Palace: React.FC<{o?: number; p?: number; x0?: number; x1?: number; y?: number; f?: number; lamps?: number}> = ({o = 1, p = 1, x0 = 120, x1 = 1800, y = 860, f = 0, lamps = 1}) => {
  if (o <= 0.001) return null;
  let cols = `M${x0 - 40},${y - 640} L${x1 + 40},${y - 640} M${x0 - 40},${y - 660} L${x1 + 40},${y - 660}`;
  const n = 7;
  for (let i = 0; i < n; i++) {
    const cx = x0 + ((x1 - x0) * i) / (n - 1);
    cols += ` M${cx - 26},${y} L${cx - 26},${y - 640} M${cx + 26},${y} L${cx + 26},${y - 640} M${cx - 40},${y - 640} L${cx + 40},${y - 640} M${cx - 38},${y} L${cx + 38},${y} M${cx - 40},${y - 620} L${cx + 40},${y - 620}`;
  }
  return (
    <g opacity={o}>
      <Line w={1.8} p={p} o={0.55} d={cols} />
      {/* draped cloth between columns */}
      <Line w={1.4} p={p} o={0.35} d={`M${x0},${y - 600} Q${(x0 * 2 + x1) / 3 - 140},${y - 520} ${(x0 * 2 + x1) / 3},${y - 600} M${(x0 + x1 * 2) / 3},${y - 600} Q${(x0 + x1 * 2) / 3 + 140},${y - 520} ${x1},${y - 600}`} />
      {lamps > 0 ? [x0 + 140, x1 - 140].map((lx, i) => <LampStand key={i} x={lx} y={y} f={f + i * 17} o={lamps} />) : null}
    </g>
  );
};

/* ============ tall lamp stand with a small clay lamp ============ */
export const LampStand: React.FC<{x: number; y: number; f?: number; o?: number; h?: number}> = ({x, y, f = 0, o = 1, h = 330}) => {
  const sw = Math.sin(f / 9) * 1.5;
  return (
    <g opacity={o}>
      <Line w={2} d={`M${x},${y} L${x},${y - h} M${x - 40},${y} L${x + 40},${y} M${x - 30},${y - h} L${x + 30},${y - h} M${x - 22},${y - h} C${x - 18},${y - h - 18} ${x + 18},${y - h - 18} ${x + 26},${y - h - 6}`} />
      <ellipse cx={x} cy={y - h - 40} rx={60} ry={70} fill="url(#halo)" opacity={0.7} />
      <path d={`M${x + 22},${y - h - 8} C${x + 14 + sw},${y - h - 26} ${x + 24 + sw},${y - h - 40} ${x + 26 + sw},${y - h - 50} C${x + 32 + sw},${y - h - 36} ${x + 36},${y - h - 22} ${x + 28},${y - h - 8} Z`} fill="#F6C46E" opacity={0.9} filter="url(#lglow)" />
    </g>
  );
};

/* ============ small clay oil lamp on a table or floor ============ */
export const ClayLamp: React.FC<{x: number; y: number; f?: number; o?: number; s?: number}> = ({x, y, f = 0, o = 1, s = 1}) => {
  const sw = Math.sin(f / 9) * 1.2;
  return (
    <g opacity={o} transform={G(x, y, s)}>
      <ellipse cx={20} cy={-40} rx={70} ry={70} fill="url(#halo)" opacity={0.6} />
      <Line w={2 / s} d="M-30,0 C-34,-16 -10,-22 10,-20 L34,-14 C40,-12 40,-4 32,-2 L10,0 Z" />
      <path d={`M30,-14 C24 ${-26},${30 + sw} ${-36} ${32 + sw},-44 C38,-32 40,-22 36,-14 Z`} fill="#F6C46E" filter="url(#lglow)" />
    </g>
  );
};

/* ============ standing stone / Baal pillar ============ */
export const Pillar: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <path d="M-50,0 L-40,-340 C-30,-370 30,-370 40,-340 L50,0 Z" fill="#100b06" />
    <Line w={2.2 / s} p={p} d="M-50,0 L-40,-340 C-30,-370 30,-370 40,-340 L50,0 M-70,0 L70,0 M-30,-300 L30,-300 M-34,-250 L34,-250" c="#C9A060" />
  </g>
);

/* ============ cave mouth in a rock face ============ */
export const Cave: React.FC<{x: number; y: number; s?: number; o?: number; p?: number; glow?: number}> = ({x, y, s = 1, o = 1, p = 1, glow = 0}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <path d="M-620,0 L-520,-300 L-380,-420 L-160,-480 L60,-470 L280,-400 L460,-260 L600,0 Z" fill="#120c07" />
    <path d="M-170,0 C-180,-140 -110,-250 -10,-254 C100,-258 170,-150 160,0 Z" fill="#040302" />
    {glow > 0 ? <ellipse cx={0} cy={-90} rx={150} ry={110} fill="url(#halo)" opacity={glow} /> : null}
    <Line w={2.4 / s} p={p} d="M-620,0 L-520,-300 L-380,-420 L-160,-480 L60,-470 L280,-400 L460,-260 L600,0 M-170,0 C-180,-140 -110,-250 -10,-254 C100,-258 170,-150 160,0 M-420,-200 L-330,-240 M220,-330 L330,-280" />
  </g>
);

/* ============ altar of twelve stones with fire ============ */
export const StoneAltar: React.FC<{x: number; y: number; s?: number; o?: number; f: number; fire?: number; wood?: number}> = ({x, y, s = 1, o = 1, f, fire = 0, wood = 1}) => {
  const st: [number, number, number][] = [[-90, -22, 46], [-30, -22, 44], [30, -22, 46], [90, -22, 44], [-60, -64, 44], [0, -64, 46], [60, -64, 44], [-30, -104, 42], [30, -104, 42], [-120, -60, 30], [120, -60, 30], [0, -140, 36]];
  return (
    <g opacity={o} transform={G(x, y, s)}>
      {st.map(([sx, sy, r], i) => <ellipse key={i} cx={sx} cy={sy} rx={r * 0.72} ry={r * 0.48} fill="#18110a" stroke="#C9A060" strokeWidth={1.8 / s} />)}
      <Line w={2.4 / s} o={wood} d="M-80,-150 L80,-170 M-70,-170 L90,-150 M-60,-140 L60,-190" />
      {fire > 0 ? <g opacity={fire}><ellipse cx={0} cy={-220} rx={260} ry={220} fill="url(#halo)" /><Fire x={0} y={-150} s={1.1} f={f} /></g> : null}
    </g>
  );
};

/* ============ prison cell: stone wall with a barred window and chain ring ============ */
export const Cell: React.FC<{o?: number; p?: number; y?: number; win?: number; light?: number}> = ({o = 1, p = 1, y = 860, win = 1400, light = 1}) => {
  if (o <= 0.001) return null;
  let st = '';
  for (let r = 0; r < 12; r++) { const yy = y - r * 64; st += ` M0,${yy} L1920,${yy}`; for (let k = 0; k < 12; k++) { const xx = ((k + (r % 2) * 0.5) * 1920) / 11; st += ` M${xx},${yy} L${xx},${yy - 64}`; } }
  return (
    <g opacity={o}>
      <rect x={0} y={0} width={1920} height={y} fill="#0d0905" opacity={0.6} />
      <Line w={1} p={p} o={0.2} c="#B98A45" d={st} />
      <rect x={win - 120} y={y - 600} width={240} height={180} fill="#2b2012" opacity={0.85} />
      <Line w={2.6} p={p} d={`M${win - 120},${y - 420} L${win - 120},${y - 600} L${win + 120},${y - 600} L${win + 120},${y - 420} Z M${win - 60},${y - 420} L${win - 60},${y - 600} M${win},${y - 420} L${win},${y - 600} M${win + 60},${y - 420} L${win + 60},${y - 600}`} />
      <path d={`M${win - 110},${y - 420} L${win + 110},${y - 420} L${win + 360},${y} L${win - 380},${y} Z`} fill="#F3D9A0" opacity={0.06 * light} />
    </g>
  );
};

/* ============ chariot of fire with two horses, heading up-right ============ */
const HORSE = 'M0,0 L10,-70 C0,-100 10,-120 40,-125 L120,-128 C150,-160 160,-190 190,-200 L230,-196 L222,-178 L196,-176 C186,-150 176,-128 170,-110 L176,-60 L168,0 L156,0 L152,-56 L120,-80 L60,-80 L40,-50 L46,0 L34,0 L26,-46 Z';
export const Chariot: React.FC<{x: number; y: number; s?: number; o?: number; f: number}> = ({x, y, s = 1, o = 1, f}) => {
  if (o <= 0.001) return null;
  const gal = Math.sin(f / 4) * 6;
  return (
    <g opacity={o} transform={G(x, y, s)}>
      <ellipse cx={0} cy={-120} rx={520} ry={260} fill="url(#halo)" opacity={0.9} />
      {[0, 1].map((k) => (
        <g key={k} transform={`translate(${40 + k * 60} ${-20 - k * 24 + (k ? -gal : gal)})`}>
          <path d={HORSE} fill="#F2B45C" opacity={0.55 + 0.2 * k} filter="url(#lglow)" />
          <path d={HORSE} fill="none" stroke="#FFE7B8" strokeWidth={2.4 / s} opacity={0.8} />
        </g>
      ))}
      <Line w={2.4 / s} c="#FFE7B8" d="M40,-90 L-80,-80 M-80,-80 L-200,-150 L-210,-60 L-80,-60 Z" u />
      <circle cx={-150} cy={-40} r={52} fill="none" stroke="#FFE7B8" strokeWidth={4 / s} />
      <Line w={2 / s} c="#FFE7B8" d="M-150,-92 L-150,12 M-202,-40 L-98,-40 M-187,-77 L-113,-3 M-113,-77 L-187,-3" u />
      {[[-260, -120], [-160, -200], [-60, -170], [60, -210], [-320, -40]].map(([fx, fy], i) => <Fire key={i} x={fx} y={fy} s={0.55} f={f + i * 13} o={0.85} />)}
    </g>
  );
};

/* ============ whirlwind: rising spiral ============ */
export const Whirl: React.FC<{x: number; y: number; f: number; o?: number; h?: number}> = ({x, y, f, o = 1, h = 800}) => {
  if (o <= 0.001) return null;
  let d = '';
  for (let k = 0; k < 9; k++) {
    const t = k / 8, yy = y - t * h, rx = 40 + t * 260, ph = f / 10 + k;
    d += ` M${x - rx * Math.cos(ph)},${yy} C${x - rx},${yy - 30} ${x + rx},${yy - 30} ${x + rx * Math.cos(ph + 1.6)},${yy - 10}`;
  }
  return <g opacity={o}><ellipse cx={x} cy={y - h * 0.6} rx={340} ry={h * 0.6} fill="url(#halo)" opacity={0.5} /><Line w={1.8} c="#F3D9A0" o={0.7} d={d} u /></g>;
};

/* ============ falling cloak (Elijah's mantle) ============ */
export const Cloak: React.FC<{x: number; y: number; rot?: number; o?: number; s?: number}> = ({x, y, rot = 0, o = 1, s = 1}) => (
  <g opacity={o} transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <Cut m="bronze" lit={1}><path d="M-70,-70 C-30,-90 30,-90 70,-70 C90,-20 110,40 140,80 C110,96 90,84 70,100 C40,86 20,104 -10,94 C-40,108 -70,90 -100,100 C-120,86 -130,90 -150,80 C-110,40 -90,-20 -70,-70 Z" /></Cut>
    <Line w={1.6 / s} c="#E9BE6E" o={0.5} d="M-30,-60 C-40,0 -50,50 -60,90 M20,-60 C30,0 40,50 50,90" />
  </g>
);

/* ============ fortress on a hill (Machaerus) ============ */
export const Fortress: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <path d="M-700,0 C-500,-60 -340,-260 -220,-300 L220,-300 C340,-260 500,-60 700,0 Z" fill="#120c07" />
    <path d="M-200,-300 L-200,-430 L-150,-430 L-150,-460 L-100,-460 L-100,-430 L100,-430 L100,-460 L150,-460 L150,-430 L200,-430 L200,-300 Z" fill="#160f08" />
    <Line w={2.4 / s} p={p} d="M-700,0 C-500,-60 -340,-260 -220,-300 L220,-300 C340,-260 500,-60 700,0 M-200,-300 L-200,-430 L-150,-430 L-150,-460 L-100,-460 L-100,-430 L100,-430 L100,-460 L150,-460 L150,-430 L200,-430 L200,-300 M-40,-300 L-40,-360 C-40,-380 40,-380 40,-360 L40,-300 M-150,-380 L-120,-380 M120,-380 L150,-380" />
  </g>
);

/* ============ covered platter ============ */
export const Platter: React.FC<{x: number; y: number; s?: number; o?: number}> = ({x, y, s = 1, o = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <Cut m="silver" lit={1}><path d="M-80,0 C-80,-50 80,-50 80,0 Z" /><path d="M-100,0 L100,0 L90,10 L-90,10 Z" /></Cut>
    <Line w={2 / s} c="#D9DCE0" o={0.6} d="M0,-38 L0,-48" />
  </g>
);

/* ============ seal and sealed letter ============ */
export const Letter: React.FC<{x: number; y: number; s?: number; o?: number; seal?: number}> = ({x, y, s = 1, o = 1, seal = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <rect x={-70} y={-24} width={140} height={48} rx={22} fill="#1a130b" />
    <Line w={2 / s} d="M-70,-24 L70,-24 M-70,24 L70,24 M-70,-24 C-84,-24 -84,24 -70,24 M70,-24 C84,-24 84,24 70,24" />
    <circle cx={0} cy={0} r={16} fill="#B5452C" opacity={seal} />
    <circle cx={0} cy={0} r={9} fill="none" stroke="#FFB592" strokeWidth={1.5 / s} opacity={seal} />
  </g>
);

/* ============ coast and harbour city (Sidon) ============ */
export const Coast: React.FC<{o?: number; f: number; y?: number}> = ({o = 1, f, y = 860}) => {
  if (o <= 0.001) return null;
  let wv = '';
  for (let r = 0; r < 4; r++) for (let k = 0; k < 9; k++) { const xx = 1100 + k * 100 + ((r * 50 + f * 0.6) % 100), yy = y - 20 + r * 40; wv += ` M${xx},${yy} q20,-10 40,0`; }
  return (
    <g opacity={o}>
      <Line w={1.6} o={0.7} d={`M1040,${y} C1080,${y - 30} 1100,${y - 40} 1920,${y - 40}`} />
      <Line w={1.4} o={0.4} d={wv} c="#C9A060" u />
      <g transform={`translate(1500 ${y - 70})`}>
        <path d="M-90,0 L90,0 L70,30 L-70,30 Z" fill="#160f08" />
        <Line w={2} d="M-90,0 L90,0 L70,30 L-70,30 Z M0,0 L0,-150 M0,-150 L60,-40 L0,-40" />
      </g>
    </g>
  );
};

/* ============ split screen: two eras side by side ============ */
export const SplitDefs: React.FC = () => (
  <defs>
    <clipPath id="clipL"><rect x={0} y={0} width={955} height={1080} /></clipPath>
    <clipPath id="clipR"><rect x={965} y={0} width={955} height={1080} /></clipPath>
  </defs>
);
/** left and right halves; each child is drawn in full-frame coordinates and shifted to its half */
export const Split: React.FC<{o?: number; left: React.ReactNode; right: React.ReactNode; labL?: string; labR?: string; labO?: number; dimL?: number; dimR?: number}> = ({o = 1, left, right, labL, labR, labO = 1, dimL = 0, dimR = 0}) => {
  if (o <= 0.001) return null;
  return (
    <g opacity={o}>
      <SplitDefs />
      <g clipPath="url(#clipL)"><g transform="translate(-480 0)" opacity={1 - 0.6 * dimL}>{left}</g></g>
      <g clipPath="url(#clipR)"><g transform="translate(480 0)" opacity={1 - 0.6 * dimR}>{right}</g></g>
      <rect x={955} y={0} width={10} height={1080} fill="#0b0805" />
      <Line w={1.6} c="#E3B465" o={0.8} d="M955,0 L955,1080 M965,0 L965,1080" />
      {labL ? <text x={478} y={1020} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={30} letterSpacing={6} opacity={labO}>{labL}</text> : null}
      {labR ? <text x={1442} y={1020} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={30} letterSpacing={6} opacity={labO}>{labR}</text> : null}
    </g>
  );
};
