import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import {Defs, Fig, plantedWalk, type ActingPose, type HandPose} from './fig';
import {beat, blend, mix, type Point} from './acting';
import {Courtyard} from './courtyard';

export const HANDOFF_FRAMES = 390;
const floor = 432;
const poseHand = (point: Point, angle: number): HandPose => ({point, angle});
const shift = (p: Point, x: number, y: number): Point => [p[0] + x, p[1] + y];

export function handoffPoses(f: number) {
  const walk = plantedWalk(f, 226, 449, 0, 105, 6);
  const stop = beat(f, 95, 118),
    lower = beat(f, 102, 174);
  const offer = beat(f, 165, 219),
    take = beat(f, 244, 282),
    bring = beat(f, 286, 338);
  const letGo = beat(f, 283, 312),
    recover = beat(f, 311, 365);
  const nod = beat(f, 157, 191) - beat(f, 210, 252);
  const gx = walk.x + 2.0 * (beat(f, 94, 105) - beat(f, 106, 119));
  const load = 4.4 * (beat(f, 280, 292) - beat(f, 295, 319));
  const carrier: Point = [gx + 31 + 3 * stop, floor - 135 + 61 * lower - walk.lift];
  const vessel = blend(blend(carrier, [507, floor - 79], offer), [543, floor - 84], bring);
  vessel[1] += load;
  const gNear = blend(shift(vessel, -4, -0.4), [gx + 20, floor - 48], letGo);
  const gFar = blend(shift(vessel, -12, -19), [gx + 29, floor - 51], letGo);
  const feet: ActingPose['feet'] = [...walk.feet];
  const back = feet[0][0] < feet[1][0] ? 0 : 1;
  const backStep = beat(f, 109, 146);
  feet[back] = [feet[back][0] - 18 * backStep, feet[back][1] - 7 * Math.sin(Math.PI * backStep)];
  const stride = Math.sin(Math.PI * Math.min(6, Math.max(0, (f / 105) * 6)));
  const breath = Math.sin(f / 29),
    returned = beat(f, 339, 371);
  const giver: ActingPose = {
    x: gx,
    floor,
    scale: 1.06,
    facing: 1,
    metal: 'gold',
    lightSide: 1,
    dress: 'mantle',
    feet,
    kneel: lower,
    lean: 4 + 6 * lower + 4 * offer - 5 * recover,
    shoulder: 2 * offer - 2 * recover + 0.8 * stride + 0.35 * breath,
    look: 0.83 + 0.17 * offer,
    nod: 1 + 8 * lower - 5 * offer - 3 * recover + 0.9 * stride + 1.1 * breath,
    lift: walk.lift,
    near: poseHand(gNear, mix(-5, 60, letGo)),
    far: poseHand(gFar, mix(-43, 46, letGo)),
  };
  const reach = beat(f, 211, 230) - beat(f, 231, 244);
  const rNear = blend([550 - 9 * reach, floor - 49 - 7 * reach], shift(vessel, 4, -0.4), take);
  const rFar = blend([557 - 3 * reach, floor - 47 - 3 * reach], shift(vessel, 13, -19), beat(f, 251, 285));
  const recipient: ActingPose = {
    x: 568,
    floor: floor + 1.5,
    scale: 0.99,
    facing: -1,
    metal: 'bronze',
    lightSide: -1,
    dress: 'veil',
    feet: [
      [591, 0],
      [551, 0],
    ],
    kneel: 0.99,
    lean: 5 + 5 * take - 4 * bring,
    shoulder: 3 * take - 2 * bring + 0.55 * Math.sin(f / 25),
    look: -0.18 + 1.11 * beat(f, 65, 111),
    nod: 12 - 13 * beat(f, 71, 114) + 7 * nod + 8 * bring - 9 * returned + 0.65 * Math.sin(f / 30),
    near: poseHand(rNear, mix(54, -3, take)),
    far: poseHand(rFar, mix(47, -37, take)),
  };
  return {giver, recipient, vessel};
}
function WaterJar({x, y}: {x: number; y: number}) {
  return (
    <g transform={`translate(${x} ${y})`} strokeLinejoin="round">
      <defs>
        <linearGradient id="clay">
          <stop stopColor="#56311f" />
          <stop offset=".27" stopColor="#925c35" />
          <stop offset=".62" stopColor="#6b412a" />
          <stop offset="1" stopColor="#36271c" />
        </linearGradient>
      </defs>
      <path
        d="M-7 -30 Q-19 -36 -17 -21 Q-16 -16 -12 -15 M8 -30 Q19 -35 17 -23 Q16 -18 13 -17"
        fill="none"
        stroke="#d19b61"
        strokeWidth="2.6"
      />
      <path
        d="M-7 -37 Q0 -39 7 -37 L6 -29 Q7 -25 12 -21 Q18 -14 12 -6 Q9 -1 5 0 L-5 0 Q-10 -2 -13 -7 Q-18 -15 -11 -22 Q-6 -26 -6 -30Z"
        fill="url(#clay)"
        stroke="#edbe81"
        strokeWidth="1.1"
      />
      <ellipse cy="-37" rx="7" ry="1.7" fill="#2e2119" stroke="#d6a568" strokeWidth="1" />
      <path
        d="M-11 -21 Q-2 -17 11 -21 M-12 -18 Q0 -14 13 -18"
        stroke="#cf9864"
        strokeWidth=".8"
        fill="none"
        opacity=".8"
      />
    </g>
  );
}
export function SampleArtwork({frame: f}: {frame: number}) {
  const {giver, recipient, vessel} = handoffPoses(f),
    push = beat(f, 78, 222);
  const zoom = 1.045 + 0.79 * push;
  const cx = 465 + 42 * push,
    cy = 277 + 72 * push;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1920"
      height="1080"
      viewBox="0 0 960 540"
      style={{display: 'block'}}
    >
      <Defs/>
      <rect width="960" height="540" fill="#1d1711" />
      <g transform={`translate(480 270) scale(${zoom}) translate(${-cx} ${-cy})`}>
        <Courtyard />
        {[giver, recipient].map((p, i) => (
          <g key={i}>
            <ellipse cx={p.x - 4} cy={p.floor + 1.6} rx={34 + 9 * p.kneel} ry="4.3" fill="#140f0b" opacity=".44" />
            <ellipse cx={p.x + 2} cy={p.floor + 0.9} rx="23" ry="2.2" fill="#0e0c09" opacity=".42" />
          </g>
        ))}
        <Fig acting={giver} />
        <Fig acting={recipient} />
        <WaterJar x={vessel[0]} y={vessel[1]} />
      </g>
    </svg>
  );
}
export function Handoff() {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: '#1d1711'}}>
      <SampleArtwork frame={frame} />
      <Audio src={staticFile('handoff.wav')} />
    </AbsoluteFill>
  );
}
