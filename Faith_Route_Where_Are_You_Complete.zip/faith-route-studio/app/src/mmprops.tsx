import React from 'react';
import {Fig, FigP, Line, Cut, TXT} from './fig';
import {win, fi, ramp, eio, eout, rng, clamp} from './lib';
import {GY} from './stage';

const G = (x: number, y: number, s = 1) => `translate(${x} ${y}) scale(${s})`;
type FP = Omit<FigP, 'm'> & {m?: FigP['m']};

/* ============================ MICHAEL (winged) ============================ */
const WING = 'M0,0 C-30,-120 -120,-330 -300,-520 C-290,-440 -270,-390 -240,-350 C-300,-370 -350,-390 -400,-430 C-370,-350 -330,-300 -280,-260 C-340,-260 -390,-280 -440,-310 C-400,-240 -340,-190 -270,-160 C-320,-150 -370,-160 -410,-180 C-370,-110 -300,-70 -220,-50 C-250,-30 -280,-10 -300,10 C-200,40 -100,40 0,30 Z';
const FEATH = 'M-40,-40 C-120,-120 -210,-230 -280,-330 M-30,-10 C-140,-60 -260,-120 -360,-200 M-40,14 C-140,0 -230,-20 -320,-60';
/** spread 0 folded .. 1 open; glow = halo behind */
export const Michael: React.FC<FP & {spread?: number; f?: number; glow?: number}> = (p) => {
  const {x, y, sc = 0.34, spread = 1, f = 0, glow = 0.55} = p;
  const fx = p.face !== undefined ? p.face : p.flip ? -1 : 1;
  const k = Math.sign(fx || 1) * Math.max(0.06, Math.abs(fx));
  const lit = p.lit ?? (fx >= 0 ? 1 : -1);
  const tf = `translate(${x} ${y}) scale(${k * sc} ${sc}) translate(-200 -1545)`;
  const a = -58 * (1 - spread) + Math.sin(f / 28) * 2.2;
  const o = p.o ?? 1;
  if (o <= 0.001) return null;
  return (
    <g opacity={o}>
      {glow > 0 ? <ellipse cx={x - k * sc * 80} cy={y - sc * 1150} rx={sc * 760} ry={sc * 820} fill="url(#halo)" opacity={glow} /> : null}
      <Cut m="gold" lit={lit} o={0.78} tf={`${tf} translate(178 452) rotate(${a + 13}) scale(1.12)`}><path d={WING} /></Cut>
      <Cut m="gold" lit={lit} tf={`${tf} translate(150 462) rotate(${a}) scale(1.22)`}><path d={WING} /></Cut>
      <g transform={`${tf} translate(150 462) rotate(${a}) scale(1.22)`}><Line d={FEATH} w={2.2 / sc} o={0.5} /></g>
      <Fig {...(p as FigP)} sc={sc} m="gold" o={1} hair={p.hair ?? 'bare'} beard={p.beard ?? 'none'} mantle={p.mantle ?? true} />
    </g>
  );
};

/* ============================ THE DEVIL (shadow) ============================ */
export const Devil: React.FC<FP & {f?: number; smoke?: number; eye?: number}> = (p) => {
  const {x, y, sc = 0.34, f = 0, smoke = 1, eye = 1} = p;
  const o = p.o ?? 1;
  if (o <= 0.001) return null;
  const fx = p.face !== undefined ? p.face : p.flip ? -1 : 1;
  const k = Math.sign(fx || 1) * Math.max(0.06, Math.abs(fx));
  const tall = p.tall ?? 1.07;
  const ex = x + k * sc * 47, ey = y + sc * tall * (140 - 1545);
  return (
    <g opacity={o}>
      {smoke > 0 ? <g opacity={smoke}>
        <ellipse cx={x} cy={y - sc * 700} rx={sc * 620} ry={sc * 900} fill="#000" opacity={0.32} filter="url(#soft)" />
        {[0, 1, 2, 3].map((i) => <ellipse key={i} cx={x + (i - 1.5) * sc * 260 + Math.sin(f / 50 + i) * 12} cy={y - 18 - Math.cos(f / 60 + i) * 6} rx={sc * 300} ry={sc * 90} fill="#120605" opacity={0.55} filter="url(#soft)" />)}
        <ellipse cx={x} cy={y - 10} rx={sc * 520} ry={sc * 70} fill="#7a2414" opacity={0.18} filter="url(#soft)" />
      </g> : null}
      <Fig {...(p as FigP)} sc={sc} m="shadow" o={1} hair={p.hair ?? 'veil'} beard={p.beard ?? 'none'} tall={tall} />
      {eye > 0 ? <><ellipse cx={ex} cy={ey} rx={sc * 30} ry={sc * 15} fill="#FF6A3C" opacity={0.5 * eye} filter="url(#lglow)" /><ellipse cx={ex} cy={ey} rx={sc * 13} ry={sc * 7} fill="#FFD0B0" opacity={eye} /></> : null}
    </g>
  );
};

/* ============================ MOSES' BODY ============================ */
export const Body: React.FC<{x: number; y: number; s?: number; o?: number; glow?: number; slab?: number; lit?: number}> = ({x, y, s = 1, o = 1, glow = 0, slab = 1, lit = 1}) => {
  if (o <= 0.001) return null;
  return (
    <g opacity={o}>
      {glow > 0 ? <ellipse cx={x} cy={y - 90 * s} rx={360 * s} ry={170 * s} fill="url(#halo)" opacity={glow} /> : null}
      {slab > 0 ? <g opacity={slab}>
        <path d={`M${x - 270 * s},${y} L${x - 256 * s},${y - 48 * s} L${x + 262 * s},${y - 48 * s} L${x + 280 * s},${y} Z`} fill="#0e0a06" />
        <Line u w={2.2} d={`M${x - 270 * s},${y} L${x - 256 * s},${y - 48 * s} L${x + 262 * s},${y - 48 * s} L${x + 280 * s},${y} M${x - 120 * s},${y - 48 * s} L${x - 130 * s},${y} M${x + 120 * s},${y - 48 * s} L${x + 130 * s},${y}`} c="#B8873E" o={0.8} />
      </g> : null}
      <Cut m="gold" lit={lit} tf={G(x, y - 48 * s * slab, s)}>
        <path d="M-226,0 C-236,-28 -222,-56 -192,-62 C-170,-92 -118,-92 -100,-62 L170,-56 C214,-54 238,-38 234,-18 L230,0 Z" />
      </Cut>
      <g transform={G(x, y - 48 * s * slab, s)}><Line w={2 / s} o={0.45} d="M-60,-60 L-52,-4 M20,-58 L26,-4 M100,-57 L104,-4 M170,-54 L172,-6" /></g>
    </g>
  );
};

/* ============================ MOUNTAIN SLOPE ============================ */
export const slopeY = (x: number, x0 = 120, y0 = 940, x1 = 1320, y1 = 420) => y0 + ((x - x0) * (y1 - y0)) / (x1 - x0);
export const Slope: React.FC<{o?: number; p?: number; x0?: number; y0?: number; x1?: number; y1?: number}> = ({o = 1, p = 1, x0 = 120, y0 = 940, x1 = 1320, y1 = 420}) => {
  const d = `M-40,${y0 + 60} L${x0},${y0} L${x1},${y1} C${x1 + 60},${y1 - 14} ${x1 + 120},${y1 - 10} ${x1 + 170},${y1 + 20} L${x1 + 460},${y1 + 260} L1960,${y1 + 420}`;
  return (
    <g opacity={o}>
      <path d={`${d} L1960,1100 L-40,1100 Z`} fill="#0b0805" opacity={0.85} />
      <Line u w={2.4} p={p} d={d} />
      <Line u w={1.4} p={p} o={0.4} d={`M${x0 + 260},${slopeY(x0 + 260, x0, y0, x1, y1) + 60} L${x0 + 420},${slopeY(x0 + 420, x0, y0, x1, y1) + 120} M${x0 + 700},${slopeY(x0 + 700, x0, y0, x1, y1) + 50} L${x0 + 820},${slopeY(x0 + 820, x0, y0, x1, y1) + 130}`} />
    </g>
  );
};

/* ============================ SUMMIT (for the vista) ============================ */
export const SUMMIT = {x: 440, y: 471};
export const Summit: React.FC<{o?: number; p?: number}> = ({o = 1, p = 1}) => {
  const d = 'M-40,700 C100,640 220,560 330,500 C380,474 470,466 540,480 C620,500 700,600 780,720 C840,810 880,900 920,1100';
  return (
    <g opacity={o}>
      <path d={`${d} L-40,1100 Z`} fill="#0b0805" opacity={0.94} />
      <Line u w={2.4} p={p} d={d} />
      <Line u w={1.4} p={p} o={0.35} d="M160,640 C200,700 230,760 250,820 M620,560 C650,620 660,680 668,740" />
    </g>
  );
};

/* ============================ PALM + VISTA ============================ */
export const Palm: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <Line w={2.2 / s} p={p} d="M0,0 C6,-60 2,-120 14,-180 M14,-180 C-20,-196 -50,-190 -74,-168 M14,-180 C40,-200 72,-196 92,-174 M14,-180 C-6,-214 -34,-226 -56,-224 M14,-180 C30,-222 56,-232 80,-226 M14,-180 C10,-210 16,-236 24,-250" />
  </g>
);
/** promised-land panorama to the right of a summit; lab = label opacity */
export const Vista: React.FC<{f: number; p?: number; lab?: number; o?: number; dot?: number; gilead?: number; jericho?: number; jordan?: number}> = ({f, p = 1, lab = 1, o = 1, dot = -1, gilead = 1, jericho = 1, jordan = 1}) => {
  if (o <= 0.001) return null;
  const river = 'M1236,452 C1210,520 1272,560 1240,620 C1206,684 1290,720 1250,780 C1226,820 1260,850 1240,900';
  return (
    <g opacity={o}>
      <Line u w={1.6} p={p} o={0.5} d="M760,520 C900,470 1040,500 1180,450 C1320,410 1480,470 1640,430 C1760,400 1860,430 1940,420" />
      <Line u w={2} p={p} o={0.75} d="M800,640 C940,600 1100,640 1220,600 C1360,560 1500,610 1660,580 C1780,560 1880,590 1940,580" />
      <path d={river} fill="none" stroke="#C9A36A" strokeWidth={9} opacity={0.22 * jordan} />
      <Line u w={2} p={p} c="#E3C17E" o={0.9 * jordan} d={river} />
      <g opacity={jericho}>
        <Line u w={2} p={p} d="M1420,742 L1420,700 L1446,700 L1446,688 L1470,688 L1470,700 L1530,700 L1530,690 L1552,690 L1552,700 L1580,700 L1580,742" />
        {[1350, 1384, 1610, 1644, 1676].map((px, i) => <Palm key={i} x={px} y={748} s={0.42 + (i % 2) * 0.08} p={p} />)}
      </g>
      <circle cx={1500} cy={720} r={140} fill="url(#halo)" opacity={0.7 * jericho} />
      {dot >= 0 ? <g><path d={`M440,450 Q900,330 ${440 + 1060 * dot},${450 + 150 * dot}`} fill="none" stroke="#E3C17E" strokeWidth={2.4} strokeDasharray="10 12" opacity={0.8} /><circle cx={440 + 1060 * dot} cy={450 + 150 * dot} r={50} fill="url(#halo)" /><circle cx={440 + 1060 * dot} cy={450 + 150 * dot} r={11} fill="#FFE2A0" filter="url(#lglow)" /></g> : null}
      <g opacity={lab}>
        <text x={1620} y={392} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={34} letterSpacing={6} opacity={gilead}>GILEAD</text>
        <text x={1500} y={812} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={34} letterSpacing={6} opacity={jericho}>JERICHO</text>
        <text x={1500} y={850} textAnchor="middle" fill={TXT.ivory} fontFamily="Corm" fontStyle="italic" fontSize={30} opacity={jericho}>the City of Palms</text>
        <text x={1140} y={720} textAnchor="end" fill={TXT.ivory} fontFamily="Cinzel" fontSize={26} letterSpacing={5} opacity={jordan}>JORDAN</text>
      </g>
    </g>
  );
};

/* ============================ BURNING BUSH ============================ */
const flame = (px: number, py: number, h: number, f: number, k: number) => {
  const w = Math.sin(f / 4.5 + k) * h * 0.08;
  return `M${px - h * 0.28},${py} C${px - h * 0.36},${py - h * 0.4} ${px - h * 0.12},${py - h * 0.6} ${px + w},${py - h} C${px + h * 0.16},${py - h * 0.6} ${px + h * 0.36},${py - h * 0.36} ${px + h * 0.28},${py} Z`;
};
export const Bush: React.FC<{x: number; y: number; s?: number; f: number; o?: number; fire?: number}> = ({x, y, s = 1, f, o = 1, fire = 1}) => {
  const B = 'M-150,0 C-190,-30 -180,-90 -140,-110 C-160,-170 -100,-210 -50,-190 C-30,-240 40,-240 60,-190 C110,-210 170,-170 150,-110 C190,-90 190,-30 150,0 Z';
  const pts: [number, number, number][] = [[-130, -100, 120], [-70, -175, 150], [0, -205, 190], [66, -180, 150], [128, -104, 120], [0, -110, 110]];
  return (
    <g opacity={o} transform={G(x, y, s)}>
      <ellipse cx={0} cy={-150} rx={300} ry={250} fill="url(#halo)" opacity={fire} />
      <ellipse cx={0} cy={-160} rx={170} ry={150} fill="#F6C46E" opacity={0.12 * fire} filter="url(#soft)" />
      <path d={B} fill="#0c0905" />
      <Line w={2.2 / s} d={`${B} M0,0 L0,-120 M0,-80 L-70,-140 M0,-60 L80,-130 M-90,-20 L-120,-80 M90,-20 L120,-70`} />
      <g opacity={fire}>
        {pts.map(([px, py, h], i) => <path key={i} d={flame(px, py, h, f, i * 1.9)} fill={i % 2 ? '#F6C46E' : '#E89A4C'} opacity={0.85} filter="url(#lglow)" />)}
        {pts.slice(0, 5).map(([px, py, h], i) => <path key={'c' + i} d={flame(px, py, h * 0.55, f, i * 1.9 + 1)} fill="#FFF0C8" opacity={0.85} />)}
      </g>
    </g>
  );
};

/* ============================ ROCK WITH WATER ============================ */
export const Rock: React.FC<{x: number; y: number; s?: number; o?: number; water?: number; f?: number; crack?: number}> = ({x, y, s = 1, o = 1, water = 0, f = 0, crack = 0}) => {
  const R = 'M-200,0 C-220,-90 -170,-190 -70,-210 C10,-250 130,-220 170,-140 C220,-70 210,-20 190,0 Z';
  return (
    <g opacity={o} transform={G(x, y, s)}>
      <path d={R} fill="#0e0a06" />
      <Line w={2.4 / s} d={`${R} M-120,-150 C-80,-170 -40,-176 0,-170 M60,-200 L90,-160`} />
      {crack > 0 ? <Line w={2.6 / s} c="#E3C17E" p={crack} d="M20,-200 L0,-150 L30,-110 L6,-60 L22,-20" /> : null}
      {water > 0 ? <g opacity={water}>
        {[0, 1, 2, 3].map((i) => (
          <path key={i} d={`M${14 + i * 4},-${120 - i * 10} C${120 + i * 30},-${150 - i * 8} ${220 + i * 40},-${60 + i * 6} ${260 + i * 50},0`} fill="none" stroke="#EADBB8" strokeWidth={(5 - i) / s} opacity={0.75 - i * 0.12} strokeDasharray="40 22" strokeDashoffset={-f * 6 - i * 11} strokeLinecap="round" />
        ))}
        <ellipse cx={300} cy={-6} rx={140} ry={16} fill="#EADBB8" opacity={0.18} />
      </g> : null}
    </g>
  );
};

/* ============================ DRAGON (Revelation 12) ============================ */
/** faces left; seven heads */
export const Dragon: React.FC<{x: number; y: number; s?: number; f: number; o?: number; rot?: number}> = ({x, y, s = 1, f, o = 1, rot = 0}) => {
  if (o <= 0.001) return null;
  const necks = Array.from({length: 7}, (_, i) => {
    const t = i / 6;
    const a = ((-168 + t * 96) * Math.PI) / 180 + Math.sin(f / 16 + i * 1.3) * 0.05;
    const L = 290 + Math.sin(i * 1.7) * 36;
    const sx = -40, sy = -110;
    const ex = sx + Math.cos(a) * L, ey = sy + Math.sin(a) * L;
    const cx = sx + Math.cos(a + 0.4) * L * 0.55, cy = sy + Math.sin(a + 0.4) * L * 0.55;
    const deg = (a * 180) / Math.PI;
    const eye = [ex + Math.cos(a) * 40 + Math.cos(a - 1.57) * 12, ey + Math.sin(a) * 40 + Math.sin(a - 1.57) * 12];
    return {d: `M${sx},${sy} Q${cx},${cy} ${ex},${ey}`, tf: `translate(${ex} ${ey}) rotate(${deg})`, eye};
  });
  const flap = Math.sin(f / 14) * 6;
  return (
    <g opacity={o} transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
      <ellipse cx={120} cy={-160} rx={520} ry={360} fill="#5a1a10" opacity={0.22} filter="url(#soft)" />
      <Cut m="shadow" lit={-1} o={0.8}><path d={`M70,-120 C40,-300 110,-460 270,${-560 - flap} C245,-470 255,-420 290,-380 C315,-450 360,-490 430,${-510 - flap} C395,-420 395,-360 420,-320 C460,-370 510,-395 570,${-405 - flap} C520,-310 480,-220 360,-110 Z`} /></Cut>
      <Cut m="shadow" lit={-1}>
        <path d="M-120,-40 C-110,-170 120,-200 230,-120 C300,-70 380,-60 460,-100 C520,-130 590,-110 610,-60 C560,-80 510,-60 460,-20 C370,50 250,60 150,24 C50,56 -110,36 -120,-40 Z M610,-60 L670,-100 L652,-36 Z M14,8 C6,50 0,80 -8,104 L-30,114 L40,114 L44,100 C48,80 54,50 56,22 Z M196,28 C190,64 186,90 182,108 L160,118 L230,118 L232,104 C236,84 240,60 242,34 Z" />
        {necks.map((n, i) => <path key={i} d={n.d} fill="none" stroke="#fff" strokeWidth={30} strokeLinecap="round" />)}
        {necks.map((n, i) => <g key={'h' + i} transform={n.tf}><path d="M-14,-24 C20,-34 64,-30 104,-12 L112,0 C84,4 56,10 26,20 C8,24 -10,18 -16,8 Z" /><path d="M-4,-20 C-22,-44 -48,-56 -74,-60 C-52,-44 -36,-30 -20,-12 Z" /></g>)}
        <path d={`M150,-140 C120,-320 200,-470 360,${-540 + flap} C335,-450 345,-400 380,-360 C405,-430 450,-470 520,${-490 + flap} C485,-400 485,-340 510,-300 C550,-350 600,-375 660,${-385 + flap} C610,-290 570,-200 450,-90 Z`} />
      </Cut>
      {necks.map((n, i) => <circle key={'e' + i} cx={n.eye[0]} cy={n.eye[1]} r={6} fill="#FFB08A" opacity={0.95} />)}
    </g>
  );
};

/* ============================ CLOUDS ============================ */
export const Clouds: React.FC<{y: number; o?: number; f?: number; seed?: number}> = ({y, o = 1, f = 0, seed = 3}) => {
  const r = rng(seed);
  const cl = Array.from({length: 7}, (_, i) => ({x: i * 300 + r() * 120 - 40, w: 180 + r() * 120, h: 50 + r() * 30}));
  return (
    <g opacity={o}>
      {cl.map((c, i) => {
        const x = c.x + Math.sin(f / 90 + i) * 10;
        const d = `M${x - c.w},${y} C${x - c.w},${y - c.h} ${x - c.w * 0.5},${y - c.h * 1.4} ${x - c.w * 0.15},${y - c.h * 0.9} C${x},${y - c.h * 1.8} ${x + c.w * 0.6},${y - c.h * 1.5} ${x + c.w * 0.55},${y - c.h * 0.7} C${x + c.w},${y - c.h * 0.9} ${x + c.w},${y} ${x + c.w * 0.8},${y}`;
        return <g key={i}><path d={`${d} Z`} fill="#0d0905" opacity={0.85} /><Line u w={1.8} o={0.55} d={d} /></g>;
      })}
    </g>
  );
};

/* ============================ 66 BOOKS ============================ */
export const BookRow: React.FC<{f: number; a: number; b?: number; y?: number; hl?: number; lit?: number}> = ({f, a, b, y = 760, hl = 64, lit = 1}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const x0 = 250, x1 = 1670, n = 66, w = (x1 - x0) / n;
  const r = rng(66);
  return (
    <g opacity={o}>
      <Line u w={2.2} d={`M${x0 - 30},${y} L${x1 + 30},${y} M${x0 - 30},${y + 14} L${x1 + 30},${y + 14}`} />
      {Array.from({length: n}, (_, i) => {
        const h = 150 + r() * 120, x = x0 + i * w;
        const on = i === hl;
        const ap = fi(f, a + i * 0.7, 10);
        return (
          <g key={i} opacity={ap}>
            {on ? <ellipse cx={x + w / 2} cy={y - h / 2} rx={90} ry={h * 0.8} fill="url(#halo)" opacity={lit} /> : null}
            <rect x={x + 2} y={y - h} width={w - 4} height={h} fill={on ? '#E8B455' : '#0e0a06'} opacity={on ? 0.3 + 0.6 * lit : 1} stroke={on ? '#F4CF86' : i < 39 ? '#7A5A30' : '#9C6E2C'} strokeWidth={on ? 2.4 : 1.4} />
          </g>
        );
      })}
      <text x={x0 + 19.5 * w} y={y + 60} textAnchor="middle" fill={TXT.ivory} fontFamily="Cinzel" fontSize={26} letterSpacing={5} opacity={fi(f, a + 30)}>OLD TESTAMENT</text>
      <text x={x0 + 52.5 * w} y={y + 60} textAnchor="middle" fill={TXT.ivory} fontFamily="Cinzel" fontSize={26} letterSpacing={5} opacity={fi(f, a + 40)}>NEW TESTAMENT</text>
      <g opacity={lit * fi(f, a + 50)}>
        <Line u w={2.4} c="#E3B465" d={`M${x0 + hl * w + w / 2},${y - 300} L${x0 + hl * w + w / 2},${y - 340} M${x0 + hl * w + w / 2 - 12},${y - 316} L${x0 + hl * w + w / 2},${y - 300} L${x0 + hl * w + w / 2 + 12},${y - 316}`} />
        <text x={x0 + hl * w + w / 2} y={y - 360} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={44} letterSpacing={6}>JUDE</text>
      </g>
    </g>
  );
};

/* ============================ CODEX WITH LOST ENDING ============================ */
export const Codex: React.FC<{x: number; y: number; s?: number; o?: number; p?: number; torn?: number; q?: number}> = ({x, y, s = 1, o = 1, p = 1, torn = 0, q = 0}) => {
  if (o <= 0.001) return null;
  const tx = 260 - 190 * torn;
  let lines = '';
  for (let i = 0; i < 9; i++) {
    const yy = -220 + i * 22;
    lines += ` M-226,${yy} L-36,${yy + 2}`;
    if (36 < tx - 30) lines += ` M36,${yy + 2} L${Math.min(226, tx - 30)},${yy}`;
  }
  const jag = `M${tx},-252 L${tx - 14},-220 L${tx + 8},-190 L${tx - 10},-150 L${tx + 10},-110 L${tx - 12},-70 L${tx + 6},-34 L${tx - 6},-6`;
  return (
    <g opacity={o} transform={G(x, y, s)}>
      <path d={`M0,0 C-80,-24 -200,-24 -260,-4 L-260,-250 C-200,-270 -80,-270 0,-246 C60,-264 ${tx * 0.6},-266 ${tx},-252 L${tx},-6 C${tx * 0.6},-22 60,-24 0,0 Z`} fill="#0e0a06" />
      <Line w={2.2 / s} p={p} d={`M0,0 C-80,-24 -200,-24 -260,-4 L-260,-250 C-200,-270 -80,-270 0,-246 M0,-246 C60,-264 ${tx * 0.6},-266 ${tx},-252 M0,0 C60,-24 ${tx * 0.6},-22 ${tx},-6 M0,0 L0,-246 ${lines}`} />
      {torn > 0 ? <>
        <Line w={2.2 / s} c="#C67D41" d={jag} />
        <path d={`M${tx + 10},-252 C${tx + 80},-262 220,-266 260,-250 L260,-4 C220,-20 ${tx + 80},-22 ${tx + 6},-6`} fill="none" stroke="#9C6E2C" strokeWidth={2 / s} strokeDasharray="10 10" opacity={0.7 * torn} />
        <text x={(tx + 260) / 2 + 6} y={-96} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={96} opacity={q}>?</text>
      </> : null}
    </g>
  );
};

/* ============================ FRAGMENTS ASSEMBLING ============================ */
export const Fragments: React.FC<{x: number; y: number; p: number; o?: number; s?: number}> = ({x, y, p, o = 1, s = 1}) => {
  if (o <= 0.001) return null;
  const pcs = [
    {d: 'M-200,-260 L40,-260 L20,-120 L-60,-140 L-200,-90 Z', ox: -420, oy: -120, r: -18},
    {d: 'M40,-260 L200,-260 L200,-60 L80,-80 L20,-120 Z', ox: 380, oy: -160, r: 22},
    {d: 'M-200,-90 L-60,-140 L20,-120 L80,-80 L40,40 L-200,60 Z', ox: -360, oy: 200, r: 14},
    {d: 'M80,-80 L200,-60 L200,140 L60,120 L40,40 Z', ox: 420, oy: 180, r: -26},
    {d: 'M-200,60 L40,40 L60,120 L200,140 L200,240 L-200,240 Z', ox: 40, oy: 330, r: 10},
  ];
  return (
    <g opacity={o} transform={G(x, y, s)}>
      {pcs.map((pc, i) => {
        const t = eio(clamp(p * 1.25 - i * 0.06));
        return (
          <g key={i} transform={`translate(${0.7 * pc.ox * (1 - t)} ${0.7 * pc.oy * (1 - t)}) rotate(${pc.r * (1 - t)})`}>
            <path d={pc.d} fill="#1a120a" />
            <Line w={2 / s} d={pc.d} o={0.9} />
            {[0, 1, 2].map((k) => <Line key={k} w={1.4 / s} o={0.35} d={`M-180,${-220 + i * 90 + k * 26} L160,${-220 + i * 90 + k * 26}`} />)}
          </g>
        );
      })}
      <rect x={-210} y={-270} width={420} height={520} fill="none" stroke="#F1CD86" strokeWidth={2 / s} opacity={0.6 * eout(clamp(p * 2 - 1))} filter="url(#lglow)" />
    </g>
  );
};

/* ============================ CASE FILE (recurring diagram) ============================ */
export type CaseRow = {tag: string; acc: string; who: string; charge?: string; ans: string; o?: number; ansO?: number; chargeO?: number; hl?: number; dim?: number};
const Cell: React.FC<{x: number; y: number; w: number; h: number; main: string; sub?: string; subO?: number; o: number; hl?: number; c?: string; size?: number}> = ({x, y, w, h, main, sub, subO = 1, o, hl = 0, c = TXT.ivory, size = 40}) => (
  o <= 0.001 ? null : <g opacity={o}>
    <rect x={x - w / 2} y={y - h / 2} width={w} height={h} fill="#000" opacity={0.45} />
    {hl > 0 ? <rect x={x - w / 2} y={y - h / 2} width={w} height={h} fill="#C99A4A" opacity={0.12 * hl} /> : null}
    <rect x={x - w / 2} y={y - h / 2} width={w} height={h} fill="none" stroke="url(#goldLine)" strokeWidth={1.8 + hl} filter="url(#lglow)" />
    <text x={x} y={y + (sub ? -4 : size * 0.35)} textAnchor="middle" fill={c} fontFamily="Cinzel" fontSize={size} letterSpacing={2}>{main}</text>
    {sub ? <text x={x} y={y + 40} textAnchor="middle" fill={TXT.ember} fontFamily="Cinzel" fontSize={26} letterSpacing={4} opacity={subO}>{sub}</text> : null}
  </g>
);
export const CaseFile: React.FC<{f: number; o: number; rows: CaseRow[]; y0?: number}> = ({f, o, rows, y0 = 330}) => {
  if (o <= 0.001) return null;
  const xs = [560, 1000, 1470], ws = [380, 380, 500], rh = 150, gap = 178;
  return (
    <g opacity={o}>
      {['ACCUSER', 'ACCUSED', 'ANSWER'].map((h, i) => <text key={h} x={xs[i]} y={y0 - 110} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={30} letterSpacing={8}>{h}</text>)}
      {rows.map((r, i) => {
        const y = y0 + i * gap, ro = r.o ?? 1, dim = 1 - 0.55 * (r.dim ?? 0);
        return (
          <g key={i} opacity={ro * dim}>
            <text x={200} y={y + 12} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={30} letterSpacing={3}>{r.tag}</text>
            <Cell x={xs[0]} y={y} w={ws[0]} h={rh} main={r.acc} o={1} c={TXT.ember} hl={r.hl} />
            <Cell x={xs[1]} y={y} w={ws[1]} h={rh} main={r.who} sub={r.charge} subO={r.chargeO ?? 1} o={1} hl={r.hl} />
            <Cell x={xs[2]} y={y} w={ws[2]} h={rh} main={(r.ansO ?? 1) > 0.5 ? r.ans : '?'} o={1} c={TXT.gold} hl={(r.hl ?? 0) * (r.ansO ?? 1)} size={r.ans.length > 16 && (r.ansO ?? 1) > 0.5 ? 32 : 40} />
            <path d={`M${xs[0] + ws[0] / 2 + 8},${y} L${xs[1] - ws[1] / 2 - 8},${y} M${xs[1] + ws[1] / 2 + 8},${y} L${xs[2] - ws[2] / 2 - 8},${y}`} stroke="#9C6E2C" strokeWidth={2} />
          </g>
        );
      })}
    </g>
  );
};

/* ============================ CHARGE LIST (unrolling scroll) ============================ */
export const ChargeList: React.FC<{x: number; y: number; p: number; items?: string[]; itemO?: number[]; checks?: number[]; more?: number; o?: number; burn?: number; w?: number; L?: number}> = ({x, y, p, items = [], itemO = [], checks = [], more = 0, o = 1, burn = 0, w = 420, L = 520}) => {
  if (o <= 0.001) return null;
  const h = 30 + L * eio(p);
  const nMore = Math.round(more * 14);
  return (
    <g opacity={o}>
      <defs><clipPath id={`cl${Math.round(x)}${Math.round(y)}`}><rect x={x - w / 2} y={y} width={w} height={h * (1 - burn)} /></clipPath></defs>
      <rect x={x - w / 2} y={y} width={w} height={h * (1 - burn)} fill="#1a120a" />
      <g clipPath={`url(#cl${Math.round(x)}${Math.round(y)})`}>
        {items.map((t, i) => (
          <g key={i} opacity={itemO[i] ?? 1}>
            <text x={x - w / 2 + 64} y={y + 70 + i * 62} fill={TXT.ivory} fontFamily="Cinzel" fontSize={25} letterSpacing={2}>{t}</text>
            <path d={`M${x - w / 2 + 22},${y + 60 + i * 62} l10,12 l18,-24`} fill="none" stroke={TXT.ember} strokeWidth={3.2} opacity={checks[i] ?? 0} strokeLinecap="round" strokeLinejoin="round" />
          </g>
        ))}
        {Array.from({length: nMore}, (_, i) => <path key={'m' + i} d={`M${x - w / 2 + 30},${y + 70 + items.length * 62 + i * 30} L${x + w / 2 - 30 - (i % 3) * 40},${y + 70 + items.length * 62 + i * 30}`} stroke="#9C6E2C" strokeWidth={2} opacity={0.6 * clamp(more * 14 - i)} />)}
      </g>
      <Line u w={2} d={`M${x - w / 2},${y} L${x - w / 2},${y + h * (1 - burn)} M${x + w / 2},${y} L${x + w / 2},${y + h * (1 - burn)}`} o={0.8} />
      <rect x={x - w / 2 - 16} y={y - 12} width={w + 32} height={22} rx={11} fill="#0c0905" stroke="#C99A4A" strokeWidth={2} />
      <rect x={x - w / 2 - 16} y={y + h * (1 - burn) - 10} width={w + 32} height={22} rx={11} fill="#0c0905" stroke="#C99A4A" strokeWidth={2} opacity={1 - burn} />
      {burn > 0 && burn < 1 ? <><rect x={x - w / 2} y={y + h * (1 - burn) - 8} width={w} height={16} fill="#F6C46E" opacity={0.8} filter="url(#lglow)" /><ellipse cx={x} cy={y + h * (1 - burn)} rx={w * 0.7} ry={60} fill="url(#halo)" /></> : null}
    </g>
  );
};

/* ============================ BRAND SNATCHED FROM FIRE ============================ */
export const Brand: React.FC<{x: number; y: number; f: number; t: number; s?: number; o?: number}> = ({x, y, f, t, s = 1, o = 1}) => {
  if (o <= 0.001) return null;
  const u = eio(t);
  const w = (k: number) => Math.sin(f / 4 + k) * 7;
  return (
    <g opacity={o} transform={G(x, y, s)}>
      <ellipse cx={0} cy={-60} rx={240} ry={160} fill="url(#halo)" opacity={1} />
      {[[-60, 0, 110], [0, 0, 150], [60, 0, 120], [-20, 0, 90], [30, 0, 100]].map(([px, py, h], i) => <path key={i} d={flame(px, py, h, f, i * 2.1)} fill={i % 2 ? '#F6C46E' : '#E89A4C'} opacity={0.85} filter="url(#lglow)" />)}
      <Line w={2.2 / s} d="M-120,4 L110,-10 M-110,-8 L120,6" />
      <g transform={`translate(${-40 - 160 * u} ${-40 - 260 * u}) rotate(${-30 + 50 * u})`}>
        <rect x={-10} y={-160} width={20} height={200} rx={8} fill="#140c06" stroke="#9C6E2C" strokeWidth={2} />
        <ellipse cx={0} cy={36} rx={22} ry={18} fill="#F08A50" opacity={0.95} filter="url(#lglow)" />
        <path d={`M-12,40 C-16,${60 + w(1)} -4,${76 + w(2)} ${2 + w(3)},${92} C10,76 16,62 12,40 Z`} fill="#F6C46E" opacity={1 - u * 0.6} filter="url(#lglow)" />
      </g>
    </g>
  );
};

/* ============================ GHOST SHRINE ============================ */
export const Shrine: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <path d="M-200,0 L-200,-200 C-200,-330 200,-330 200,-200 L200,0 Z" fill="none" stroke="#C99A4A" strokeWidth={2.4 / s} strokeDasharray="14 12" opacity={p} />
    <path d="M-240,0 L240,0 M-60,0 L-60,-120 C-60,-170 60,-170 60,-120 L60,0 M0,-330 L0,-390 M-24,-366 L24,-366" fill="none" stroke="#C99A4A" strokeWidth={2.2 / s} strokeDasharray="14 12" opacity={p} />
  </g>
);

/* ============================ HIDDEN GRAVE (valley) ============================ */
export const Valley: React.FC<{f: number; o?: number; p?: number; grave?: number; seal?: number; q?: number; label?: number}> = ({f, o = 1, p = 1, grave = 0, seal = 0, q = 0, label = 0}) => {
  if (o <= 0.001) return null;
  return (
    <g opacity={o}>
      <path d="M-40,520 C220,560 520,760 860,860 C1000,900 1160,880 1300,820 C1560,700 1760,560 1960,520 L1960,1100 L-40,1100 Z" fill="#0b0805" opacity={0.85} />
      <Line u w={2.4} p={p} d="M-40,520 C220,560 520,760 860,860 C1000,900 1160,880 1300,820 C1560,700 1760,560 1960,520" />
      <Line u w={1.4} p={p} o={0.35} d="M300,650 C420,690 520,740 600,780 M1500,700 C1600,650 1700,610 1800,590" />
      <g opacity={grave}>
        <ellipse cx={1060} cy={866} rx={220} ry={90} fill="url(#halo)" opacity={1 - seal * 0.7} />
        <path d="M990,872 C1010,850 1110,850 1130,872 Z" fill="#E8B455" opacity={0.35 * (1 - seal)} />
        <Line u w={2} d="M980,874 C1010,846 1110,846 1140,874" c="#E3C17E" o={1 - seal * 0.8} />
      </g>
      <text x={1060} y={800} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={110} opacity={q}>?</text>
      <text x={1060} y={980} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={32} letterSpacing={6} opacity={label}>BETH PEOR</text>
    </g>
  );
};

/* ============================ TIMELINE BAR ============================ */
export const TimeBar: React.FC<{f: number; a: number; b?: number; l: string; r: string; mid: string; y?: number; dot?: number}> = ({f, a, b, l, r, mid, y = 600, dot = 1}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const p = eio(ramp(f, a + 6, 40)), dx = 360 + 1200 * eio(clamp(dot)) * p;
  return (
    <g opacity={o}>
      <Line u w={2.6} p={p} c="#E3B465" d={`M360,${y} L1560,${y}`} />
      <circle cx={360} cy={y} r={14} fill="#E8B455" />
      <circle cx={1560} cy={y} r={14} fill="#E8B455" opacity={p} />
      <circle cx={dx} cy={y} r={50} fill="url(#halo)" /><circle cx={dx} cy={y} r={9} fill="#FFE2A0" filter="url(#lglow)" />
      <text x={360} y={y + 70} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={38} letterSpacing={5}>{l}</text>
      <text x={1560} y={y + 70} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={38} letterSpacing={5} opacity={p}>{r}</text>
      <text x={960} y={y - 40} textAnchor="middle" fill={TXT.ivory} fontFamily="Corm" fontStyle="italic" fontSize={48} opacity={fi(f, a + 30)}>{mid}</text>
    </g>
  );
};

/* ============================ WORD BOXES (four words) ============================ */
export const WordBoxes: React.FC<{f: number; a: number; b?: number; words: string[]; keys: number[]; y?: number}> = ({f, a, b, words, keys, y = 560}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const n = words.length, w = 330, g = 30, x0 = 960 - ((n * w + (n - 1) * g) / 2) + w / 2;
  return (
    <g opacity={o}>
      {words.map((t, i) => {
        const on = eout(ramp(f, keys[i] ?? a, 10));
        const x = x0 + i * (w + g);
        return (
          <g key={i} opacity={0.35 + 0.65 * on}>
            {on > 0 ? <ellipse cx={x} cy={y} rx={200} ry={110} fill="url(#halo)" opacity={on} /> : null}
            <rect x={x - w / 2} y={y - 70} width={w} height={140} fill="#000" opacity={0.45} />
            <rect x={x - w / 2} y={y - 70} width={w} height={140} fill="none" stroke="url(#goldLine)" strokeWidth={2 + on} filter="url(#lglow)" />
            <text x={x} y={y + 18} textAnchor="middle" fill={on > 0.5 ? TXT.gold : TXT.ivory} fontFamily="Cinzel" fontSize={52} letterSpacing={3}>{t}</text>
          </g>
        );
      })}
    </g>
  );
};
