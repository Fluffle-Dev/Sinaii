import W from './words.json';
export const FPS = 30;
export type Word = {t: string; n: string; s: number; e: number};
export const words = W as Word[];
export const END = Math.ceil((words[words.length - 1].e + 2.4) * FPS);
const nz = (s: string) => s.toLowerCase().replace(/[’']/g, '').split(/\s+/).map((x) => x.replace(/[^a-z0-9]/g, '')).filter(Boolean);
function find(phrase: string, nth: number) {
  const q = nz(phrase); let hit = 0;
  for (let i = 0; i <= words.length - q.length; i++) {
    let ok = true;
    for (let k = 0; k < q.length; k++) if (words[i + k].n !== q[k]) { ok = false; break; }
    if (ok && ++hit === nth) return i;
  }
  throw new Error(`phrase not found: "${phrase}" #${nth}`);
}
export const at = (p: string, nth = 1) => Math.round(words[find(p, nth)].s * FPS);
export const atEnd = (p: string, nth = 1) => Math.round(words[find(p, nth) + nz(p).length - 1].e * FPS);
export const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x));
export const ramp = (f: number, s: number, d: number) => clamp((f - s) / Math.max(1, d));
export const eio = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const eout = (t: number) => 1 - Math.pow(1 - t, 3);
/** fade in at s over d frames */
export const fi = (f: number, s: number, d = 14) => eout(ramp(f, s, d));
/** fade out starting at s */
export const fo = (f: number, s: number | undefined, d = 14) => (s === undefined ? 1 : 1 - eio(ramp(f, s, d)));
/** visible window */
export const win = (f: number, a: number, b?: number, d = 14) => fi(f, a, d) * fo(f, b, d);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
/** keyframed value: [[frame, value], ...] eased between keys */
export const kf = (f: number, keys: [number, number][], dur = 20) => {
  let v = keys[0][1];
  for (const [k, val] of keys) { if (f >= k) v = lerp(v, val, eio(ramp(f, k, dur))); }
  return v;
};
export const rng = (seed: number) => { let s = seed; return () => { s = (s * 16807) % 2147483647; return s / 2147483647; }; };
