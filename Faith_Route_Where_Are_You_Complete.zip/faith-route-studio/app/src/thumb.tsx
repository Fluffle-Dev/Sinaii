import React from 'react';
import {AbsoluteFill, staticFile} from 'remotion';
import {Defs, Fig} from './fig';
import {Spot, Ground, GY} from './stage';
import {Beam} from './covprops';
import {FigTree} from './figprops';
import {ADAM, EVE} from './scenes/ay1';

export const Thumb: React.FC<{v: number}> = ({v}) => {
  const lines =
    v === 1
      ? [['WHERE', '#F1E6CF'], ['ARE YOU?', '#E9BE6E']]
      : v === 2
      ? [['HE ALREADY', '#F1E6CF'], ['KNEW.', '#E9BE6E']]
      : [['STOP', '#F1E6CF'], ['HIDING.', '#E2785A']];
  return (
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 72% 35%, #6b4719 0%, #2a1b0b 45%, #0d0905 100%)'}}>
      <style>{`
        @font-face{font-family:CinzelB;src:url(${staticFile('fonts/cinzel-latin-700-normal.woff2')}) format('woff2')}
        @font-face{font-family:Heb;src:url(${staticFile('fonts/noto-serif-hebrew-hebrew-500-normal.woff2')}) format('woff2')}
      `}</style>
      <svg width={0} height={0} style={{position: 'absolute'}}><Defs /></svg>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute'}}>
        <g transform="translate(1410 1080) scale(1.18) translate(-1310 -900)">
          <Spot id="th" x={1350} y={500} r={760} a={0.75} />
          <Ground id="thg" cx={1350} />
          <Beam x={1230} w={290} o={0.85} f={0} bottom={GY} />
          <Fig {...ADAM(1470, {flip: true, robe: 'stoop', head: 18, bend: 14, sc: 0.34})} />
          <Fig {...EVE(1590, {flip: true, robe: 'stoop', head: 18, bend: 14, sc: 0.31})} />
          <FigTree x={1380} y={GY} s={1.15} leaf={1} fruit={1} o={0.92} seed={12} />
        </g>
        <defs>
          <radialGradient id="vig" cx="0.62" cy="0.45" r="0.82">
            <stop offset="0.52" stopColor="#000" stopOpacity={0} />
            <stop offset="1" stopColor="#000" stopOpacity={0.72} />
          </radialGradient>
        </defs>
        <rect width={1920} height={1080} fill="url(#vig)" />
      </svg>
      <div style={{position: 'absolute', left: 96, top: 205, fontFamily: 'Heb', fontSize: 120, color: 'rgba(233,190,110,0.28)', direction: 'rtl'}}>
        אַיֶּכָּה
      </div>
      <div style={{position: 'absolute', left: 90, top: 375, fontFamily: 'CinzelB', lineHeight: 1.02}}>
        {lines.map(([s, c], i) => (
          <div key={i} style={{fontSize: i === 0 ? 158 : 186, color: c, textShadow: '0 6px 24px rgba(0,0,0,0.88)'}}>
            {s}
          </div>
        ))}
      </div>
    </AbsoluteFill>
  );
};
