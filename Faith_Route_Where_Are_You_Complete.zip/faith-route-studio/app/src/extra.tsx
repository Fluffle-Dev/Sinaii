import React from 'react';
import {Line, Cut, MET} from './fig';

/** glowing column (pillar of cloud or fire) */
export const Pillar: React.FC<{x: number; y: number; h?: number; fire?: boolean; f: number; o?: number}> = ({x, y, h = 620, fire = false, f, o = 1}) => {
  const w = 70 + Math.sin(f / 13) * 6;
  const id = fire ? 'pilF' : 'pilC';
  return (
    <g opacity={o}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={fire ? '#FFD38A' : '#E9DFC8'} stopOpacity={0} />
          <stop offset="0.25" stopColor={fire ? '#F2B24E' : '#D8CCB2'} stopOpacity={0.55} />
          <stop offset="1" stopColor={fire ? '#E09A3A' : '#B8A88A'} stopOpacity={0.15} />
        </linearGradient>
      </defs>
      <ellipse cx={x} cy={y - h * 0.45} rx={w * 2.6} ry={h * 0.62} fill="url(#halo)" opacity={fire ? 0.9 : 0.45} />
      <path d={`M${x - w * 0.5},${y} C${x - w * 0.9},${y - h * 0.4} ${x - w * 0.5 + Math.sin(f / 17) * 10},${y - h * 0.8} ${x - w * 0.3},${y - h} L${x + w * 0.3},${y - h} C${x + w * 0.5 + Math.sin(f / 19) * 10},${y - h * 0.8} ${x + w * 0.9},${y - h * 0.4} ${x + w * 0.5},${y} Z`} fill={`url(#${id})`} />
    </g>
  );
};

/** manna flakes on the ground */
export const Flakes: React.FC<{x0: number; x1: number; y: number; n?: number; f: number; a: number; o?: number; rot?: boolean}> = ({x0, x1, y, n = 70, f, a, o = 1, rot = false}) => {
  let s = 17; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  return (
    <g opacity={o}>
      {Array.from({length: n}, (_, i) => {
        const x = x0 + r() * (x1 - x0), yy = y - 2 - r() * 10, t = Math.max(0, Math.min(1, (f - a - r() * 30) / 12));
        return <ellipse key={i} cx={x} cy={yy} rx={rot ? 3 : 4} ry={rot ? 1.2 : 1.6} fill={rot ? '#7A6A48' : '#F6E2B0'} opacity={t * (rot ? 0.6 : 0.9)} filter={rot ? undefined : 'url(#lglow)'} />;
      })}
    </g>
  );
};

/** tiny wriggling marks (maggots) */
export const Wriggles: React.FC<{x0: number; x1: number; y: number; f: number; o?: number}> = ({x0, x1, y, f, o = 1}) => {
  let d = '';
  for (let i = 0; i < 18; i++) { const x = x0 + ((x1 - x0) * i) / 18 + Math.sin(i * 7) * 10, yy = y - 4 - (i % 3) * 3, k = Math.sin(f / 3 + i) * 2; d += ` M${x},${yy} q3,${-2 + k} 6,0 q3,${2 - k} 6,0`; }
  return <g opacity={o}><path d={d} stroke="#9C8A62" strokeWidth={1.4} fill="none" strokeLinecap="round" /></g>;
};

export const Pot: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}><Line w={2.2 / s} p={p} d="M-60,0 C-80,-20 -80,-70 -56,-90 L56,-90 C80,-70 80,-20 60,0 Z M-66,-90 L66,-90 M-70,-80 L-86,-84 M70,-80 L86,-84" /></g>
);
export const Jar: React.FC<{x: number; y: number; s?: number; o?: number}> = ({x, y, s = 1, o = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}><Line w={2 / s} d="M-22,0 C-34,-14 -34,-46 -18,-58 L-12,-70 L12,-70 L18,-58 C34,-46 34,-14 22,0 Z M-14,-70 L14,-70" /></g>
);
export const Bread: React.FC<{x: number; y: number; s?: number; o?: number}> = ({x, y, s = 1, o = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}><Line w={2 / s} d="M-40,0 C-44,-20 -20,-30 0,-30 C20,-30 44,-20 40,0 Z M-20,-22 L-14,-12 M0,-26 L4,-14 M18,-22 L22,-12" /></g>
);
export const Sandal: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}><Line w={2.2 / s} p={p} d="M-130,0 C-138,-14 -122,-24 -100,-24 L112,-24 C132,-24 140,-12 134,0 Z M-70,-24 C-60,-74 -20,-96 14,-86 C40,-70 60,-46 72,-24 M-110,-24 C-120,-64 -96,-92 -60,-90" /></g>
);

/** rock outcrop with a cave mouth */
export const Cave: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <Line w={2 / s} p={p} d="M-420,0 C-400,-120 -330,-260 -200,-300 C-80,-340 60,-320 160,-270 C280,-210 360,-110 420,0 M-150,0 C-150,-110 -90,-170 0,-170 C90,-170 150,-110 150,0 M-300,-180 L-250,-160 M200,-200 L250,-170 M60,-280 L110,-262" />
  </g>
);

/** broom bush (Retama): thin upright twigs */
export const Broom: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => {
  let d = 'M0,0 L0,-40';
  for (let i = -5; i <= 5; i++) { const a = i * 0.16; d += ` M0,-30 L${Math.sin(a) * 200},${-30 - Math.cos(a) * 180}`; d += ` M${Math.sin(a) * 90},${-30 - Math.cos(a) * 80} L${Math.sin(a + 0.25) * 150},${-30 - Math.cos(a + 0.25) * 150}`; }
  return <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}><Line w={1.6 / s} p={p} d={d} /></g>;
};

export const Mountain: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <Line w={2 / s} p={p} d="M-520,0 L-300,-180 L-200,-140 L-40,-380 L60,-300 L140,-340 L320,-160 L520,0 M-40,-380 L-10,-250 L-60,-120 M140,-340 L120,-220" />
  </g>
);

/** dove descending (line) */
export const Dove: React.FC<{x: number; y: number; s?: number; o?: number; f: number}> = ({x, y, s = 1, o = 1, f}) => {
  const w = Math.sin(f / 5) * 18;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
      <ellipse cx={0} cy={0} rx={120} ry={90} fill="url(#halo)" opacity={0.8} />
      <path d={`M-40,0 C-20,-10 20,-10 40,0 C30,8 -20,10 -40,0 Z M-6,-4 C-30,${-40 - w} -70,${-50 - w} -100,${-30 - w} C-70,${-20 - w / 2} -40,-10 -6,-4 Z M6,-4 C30,${-40 - w} 70,${-50 - w} 100,${-30 - w} C70,${-20 - w / 2} 40,-10 6,-4 Z M40,0 L54,-6 L46,4 Z`} fill="#F4E6C4" filter="url(#lglow)" />
    </g>
  );
};

export const River: React.FC<{y: number; x0?: number; x1?: number; o?: number; f: number}> = ({y, x0 = 0, x1 = 1920, o = 1, f}) => {
  const ph = f / 12;
  const wave = (yy: number, a: number) => { let d = `M${x0},${yy}`; for (let x = x0; x <= x1; x += 40) d += ` L${x},${yy + Math.sin(x / 90 + ph + a) * 5}`; return d; };
  return <g opacity={o}><Line w={1.4} d={wave(y, 0)} o={0.7} /><Line w={1.2} d={wave(y + 22, 1.4)} o={0.45} /><Line w={1} d={wave(y + 42, 2.6)} o={0.3} /></g>;
};

export const Stones: React.FC<{x: number; y: number; o?: number; lit?: number}> = ({x, y, o = 1, lit = 1}) => (
  <Cut m="bronze" lit={lit} o={o} tf={`translate(${x} ${y})`}>
    <path d="M-80,0 C-86,-22 -66,-34 -46,-30 C-30,-28 -24,-12 -28,0 Z" /><path d="M-20,0 C-24,-30 6,-44 30,-36 C48,-30 50,-10 44,0 Z" /><path d="M54,0 C52,-16 66,-24 80,-20 C92,-16 92,-6 90,0 Z" />
  </Cut>
);

/** wings for an angel figure (drawn behind the figure) */
export const Wings: React.FC<{x: number; y: number; s?: number; flip?: boolean; o?: number; f: number}> = ({x, y, s = 1, flip = false, o = 1, f}) => {
  const k = Math.sin(f / 20) * 4;
  return (
    <g transform={`translate(${x} ${y}) scale(${(flip ? -1 : 1) * s} ${s})`} opacity={o}>
      <ellipse cx={-60} cy={-120} rx={200} ry={200} fill="url(#halo)" opacity={0.7} />
      <Line w={2 / s} d={`M0,-180 C-60,${-260 - k} -160,${-280 - k} -220,${-220 - k} C-180,-200 -150,-160 -140,-110 M-20,-150 C-80,-200 -160,-200 -200,-160 M-30,-120 C-80,-150 -140,-150 -170,-120`} />
    </g>
  );
};

export const Altar: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => {
  let d = 'M-100,0 L-100,-120 L100,-120 L100,0';
  for (let r = 1; r < 5; r++) for (let k = 0; k < 4; k++) { const yy = -r * 24, xx = -92 + k * 50 + (r % 2) * 20; d += ` M${xx},${yy} L${xx + 26},${yy}`; }
  return <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}><Line w={2 / s} p={p} d={d} /></g>;
};

export const Door: React.FC<{x: number; y: number; open?: number; o?: number}> = ({x, y, open = 0, o = 1}) => (
  <g opacity={o}>
    <Line d={`M${x - 90},${y} L${x - 90},${y - 300} L${x + 90},${y - 300} L${x + 90},${y}`} />
    <Line w={1.6} d={`M${x - 90},${y} L${x - 90 + 180 * (1 - open)},${y - 6 * open} L${x - 90 + 180 * (1 - open)},${y - 300 + 10 * open} L${x - 90},${y - 300}`} o={0.8} />
  </g>
);

/** Sinai map: Egypt, the coast road, the wilderness route, Canaan */
export const SinaiMap: React.FC<{coast: number; long: number; xmark: number; o?: number}> = ({coast, long, xmark, o = 1}) => (
  <g opacity={o}>
    <Line w={1.4} o={0.55} d="M120,330 C300,300 520,290 700,320 C860,346 1000,330 1120,280 C1220,236 1300,180 1360,120" />
    <Line w={1.4} o={0.45} d="M760,1000 C820,860 900,760 980,700 C1060,640 1120,560 1150,470 M1300,1000 C1260,880 1240,780 1250,700 C1260,620 1300,560 1330,470" />
    <path d="M520,520 C620,420 820,360 1000,340 C1120,326 1220,300 1300,250" fill="none" stroke="#E0AE60" strokeWidth={3} strokeDasharray="10 12" pathLength={1} opacity={0.9 * Math.min(1, coast * 2)} filter="url(#lglow)" />
    <g opacity={xmark}><Line w={3} d="M860,330 L940,410 M940,330 L860,410" c="#E9BE6E" /></g>
    <path d="M520,520 C600,640 760,740 900,800 C1020,850 1100,820 1140,720 C1180,620 1180,520 1230,420 C1260,360 1290,300 1300,250" fill="none" stroke="#F3D08A" strokeWidth={3.4} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - long} filter="url(#lglow)" />
    <circle cx={520} cy={520} r={8} fill="#F3D08A" filter="url(#lglow)" />
    <circle cx={1300} cy={250} r={8} fill="#F3D08A" filter="url(#lglow)" opacity={Math.max(coast, long) > 0.2 ? 1 : 0} />
  </g>
);

/** side profile from the sea, over the Judean hills, down to the Dead Sea */
export const RainProfile: React.FC<{p: number; rain: number; shadow: number; f: number; o?: number}> = ({p, rain, shadow, f, o = 1}) => {
  const ridge = 'M80,820 C300,800 500,720 700,560 C760,510 820,480 880,476 C940,474 990,500 1040,560 C1180,720 1380,860 1560,900 C1680,926 1780,930 1860,930';
  let rd = '';
  for (let i = 0; i < 14; i++) { const x = 360 + i * 36, yy = 300 + ((f * 6 + i * 37) % 140); rd += ` M${x},${yy} l-8,22`; }
  return (
    <g opacity={o}>
      <Line w={2.2} p={p} d={ridge} />
      <Line w={1.2} o={0.5 * p} d="M1560,930 L1860,930 M1600,940 L1820,940" />
      <g opacity={rain}>
        <Line w={1.8} d="M300,250 C300,210 360,196 390,214 C410,180 480,180 500,214 C540,200 580,222 570,256 C580,276 560,292 530,288 L320,288 C290,288 280,266 300,250 Z" />
        <Line w={1.8} d="M560,300 C560,270 600,260 620,272 C636,248 686,248 700,272 C728,262 756,280 748,304 C754,318 742,330 720,328 L580,328 C556,328 548,312 560,300 Z" />
        <path d={rd} stroke="#D8C49A" strokeWidth={1.6} opacity={0.6} strokeLinecap="round" />
      </g>

    </g>
  );
};
export {MET};
