import React from 'react';
import {FigP, Fig} from './fig';
import {win, fi, kf, eio, ramp} from './lib';
import {GY} from './stage';

export {GY};
/** Jesus: gold, mantle */
export const JP = (x: number, o: Partial<FigP> = {}): FigP => ({x, y: GY, m: 'gold', sc: 0.33, mantle: true, beard: 'short', lit: o.flip ? -1 : 1, arm: [-5, -36], ...o});
/** disciple / chosen (gold, plain) */
export const DP = (x: number, o: Partial<FigP> = {}): FigP => ({x, y: GY, m: 'gold', sc: 0.31, lit: o.flip ? -1 : 1, arm: [-5, -36], ...o});
/** ordinary person (bronze) */
export const BP = (x: number, o: Partial<FigP> = {}): FigP => ({x, y: GY, m: 'bronze', sc: 0.3, lit: o.flip ? -1 : 1, arm: [-5, -36], ...o});
/** leader / official (silver) */
export const SP = (x: number, o: Partial<FigP> = {}): FigP => ({x, y: GY, m: 'silver', sc: 0.32, lit: o.flip ? -1 : 1, arm: [-5, -36], mantle: true, beard: 'long', ...o});

/** figure in window [a,b) with optional x keyframes and settle */
export const F = (f: number, a: number, b: number | undefined, p: FigP, k?: string | number, xs?: [number, number][], dur = 40) => {
  const x = xs ? kf(f, xs, dur) : p.x;
  return <Fig key={k} {...p} x={x} o={(p.o ?? 1) * win(f, a, b, 16)} y={p.y + (1 - fi(f, a, 18)) * 10} />;
};
/** group fade */
export const Gp: React.FC<{o: number; children: React.ReactNode}> = ({o, children}) => (o <= 0.001 ? null : <g opacity={o}>{children}</g>);
/** progress of a line draw starting at a */
export const pr = (f: number, a: number, d = 36) => eio(ramp(f, a, d));

/** eased value change: from a to b starting at frame t over d frames */
export const ez = (f: number, t: number, a: number, b: number, d = 12) => a + (b - a) * eio(ramp(f, t, d));
/** eased arm pose change */
export const ezArm = (f: number, t: number, a: [number, number], b: [number, number], d = 12): [number, number] => [ez(f, t, a[0], b[0], d), ez(f, t, a[1], b[1], d)];
/** facing value for a turn at frame t (1 -> -1 or reverse) */
export const turn = (f: number, t: number, from = 1, d = 10) => from * Math.cos(Math.PI * eio(ramp(f, t, d)));
/** walk along x from x0 to x1 between frames t0..t1 (eased); returns {x, walk, wa} to spread into Fig */
export const walkX = (f: number, t0: number, t1: number, x0: number, x1: number, stride = 70) => {
  const d = Math.max(1, t1 - t0);
  const X = (ff: number) => x0 + (x1 - x0) * eio(ramp(ff, t0, d));
  const x = X(f), v = Math.abs(X(f + 1) - X(f - 1)) / 2, avg = Math.abs(x1 - x0) / d;
  const wa = Math.min(1, v / (avg * 0.9 + 1e-6));
  return {x, walk: Math.abs(x - x0) / stride, wa};
};
