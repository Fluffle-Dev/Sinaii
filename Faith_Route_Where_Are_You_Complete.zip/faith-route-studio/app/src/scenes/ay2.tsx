import React from 'react';
import {at, win, fi, ramp, eio} from '../lib';
import {Fig, Throne, Sun, Fire, TXT} from '../fig';
import {Ref, Big, Note, Name, Verse} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Mountain, Broom, Stones} from '../extra';
import {Road} from '../props';
import {FigTree, Soil} from '../figprops';
import {JP, DP, F, Gp, pr, ez, ezArm, turn} from '../kit';
import {Beam, Q} from '../covprops';
import {Temple} from '../tcprops';
import {Bush} from '../mmprops';
import {DotGrid, PathRoad} from '../psprops';
import {Palace, LampStand, Cave, StoneAltar, Whirl, Cloak, Split} from '../jzprops';
import {QuestionTrack, Spring, WindLines, QuakeCracks} from '../ayprops';
import {
  REST,
  ADAM,
  CAIN,
  ABRAHAM,
  HAGAR,
  ELI,
  JEZ,
  PPL,
  Night,
  WK,
  GardenSet,
  DesertSet,
} from './ay1';

export const AY2: Scene[] = [];
const push = (start: number, render: Scene['render']) => AY2.push({start, render});

// SCENE 12: MOUNT CARMEL & JEZEBEL'S THREAT
{
  const a0 = at('Centuries later the pattern comes back');
  const aCarm = at('Mount Carmel');
  const aFire = at('fire fell from the sky');
  const aJez = at('Then Queen Jezebel');
  const aEnd = at('Elijah broke');

  push(a0, (f) => ({
    svg: (
      <>
        <QuestionTrack active={4} />
        <Gp o={win(f, a0, aJez + 6)}>
          <Night o={0.38} />
          <Spot id="ay12a" x={860} y={560} r={920} a={0.58} />
          <Mountain x={880} y={GY} s={1.25} o={0.36} />
          <Ground id="ay12ag" cx={820} />
          <Beam x={640} w={250} o={0.9 * fi(f, aFire - 6, 16)} f={f} />
          <StoneAltar x={640} y={GY} f={f} fire={fi(f, aFire - 4, 14)} />
          <Fig {...ELI(450, {arm: ezArm(f, aFire - 10, REST, [-82, -62], 18), head: ez(f, aFire - 10, 0, -14, 16)})} />
          {[0, 1, 2, 3, 4, 5, 6].map((k) => (
            <Fig
              key={'baal' + k}
              {...PPL(960 + k * 115, {
                flip: true,
                sc: 0.24 + (k % 2) * 0.02,
                robe: k % 3 === 0 ? 'kneel' : 'stoop',
                head: 14,
                o: fi(f, aCarm + k * 4, 14),
              })}
            />
          ))}
        </Gp>

        <Gp o={fi(f, aJez, 16)}>
          <Night o={0.48} />
          <Spot id="ay12b" x={960} y={560} r={900} a={0.5} />
          <Palace f={f} />
          <Ground id="ay12bg" />
          <Throne x={1360} y={GY} />
          <LampStand x={1560} y={GY} f={f} />
          <Fig {...JEZ(1360, {robe: 'seat', bench: true, arm: ezArm(f, aJez + 12, REST, [-86, -12], 14)})} />
          <Fig {...PPL(1660, {flip: true, prop: 'spear', hair: 'helmet', sc: 0.29})} />
          <Fig {...PPL(1120, {flip: true, prop: 'spear', hair: 'helmet', sc: 0.27, o: 0.72})} />
          {WK(f, aJez + 10, aEnd, aJez + 18, aEnd, 1140, 260, PPL(0, {face: -1, sc: 0.28, head: 6}), 'msg12')}
        </Gp>
      </>
    ),
    html: (
      <>
        <Ref f={f} a={a0 + 4} b={aJez} y={62} size={28}>1 KINGS 18–19 · ELIJAH</Ref>
        <Note f={f} a={a0 + 12} b={aFire} y={116} size={46}>alone on Mount Carmel against 450 prophets of Baal</Note>
        <Big f={f} a={aFire - 4} b={aJez} y={165} size={66} c={TXT.gold}>FIRE FELL FROM THE SKY</Big>
        <Note f={f} a={aJez + 6} b={aEnd} y={82} size={48}>Queen Jezebel swore to kill him by morning</Note>
      </>
    ),
  }));
}

// SCENE 13: BROOM TREE & FORTY DAYS TO MOUNT HOREB
{
  const a0 = at('Elijah broke');
  const aBroom = at('sat under a broom tree');
  const aForty = at('Then he walked forty days');
  const aMoses = at('where Moses had stood before God');
  const aCave = at('went inside a cave');
  const aEnd = at('There the word of the Lord');

  push(a0, (f) => ({
    svg: (
      <>
        <QuestionTrack active={4} />
        <Gp o={win(f, a0, aForty + 6)}>
          <DesertSet id="ay13a" night={0.32} cx={960} />
          <Broom x={1120} y={GY} s={1.18} />
          <Gp o={win(f, a0, aBroom + 6)}>
            {WK(f, a0, aBroom + 6, a0, aBroom, 320, 980, ELI(0, {face: 1, head: 14, bend: 10}), 'el13r')}
          </Gp>
          <Gp o={fi(f, aBroom, 16)}>
            <Fig {...ELI(1030, {robe: 'seat', head: 24, bend: 16, arm: [-30, -45]})} />
          </Gp>
        </Gp>

        <Gp o={fi(f, aForty, 16)}>
          <Night o={0.38} />
          <Spot id="ay13b" x={960} y={600} r={940} a={0.52} />
          <Sun x={380 + 700 * eio(ramp(f, aForty, Math.max(30, aEnd - aForty)))} y={230} r={24} t={f} o={0.55} />
          <Mountain x={1480} y={GY} s={1.25} o={0.45} />
          <Cave x={1480} y={GY} s={0.85} glow={0.25} />
          <Road x0={160} x1={1420} y={GY} p={pr(f, aForty, 40)} />
          <Ground id="ay13bg" />
          <Gp o={win(f, aMoses - 6, aCave + 8)}>
            <Beam x={1480} w={220} o={0.42} f={f} />
            <Fig {...DP(1460, {hair: 'cloth', beard: 'long', mantle: true, prop: 'staff', sc: 0.28, o: 0.48})} />
          </Gp>
          {WK(f, aForty, aEnd, aForty, aCave + 24, 240, 1460, ELI(0, {face: 1, prop: 'staff', head: 14, bend: 10}), 'el13w')}
        </Gp>
      </>
    ),
    html: (
      <>
        <Note f={f} a={a0 + 6} b={aForty} y={84} size={48}>he sat under a broom tree and asked God to take his life</Note>
        <Ref f={f} a={aForty + 4} b={aEnd} y={62} size={28}>FORTY DAYS · MOUNT HOREB (SINAI)</Ref>
        <Note f={f} a={aMoses} b={aCave} y={118} size={46}>the same mountain where Moses had stood before God</Note>
        <Note f={f} a={aCave} b={aEnd} y={118} size={46}>and he went inside a cave</Note>
      </>
    ),
  }));
}

// SCENE 14: MAH-LECHA POH ELIYAHU & ELIJAH'S REHEARSED SPEECH
{
  const a0 = at('There the word of the Lord');
  const aWhat = at('what are you doing here', 1);
  const aSpeech = at('Elijah answers with a speech');
  const aAltars = at('torn down your altars');
  const aOnly = at('I am the only one left', 1);
  const aEnd = at('God tells him to go stand');

  push(a0, (f) => ({
    svg: (
      <>
        <Night o={0.52} />
        <Spot id="ay14" x={960} y={600} r={900} a={0.52} />
        <Cave x={1220} y={GY} s={1.15} glow={0.35} />
        <Ground id="ay14g" />
        <QuestionTrack active={4} />
        <Beam x={640} w={280} o={0.82 * fi(f, a0, 20)} f={f} />

        <Gp o={win(f, a0, aSpeech + 6)}>
          <Fig {...ELI(1200, {flip: true, robe: 'seat', head: ez(f, aWhat - 10, 18, -4, 16)})} />
        </Gp>

        <Gp o={fi(f, aSpeech, 16)}>
          <Fig {...ELI(1160, {flip: true, arm: ezArm(f, aSpeech + 14, REST, [-82, -20], 16), head: -4})} />
          <Gp o={fi(f, aAltars - 6, 18) * 0.62}>
            <Stones x={360} y={GY} o={0.85} />
            <Fig {...PPL(280, {robe: 'kneel', head: 22, sc: 0.24})} />
            <Fig {...PPL(430, {robe: 'kneel', head: 22, sc: 0.24, flip: true})} />
            <Fig {...PPL(580, {flip: true, prop: 'spear', hair: 'helmet', sc: 0.26})} />
          </Gp>
        </Gp>
      </>
    ),
    html: (
      <>
        <Verse
          f={f}
          a={a0 + 12}
          b={aSpeech}
          e={aWhat + 18}
          refText="1 KINGS 19:9"
          orig="מַה־לְּךָ פֹה אֵלִיָּהוּ"
          origKey={[0, 1]}
          eng="*What are you doing here*, Elijah?"
          keys={[aWhat]}
          y={58}
        />
        <Note f={f} a={aSpeech + 6} b={aOnly} y={76} size={46}>a speech rehearsed for forty days</Note>
        <Q
          f={f}
          a={aOnly - 8}
          b={aEnd}
          refText="1 KINGS 19:10"
          eng="“*I am the only one left*, and now they are trying to kill me too.”"
          keys={[aOnly]}
          y={64}
        />
      </>
    ),
  }));
}

// SCENE 15: WIND, EARTHQUAKE, FIRE, THIN SILENCE
{
  const a0 = at('God tells him to go stand');
  const aWind = at('A wind tears the mountain');
  const aQuake = at('An earthquake shakes the rock');
  const aFire = at('A fire sweeps past');
  const aStill = at('Then comes kol demamah');
  const aEnd = at('Elijah wraps his cloak');

  push(a0, (f) => {
    const inQuake = f >= aQuake && f < aFire;
    const qx = inQuake ? Math.sin(f * 2.4) * 10 : 0;
    const qy = inQuake ? Math.cos(f * 2.9) * 6 : 0;
    return {
      svg: (
        <>
          <g transform={`translate(${qx} ${qy})`}>
            <Night o={0.55} />
            <Spot
              id="ay15"
              x={960}
              y={580}
              r={940}
              a={0.54}
              c={f >= aFire && f < aStill ? '#a34820' : '#8C6431'}
            />
            <Mountain x={960} y={GY} s={1.3} o={0.38} />
            <Cave x={1340} y={GY} s={1.08} glow={0.2} />
            <Ground id="ay15g" />
            <Fig
              {...ELI(1160, {
                flip: true,
                bend: f >= aWind && f < aStill ? 10 : 0,
                head: f >= aStill ? -6 : 12,
                arm: ezArm(f, aWind, REST, [-45, -70], 14),
              })}
            />
            <Gp o={win(f, aWind - 4, aQuake + 6)}>
              <Whirl x={620} y={GY} f={f} h={760} o={0.78} />
              <WindLines f={f} o={0.85} />
            </Gp>
            <Gp o={win(f, aQuake - 4, aFire + 6)}>
              <QuakeCracks p={pr(f, aQuake, 24)} />
            </Gp>
            <Gp o={win(f, aFire - 4, aStill + 6)}>
              <Fire x={520} y={GY} s={2.1} f={f} />
              <Fire x={780} y={GY} s={1.8} f={f + 15} />
              <Fire x={340} y={GY} s={1.5} f={f + 32} />
            </Gp>
            <Gp o={fi(f, aStill, 24)}>
              <Beam x={760} w={140} o={0.72} f={f} />
            </Gp>
          </g>
          <QuestionTrack active={4} />
        </>
      ),
      html: (
        <>
          <Note f={f} a={a0 + 4} b={aWind} y={84} size={48}>stand at the mouth of the cave</Note>
          <Big f={f} a={aWind} b={aQuake} y={150} size={64} c={TXT.ivory}>NOT IN THE WIND</Big>
          <Big f={f} a={aQuake} b={aFire} y={150} size={64} c={TXT.ivory}>NOT IN THE EARTHQUAKE</Big>
          <Big f={f} a={aFire} b={aStill} y={150} size={64} c={TXT.ember}>NOT IN THE FIRE</Big>
          <Verse
            f={f}
            a={aStill}
            b={aEnd}
            e={aEnd - 15}
            refText="1 KINGS 19:12"
            orig="קוֹל דְּמָמָה דַקָּה"
            origKey={[0, 1, 2]}
            eng="the sound of a *thin silence*"
            keys={[aStill + 30]}
            y={64}
          />
        </>
      ),
    };
  });
}

// SCENE 16: CLOAK OVER FACE & REPEATED QUESTION / SPEECH
{
  const a0 = at('Elijah wraps his cloak');
  const aAsk = at('What are you doing here Elijah', 2);
  const aRep = at('And Elijah gives the exact same speech');
  const aEnd = at('He is too worn out');

  push(a0, (f) => ({
    svg: (
      <>
        <Night o={0.58} />
        <Spot id="ay16" x={960} y={600} r={880} a={0.48} />
        <Cave x={1260} y={GY} s={1.15} glow={0.22} />
        <Ground id="ay16g" />
        <QuestionTrack active={4} />
        <Beam x={680} w={180} o={0.78} f={f} />
        <Gp o={win(f, a0, aRep + 6)}>
          {WK(f, a0, aRep + 6, a0, aAsk - 6, 1260, 1080, ELI(0, {face: -1, head: 14, arm: [-102, -52]}), 'el16')}
        </Gp>
        <Gp o={fi(f, aRep, 16)}>
          <Fig {...ELI(1080, {flip: true, head: 18, bend: 10, arm: ezArm(f, aRep + 10, [-102, -52], [-72, -25], 18)})} />
        </Gp>
      </>
    ),
    html: (
      <>
        <Q
          f={f}
          a={aAsk - 6}
          b={aRep}
          refText="1 KINGS 19:13"
          eng="“*What are you doing here*, Elijah?”"
          keys={[aAsk]}
          y={68}
        />
        <Note f={f} a={aRep + 6} b={aEnd} y={72} size={46} c={TXT.dim}>word for word, the exact same speech again</Note>
        <Note f={f} a={aRep + 48} b={aEnd} y={136} size={48}>“I have been zealous. I am the only one left.”</Note>
      </>
    ),
  }));
}

// SCENE 17: ROAD BACK, ELISHA & 7,000 WHO NEVER BOWED
{
  const a0 = at('He is too worn out');
  const aRoad = at('He gives Elijah a road back');
  const aElisha = at('student named Elisha');
  const aSeven = at('There are seven thousand');
  const aNever = at('He was never the only one left');
  const aEnd = at('Look at all four moments');

  push(a0, (f) => ({
    svg: (
      <>
        <QuestionTrack active={4} />
        <Gp o={win(f, a0, aSeven + 6)}>
          <Spot id="ay17a" x={960} y={600} r={920} a={0.55} />
          <Cave x={280} y={GY} s={0.78} o={0.55} />
          <PathRoad p={pr(f, aRoad, 36)} />
          <Ground id="ay17ag" />
          <Beam x={960} w={300} o={0.75 * fi(f, aRoad, 22)} f={f} />
          {WK(f, a0, aSeven + 6, aRoad, aElisha + 16, 460, 880, ELI(0, {face: 1}), 'el17')}
          {F(f, aElisha - 10, aSeven + 6, DP(1180, {flip: true, hair: 'cloth', beard: 'short', sc: 0.3}), 'elsh')}
          <Cloak x={1030} y={GY - 260} o={fi(f, aElisha + 18, 16)} s={0.9} />
        </Gp>

        <Gp o={fi(f, aSeven, 16)}>
          <Spot id="ay17b" x={960} y={560} r={980} a={0.58} />
          <Ground id="ay17bg" />
          <DotGrid f={f} a={aSeven + 6} b={aEnd} x={960} y={240} n={70} cols={14} gap={48} r={9} dur={44} />
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((k) => {
            const xPos = 220 + k * 165;
            const isGold = k === 4 || k === 5;
            return (
              <Fig
                key={'rem' + k}
                {...(isGold
                  ? DP(xPos, {sc: 0.27, flip: k >= 5})
                  : PPL(xPos, {sc: 0.25 + (k % 2) * 0.02, hair: k % 3 === 0 ? 'veil' : 'cloth', beard: k % 3 === 0 ? 'none' : 'short', flip: k >= 5}))}
                o={fi(f, aSeven + k * 4, 14)}
              />
            );
          })}
        </Gp>
      </>
    ),
    html: (
      <>
        <Note f={f} a={a0 + 6} b={aRoad} y={84} size={46}>too worn out to hear past his own exhaustion</Note>
        <Note f={f} a={aRoad} b={aSeven} y={84} size={48}>a road back, and a student named Elisha to train</Note>
        <Big f={f} a={aSeven} b={aEnd} y={135} size={84} c={TXT.gold}>7,000 IN ISRAEL</Big>
        <Note f={f} a={aNever - 6} b={aEnd} y={196} size={46}>he was never the only one left</Note>
      </>
    ),
  }));
}

// SCENE 18: ALL FOUR MOMENTS SIDE BY SIDE — GOD WAITS OUTSIDE
{
  const a0 = at('Look at all four moments');
  const aAdam = at('Adam hides behind trees');
  const aCain = at('Cain hides behind a lie');
  const aHagar = at('Hagar runs into the desert');
  const aElijah = at('Elijah crawls into a cave');
  const aWait = at('In all four places');
  const aEnd = at('And across the Hebrew Bible');

  push(a0, (f) => ({
    svg: (
      <>
        <Spot id="ay18" x={960} y={580} r={980} a={0.56} />
        <Ground id="ay18g" />
        <QuestionTrack active={4} />
        <Gp o={fi(f, a0, 16)}>
          <FigTree x={250} y={GY} s={0.72} leaf={1} o={0.55} seed={3} />
          <Fig {...ADAM(300, {sc: 0.26, robe: 'stoop', head: 16, dim: f >= aCain && f < aWait ? 0.55 : 0})} />
          <Beam x={300} w={180} o={0.72 * fi(f, aWait, 20)} f={f} />
        </Gp>
        <Gp o={fi(f, aCain - 8, 16)}>
          <Soil x={735} y={GY} o={0.65} />
          <Fig {...CAIN(735, {sc: 0.26, flip: true, head: 10, dim: f >= aHagar && f < aWait ? 0.55 : 0})} />
          <Beam x={735} w={180} o={0.72 * fi(f, aWait + 6, 20)} f={f} />
        </Gp>
        <Gp o={fi(f, aHagar - 8, 16)}>
          <Spring x={1185} y={GY} f={f} s={0.62} />
          <Fig {...HAGAR(1155, {sc: 0.24, robe: 'seat', head: 14, dim: f >= aElijah && f < aWait ? 0.55 : 0})} />
          <Beam x={1175} w={180} o={0.72 * fi(f, aWait + 12, 20)} f={f} />
        </Gp>
        <Gp o={fi(f, aElijah - 8, 16)}>
          <Cave x={1625} y={GY} s={0.48} glow={0.28} />
          <Fig {...ELI(1625, {sc: 0.26, flip: true, head: 16})} />
          <Beam x={1625} w={180} o={0.72 * fi(f, aWait + 18, 20)} f={f} />
        </Gp>
      </>
    ),
    html: (
      <>
        <Name f={f} a={aAdam} b={aEnd} x={300} y={874} en="ASHAMED" />
        <Name f={f} a={aCain} b={aEnd} x={735} y={874} en="GUILTY" c={TXT.ember} />
        <Name f={f} a={aHagar} b={aEnd} x={1175} y={874} en="MISTREATED" c={TXT.bronze} />
        <Name f={f} a={aElijah} b={aEnd} x={1625} y={874} en="EMPTY" />
        <Note f={f} a={a0 + 4} b={aWait} y={76} size={48}>four people · four hiding places</Note>
        <Big f={f} a={aWait} b={aEnd} y={136} size={56} c={TXT.gold}>GOD WAITS OUTSIDE AND LETS YOU SPEAK FIRST</Big>
      </>
    ),
  }));
}

// SCENE 19: HINENI — ABRAHAM, MOSES, ISAIAH & OPPOSITE OF HIDING
{
  const a0 = at('And across the Hebrew Bible');
  const aHin = at('Hineni', 1);
  const aAbr = at('When God calls Abrahams name');
  const aMos = at('When God calls Moses');
  const aIsa = at('When Isaiah hears God ask');
  const aOpp = at('In Hebrew Hineni is the opposite');
  const aEnd = at('Every person eventually ends up');

  push(a0, (f) => {
    const L = (
      <>
        <GardenSet id="ay19l" night={0.35} cx={960} />
        <Fig {...ADAM(1040, {flip: true, robe: 'stoop', head: 18, bend: 14})} />
      </>
    );
    const R = (
      <>
        <Spot id="ay19r" x={960} y={560} r={880} a={0.62} />
        <Ground id="ay19rg" />
        <Beam x={960} w={340} o={0.92} f={f} />
        <Fig {...DP(960, {sc: 0.32, head: -8, arm: [-45, -55]})} />
      </>
    );
    return {
      svg: (
        <>
          <Gp o={win(f, a0, aAbr + 6)}>
            <Spot id="ay19a" x={960} y={560} r={940} a={0.6} />
            <Ground id="ay19ag" />
            <Beam x={960} w={360} o={0.9 * fi(f, aHin - 10, 22)} f={f} />
            {WK(f, a0, aAbr + 6, a0 + 6, aHin + 10, 560, 960, DP(0, {face: 1, sc: 0.32, head: -6}), 'hi19')}
          </Gp>

          <Gp o={win(f, aAbr, aOpp + 6)}>
            <Spot id="ay19b" x={960} y={580} r={980} a={0.58} />
            <Ground id="ay19bg" />
            <Gp o={fi(f, aAbr, 16)}>
              <Beam x={380} w={230} o={0.72} f={f} />
              <Fig {...ABRAHAM(380, {sc: 0.3, head: -10, arm: ezArm(f, aAbr + 12, REST, [-45, -50], 16)})} />
            </Gp>
            <Gp o={fi(f, aMos, 16)}>
              <Bush x={810} y={GY} s={0.95} f={f} fire={1} />
              <Fig {...DP(1030, {flip: true, hair: 'cloth', beard: 'long', mantle: true, prop: 'staff', sc: 0.3, head: -6})} />
            </Gp>
            <Gp o={fi(f, aIsa, 16)}>
              <Temple x={1560} y={GY} s={0.62} o={0.6} />
              <Beam x={1560} w={230} o={0.75} f={f} />
              <Fig {...DP(1560, {hair: 'long', beard: 'short', mantle: true, sc: 0.3, head: -10, arm: ezArm(f, aIsa + 12, REST, [-68, -60], 16)})} />
            </Gp>
          </Gp>

          <Gp o={fi(f, aOpp, 16)}>
            <Split left={L} right={R} labL="אַיֶּכָּה · HIDING" labR="הִנֵּנִי · STANDING IN THE OPEN" labO={fi(f, aOpp + 10)} />
          </Gp>
        </>
      ),
      html: (
        <>
          <Verse
            f={f}
            a={aHin - 12}
            b={aAbr}
            e={aAbr - 12}
            refText="THE ANSWER BEFORE THE QUESTION"
            orig="הִנֵּנִי"
            origKey={[0]}
            eng="*Hineni* — Here I am."
            keys={[aHin]}
            y={72}
          />
          <Name f={f} a={aAbr} b={aOpp} x={380} y={880} heb="הִנֵּנִי" en="ABRAHAM · GEN 22" />
          <Name f={f} a={aMos} b={aOpp} x={980} y={880} heb="הִנֵּנִי" en="MOSES · EXODUS 3" />
          <Name f={f} a={aIsa} b={aOpp} x={1560} y={880} heb="הִנֵּנִי" en="ISAIAH · ISAIAH 6" />
          <Note f={f} a={aOpp + 6} b={aEnd} y={64} size={46}>standing in the open, listening, ready to answer</Note>
        </>
      ),
    };
  });
}

// SCENE 20: EVERY PERSON & THE ISAIAH 65:1 REVERSAL
{
  const a0 = at('Every person eventually ends up');
  const aHangs = at('Where are you', 4);
  const aCent = at('Yet centuries after Eden');
  const aIsa65 = at('In Isaiah chapter 65');
  const aSaid = at('I said Here I am');
  const aGen = at('In Genesis God walks');
  const aByIsa = at('By Isaiah God is the one');
  const aEnd = at('If you have watched this video');

  push(a0, (f) => {
    const L = (
      <>
        <GardenSet id="ay20l" night={0.35} cx={960} />
        <Beam x={700} w={250} o={0.78} f={f} />
        <Fig {...ADAM(1140, {flip: true, robe: 'stoop', head: 18})} />
      </>
    );
    const R = (
      <>
        <Spot id="ay20r" x={960} y={540} r={940} a={0.68} />
        <Ground id="ay20rg" />
        <Beam x={960} w={420} o={0.95} f={f} />
        <Fig {...JP(960, {arm: ezArm(f, aByIsa + 12, REST, [-66, -18], 20)})} />
        {[0, 1, 2, 3].map((k) => (
          <Fig
            key={'cr' + k}
            {...PPL(k < 2 ? 420 + k * 140 : 1280 + (k - 2) * 140, {
              flip: k >= 2,
              sc: 0.25,
              hair: k % 2 ? 'veil' : 'cloth',
              beard: k % 2 ? 'none' : 'short',
              o: fi(f, aByIsa + k * 6, 16),
            })}
          />
        ))}
      </>
    );
    return {
      svg: (
        <>
          <Gp o={win(f, a0, aCent + 6)}>
            <Spot id="ay20a" x={960} y={580} r={960} a={0.52} />
            <Ground id="ay20ag" />
            <Beam x={960} w={360} o={0.62 * fi(f, aHangs - 16, 22)} f={f} />
            <Fig {...PPL(320, {robe: 'stoop', head: 18, bend: 12, sc: 0.28})} />
            <Fig {...PPL(620, {flip: true, head: 10, sc: 0.29})} />
            <Fig {...PPL(960, {hair: 'veil', beard: 'none', robe: 'seat', head: 16, sc: 0.27})} />
            <Fig {...PPL(1300, {flip: true, robe: 'kneel', head: 20, sc: 0.28})} />
            <Fig {...PPL(1590, {flip: true, head: 14, bend: 8, sc: 0.27})} />
          </Gp>

          <Gp o={win(f, aCent, aGen + 6)}>
            <Spot id="ay20b" x={960} y={540} r={980} a={0.65} />
            <Ground id="ay20bg" />
            <Beam x={960} w={420} o={0.92} f={f} />
            <Fig {...JP(960, {arm: ezArm(f, aSaid, REST, [-68, -20], 18)})} />
            <Fig {...PPL(360, {face: turn(f, aSaid + 16, -1, 18), sc: 0.27})} />
            <Fig {...PPL(540, {face: turn(f, aSaid + 24, -1, 18), hair: 'veil', beard: 'none', sc: 0.26})} />
            <Fig {...PPL(1380, {face: turn(f, aSaid + 20, 1, 18), sc: 0.27})} />
            <Fig {...PPL(1560, {face: turn(f, aSaid + 28, 1, 18), hair: 'veil', beard: 'none', sc: 0.26})} />
          </Gp>

          <Gp o={fi(f, aGen, 16)}>
            <Split left={L} right={R} labL="GENESIS · WHERE ARE YOU?" labR="ISAIAH · HERE I AM" labO={fi(f, aGen + 10)} />
          </Gp>
        </>
      ),
      html: (
        <>
          <Note f={f} a={a0 + 6} b={aHangs - 10} y={82} size={46}>every person eventually ends up in one of those four places</Note>
          <Big f={f} a={aHangs - 8} b={aCent} y={160} size={84} c={TXT.gold}>“WHERE ARE YOU?”</Big>
          <Note f={f} a={aCent + 4} b={aIsa65} y={84} size={48}>one verse turns the entire pattern around</Note>
          <Verse
            f={f}
            a={aIsa65}
            b={aGen}
            e={aGen - 15}
            refText="ISAIAH 65:1"
            orig="אָמַרְתִּי הִנֵּנִי הִנֵּנִי"
            origKey={[1, 2]}
            eng="“I said, ‘*Here I am, here I am*,’ to a nation that did not call my name.”"
            keys={[aSaid + 10]}
            y={56}
          />
          <Note f={f} a={aGen + 4} b={aByIsa} y={56} size={46}>in Genesis, God searches for a hiding man</Note>
          <Big f={f} a={aByIsa} b={aEnd} y={136} size={66} c={TXT.gold}>“HERE I AM.”</Big>
        </>
      ),
    };
  });
}

// SCENE 21: OUTRO — JESUS LOVES YOU
{
  const a0 = at('If you have watched this video');
  const aSub = at('Please subscribe and like');
  const aSee = at('See you on the next one');
  const aLove = at('Jesus loves you');

  push(a0, (f) => ({
    svg: (
      <>
        <Spot id="ay21" x={960} y={580} r={920} a={0.6} />
        <Ground id="ay21g" />
        <Beam x={960} w={360} o={0.88} f={f} />
        <Fig {...JP(960, {arm: ezArm(f, aLove - 12, REST, [-60, -14], 16)})} />
        {WK(f, a0, undefined, a0, aLove + 20, 320, 620, PPL(0, {face: 1, sc: 0.27, o: 0.85}), 'out1')}
        {WK(f, a0, undefined, a0 + 8, aLove + 20, 1600, 1300, PPL(0, {face: -1, hair: 'veil', beard: 'none', sc: 0.26, o: 0.85}), 'out2')}
      </>
    ),
    html: (
      <>
        <Note f={f} a={a0 + 4} b={aSub} y={86} size={50}>thank you for your time</Note>
        <Big f={f} a={aSub} b={aSee} y={136} size={58} c={TXT.gold}>LIKE · SUBSCRIBE · SHARE</Big>
        <Note f={f} a={aSee} b={aLove - 6} y={86} size={50}>see you on the next one</Note>
        <Big f={f} a={aLove - 6} y={145} size={74} c={TXT.gold}>JESUS LOVES YOU</Big>
      </>
    ),
  }));
}
