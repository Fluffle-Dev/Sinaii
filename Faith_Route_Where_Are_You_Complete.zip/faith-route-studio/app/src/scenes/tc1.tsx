import React from 'react';
import {at, win, fi, kf, ramp, eio, eout, clamp} from '../lib';
import {Fig, FigP, Line, Tent, Sheep, TXT} from '../fig';
import {Ref, Big, Note, Name} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Altar} from '../extra';
import {CrossHill} from '../props';
import {JP, DP, BP, SP, F, Gp, pr, ez, ezArm, turn, walkX} from '../kit';
import {Beam, Card, Q, Arrow} from '../covprops';
import {Curtain, Ark, Plan, Temple, CherubFig, CherubArt, FlameSword, LifeTree, YearDots, Lampstand, Incense} from '../tcprops';

export const TC1: Scene[] = [];
const push = (start: number, render: Scene['render']) => TC1.push({start, render});

/* ---------- cast and helpers ---------- */
export const PRIEST = (x: number, o: Partial<FigP> = {}) => DP(x, {hair: 'cap', beard: 'long', mantle: true, ...o});
export const MOSES = (x: number, o: Partial<FigP> = {}) => DP(x, {beard: 'long', hair: 'cloth', mantle: true, prop: 'staff', ...o});
export const PPL = (x: number, o: Partial<FigP> = {}) => BP(x, {sc: 0.27, ...o});
export const WK = (f: number, a: number, b: number | undefined, t0: number, t1: number, x0: number, x1: number, p: FigP, k?: string | number, stride = 70) => {
  const w = walkX(f, t0, t1, x0, x1, stride);
  return <Fig key={k} {...p} x={w.x} walk={w.walk} wa={w.wa} face={p.face ?? (x1 >= x0 ? 1 : -1)} o={(p.o ?? 1) * win(f, a, b, 16)} />;
};
export const Dark: React.FC<{o: number}> = ({o}) => (o > 0.001 ? <rect width={1920} height={1080} fill="#030201" opacity={o} /> : null);
/** Jerusalem wall skyline (line art) */
export const Walls: React.FC<{x0?: number; x1?: number; o?: number; p?: number}> = ({x0 = 0, x1 = 900, o = 1, p = 1}) => {
  let d = `M${x0},${GY} L${x0},${GY - 150}`;
  for (let x = x0; x < x1; x += 120) d += ` L${x + 20},${GY - 150} L${x + 20},${GY - 170} L${x + 40},${GY - 170} L${x + 40},${GY - 150} L${x + 70},${GY - 150} L${x + 70},${GY - (x % 360 === 0 ? 250 : 170)} L${x + 100},${GY - (x % 360 === 0 ? 250 : 170)} L${x + 100},${GY - 150} L${x + 120},${GY - 150}`;
  d += ` L${x1},${GY}`;
  return <g opacity={o}><path d={d + ' Z'} fill="#0e0a06" opacity={0.9} /><Line u w={2} d={d} p={p} c="#C99A4A" /></g>;
};
/** tear progress helper: tear starts at t over d frames */
export const tearAt = (f: number, t: number, d = 60) => eio(ramp(f, t, d));
/** ground cracks for the earthquake */
const Cracks: React.FC<{p: number}> = ({p}) => (
  <g opacity={p > 0 ? 1 : 0}>
    <Line u w={2.2} c="#C67D41" p={p} d={`M300,${GY} L340,${GY + 30} L320,${GY + 60} L360,${GY + 110} M1300,${GY} L1270,${GY + 40} L1310,${GY + 80} L1290,${GY + 140} M820,${GY} L850,${GY + 26} L830,${GY + 70}`} />
  </g>
);

// 0 HOOK ---------------------------------------------------------------------------------------
{
  const aMost = at('Most people think'), aHalf = at('but it only tells half'), aMat = at('Matthew wrote down one small detail'), aTop = at('The curtain tore from top'),
    aWoven = at('what was woven into that curtain'), aEden = at('to a pair of guards'), aSo = at('So who tore it'), aWhat = at('what were those guards protecting'), aEnd = at('It was a Friday afternoon');
  push(0, (f) => {
    const zoom = ez(f, aWoven, 1.1, 1.6, 50);
    return {
      svg: <>
        <Spot id="a0" x={960} y={520} r={860} />
        <Gp o={win(f, 0, aEden + 4)}>
          <Ground id="a0g" />
          <Gp o={win(f, 0, aWoven + 4)}>
            <Curtain id="a0c" f={f} tear={tearAt(f, aTop + 6, 50)} open={0.55 * eio(ramp(f, aTop + 30, 40))} light={0.9} draw={pr(f, 0, 50)} />
          </Gp>
          <Gp o={fi(f, aWoven - 4)}>
            <g transform={`translate(960 560) scale(${zoom}) translate(-960 -560)`}>
              <Curtain id="a0z" f={f} light={0.4} />
            </g>
          </Gp>
          {WK(f, aMost, aWoven, aMost + 10, aHalf + 10, 1900, 1480, PPL(0, {sc: 0.26}), 'a0p')}
          <circle cx={960} cy={300} r={260} fill="url(#halo)" opacity={0.6 * win(f, aWoven + 20, aEden)} />
        </Gp>
        <Gp o={fi(f, aEden)}>
          <Ground id="a0g2" />
          <LifeTree x={480} y={GY} s={0.95} p={pr(f, aEden, 40)} />
          <CherubFig x={1120} f={f} flip o={fi(f, aEden + 10)} />
          <FlameSword x={1300} y={GY - 60} f={f} o={fi(f, aEden + 24)} />
          <CherubFig x={1480} f={f} o={fi(f, aEden + 16)} />
          <Gp o={0.5 * fi(f, aSo, 30)}><rect width={1920} height={1080} fill="#050302" /></Gp>
        </Gp>
      </>,
      html: <>
        <Big f={f} a={2} b={aMost} y={90} size={66} c={TXT.gold}>THE TORN CURTAIN</Big>
        <Note f={f} a={6} b={aMost} y={190} size={46}>why did it tear the moment Jesus died?</Note>
        <Note f={f} a={aMost + 10} b={aHalf} y={60} size={44}>God finally letting us in</Note>
        <Note f={f} a={aHalf} b={aMat} y={60} size={46}>only half the story</Note>
        <Ref f={f} a={aMat} b={aTop + 10} y={50}>MATTHEW 27:51</Ref>
        <Big f={f} a={aTop + 6} b={aWoven} y={36} size={64} c={TXT.gold}>FROM TOP TO BOTTOM</Big>
        <Note f={f} a={aWoven + 20} b={aEden} y={60} size={46}>woven into the cloth</Note>
        <Ref f={f} a={aEden + 6} b={aSo} y={60}>THE EDGE OF EDEN</Ref>
        <Big f={f} a={aSo} b={aWhat} y={200} size={66} c={TXT.gold}>WHO TORE IT?</Big>
        <Big f={f} a={aWhat} b={aEnd} y={200} size={60} c={TXT.gold}>WHAT WERE THEY GUARDING?</Big>
      </>,
    };
  });
}

// 1 THE CROSS AND THE TEMPLE -------------------------------------------------------------------
{
  const b0 = at('It was a Friday afternoon'), bDark = at('From noon until three'), bCry = at('Then Jesus cried out one last time'), bQ = at('And when Jesus had cried out again'),
    bQ2 = at('At that moment the curtain'), bShook = at('The earth shook'), bMark = at('Mark and Luke record'), bHour = at('Three in the afternoon was the hour'),
    bSome = at('Something happened inside the holiest'), bConn = at('the two events were connected'), bEnd = at('To understand why this matters');
  push(b0, (f) => {
    const dark = 0.5 * fi(f, bDark, 50) * (1 - fi(f, bMark, 30));
    const shake = f > bShook && f < bShook + 40 ? Math.sin(f * 2.3) * 5 * (1 - (f - bShook) / 40) : 0;
    return {
      svg: <>
        <Spot id="b1" x={960} y={560} r={860} />
        <g transform={`translate(${shake} 0)`}>
          <Gp o={win(f, b0, bMark + 6)}>
            <Ground id="b1g" />
            <Walls x0={0} x1={720} p={pr(f, b0, 40)} o={0.85 * (1 - fi(f, bQ2, 30))} />
            <g transform={`translate(${ez(f, bQ2, 0, -380, 30)} 0)`}><CrossHill x={1180} y={GY} s={1} p={pr(f, b0 + 10, 50)} /></g>
            <Gp o={fi(f, bQ2)}>
              <Curtain id="b1c" f={f} x={1360} top={340} bottom={GY} w={420} tear={tearAt(f, at('torn in two from top') , 50)} open={0.6 * eio(ramp(f, at('torn in two from top') + 20, 40))} />
            </Gp>
            <Dark o={dark} />
            <Cracks p={pr(f, bShook + 4, 24)} />
          </Gp>
        </g>
        <Gp o={win(f, bMark, bHour + 6)}>
          <Card f={f} a={bMark - 6} x={960} y={540} w={480} h={200} top="MATTHEW 27:51" en="top to bottom" />
          <Card f={f} a={bMark + 8} x={440} y={540} w={420} h={200} top="MARK 15:38" en="top to bottom" />
          <Card f={f} a={bMark + 20} x={1480} y={540} w={420} h={200} top="LUKE 23:45" en="torn in two" />
        </Gp>
        <Gp o={win(f, bHour, bSome + 6)}>
          <Ground id="b1g2" />
          <Temple x={1180} y={GY} s={0.95} p={pr(f, bHour, 40)} />
          {[0, 1, 2, 3, 4].map((k) => F(f, bHour + 10 + k * 6, bSome + 6, PPL(260 + k * 120, {sc: 0.22, head: -6, o: 0.9}), 'w' + k))}
          {F(f, bHour + 30, bSome + 6, PRIEST(1640, {sc: 0.24, flip: true}), 'pr1')}
        </Gp>
        <Gp o={fi(f, bSome)}>
          <Ground id="b1g3" />
          <Dark o={0.35} />
          <CrossHill x={500} y={GY} s={0.8} />
          <Temple x={1440} y={GY} s={0.7} />
          <Curtain id="b1d" f={f} x={1440} top={GY - 330 * 0.7 * 1.0} bottom={GY - 42} w={150} tear={tearAt(f, bSome + 30, 40)} open={0.7} cher={0} o={fi(f, bSome + 10)} />
          <path d={`M640,${GY - 360} C860,${GY - 560} 1140,${GY - 560} 1360,${GY - 360}`} fill="none" stroke="#F1CD86" strokeWidth={2.6} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - pr(f, bConn - 10, 30)} filter="url(#lglow)" />
        </Gp>
      </>,
      html: <>
        <Ref f={f} a={b0} b={bDark}>OUTSIDE THE WALLS OF JERUSALEM</Ref>
        <Note f={f} a={bDark} b={bCry} y={130} size={46}>noon until three, darkness over the land</Note>
        <Note f={f} a={bCry} b={bQ} y={130} size={46}>one last cry</Note>
        <Q f={f} a={bQ} b={bQ2} refText="MATTHEW 27:50" eng="“And when Jesus had cried out again in a loud voice, he *gave up his spirit*.”" keys={[at('gave up his spirit')]} y={90} />
        <Q f={f} a={bQ2} b={bMark} refText="MATTHEW 27:51" eng="“At that moment the curtain of the temple was *torn in two from top to bottom*. The earth shook, the rocks split.”" keys={[at('torn in two from top')]} y={60} />
        <Ref f={f} a={bMark} b={bHour} y={300}>THREE GOSPELS · ONE MOMENT</Ref>
        <Ref f={f} a={bHour} b={bSome} y={90}>ACTS 3:1 · THREE IN THE AFTERNOON</Ref>
        <Note f={f} a={bHour + 10} b={bSome} y={150} size={44}>the hour of prayer, the courts full</Note>
        <Big f={f} a={bConn} b={bEnd} y={140} size={60} c={TXT.gold}>CONNECTED</Big>
      </>,
    };
  });
}

// 2 THE TABERNACLE, THE CURTAIN, THE ARK -------------------------------------------------------
{
  const c0 = at('To understand why this matters'), cMoses = at('When God gave Moses the design'), cQ = at('Make a curtain of blue'), cExp = at('Then he explained what it was for'), cQ2 = at('The curtain will separate'),
    cArk = at('Behind it sat the ark'), cLid = at('covered by a lid'), cHeav = at('That small room was the place'), cEvery = at('Everything in Israel’s worship'), cWall = at('like a wall made of cloth'), cEnd = at('Now notice the detail God asked for');
  push(c0, (f) => ({
    svg: <>
      <Spot id="c2" x={960} y={560} r={860} />
      <Gp o={win(f, c0, cQ + 6)}>
        <Ground id="c2g" />
        <Tent x={1100} y={GY} s={1.2} p={pr(f, c0, 40)} />
        <Beam x={1100} w={300} o={0.8 * fi(f, c0 + 10)} f={f} />
        {[0, 1, 2, 3].map((k) => <g key={k} opacity={0.4 * fi(f, c0 + 20 + k * 6)}><Tent x={[260, 480, 1560, 1760][k]} y={GY} s={0.45} /></g>)}
        {WK(f, cMoses, cQ + 6, cMoses + 6, cMoses + 70, 300, 760, MOSES(0, {head: -8}), 'mo')}
      </Gp>
      <Gp o={win(f, cQ, cQ2 + 6)}>
        <Ground id="c2g2" />
        <Curtain id="c2c" f={f} draw={pr(f, cQ, 80)} cher={fi(f, at('with cherubim woven'), 30)} light={0.5} />
      </Gp>
      <Gp o={win(f, cQ2, cArk + 6)}>
        <Plan f={f} p={pr(f, cQ2, 50)} hl={f > cQ2 + 40 ? 'mhp' : null} curtainGlow={fi(f, cQ2 + 40)} items={0.6} />
      </Gp>
      <Gp o={win(f, cArk, cEvery + 6)}>
        <Ground id="c2g3" />
        <Ark x={960} y={GY} s={1.5} glow={0.6 + 0.4 * fi(f, cHeav)} o={fi(f, cArk)} />
        <Beam x={960} w={420} o={0.9 * fi(f, cHeav)} f={f} />
        <Incense x={960} y={GY - 360} f={f} amt={0.8 * fi(f, at('appear there in a cloud'), 40)} w={600} />
        <Card f={f} a={cLid} b={cHeav + 10} x={960} y={250} w={620} h={240} top="KAPPORET" heb="כַּפֹּרֶת" en="the atonement cover" />
      </Gp>
      <Gp o={win(f, cEvery, cWall + 6)}>
        <Plan f={f} curtainGlow={1} items={1} hl="mhp" />
      </Gp>
      <Gp o={fi(f, cWall)}>
        <Ground id="c2g4" />
        <Curtain id="c2w" f={f} light={0.7} />
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={c0} b={cMoses}>THE TABERNACLE · IN THE WILDERNESS</Ref>
      <Note f={f} a={cMoses} b={cQ} y={130} size={46}>instructions for one curtain</Note>
      <Q f={f} a={cQ} b={cExp} refText="EXODUS 26:31" eng="“Make a curtain of blue, purple and scarlet yarn and finely twisted linen, with *cherubim woven into it* by a skilled worker.”" keys={[at('cherubim woven into it')]} y={30} size={46} />
      <Q f={f} a={cQ2 - 10} b={cArk} refText="EXODUS 26:33" eng="“The curtain will separate the Holy Place from the *Most Holy Place*.”" keys={[at('the Most Holy Place', 1) + 10]} y={110} />
      <Ref f={f} a={cArk} b={cLid} y={150}>THE ARK OF THE COVENANT</Ref>
      <Note f={f} a={cHeav} b={cEvery} y={120} size={46}>where heaven touched earth</Note>
      <Note f={f} a={cEvery} b={cWall} y={150} size={44}>everything arranged around one room</Note>
      <Big f={f} a={cWall + 6} b={cEnd} y={140} size={60} c={TXT.gold}>A WALL MADE OF CLOTH</Big>
    </>,
  }));
}

// 3 CHERUBIM, EDEN, EAST -----------------------------------------------------------------------
{
  const d0 = at('Now notice the detail God asked for'), dFirst = at('The first time cherubim appear'), dQ = at('After he drove the man out'), dGuard = at('So the cherubim were guards'),
    dJob = at('their job was to keep anyone'), dEast = at('When Israel set up the tabernacle'), dEden = at('just like the entrance to Eden'), dMany = at('Many readers have noticed'),
    dLast = at('and the last thing he saw'), dMsg = at('The message was stitched'), dClosed = at('The way back to God was still closed'), dEnd = at('Only one person could ever go through');
  push(d0, (f) => {
    const zoom = 1.6;
    return {
      svg: <>
        <Spot id="d3" x={960} y={560} r={860} />
        <Gp o={win(f, d0, dFirst + 6)}>
          <g transform={`translate(960 560) scale(${ez(f, d0, 1.05, zoom, 50)}) translate(-960 -560)`}>
            <Curtain id="d3c" f={f} light={0.4} draw={1} />
            <circle cx={819} cy={572} r={170} fill="url(#halo)" opacity={0.7 * fi(f, d0 + 20)} />
            <circle cx={1101} cy={572} r={170} fill="url(#halo)" opacity={0.7 * fi(f, d0 + 30)} />
          </g>
        </Gp>
        <Gp o={win(f, dFirst, dEast + 6)}>
          <Ground id="d3g" />
          <LifeTree x={360} y={GY} s={0.95} p={pr(f, dFirst, 40)} />
          {WK(f, dFirst, dQ + 30, dFirst + 10, dQ + 20, 700, 1960, DP(0, {beard: 'short', hair: 'bare', head: 10}), 'ad', 72)}
          {WK(f, dFirst, dQ + 30, dFirst + 18, dQ + 28, 580, 1840, DP(0, {beard: 'none', hair: 'long', sc: 0.29, head: 10}), 'ev', 72)}
          <CherubFig x={1080} f={f} flip o={fi(f, dQ + 30)} />
          <FlameSword x={1270} y={GY - 60} f={f} o={fi(f, dQ + 50)} />
          <CherubFig x={1460} f={f} o={fi(f, dQ + 40)} />
          <Line u w={2} c="#C99A4A" d={`M1560,${GY - 30} L1760,${GY - 30} M1740,${GY - 42} L1760,${GY - 30} L1740,${GY - 18}`} o={fi(f, dQ + 50)} />
        </Gp>
        <Gp o={win(f, dEast, dLast + 6)}>
          <Plan f={f} p={pr(f, dEast, 40)} eden={fi(f, dEden)} curtainGlow={fi(f, dMany)} walker={f > dMany + 20 ? eio(ramp(f, dMany + 20, dLast - dMany - 30)) : -1} />
        </Gp>
        <Gp o={win(f, dLast, dClosed + 6)}>
          <Ground id="d3g2" />
          <Curtain id="d3w" f={f} x={760} w={680} light={0.35} />
          {WK(f, dLast, undefined, dLast, dLast + 70, 1900, 1300, PRIEST(0, {}), 'pw')}
          <circle cx={610} cy={572} r={190} fill="url(#halo)" opacity={0.8 * fi(f, dMsg)} />
          <circle cx={910} cy={572} r={190} fill="url(#halo)" opacity={0.8 * fi(f, dMsg)} />
        </Gp>
        <Gp o={fi(f, dClosed)}>
          <Ground id="d3g3" />
          <Curtain id="d3x" f={f} light={0.25} />
          <Dark o={0.35} />
        </Gp>
      </>,
      html: <>
        <Ref f={f} a={d0 + 10} b={dFirst} y={40}>CHERUBIM</Ref>
        <Q f={f} a={dQ} b={dGuard} refText="GENESIS 3:24" eng="“After he drove the man out, he placed on the east side of the Garden of Eden *cherubim* and a flaming sword flashing back and forth to *guard the way to the tree of life*.”" keys={[at('cherubim and a flaming'), at('guard the way to the tree')]} y={40} size={46} />
        <Big f={f} a={dGuard} b={dJob} y={130} size={80} c={TXT.gold}>GUARDS</Big>
        <Note f={f} a={dJob} b={dEast} y={130} size={46}>keeping anyone from going back in</Note>
        <Ref f={f} a={dEast} b={dEden} y={200}>THE ENTRANCE FACED EAST</Ref>
        <Note f={f} a={dEden} b={dMany} y={190} size={44}>just like the gate of Eden</Note>
        <Note f={f} a={dMany} b={dLast} y={190} size={44}>walking west, back toward the garden</Note>
        <Note f={f} a={dLast + 10} b={dMsg} y={60} size={44}>the last thing he saw</Note>
        <Note f={f} a={dMsg} b={dClosed} y={60} size={44}>stitched into the fabric</Note>
        <Big f={f} a={dClosed} b={dEnd} y={150} size={64} c={TXT.gold}>THE WAY BACK WAS CLOSED</Big>
      </>,
    };
  });
}

// 4 ONE MAN, ONE DAY ---------------------------------------------------------------------------
{
  const e0 = at('Only one person could ever go through'), eDay1 = at('only on one day of the year'), eQ = at('Tell your brother Aaron'), eAt = at('On the Day of Atonement'),
    eInc = at('cloud of incense'), eSpr = at('and sprinkled it on the atonement cover'), eHeb = at('The book of Hebrews sums it up'), eRope = at('You may have heard that the priests'),
    ePop = at('That story is popular'), eSer = at('What the Bible does make clear'), eSac = at('Approaching God was possible'), eEnd = at('By the time of Jesus');
  push(e0, (f) => {
    const sprArm = ezArm(f, eSpr, [-5, -36], [-70, -40], 10);
    return {
      svg: <>
        <Spot id="e4" x={960} y={560} r={860} />
        <Gp o={win(f, e0, eQ + 6)}>
          <YearDots f={f} a={e0} x={960} y={560} lit={fi(f, eDay1, 30)} hl={190} />
        </Gp>
        <Gp o={win(f, eQ, eAt + 6)}>
          <Ground id="e4g" />
          <Curtain id="e4c" f={f} x={700} w={620} light={0.4} />
          {F(f, eQ, eAt + 6, PRIEST(1260, {flip: true, head: 8}))}
        </Gp>
        <Gp o={win(f, eAt, eHeb + 6)}>
          <Ground id="e4g2" />
          <Spot id="e4s" x={760} y={600} r={600} a={0.5} />
          <Ark x={700} y={GY} s={1.3} glow={0.9} />
          <Incense x={760} y={GY - 260} f={f} amt={0.95 * fi(f, eInc, 50)} w={700} />
          {WK(f, eAt, undefined, eAt + 10, eAt + 60, 1700, 1140, PRIEST(0, {arm: f > eSpr ? sprArm : [-5, -36]}), 'hp')}
          {Array.from({length: 7}, (_, i) => {
            const t = ramp(f, eSpr + 10 + i * 9, 18);
            return t > 0 && t < 1 ? <circle key={i} cx={1000 - t * 120} cy={GY - 330 + t * t * 120} r={5} fill="#8a2a1c" opacity={1 - t * 0.3} /> : null;
          })}
        </Gp>
        <Gp o={win(f, eHeb, eRope + 6)}>
          <Ground id="e4g3" />
          <Curtain id="e4h" f={f} light={0.35} />
          {F(f, eHeb, eRope + 6, PRIEST(1450, {flip: true}))}
        </Gp>
        <Gp o={win(f, eRope, eSac + 6)}>
          <Ground id="e4g4" />
          <Curtain id="e4r" f={f} x={620} w={620} light={0.3} />
          {F(f, eRope, eSer + 6, PPL(1500, {flip: true, arm: [-50, -20]}))}
          <Gp o={1 - fi(f, eSer, 20)}>
            <path d={`M900,${GY - 6} C1100,${GY + 6} 1300,${GY - 2} 1440,${GY - 160}`} fill="none" stroke="#C9A36A" strokeWidth={3} opacity={1 - 0.75 * fi(f, ePop + 10)} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - pr(f, eRope + 10, 30)} />
            <Gp o={fi(f, ePop + 10)}><Line u w={4} c="#C67D41" d={`M1080,${GY - 120} L1260,${GY + 40} M1260,${GY - 120} L1080,${GY + 40}`} /></Gp>
          </Gp>
          <Dark o={0.3 * fi(f, eSer)} />
        </Gp>
        <Gp o={fi(f, eSac)}>
          <Ground id="e4g5" />
          <Altar x={1000} y={GY} s={1.1} p={pr(f, eSac, 30)} />
          <Sheep x={1290} y={GY} s={0.8} m="bronze" />
          {F(f, eSac + 10, undefined, PPL(720, {robe: 'kneel', bend: 18, head: 22}))}
          <Beam x={1000} w={300} o={0.55} f={f} />
        </Gp>
      </>,
      html: <>
        <Big f={f} a={e0 + 4} b={eDay1} y={160} size={64} c={TXT.gold}>ONE PERSON</Big>
        <Big f={f} a={eDay1} b={eQ} y={160} size={64} c={TXT.gold}>ONE DAY A YEAR</Big>
        <Q f={f} a={eQ} b={eAt} refText="LEVITICUS 16:2" eng="“Tell your brother Aaron that he is not to come *whenever he chooses* into the Most Holy Place behind the curtain in front of the atonement cover on the ark, or else *he will die*.”" keys={[at('whenever he chooses'), at('or else he will die')]} y={30} size={44} />
        <Ref f={f} a={eAt} b={eSpr} y={90}>THE DAY OF ATONEMENT</Ref>
        <Note f={f} a={eSpr} b={eHeb} y={90} size={44}>blood on the atonement cover</Note>
        <Q f={f} a={eHeb + 10} b={eRope} refText="HEBREWS 9:7" eng="“But only the high priest entered the inner room, and that only once a year, and *never without blood*.”" keys={[at('never without blood')]} y={60} />
        <Note f={f} a={eRope + 10} b={ePop} y={110} size={44}>a rope around his ankle?</Note>
        <Big f={f} a={ePop} b={eSer} y={110} size={54} c={TXT.gold}>A LATER LEGEND · NOT IN THE BIBLE</Big>
        <Note f={f} a={eSer} b={eSac} y={150} size={46}>how serious that room was</Note>
        <Note f={f} a={eSac + 10} b={eEnd} y={140} size={44}>a sacrifice in the sinner’s place</Note>
      </>,
    };
  });
}
