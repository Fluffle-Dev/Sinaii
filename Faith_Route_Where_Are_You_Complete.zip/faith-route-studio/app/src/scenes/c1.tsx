import React from 'react';
import {at, win, fi, kf, ramp, eio, rng} from '../lib';
import {Fig, House, Hills, Moon, Sun, Colonnade, Line, Tent, Pyramids, Throne, Sheep, TXT} from '../fig';
import {Ref, Big, Note, Name, Verse} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Altar} from '../extra';
import {Book, Stars, Road, Word, CrossHill, Well} from '../props';
import {Goat, Robe, Pit, Bars, Tablets, Sacks, Smoke, Baby, Lineage} from '../famprops';
import {JP, DP, BP, SP, F, Gp, pr} from '../kit';

export const C1: Scene[] = [];
const push = (start: number, render: Scene['render']) => C1.push({start, render});

// ABRAHAM, SARAH, ISAAC, REBEKAH etc as consistent figures
const ABR = (x: number, o = {}) => DP(x, {beard: 'long', hair: 'cloth', sc: 0.31, ...o});
const SAR = (x: number, o = {}) => DP(x, {hair: 'veil', beard: 'none', sc: 0.29, ...o});
const ISA = (x: number, o = {}) => DP(x, {beard: 'short', hair: 'cloth', sc: 0.31, ...o});
const REB = (x: number, o = {}) => DP(x, {hair: 'veil', beard: 'none', sc: 0.29, ...o});
const JAC = (x: number, o = {}) => DP(x, {beard: 'short', hair: 'cloth', sc: 0.3, ...o});
const RAC = (x: number, o = {}) => DP(x, {hair: 'veil', beard: 'none', sc: 0.28, ...o});
const LEA = (x: number, o = {}) => BP(x, {hair: 'veil', beard: 'none', sc: 0.28, ...o});
const ESA = (x: number, o = {}) => BP(x, {beard: 'long', hair: 'long', sc: 0.31, wide: 1.12, ...o});
const JOS = (x: number, o = {}) => DP(x, {beard: 'none', hair: 'cloth', sc: 0.29, ...o});
const KING = (x: number, o = {}) => SP(x, {crown: true, beard: 'short', ...o});

// 0 HOOK ------------------------------------------------------------------------------------
{
  const a1 = at('Abraham leaves home'), a2 = at('Isaac nearly dies'), a3 = at('Jacob wrestles with God'), a4 = at('Joseph rises from a prison'), a5 = at('But if you read those chapters'),
    a6 = at('The same lie gets told'), a7 = at('The same goat shows up'), a8 = at('The same heartbreak falls'), a9 = at('It almost looks as if'), a10 = at('So was Abraham’s family'), a11 = at('how did one young man');
  push(0, (f) => {
    const gen = kf(f, [[0, 0], [a1, 1], [a2, 2], [a3, 3], [a4, 4]], 30);
    return {
      svg: <>
        <Spot id="c0" x={960} y={560} r={800} />
        <Gp o={win(f, 0, a1 + 10)}>
          <Ground id="cg0s" />
          <Book x={960} y={800} s={1.3} p={pr(f, 0, 40)} lines={fi(f, 10, 40)} />
          <circle cx={960} cy={560} r={380} fill="url(#halo)" opacity={0.4 * fi(f, 20)} />
        </Gp>
        <Gp o={win(f, a1 - 6, a6)}>
          <Lineage gen={gen} hl={f > a4 ? ['jos'] : f > a3 ? ['jac'] : f > a2 ? ['isa'] : f > a1 ? ['abr'] : []} />
        </Gp>
        <Gp o={win(f, a6, a10)}>
          <Ground id="cg0" />
          <Gp o={win(f, a6, a7)}>
            {F(f, a6, a7, KING(520, {robe: 'seat', bench: true, flip: true, lit: -1}))}
            {F(f, a6 + 6, a7, ABR(760))}
            {F(f, a6 + 20, a7, KING(1160, {robe: 'seat', bench: true}))}
            {F(f, a6 + 26, a7, ISA(1400, {flip: true, lit: -1}))}
            <Line u w={1.6} d="M960,380 L960,860" o={0.5} p={pr(f, a6 + 10, 20)} />
          </Gp>
          <Gp o={win(f, a7, a8)}>
            <Goat x={760} y={GY} s={1.3} p={pr(f, a7, 30)} />
            <Robe x={1200} y={GY - 20} s={0.95} o={fi(f, a7 + 30)} stain={fi(f, a7 + 50)} />
          </Gp>
          <Gp o={win(f, a8, a10)}>
            <Stars o={0.9} seed={3} n={80} y1={460} />
            {[0, 1, 2].map((k) => F(f, a8 + k * 10, a10, (k === 0 ? SAR : k === 1 ? REB : RAC)(620 + k * 340, {head: 18, bend: 8}), 'w' + k))}
            <rect x={0} y={0} width={1920} height={1080} fill="#000" opacity={0.35 * fi(f, a9, 40)} />
          </Gp>
        </Gp>
        <Gp o={fi(f, a10)}>
          <Ground id="cg0b" />
          <Bars x={960} y={GY - 120} s={1.1} p={pr(f, a11, 30)} o={fi(f, a11)} />
          {F(f, a11, undefined, JOS(960, {y: GY, head: 10}))}
          <circle cx={960} cy={560} r={260} fill="url(#halo)" opacity={0.5 * fi(f, a11 + 20)} />
        </Gp>
      </>,
      html: <>
        <Big f={f} a={8} b={a1} y={300} size={110} c={TXT.gold} ls={0.2}>GENESIS</Big>
        <Note f={f} a={30} b={a1} y={380} size={36}>a collection of separate stories?</Note>
        <Ref f={f} a={a5} b={a6}>READ IT STRAIGHT THROUGH</Ref>
        <Note f={f} a={a6} b={a7} y={150} size={40}>the same lie · the same town · the same king’s name</Note>
        <Note f={f} a={a7} b={a8} y={150} size={40}>the same goat, forty years apart</Note>
        <Note f={f} a={a8} b={a9} y={150} size={40}>the same heartbreak, three wives</Note>
        <Big f={f} a={a10} b={a11} y={300} size={86} c={TXT.gold}>A FAMILY CURSE?</Big>
        <Name f={f} a={a11 + 10} x={960} y={885} en="JOSEPH · AN EGYPTIAN PRISON" />
      </>,
    };
  });
}

// 1 EGYPT: THE FIRST LIE -------------------------------------------------------------------
{
  const a0 = at('To see the pattern'), a1 = at('When a famine drove Abraham'), a2 = at('Abraham grew afraid'), a3 = at('So he told her'), k3 = at('Say you are my sister'),
    a4 = at('Sarah was taken into Pharaoh’s palace'), a5 = at('until our God stepped in');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c1" x={960} y={620} r={780} />
      <Sun x={1500} y={240} r={28} o={win(f, a0, a4)} t={0} />
      <Ground id="cg1" />
      <Gp o={win(f, a0, a4)}>
        <Pyramids x={1350} y={GY} s={0.9} p={pr(f, a0, 50)} o={0.7} />
        {F(f, a0, a4, ABR(700, {head: f > a2 ? 12 : 0}), 'a', [[0, 380], [a0 + 10, 700]], 200)}
        {F(f, a0 + 6, a4, SAR(900, {flip: f > a3, lit: f > a3 ? -1 : 1}), 's', [[0, 580], [a0 + 16, 900]], 200)}
        <Gp o={win(f, a2, a3 + 40)}>{[0, 1].map((k) => <Fig key={k} x={1500 + k * 110} y={GY} m="silver" sc={0.24} flip lit={-1} beard="short" prop="spear" o={0.6} />)}</Gp>
      </Gp>
      <Gp o={fi(f, a4)}>
        <Colonnade x={1100} y={GY} w={900} h={520} n={6} o={0.5} p={pr(f, a4, 40)} />
        <Throne x={1300} y={GY} s={0.9} o={0.7} />
        {F(f, a4, undefined, KING(1300, {robe: 'seat', bench: false, flip: true, lit: -1}))}
        {F(f, a4 + 8, undefined, SAR(980, {head: 12}))}
        <circle cx={980} cy={560} r={260} fill="url(#halo)" opacity={0.6 * fi(f, a5)} />
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={a1 + 10} b={a3}>GENESIS 12 · EGYPT</Ref>
      <Verse f={f} a={a3} b={a4} e={k3 + 40} small refText="GENESIS 12:13" lang="heb" orig="אִמְרִי־נָא אֲחֹתִי אָתְּ" origKey={[1]} eng="Say you are my *sister*, so that I will be treated well for your sake" keys={[k3 + 10]} />
      <Name f={f} a={a4 + 10} x={1300} y={885} en="PHARAOH" c={TXT.silver} />
      <Name f={f} a={a4 + 16} x={980} y={885} en="SARAH" />
    </>,
  }));
}

// 2 GERAR: THE LIE AGAIN ----------------------------------------------------------------------
{
  const a0 = at('Years later, in a town called Gerar'), a1 = at('Abraham told the very same lie again'), k1 = at('She is my sister', 1), a2 = at('This time it was the king of Gerar'), a3 = at('a man named Abimelek'), a4 = at('again the Almighty had to step in');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c2" x={960} y={620} r={780} />
      <Ground id="cg2" />
      <House x={1550} y={GY} s={0.8} o={0.5} p={pr(f, a0, 40)} /><House x={300} y={GY} s={0.6} o={0.4} />
      {F(f, a0, undefined, ABR(620, {arm: f > a1 ? [-60, -30] : [-16, -24]}))}
      {F(f, a0 + 6, undefined, SAR(820))}
      {F(f, a2, undefined, KING(1250, {flip: true, lit: -1, arm: [-40, -30]}))}
      <circle cx={820} cy={560} r={240} fill="url(#halo)" opacity={0.6 * fi(f, a4)} />
    </>,
    html: <>
      <Ref f={f} a={a0 + 10} b={a1}>GENESIS 20 · GERAR</Ref>
      <Note f={f} a={k1 - 10} b={a3} y={150} size={44}>“She is my sister.”</Note>
      <Name f={f} a={a3} x={1250} y={885} heb="אֲבִימֶלֶךְ" en="ABIMELEK" c={TXT.silver} />
    </>,
  }));
}

// 3 ISAAC: THE ECHO -----------------------------------------------------------------------------
{
  const a0 = at('Now fast forward one generation'), a1 = at('Isaac, the son of the promise'), a2 = at('The men of the town notice'), a3 = at('almost like an echo'), a4 = at('When the men of that place asked him'), k4 = at('She is my sister', 2), k5 = at('because she is beautiful');
  const r = rng(5); const men = Array.from({length: 4}, (_, i) => ({x: 1250 + i * 130}));
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c3" x={960} y={620} r={780} />
      <Gp o={win(f, a0 - 10, a1 + 20)}><Lineage gen={4} hl={['abr', 'isa']} dim={0.5} /></Gp>
      <Gp o={fi(f, a1)}>
        <Ground id="cg3" />
        <House x={1650} y={GY} s={0.7} o={0.45} />
        {F(f, a1, undefined, ISA(620, {head: f > a4 ? 10 : 0}))}
        {F(f, a1 + 6, undefined, REB(820))}
        {men.map((m, i) => F(f, a2 + i * 4, undefined, BP(m.x, {flip: true, lit: -1, sc: 0.26, beard: i % 2 ? 'short' : 'long', head: -4}), i))}
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={a1 + 10} b={a4}>GENESIS 26 · GERAR AGAIN</Ref>
      <Note f={f} a={a3} b={a4} y={150} size={40}>almost like an echo</Note>
      <Verse f={f} a={a4} e={k5 + 30} small refText="GENESIS 26:7" lang="heb" orig="וַיֹּאמֶר אֲחֹתִי הִוא" origKey={[1]} eng="he said, ‘She is my *sister*,’ because he was *afraid* to say, ‘She is my wife.’" keys={[k4, k4 + 30]} />
    </>,
  }));
}

// 4 SAME LIE, SAME TOWN, SAME KING ------------------------------------------------------------------
{
  const a0 = at('It is the same lie in the same town'), a1 = at('again called Abimelek'), a2 = at('Isaac had not even been born'), a3 = at('Children learn far more'), a4 = at('somewhere along the way'), a5 = at('let someone else carry the risk');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c4" x={960} y={620} r={800} />
      <Ground id="cg4" />
      <Gp o={win(f, a0, a3)}>
        <Line u w={1.6} d="M960,300 L960,880" o={0.5} p={pr(f, a0, 20)} />
        {F(f, a0, a3, ABR(300, {sc: 0.26}))}{F(f, a0, a3, SAR(450, {sc: 0.25}))}{F(f, a0 + 10, a3, KING(720, {sc: 0.27, flip: true, lit: -1}))}
        {F(f, a0 + 4, a3, ISA(1180, {sc: 0.26}))}{F(f, a0 + 4, a3, REB(1330, {sc: 0.25}))}{F(f, a1, a3, KING(1600, {sc: 0.27, flip: true, lit: -1}))}
      </Gp>
      <Gp o={fi(f, a3)}>
        <Tent x={1350} y={GY} s={1} o={0.6} />
        {F(f, a3, undefined, ABR(820, {arm: [-50, -30], head: 6}))}
        {F(f, a3 + 8, undefined, ISA(1080, {sc: 0.17, flip: true, lit: -1, beard: 'none', head: -14}))}
        <circle cx={1080} cy={700} r={140} fill="url(#halo)" opacity={0.4 * fi(f, a4)} />
      </Gp>
    </>,
    html: <>
      <Name f={f} a={a0 + 10} b={a3} x={480} y={885} en="GENESIS 20 · ABRAHAM" />
      <Name f={f} a={a0 + 14} b={a3} x={1400} y={885} en="GENESIS 26 · ISAAC" />
      <Note f={f} a={a1} b={a3} y={180} size={38}>two kings named Abimelek</Note>
      <Note f={f} a={a3} b={a5} y={150} size={38}>children learn from what we do</Note>
      <Note f={f} a={a5 - 20} y={150} size={38}>when afraid, let someone else carry the risk</Note>
    </>,
  }));
}

// 5 FAVORITES ---------------------------------------------------------------------------------------
{
  const a0 = at('The second strand of the pattern'), a1 = at('When Isaac and Rebekah finally had twin sons'), a2 = at('how the family split'), k3 = at('Isaac, who had a taste for wild game'), k4 = at('but Rebekah loved Jacob'), a5 = at('Each parent had a favorite');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c5" x={960} y={620} r={800} />
      <Ground id="cg5" />
      <Tent x={960} y={GY} s={1.1} o={0.45} p={pr(f, a0, 40)} />
      {F(f, a1, undefined, ISA(560, {beard: 'long', arm: f > k3 ? [-60, -30] : [-16, -24]}))}
      {F(f, a1 + 6, undefined, REB(1360, {flip: true, lit: -1, arm: f > k4 ? [-60, -30] : [-16, -24]}))}
      {F(f, a1 + 10, undefined, ESA(780, {sc: 0.28, prop: 'spear'}), 'es')}
      {F(f, a1 + 14, undefined, JAC(1140, {sc: 0.27, flip: true, lit: -1}), 'ja')}
      <Line u w={2} d="M960,300 L960,880" p={pr(f, a2, 30)} o={0.7} />
      <circle cx={680} cy={600} r={240} fill="url(#halo)" opacity={0.45 * fi(f, k3)} />
      <circle cx={1250} cy={600} r={240} fill="url(#halo)" opacity={0.45 * fi(f, k4)} />
    </>,
    html: <>
      <Ref f={f} a={a0} b={k3}>STRAND TWO · FAVORITES</Ref>
      <Verse f={f} a={k3 - 10} e={k4 + 40} small refText="GENESIS 25:28" lang="heb" orig="וַיֶּאֱהַב יִצְחָק אֶת־עֵשָׂו … וְרִבְקָה אֹהֶבֶת אֶת־יַעֲקֹב" origKey={[0, 4]} eng="Isaac … *loved* Esau, but Rebekah *loved* Jacob." keys={[k3 + 20, k4]} />
      <Name f={f} a={a1 + 20} x={780} y={885} en="ESAU" />
      <Name f={f} a={a1 + 24} x={1140} y={885} en="JACOB" />
      <Note f={f} a={a5} y={360} size={36}>and everyone in the house knew it</Note>
    </>,
  }));
}

// 6 THE STOLEN BLESSING ---------------------------------------------------------------------------
{
  const a0 = at('That division led to'), a1 = at('When Isaac was old and almost blind'), a2 = at('Rebekah overheard'), a3 = at('She dressed Jacob in Esau’s best clothes'), a4 = at('skins of young goats'),
    a5 = at('Then she cooked goat meat'), a6 = at('Jacob walked into his father’s tent'), k6 = at('I am Esau your firstborn'), a7 = at('Isaac touched the goatskin'), a8 = at('gave the blessing to the wrong son');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c6" x={kf(f, [[0, 760], [a6, 1100]], 60)} y={620} r={720} a={0.5} />
      <Ground id="cg6" />
      <Gp o={win(f, a0, a6)}>
        <Tent x={1500} y={GY} s={0.9} o={0.6} />
        {F(f, a1, a6, ISA(1500, {robe: 'seat', bench: true, beard: 'long', head: 20, bend: 10, flip: true, lit: -1, dim: 0.2}))}
        {F(f, a2, a6, REB(700, {arm: f > a3 ? [-80, -20] : [-16, -24]}))}
        {F(f, a2 + 10, a6, JAC(920, {flip: true, lit: -1}))}
        <Goat x={460} y={GY} s={1} o={fi(f, a4)} p={pr(f, a4, 30)} />
        <g opacity={fi(f, a4 + 20)}><circle cx={872} cy={590} r={40} fill="url(#halo)" /><circle cx={880} cy={470} r={40} fill="url(#halo)" /></g>
        <Gp o={fi(f, a5)}><Altar x={300} y={GY} s={0.6} o={0.6} /></Gp>
      </Gp>
      <Gp o={fi(f, a6)}>
        <Tent x={1200} y={GY} s={1.1} o={0.5} />
        {F(f, a6, undefined, ISA(1250, {robe: 'seat', bench: true, beard: 'long', head: 20, bend: 10, flip: true, lit: -1, arm: f > a8 ? [-150, -20] : f > a7 ? [-70, -10] : [-16, -24]}))}
        {F(f, a6, undefined, JAC(950, {robe: f > a8 ? 'kneel' : 'stand', bend: f > a8 ? 16 : 0}), 'jk', [[0, 760], [a6 + 6, 950]], 70)}
        <circle cx={1050} cy={560} r={260} fill="url(#halo)" opacity={0.5 * fi(f, a8)} />
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={a1} b={a3}>GENESIS 27</Ref>
      <Note f={f} a={a3 + 10} b={a4} y={150} size={38}>Esau’s best clothes</Note>
      <Note f={f} a={a4 + 10} b={a6} y={150} size={38}>goatskins on his hands and neck</Note>
      <Note f={f} a={k6} b={a7 + 20} y={150} size={46}>“I am Esau your firstborn.”</Note>
      <Ref f={f} a={a8} y={230}>THE WRONG SON</Ref>
    </>,
  }));
}

// 7 ESAU'S RAGE, JACOB RUNS ---------------------------------------------------------------------------
{
  const a0 = at('Jacob got what he wanted'), a1 = at('he also had to run for his life'), a2 = at('because Esau swore to kill him');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c7" x={960} y={620} r={780} />
      <Ground id="cg7" />
      <Hills y={GY} o={0.35} />
      {F(f, a0, undefined, JAC(700, {}), 'j', [[0, 700], [a1, 1700]], 150)}
      {F(f, a2 - 10, undefined, ESA(460, {arm: [-120, -60], arm2: [-30, -90]}))}
    </>,
    html: <>
      <Note f={f} a={a1} b={a2} y={150} size={40}>running for his life</Note>
      <Note f={f} a={a2 + 10} y={150} size={36}>Esau swore to kill him</Note>
    </>,
  }));
}

// 8 LABAN, RACHEL, THE WEDDING NIGHT ---------------------------------------------------------------
{
  const a0 = at('Jacob fled to his uncle Laban'), a1 = at('met Laban’s daughter Rachel'), a2 = at('He agreed to work seven years'), a3 = at('On the wedding night'), a4 = at('heavily veiled'), a5 = at('When morning came, there was Leah'), k5 = at('Why have you deceived me');
  push(a0 - 6, (f) => {
    const night = win(f, a3, a5);
    return {
      svg: <>
        <Stars o={0.9 * night} seed={8} n={80} y1={460} />
        <Moon x={1500} y={200} r={30} o={night} />
        <Sun x={300} y={kf(f, [[a5, 700], [a5 + 1, 380]], 50)} r={28} o={fi(f, a5)} t={0} />
        <Spot id="c8" x={960} y={620} r={780} a={0.55 - 0.15 * night} />
        <Ground id="cg8" />
        <Gp o={win(f, a0, a3)}>
          <Well x={1200} y={GY} s={0.8} o={0.6} />
          {F(f, a0, a3, JAC(600))}
          {F(f, a1, a3, RAC(900, {flip: true, lit: -1}))}
          <Sheep x={1450} y={GY} s={0.9} o={fi(f, a1)} />
          <Sheep x={1640} y={GY} s={0.8} graze o={fi(f, a1 + 6)} />
          {Array.from({length: 7}, (_, i) => <circle key={i} cx={720 + i * 80} cy={300} r={9} fill="#E9BE6E" filter="url(#lglow)" opacity={fi(f, a2 + i * 6, 8)} />)}
        </Gp>
        <Gp o={fi(f, a3)}>
          <Tent x={1100} y={GY} s={1.2} o={0.6} />
          {F(f, a3 + 10, undefined, LEA(1050, {hair: 'veil', dim: f > a5 ? 0 : 0.5, head: 14}))}
          {F(f, a3, undefined, JAC(700, {arm: f > a5 ? [-80, -20] : [-16, -24]}))}
          {F(f, a5 + 20, undefined, SP(1400, {beard: 'long', flip: true, lit: -1}), 'lab')}
        </Gp>
      </>,
      html: <>
        <Ref f={f} a={a0 + 10} b={a2}>GENESIS 29 · HARRAN</Ref>
        <Name f={f} a={a1 + 10} b={a3} x={900} y={885} en="RACHEL" />
        <Ref f={f} a={a2 + 10} b={a3}>SEVEN YEARS</Ref>
        <Note f={f} a={a4} b={a5} y={150} size={38}>the bride, heavily veiled</Note>
        <Big f={f} a={a5} b={k5 - 10} y={280} size={80} c={TXT.gold}>LEAH!</Big>
        <Note f={f} a={k5 - 10} y={150} size={42}>“Why have you deceived me?”</Note>
        <Name f={f} a={a5 + 30} x={1400} y={885} en="LABAN" c={TXT.silver} />
      </>,
    };
  });
}

// 9 THE MIRROR: YOUNGER / OLDER ---------------------------------------------------------------------
{
  const a0 = at('Listen to Laban’s answer'), k0 = at('give the younger daughter'), a1 = at('Jacob, the younger son who had disguised himself'), a2 = at('tricked by an older sister disguised'), a3 = at('The deceiver had been deceived');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c9" x={960} y={620} r={800} />
      <Ground id="cg9" />
      <Gp o={win(f, a0 - 10, a1)}>
        <Tent x={1500} y={GY} s={0.9} o={0.5} />
        {F(f, a0 - 10, a1, JAC(760, {arm: [-80, -20]}))}
        {F(f, a0 - 10, a1, SP(1100, {beard: 'long', flip: true, lit: -1, arm: [-60, -30]}))}
        {F(f, a0, a1, LEA(1320, {flip: true, lit: -1, head: 14}))}
      </Gp>
      <Gp o={fi(f, a1)}>
        <Line u w={1.6} d="M960,300 L960,880" o={0.5} p={pr(f, a1, 20)} />
        {F(f, a1, undefined, JAC(520))}
        <g opacity={fi(f, a1 + 20)}><circle cx={500} cy={600} r={40} fill="url(#halo)" /><Goat x={300} y={GY} s={0.7} /></g>
        {F(f, a2, undefined, LEA(1420, {flip: true, lit: -1}))}
        <g opacity={fi(f, a2 + 20)}><circle cx={1420} cy={470} r={60} fill="url(#halo)" /></g>
      </Gp>
    </>,
    html: <>
      <Verse f={f} a={a0 + 10} b={a1} e={k0 + 40} small refText="GENESIS 29:26" lang="heb" orig="לָתֵת הַצְּעִירָה לִפְנֵי הַבְּכִירָה" origKey={[1, 3]} eng="It is not our custom here to give the *younger* daughter in marriage before the *older* one." keys={[k0 + 10, k0 + 40]} />
      <Name f={f} a={a1 + 10} x={520} y={885} en="YOUNGER, DISGUISED AS OLDER" />
      <Name f={f} a={a2 + 10} x={1420} y={885} en="OLDER, DISGUISED AS YOUNGER" />
      <Big f={f} a={a3} y={250} size={64} c={TXT.gold}>THE DECEIVER, DECEIVED</Big>
    </>,
  }));
}

// 10 JACOB'S FAVORITES, THE ROBE --------------------------------------------------------------------
{
  const a0 = at('You might expect Jacob to learn from that'), a1 = at('he loved Rachel more than Leah'), a2 = at('Then, when Rachel finally gave him a son'), k3 = at('Now Israel loved Joseph'), k4 = at('he made an ornate robe'), a5 = at('His older brothers looked at that robe');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c10" x={960} y={620} r={800} />
      <Ground id="cg10" />
      <Gp o={win(f, a0, a2)}>
        {F(f, a0, a2, JAC(960))}
        {F(f, a0 + 6, a2, RAC(1200, {flip: true, lit: -1}))}
        {F(f, a0 + 10, a2, LEA(680, {dim: f > a1 ? 0.45 : 0, head: f > a1 ? 14 : 0}))}
        <circle cx={1100} cy={600} r={220} fill="url(#halo)" opacity={0.5 * fi(f, a1)} />
      </Gp>
      <Gp o={fi(f, a2)}>
        <Tent x={1600} y={GY} s={0.8} o={0.45} />
        {F(f, a2, undefined, JAC(860, {beard: 'long', arm: f > k4 ? [-70, -30] : [-16, -24]}))}
        {F(f, a2 + 10, undefined, JOS(1100, {sc: 0.24, flip: true, lit: -1}))}
        <Robe x={1330} y={GY - 10} s={0.62} o={fi(f, k4)} />
        <circle cx={1100} cy={560} r={240} fill="url(#halo)" opacity={0.5 * fi(f, k4)} />
        {[0, 1, 2, 3].map((k) => F(f, a5 + k * 4, undefined, BP(240 + k * 120, {sc: 0.27, beard: k % 2 ? 'short' : 'long', head: 6}), 'b' + k))}
      </Gp>
    </>,
    html: <>
      <Note f={f} a={a0 + 10} b={a1} y={150} size={38}>the pattern repeats</Note>
      <Verse f={f} a={k3 - 10} e={k4 + 40} small refText="GENESIS 37:3" lang="heb" orig="וְיִשְׂרָאֵל אָהַב אֶת־יוֹסֵף מִכָּל־בָּנָיו" origKey={[1]} eng="Now Israel *loved* Joseph more than any of his other sons … and he made an *ornate robe* for him." keys={[k3 + 10, k4]} />
      <Name f={f} a={a2 + 20} x={1100} y={885} en="JOSEPH" />
      <Name f={f} a={a5 + 20} x={420} y={885} en="HIS BROTHERS" />
    </>,
  }));
}

// 11 THE PIT, THE GOAT, THE ROBE ----------------------------------------------------------------
{
  const a0 = at('The brothers seized Joseph'), a1 = at('threw him into a dry pit'), a2 = at('sold him to traders headed for Egypt'), a3 = at('Then they had to explain'), k4 = at('Then they got Joseph’s robe'), k5 = at('slaughtered a goat'), k6 = at('dipped the robe in the blood');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c11" x={960} y={620} r={800} />
      <Ground id="cg11" />
      <Gp o={win(f, a0, a3)}>
        <Hills y={GY} o={0.3} />
        <Pit x={760} y={GY + 20} s={1} p={pr(f, a1, 30)} o={fi(f, a1)} />
        {[0, 1, 2].map((k) => F(f, a0 + k * 4, a3, BP(460 + k * 130 + (k > 0 ? 500 : 0), {sc: 0.27, beard: k % 2 ? 'short' : 'long', arm: [-80, -40]}), 'b' + k))}
        {F(f, a0, a1 + 10, JOS(760, {sc: 0.24}))}
        {[0, 1, 2].map((k) => F(f, a2, a3, BP(1200 + k * 130, {sc: 0.26, beard: 'long', hair: 'cloth', prop: k === 0 ? 'staff' : null}), 't' + k, [[0, 1200 + k * 130], [a2 + 20, 1700 + k * 130]], 140))}
        {F(f, a2 + 10, a3, JOS(1100, {sc: 0.24, head: 16}), 'jt', [[0, 1100], [a2 + 20, 1600]], 140)}
      </Gp>
      <Gp o={win(f, a3 - 10, k4 + 20)}>
        <Tent x={1500} y={GY} s={0.9} o={0.5} />
        {F(f, a3 - 10, k4 + 20, JAC(1450, {beard: 'long', flip: true, lit: -1}))}
        {[0, 1, 2].map((k) => F(f, a3 - 10 + k * 4, k4 + 20, BP(420 + k * 130, {sc: 0.27, beard: k % 2 ? 'short' : 'long', head: 10}), 'w' + k, [[0, 300 + k * 130], [a3, 700 + k * 130]], 150))}
      </Gp>
      <Gp o={fi(f, k4 - 10)}>
        <Robe x={960} y={GY - 40} s={0.95} stain={eio(ramp(f, k6, 40))} o={fi(f, k4 - 10)} />
        <Goat x={1450} y={GY} s={1} o={fi(f, k5 - 10) * (1 - fi(f, k6 + 40))} />
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={a0 + 10} b={a3}>GENESIS 37</Ref>
      <Note f={f} a={a2} b={a3} y={150} size={38}>sold to traders bound for Egypt</Note>
      <Verse f={f} a={k4 - 10} e={k6 + 30} small refText="GENESIS 37:31" lang="heb" orig="וַיִּשְׁחֲטוּ שְׂעִיר עִזִּים וַיִּטְבְּלוּ אֶת־הַכֻּתֹּנֶת בַּדָּם" origKey={[1, 4]} eng="they got Joseph’s robe, slaughtered a *goat* and dipped the *robe* in the blood" keys={[k5, k6]} />
    </>,
  }));
}

// 12 DO YOU SEE IT? THE MIRROR ---------------------------------------------------------------------
{
  const a0 = at('Do you see it'), a1 = at('Decades earlier, Jacob had used a goat'), a2 = at('Now his own sons used a goat'), a3 = at('Jacob held up that bloodstained robe'), a4 = at('The same tools he had used');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c12" x={960} y={620} r={800} />
      <Ground id="cg12" />
      <Gp o={win(f, a0, a3)}>
        <Line u w={1.6} d="M960,300 L960,880" o={0.5} p={pr(f, a1, 20)} />
        <g opacity={fi(f, a1)}>
          {F(f, a1, a3, ISA(760, {robe: 'seat', bench: true, beard: 'long', head: 20, flip: true, lit: -1, sc: 0.26}))}
          {F(f, a1, a3, JAC(520, {sc: 0.26}))}
          <Goat x={300} y={GY} s={0.6} />
        </g>
        <g opacity={fi(f, a2)}>
          {F(f, a2, a3, JAC(1650, {beard: 'long', flip: true, lit: -1, sc: 0.26}))}
          {[0, 1].map((k) => F(f, a2 + k * 4, a3, BP(1180 + k * 120, {sc: 0.26, beard: 'short'}), 'b' + k))}
          <Robe x={1420} y={GY - 10} s={0.5} stain={1} />
        </g>
      </Gp>
      <Gp o={fi(f, a3)}>
        {F(f, a3, undefined, JAC(960, {beard: 'long', robe: 'kneel', bend: 20, head: 20, arm: [-70, -30]}))}
        <Robe x={1200} y={GY - 10} s={0.5} stain={1} />
      </Gp>
    </>,
    html: <>
      <Big f={f} a={a0} b={a1} y={280} size={76} c={TXT.gold}>DO YOU SEE IT?</Big>
      <Name f={f} a={a1 + 10} b={a3} x={520} y={885} en="A GOAT · HIS BROTHER’S CLOTHES" />
      <Name f={f} a={a2 + 10} b={a3} x={1400} y={885} en="A GOAT · THEIR BROTHER’S ROBE" />
      <Note f={f} a={a4} y={150} size={38}>the same tools, now breaking his heart</Note>
    </>,
  }));
}

// 13 THIRD STRAND ------------------------------------------------------------------------------------
{
  const a0 = at('So far we have two strands'), a1 = at('But there is a third strand'), a2 = at('it may be the most painful of all');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c13" x={960} y={540} r={820} />
      <Lineage gen={4} cracks={3} hl={f > a1 ? ['sar', 'reb', 'rac'] : ['abr', 'isa', 'jac']}
        tags={[{k: 'abr', t: 'THE LIE', o: fi(f, a0 + 10)}, {k: 'isa', t: 'LIE · FAVORITES', o: fi(f, a0 + 20)}, {k: 'jac', t: 'DECEPTION · FAVORITES', o: fi(f, a0 + 30)}]} />
    </>,
    html: <>
      <Ref f={f} a={a0} b={a1} y={92}>TWO STRANDS · PASSED DOWN</Ref>
      <Ref f={f} a={a1} y={92}>STRAND THREE · NOBODY’S SIN</Ref>
    </>,
  }));
}

// 14 SARAH: CHILDLESS UNTIL NINETY ---------------------------------------------------------------
{
  const a0 = at('The first thing Genesis tells us about Sarah'), k0 = at('Now Sarai was childless'), a1 = at('Our God had promised Abraham descendants'), a2 = at('his wife could not have a single child'), a3 = at('ninety years old');
  push(a0 - 6, (f) => ({
    svg: <>
      <Stars o={fi(f, a1, 30)} seed={21} n={140} y1={520} />
      <Spot id="c14" x={960} y={660} r={720} a={0.4} />
      <Ground id="cg14" />
      <Tent x={1450} y={GY} s={0.8} o={0.5} />
      {F(f, a0, undefined, ABR(760, {head: f > a1 ? -24 : 0, arm: f > a1 ? [-150, 10] : [-16, -24]}))}
      {F(f, a0 + 6, undefined, SAR(1150, {head: 16, bend: 6, flip: true, lit: -1}))}
    </>,
    html: <>
      <Verse f={f} a={k0 - 10} b={a1} e={k0 + 40} small refText="GENESIS 11:30" lang="heb" orig="וַתְּהִי שָׂרַי עֲקָרָה" origKey={[2]} eng="Now Sarai was *childless* because she was not able to conceive." keys={[k0 + 20]} />
      <Note f={f} a={a1 + 10} b={a3} y={150} size={38}>descendants as many as the stars</Note>
      <Big f={f} a={a3} y={280} size={110} c={TXT.gold}>90</Big>
    </>,
  }));
}

// 15 REBEKAH: TWENTY YEARS -------------------------------------------------------------------------
{
  const a0 = at('Then her son Isaac married Rebekah'), a1 = at('Isaac was forty when he married'), a2 = at('not born until he was sixty'), k3 = at('Isaac prayed to the LORD'), a4 = at('That one sentence covers twenty years');
  push(a0 - 6, (f) => {
    const n = Math.round(kf(f, [[0, 40], [a1, 40], [a2, 60]], 60));
    return {
      svg: <>
        <Spot id="c15" x={960} y={620} r={780} />
        <Ground id="cg15" />
        <Tent x={1450} y={GY} s={0.8} o={0.5} />
        {F(f, a0, undefined, ISA(820, {robe: f > k3 ? 'kneel' : 'stand', bend: f > k3 ? 10 : 0, head: f > k3 ? -12 : 0, arm: f > k3 ? [-150, -10] : [-16, -24]}))}
        {F(f, a0 + 6, undefined, REB(1080, {head: 14, flip: true, lit: -1}))}
        <circle cx={960} cy={560} r={260} fill="url(#halo)" opacity={0.5 * fi(f, k3 + 60)} />
      </>,
      html: <>
        <Big f={f} a={a1} b={k3} y={280} size={100} c={TXT.gold}>{n}</Big>
        <Note f={f} a={a1} b={k3} y={360} size={34}>Isaac’s age</Note>
        <Verse f={f} a={k3} b={a4 + 70} e={k3 + 80} small refText="GENESIS 25:21" lang="heb" orig="וַיֶּעְתַּר יִצְחָק לַיהוָה לְנֹכַח אִשְׁתּוֹ" origKey={[0]} eng="Isaac *prayed* to the LORD on behalf of his wife, because she was childless." keys={[k3 + 20]} />
        <Big f={f} a={a4} y={360} size={56} c={TXT.gold}>20 YEARS</Big>
      </>,
    };
  });
}

// 16 RACHEL ----------------------------------------------------------------------------------------
{
  const a0 = at('Then came Rachel'), a1 = at('Her sister Leah had son after son'), a2 = at('Her pain spilled out'), k2 = at('Give me children'), a3 = at('Years passed before Genesis finally says'), k3 = at('Then God remembered Rachel'), a4 = at('The son she gave birth to was Joseph');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c16" x={960} y={620} r={780} />
      <Ground id="cg16" />
      {F(f, a0, undefined, RAC(1100, {head: f > k3 ? 0 : 16, bend: f > k3 ? 0 : 8, flip: true, lit: -1}))}
      {F(f, a1, undefined, LEA(560))}
      {[0, 1, 2, 3].map((k) => F(f, a1 + 10 + k * 8, undefined, BP(700 + k * 70, {sc: 0.14 + k * 0.01, beard: 'none'}), 'c' + k))}
      {F(f, a2, a3, JAC(1350, {flip: true, lit: -1}))}
      <circle cx={1100} cy={560} r={260} fill="url(#halo)" opacity={0.6 * fi(f, k3)} />
      <Baby x={1250} y={680} s={1} o={fi(f, a4)} />
    </>,
    html: <>
      <Name f={f} a={a0 + 10} x={1100} y={885} en="RACHEL" />
      <Name f={f} a={a1 + 10} x={560} y={885} en="LEAH" />
      <Note f={f} a={k2 - 10} b={a3} y={150} size={46}>“Give me children, or I’ll die!”</Note>
      <Verse f={f} a={k3 - 10} b={a4 + 60} e={k3 + 40} small refText="GENESIS 30:22" lang="heb" orig="וַיִּזְכֹּר אֱלֹהִים אֶת־רָחֵל" origKey={[0]} eng="Then God *remembered* Rachel; he listened to her and enabled her to conceive." keys={[k3 + 10]} />
      <Name f={f} a={a4 + 20} x={1250} y={790} en="JOSEPH" />
    </>,
  }));
}

// 17 THREE WIVES ------------------------------------------------------------------------------------
{
  const a0 = at('Three generations of wives'), a1 = at('If you were living inside that family');
  push(a0 - 6, (f) => ({
    svg: <>
      <Stars o={0.8} seed={30} n={90} y1={460} />
      <Spot id="c17" x={960} y={640} r={780} a={0.45} />
      <Ground id="cg17" />
      {[0, 1, 2].map((k) => F(f, a0 + k * 8, undefined, (k === 0 ? SAR : k === 1 ? REB : RAC)(560 + k * 400, {head: 14, bend: 6}), 'w' + k))}
      {[0, 1, 2].map((k) => <circle key={k} cx={560 + k * 400} cy={600} r={160} fill="url(#halo)" opacity={0.35 * fi(f, a0 + 20 + k * 8)} />)}
    </>,
    html: <>
      <Name f={f} a={a0 + 6} x={560} y={885} en="SARAH" />
      <Name f={f} a={a0 + 14} x={960} y={885} en="REBEKAH" />
      <Name f={f} a={a0 + 22} x={1360} y={885} en="RACHEL" />
      <Note f={f} a={a1} y={150} size={38}>something wrong with the bloodline?</Note>
    </>,
  }));
}

// 18 WAS IT A CURSE? --------------------------------------------------------------------------------
{
  const a0 = at('So was it a curse'), a1 = at('Genesis never uses that word'), a2 = at('the three strands are very different');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c18" x={960} y={560} r={820} />
      <Gp o={win(f, a0, a2)}><Book x={960} y={800} s={1.1} p={pr(f, a0, 30)} lines={1} /></Gp>
      <Gp o={fi(f, a2)}>
        <Lineage gen={4} cracks={3} tags={[{k: 'abr', t: 'SIN · COPIED', o: fi(f, a2 + 10)}, {k: 'jac', t: 'SIN · COPIED', o: fi(f, a2 + 20)}, {k: 'sar', t: 'NOBODY’S FAULT', o: fi(f, a2 + 30), c: TXT.ivory}, {k: 'rac', t: 'NOBODY’S FAULT', o: fi(f, a2 + 36), c: TXT.ivory}]} />
      </Gp>
    </>,
    html: <>
      <Big f={f} a={a0} b={a2} y={300} size={80}>A CURSE?</Big>
      <Note f={f} a={a1} b={a2} y={380} size={38}>Genesis never calls it one</Note>
    </>,
  }));
}

// 19 THIRD AND FOURTH GENERATION -------------------------------------------------------------------
{
  const a0 = at('The lies and the favoritism were real sins'), a1 = at('When our God gave the Ten Commandments'), k1 = at('punishing the children'), a2 = at('Sin rarely stays with one person'), a3 = at('like smoke filling a house');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c19" x={960} y={620} r={800} />
      <Ground id="cg19" />
      <Gp o={win(f, a0, a2)}>
        {F(f, a0, a1, ABR(800, {arm: [-50, -30]}))}{F(f, a0 + 6, a1, ISA(1080, {sc: 0.2, flip: true, lit: -1, beard: 'none'}))}
        <Gp o={fi(f, a1)}><Tablets x={960} y={GY} s={1.1} p={pr(f, a1, 40)} /></Gp>
      </Gp>
      <Gp o={fi(f, a2)}>
        <House x={960} y={GY} s={1.4} o={0.7} />
        <Smoke x={960} y={GY - 60} f={f - a2} o={fi(f, a3 - 20)} />
        {[0, 1, 2].map((k) => F(f, a2 + k * 6, undefined, BP(620 + k * 340, {sc: 0.22 - k * 0.02, beard: k ? 'none' : 'short', hair: k === 1 ? 'veil' : 'cloth'}), 'h' + k))}
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={a0} b={a1}>SINS COPIED FROM PARENTS</Ref>
      <Verse f={f} a={a1 + 10} b={a2} e={k1 + 60} small refText="EXODUS 20:5" lang="heb" orig="עַל־שִׁלֵּשִׁים וְעַל־רִבֵּעִים" origKey={[0, 1]} eng="punishing the children for the sin of the parents to the *third* and *fourth* generation of those who hate me" keys={[k1 + 40, k1 + 60]} />
      <Note f={f} a={a3} y={150} size={38}>like smoke filling a house</Note>
    </>,
  }));
}

// 20 A THOUSAND GENERATIONS + EZEKIEL ------------------------------------------------------------
{
  const a0 = at('But the very next words'), k0 = at('showing love to a thousand generations'), a1 = at('Three or four generations of consequences'), a2 = at('Centuries later, through the prophet Ezekiel'), k2 = at('The child will not share the guilt'), a3 = at('Children are not condemned');
  push(a0 - 6, (f) => {
    const n = Math.round(1000 * eio(ramp(f, a1, 90)));
    return {
      svg: <>
        <Spot id="c20" x={960} y={560} r={820} />
        <Gp o={win(f, a0 - 30, a1)}><Ground id="cg20t" /><Tablets x={960} y={GY} s={1.1} /></Gp>
        <Gp o={win(f, a0, a2)}>
          {[0, 1, 2, 3].map((k) => <circle key={k} cx={270 + k * 44} cy={560} r={14} fill="#C67D41" filter="url(#lglow)" opacity={fi(f, a1 - 20 + k * 4)} />)}
          {Array.from({length: 400}, (_, i) => {
            const cx = 560 + (i % 40) * 30, cy = 380 + Math.floor(i / 40) * 36;
            return i < n * 0.4 ? <circle key={i} cx={cx} cy={cy} r={6} fill="#FFE0A8" opacity={0.9} /> : null;
          })}
        </Gp>
        <Gp o={fi(f, a2)}>
          <Ground id="cg20" />
          {F(f, a2, undefined, DP(760, {beard: 'long', arm: [-60, -30]}))}
          {F(f, a3, undefined, BP(1150, {sc: 0.2, beard: 'none', flip: true, lit: -1}))}
          <circle cx={1150} cy={680} r={160} fill="url(#halo)" opacity={0.5 * fi(f, a3)} />
        </Gp>
      </>,
      html: <>
        <Verse f={f} a={a0 + 10} b={a1} e={k0 + 40} small refText="EXODUS 20:6" lang="heb" orig="וְעֹשֶׂה חֶסֶד לַאֲלָפִים" origKey={[1, 2]} eng="showing *love* to a *thousand* generations of those who love me" keys={[k0, k0 + 30]} />
        <Name f={f} a={a1} b={a2} x={360} y={620} en="3 – 4" />
        <Big f={f} a={a1} b={a2} x={1160} y={300} size={60} c={TXT.gold}>{n.toLocaleString()}</Big>
        <Verse f={f} a={k2 - 30} e={k2 + 40} small refText="EZEKIEL 18:20" lang="heb" orig="בֵּן לֹא־יִשָּׂא בַּעֲוֹן הָאָב" origKey={[2]} eng="The child will *not share the guilt* of the parent" keys={[k2 + 10]} />
        <Name f={f} a={a2 + 10} x={760} y={885} en="EZEKIEL" />
        <Note f={f} a={a3} y={420} size={36}>not condemned · only tempted to repeat</Note>
      </>,
    };
  });
}

// 21 BARRENNESS NEVER A PUNISHMENT -----------------------------------------------------------------
{
  const a0 = at('And the barrenness was never a punishment'), a1 = at('It served a purpose'), a2 = at('Paul’s letter to the Romans'), a3 = at('Each child in that family line was a gift'), a4 = at('came from human strength');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c21" x={960} y={620} r={800} />
      <Ground id="cg21" />
      <Gp o={win(f, a0, a2)}>
        {[0, 1, 2].map((k) => F(f, a0 + k * 6, a2, (k === 0 ? SAR : k === 1 ? REB : RAC)(560 + k * 400), 'w' + k))}
        <circle cx={960} cy={500} r={360} fill="url(#halo)" opacity={0.5 * fi(f, a1)} />
      </Gp>
      <Gp o={win(f, a2, a3)}>
        <Stars o={0.6} seed={2} n={60} y1={420} />
        {F(f, a2, a3, ABR(800, {bend: 14, head: -18, beard: 'long'}))}
        {F(f, a2 + 6, a3, SAR(1060, {bend: 10, flip: true, lit: -1}))}
      </Gp>
      <Gp o={fi(f, a3)}>
        {[0, 1, 2].map((k) => F(f, a3, undefined, (k === 0 ? SAR : k === 1 ? REB : RAC)(500 + k * 400, {arm: [-70, -50]}), 'm' + k))}
        {[0, 1, 2].map((k) => <Baby key={k} x={600 + k * 400} y={620} s={1.6} o={fi(f, a3 + 10 + k * 10)} />)}
      </Gp>
    </>,
    html: <>
      <Big f={f} a={a0 + 10} b={a1} y={260} size={60}>NEVER A PUNISHMENT</Big>
      <Verse f={f} a={a2 + 10} b={a3} e={a2 + 120} small refText="ROMANS 4:19" lang="grk" orig="τὴν νέκρωσιν τῆς μήτρας Σάρρας" origKey={[1]} eng="he faced the fact that his body was as good as dead … and that Sarah’s womb was also *dead*" keys={[a2 + 90]} />
      <Note f={f} a={a3 + 10} y={150} size={38}>a gift only the Almighty could give</Note>
    </>,
  }));
}

// 22 CARRIED BY A GOD WHO WOULD NOT LET GO ---------------------------------------------------------
{
  const a0 = at('So the family was not under a curse'), a1 = at('It was a family of broken people'), a2 = at('carried along by a God');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c22" x={960} y={540} r={820} />
      <Lineage gen={4} cracks={3} />
      <path d="M560,880 C700,960 1220,960 1360,880" stroke="url(#goldLine)" strokeWidth={4} fill="none" filter="url(#lglow)" pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - eio(ramp(f, a2, 50))} />
      <circle cx={960} cy={520} r={420} fill="url(#halo)" opacity={0.45 * fi(f, a2)} />
    </>,
    html: <>
      <Note f={f} a={a1} b={a2} y={92} size={38}>broken people repeating each other’s mistakes</Note>
      <Ref f={f} a={a2} y={92}>CARRIED BY A GOD WHO KEPT HIS PROMISE</Ref>
    </>,
  }));
}

// 23 AND THEN CAME JOSEPH --------------------------------------------------------------------------
{
  const a0 = at('And then came Joseph'), a1 = at('He was the favorite son'), a2 = at('sold as a slave'), a3 = at('falsely accused'), a4 = at('forgotten in an Egyptian prison'), a5 = at('If anyone had the right'), a6 = at('But our God was at work'), a7 = at('By the time Joseph stood second');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c23" x={960} y={620} r={800} />
      <Ground id="cg23" />
      <Gp o={win(f, a1, a4)}>
        <Robe x={540} y={GY - 10} s={0.6} o={fi(f, a1)} />
        <Pit x={960} y={GY + 20} s={0.7} o={fi(f, a2)} />
        <Line w={2} d="M1300,700 C1340,660 1380,660 1420,700 C1460,740 1500,740 1540,700" o={fi(f, a3)} p={pr(f, a3, 20)} />
        {F(f, a1, a4, JOS(540, {head: 10}), 'jm', [[0, 380], [a1 + 6, 640], [a2, 1060], [a3, 1500]], 40)}
      </Gp>
      <Gp o={win(f, a4, a7)}>
        <Bars x={960} y={GY - 140} s={1.1} p={pr(f, a4, 30)} />
        {F(f, a4, a7, JOS(960, {head: f > a6 ? -10 : 14}))}
        <circle cx={960} cy={560} r={240} fill="url(#halo)" opacity={0.6 * fi(f, a6)} />
      </Gp>
      <Gp o={fi(f, a7)}>
        <Pyramids x={1550} y={GY} s={0.7} o={0.5} />
        <Colonnade x={960} y={GY} w={900} h={540} n={6} o={0.5} />
        <Throne x={1150} y={GY} s={0.8} o={0.6} />
        {F(f, a7, undefined, KING(1150, {robe: 'seat', flip: true, lit: -1, sc: 0.3}))}
        {F(f, a7 + 6, undefined, JOS(820, {mantle: true, sc: 0.31}))}
        <circle cx={820} cy={560} r={240} fill="url(#halo)" opacity={0.5} />
      </Gp>
    </>,
    html: <>
      <Big f={f} a={a0 - 6} b={a1} y={300} size={80} c={TXT.gold}>AND THEN CAME JOSEPH</Big>
      <Name f={f} a={a1} b={a4} x={540} y={915} en="FAVORED" />
      <Name f={f} a={a2} b={a4} x={960} y={915} en="SOLD" />
      <Name f={f} a={a3} b={a4} x={1420} y={915} en="FALSELY ACCUSED" />
      <Name f={f} a={a4 + 10} b={a7} x={960} y={885} en="FORGOTTEN" />
      <Note f={f} a={a5} b={a6} y={150} size={38}>every reason for revenge</Note>
      <Ref f={f} a={a7 + 10}>SECOND ONLY TO PHARAOH</Ref>
    </>,
  }));
}

// 24 THE REVEAL -------------------------------------------------------------------------------------
{
  const a0 = at('When they came to Egypt begging for grain'), a1 = at('Joseph tested them'), a2 = at('unable to hold back any longer'), a3 = at('He told them who he was'), a4 = at('And instead of revenge'), k4 = at('it was to save lives');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c24" x={960} y={620} r={800} />
      <Ground id="cg24" />
      <Colonnade x={960} y={GY} w={1300} h={520} n={7} o={0.4} />
      <Sacks x={1500} y={GY} s={0.9} o={fi(f, a0)} />
      {F(f, a0, undefined, JOS(620, {mantle: true, head: f > a2 ? 18 : 0, bend: f > a2 && f < a3 ? 10 : 0, arm: f > a4 ? [-90, -20] : [-16, -24]}))}
      {[0, 1, 2, 3].map((k) => F(f, a0 + 6 + k * 4, undefined, BP(900 + k * 140, {robe: f > a3 ? 'stand' : 'kneel', bend: f > a3 ? 0 : 20, flip: true, lit: -1, sc: 0.27, beard: k % 2 ? 'short' : 'long'}), 'b' + k))}
      <circle cx={760} cy={560} r={300} fill="url(#halo)" opacity={0.6 * fi(f, a3)} />
    </>,
    html: <>
      <Ref f={f} a={a0 + 10} b={a2}>GENESIS 42–45</Ref>
      <Note f={f} a={a1} b={a2} y={150} size={38}>had they changed?</Note>
      <Note f={f} a={a2 + 10} b={a3} y={150} size={38}>he wept so loudly the Egyptians heard</Note>
      <Big f={f} a={a3} b={a4} y={260} size={60} c={TXT.gold}>“I AM JOSEPH”</Big>
      <Verse f={f} a={a4} e={k4 + 40} small refText="GENESIS 45:5" lang="heb" orig="כִּי לְמִחְיָה שְׁלָחַנִי אֱלֹהִים לִפְנֵיכֶם" origKey={[1, 3]} eng="because it was to *save lives* that *God sent me* ahead of you" keys={[k4, k4 + 30]} />
    </>,
  }));
}

// 25 GENESIS 50:20 ---------------------------------------------------------------------------------
{
  const a0 = at('Years later, after their father Jacob died'), a1 = at('Joseph wept again'), k1 = at('but God intended it for good'), a2 = at('So then, don’t be afraid'), a3 = at('I will provide for you and your children');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c25" x={960} y={620} r={800} />
      <Ground id="cg25" />
      {F(f, a0, undefined, JOS(800, {mantle: true, arm: f > a2 ? [-90, -20] : [-16, -24], head: f > a1 && f < k1 ? 16 : 0}))}
      {[0, 1, 2].map((k) => F(f, a0 + 6 + k * 4, undefined, BP(1050 + k * 140, {robe: f > a2 ? 'stand' : 'kneel', bend: f > a2 ? 0 : 22, head: f > a2 ? 0 : 20, flip: true, lit: -1, sc: 0.27, beard: k % 2 ? 'short' : 'long'}), 'b' + k))}
      {[0, 1].map((k) => F(f, a3, undefined, BP(1500 + k * 90, {sc: 0.16, beard: 'none', flip: true, lit: -1}), 'c' + k))}
      <circle cx={960} cy={560} r={360} fill="url(#halo)" opacity={0.6 * fi(f, k1)} />
    </>,
    html: <>
      <Note f={f} a={a0 + 10} b={a1} y={150} size={38}>sure he would pay them back</Note>
      <Verse f={f} a={a1 + 20} e={k1 + 40} small refText="GENESIS 50:20" lang="heb" orig="אֱלֹהִים חֲשָׁבָהּ לְטֹבָה" origKey={[0, 2]} eng="You intended to harm me, but *God* intended it *for good* … the saving of many lives." keys={[k1, k1 + 20]} />
      <Note f={f} a={a2} y={380} size={38}>“Don’t be afraid. I will provide for you and your children.”</Note>
    </>,
  }));
}

// 26 THE PATTERN BROKE ------------------------------------------------------------------------------
{
  const a0 = at('That is the moment the pattern broke'), a1 = at('Joseph answered betrayal with forgiveness'), a2 = at('He did not pretend the harm was small'), a3 = at('He simply trusted');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c26" x={960} y={540} r={820} />
      <Lineage gen={4} cracks={3} heal={eio(ramp(f, a1, 60))} hl={['jos']} tags={[{k: 'jos', t: 'FORGIVENESS', o: fi(f, a1 + 20)}]} />
    </>,
    html: <>
      <Big f={f} a={a0} b={a1 + 20} y={92} size={56} c={TXT.gold}>THE PATTERN BROKE</Big>
      <Note f={f} a={a2} y={110} size={38}>God was bigger than what was done to him</Note>
    </>,
  }));
}

// 27 YOUR FAMILY -------------------------------------------------------------------------------------
{
  const a0 = at('Maybe you can see patterns in your own family'), a1 = at('Maybe it is anger'), a2 = at('Maybe, like Rachel'), a3 = at('Genesis does not pretend'), a4 = at('they are not the end of the story');
  const ws = [['anger', 'ANGER'], ['addiction', 'ADDICTION'], ['silence', 'SILENCE'], ['the same broken marriages', 'BROKEN MARRIAGES']];
  push(a0 - 6, (f) => {
    const wt = ws.map(([p]) => at(p));
    return {
      svg: <>
        <Spot id="c27" x={960} y={620} r={800} />
        <Ground id="cg27" />
        <House x={1450} y={GY} s={1.1} o={0.5} />
        {[0, 1, 2, 3].map((k) => F(f, a0 + k * 5, undefined, BP(500 + k * 170, {sc: [0.3, 0.28, 0.2, 0.17][k], hair: k === 1 ? 'veil' : 'cloth', beard: k === 0 ? 'short' : 'none', dim: f > a4 ? 0 : 0.3}), 'p' + k))}
        <Gp o={win(f, a2, a3)}>{F(f, a2, a3, RAC(1250, {head: 16, flip: true, lit: -1}))}</Gp>
        <circle cx={760} cy={560} r={340} fill="url(#halo)" opacity={0.5 * fi(f, a4)} />
      </>,
      html: <>
        {ws.map(([, t], i) => (
          <div key={t} style={{position: 'absolute', left: 240 + i * 380, top: 230, width: 300, textAlign: 'center', fontFamily: 'Cinzel', fontSize: 26, letterSpacing: '0.18em', color: TXT.ivory, opacity: win(f, wt[i], a2, 12)}}>{t}</div>
        ))}
        <Note f={f} a={a2 + 10} b={a3} y={150} size={38}>a pain you did nothing to cause</Note>
        <Ref f={f} a={a4 - 10} y={200}>NOT THE END OF THE STORY</Ref>
      </>,
    };
  });
}

// 28 CHRIST BECAME A CURSE FOR US ----------------------------------------------------------------
{
  const a0 = at('You are not doomed to repeat'), a1 = at('Paul writes'), k1 = at('by becoming a curse for us'), a2 = at('Jesus took the full weight'), a3 = at('And to everyone who belongs to him'), k3 = at('the new creation has come');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c28" x={960} y={620} r={800} />
      <Sun x={1500} y={kf(f, [[a3, 820], [a3 + 1, 300]], 120)} r={30} o={fi(f, a3)} t={0} />
      <Ground id="cg28" />
      <Hills y={GY} o={0.3} />
      <CrossHill x={960} y={GY} s={1} p={pr(f, a0, 50)} o={0.85} />
      <circle cx={960} cy={420} r={320} fill="url(#halo)" opacity={0.5 * fi(f, a2)} />
    </>,
    html: <>
      <Note f={f} a={a0} b={a1} y={150} size={40}>you are not doomed to repeat it</Note>
      <Verse f={f} a={a1 + 10} b={a3} e={k1 + 40} small refText="GALATIANS 3:13" lang="grk" orig="γενόμενος ὑπὲρ ἡμῶν κατάρα" origKey={[3]} eng="Christ redeemed us from the curse of the law by becoming a *curse* for us" keys={[k1 + 20]} />
      <Verse f={f} a={a3 + 10} e={k3 + 40} small refText="2 CORINTHIANS 5:17" lang="grk" orig="εἴ τις ἐν Χριστῷ, καινὴ κτίσις" origKey={[3, 4]} eng="If anyone is in Christ, the *new creation* has come: The old has gone, the new is here!" keys={[k3]} />
    </>,
  }));
}

// 29 JOSEPH AND JESUS BROKE IT ---------------------------------------------------------------------
{
  const a0 = at('Joseph broke the pattern in his family'), a1 = at('Jesus broke it for all of us'), a2 = at('the story of your family can change');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c29" x={960} y={620} r={800} />
      <Ground id="cg29" />
      {F(f, a0, undefined, JOS(620, {mantle: true, arm: [-60, -30]}))}
      {F(f, a1, undefined, JP(1300, {flip: true, lit: -1, arm: [-90, -20]}))}
      <circle cx={1300} cy={540} r={320} fill="url(#halo)" opacity={0.6 * fi(f, a1)} />
      <Gp o={fi(f, a2)}>{[0, 1, 2].map((k) => F(f, a2 + k * 6, undefined, BP(860 + k * 110, {sc: [0.27, 0.25, 0.16][k], hair: k === 1 ? 'veil' : 'cloth', beard: k ? 'none' : 'short'}), 'p' + k))}</Gp>
    </>,
    html: <>
      <Name f={f} a={a0 + 10} x={620} y={885} en="BY FORGIVING" />
      <Name f={f} a={a1 + 10} x={1300} y={885} en="BY DYING AND RISING" />
      <Ref f={f} a={a2} y={200}>YOUR FAMILY STORY CAN CHANGE</Ref>
    </>,
  }));
}

// 30 OUTRO -------------------------------------------------------------------------------------------
{
  const a0 = at('If this helped you see Genesis'), a1 = at('like this video'), a2 = at('And always remember'), a3 = at('Jesus loves you'), a4 = at('See you on the next one');
  push(a0 - 6, (f) => ({
    svg: <>
      <Spot id="c30" x={960} y={560} r={800} />
      <Gp o={win(f, a0, a2)}><Lineage gen={4} heal={1} cracks={3} o={0.5} /></Gp>
      <Gp o={fi(f, a2)}>
        <Ground id="cg30" />
        {F(f, a2, undefined, JP(960, {arm: [-110, -10], arm2: [-110, -10]}))}
        <circle cx={960} cy={540} r={380} fill="url(#halo)" opacity={0.75} />
      </Gp>
    </>,
    html: <>
      <Big f={f} a={a1} b={a2} y={300} size={60}>LIKE · SUBSCRIBE · SHARE</Big>
      <Big f={f} a={a3} y={250} size={84} c={TXT.gold}>JESUS LOVES YOU</Big>
      <Ref f={f} a={a4} y={330}>SEE YOU ON THE NEXT ONE</Ref>
    </>,
  }));
}
