import React from 'react';
import {at, win, fi, kf, ramp, eio, eout, clamp} from '../lib';
import {Fig, FigP, Line, Throne, TXT} from '../fig';
import {Ref, Big, Note, Name} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Altar, River, Dove} from '../extra';
import {CrossHill} from '../props';
import {JP, DP, BP, SP, F, Gp, pr, ez, ezArm, turn, walkX} from '../kit';
import {Beam, Card, Q, Arrow} from '../covprops';
import {Curtain, Ark, Temple, CherubArt, LifeTree, SkyTear, Flames} from '../tcprops';
import {PRIEST, PPL, WK, Dark, tearAt} from './tc1';

export const TC2: Scene[] = [];
const push = (start: number, render: Scene['render']) => TC2.push({start, render});

/** simple priest token for the crowd of 300 (no filters, cheap) */
const Token: React.FC<{x: number; y: number; s?: number; o?: number}> = ({x, y, s = 1, o = 1}) => (
  <g opacity={o} transform={`translate(${x} ${y}) scale(${s})`}>
    <circle cx={0} cy={-26} r={6} fill="#C99A4A" />
    <path d="M-7,-18 L7,-18 L9,0 L-9,0 Z" fill="#9C6E2C" />
  </g>
);

// 5 HEROD'S TEMPLE, THE SIZE --------------------------------------------------------------------
{
  const f0 = at('By the time of Jesus'), fJos = at('The Jewish historian Josephus'), fHeav = at('a picture of the heavens'), fMish = at('A later Jewish tradition'),
    fPalm = at('as thick as the palm'), f300 = at('three hundred priests'), fNot = at('You do not have to take every number'), fNo = at('No person standing on the floor'),
    fAcc = at('nobody tore it by accident'), fEnd = at('That is why Matthew and Mark');
  push(f0, (f) => {
    const top = 120, bot = GY;
    const hum = (bot - top) / 10.5;
    return {
      svg: <>
        <Spot id="f5" x={960} y={560} r={860} />
        <Gp o={win(f, f0, fJos + 6)}>
          <Ground id="f5g" />
          <Temple x={960} y={GY} s={1.2} p={pr(f, f0, 50)} />
          {[0, 1, 2, 3].map((k) => F(f, f0 + 20 + k * 6, fJos + 6, PPL([200, 330, 1600, 1730][k], {sc: 0.2, flip: k > 1, o: 0.85}), 'tp' + k))}
        </Gp>
        <Gp o={win(f, fJos, fNo + 6)}>
          <Ground id="f5g2" />
          <Curtain id="f5c" f={f} x={ez(f, fMish, 960, 1180, 36)} w={ez(f, fMish, 640, 440, 36)} top={ez(f, fMish, 300, top, 36)} stars={fi(f, fHeav, 40) * (1 - fi(f, fMish, 30))} cher={1 - 0.6 * fi(f, fHeav, 40) + 0.4 * fi(f, fMish, 30)} light={0.35} />
          <g opacity={fi(f, fMish + 30)}>
            <Line u w={2.4} c="#E3B465" d={`M920,${top} L920,${bot} M902,${top} L938,${top} M902,${bot} L938,${bot}`} p={pr(f, fMish + 30, 30)} />
            <text x={890} y={(top + bot) / 2} textAnchor="end" fill={TXT.gold} fontFamily="Cinzel" fontSize={40} letterSpacing={3}>≈ 60 FT</text>
          </g>
          {F(f, fMish + 40, fNo + 6, PRIEST(1460, {sc: hum / 1545, flip: true}))}
          <Card f={f} a={fPalm} b={f300} x={430} y={560} w={460} h={200} top="THICKNESS" big="ONE HANDBREADTH" />
          <Gp o={win(f, f300, fNo + 6)}>
            {Array.from({length: 300}, (_, i) => <Token key={i} x={100 + (i % 30) * 19} y={420 + Math.floor(i / 30) * 40} s={0.9} o={fi(f, f300 + (i % 30) * 0.5 + Math.floor(i / 30) * 2, 8)} />)}
          </Gp>
        </Gp>
        <Gp o={fi(f, fNo)}>
          <Ground id="f5g4" />
          <Curtain id="f5n" f={f} light={0.35} />
          {F(f, fNo, undefined, PPL(1240, {sc: 0.27, flip: true, arm: ezArm(f, fNo + 20, [-5, -36], [-170, -8], 14)}))}
          <Line u w={2} c="#E3B465" o={0.7 * fi(f, fNo + 30)} d={`M1210,${GY - 520} L1210,140`} p={pr(f, fNo + 30, 30)} />
        </Gp>
      </>,
      html: <>
        <Name f={f} a={f0 + 10} b={fJos} x={960} y={920} en="HEROD’S TEMPLE · JERUSALEM" />
        <Ref f={f} a={fJos} b={fMish} y={40}>JOSEPHUS · JEWISH WAR 5</Ref>
        <Note f={f} a={fHeav} b={fMish} y={960} size={44}>a picture of the heavens worked into the cloth</Note>
        <Ref f={f} a={fMish} b={fNot} y={40}>MISHNAH · SHEKALIM 8:5</Ref>
        <Note f={f} a={f300} b={fNot} y={300} x={430} size={40}>“three hundred priests”</Note>
        <Note f={f} a={fNot} b={fNo} y={180} size={44}>you do not need every number to get the point</Note>
        <Big f={f} a={fAcc} b={fEnd} y={40} size={56} c={TXT.gold}>NOBODY TORE IT BY ACCIDENT</Big>
      </>,
    };
  });
}

// 6 TOP TO BOTTOM, SCHIZO, TWO TEARINGS --------------------------------------------------------
{
  const g0 = at('That is why Matthew and Mark'), gMan = at('A man tearing cloth starts'), gTop = at('This tear started at the top'), gGod = at('where only God could take hold'),
    gMark = at('Mark adds another clue'), gWord = at('The Greek word he uses'), gTwice = at('in his whole Gospel he uses that verb'), gBap = at('The first time is at the very beginning'),
    gSky = at('saw heaven being torn open'), gVoice = at('a voice comes from heaven'), gSec = at('The second time is here'), gCent = at('a Roman centurion'),
    gBook = at('Mark builds his whole Gospel'), gDown = at('God tears open the sky'), gUp = at('God tears open the curtain'), gBoth = at('Both times, someone declares'), gEnd = at('So what did it mean');
  push(g0, (f) => {
    const tear = tearAt(f, gTop + 4, gGod - gTop + 30);
    return {
      svg: <>
        <Spot id="g6" x={960} y={560} r={860} />
        <Gp o={win(f, g0, gMark + 6)}>
          <Ground id="g6g" />
          <Curtain id="g6c" f={f} tear={tear} open={eio(ramp(f, gGod, 50))} light={1} />
          <Beam x={960} w={260} o={0.8 * win(f, gTop, gMark)} f={f} bottom={300} />
          {F(f, gMan, gTop + 10, PPL(1000, {sc: 0.27, flip: true, robe: 'stand', bend: 14, arm: [-60, -30]}))}
          <circle cx={960} cy={GY - 40} r={60} fill="url(#halo)" opacity={win(f, gMan + 10, gTop)} />
        </Gp>
        <Gp o={win(f, gMark, gBap + 6)}>
          <Card f={f} a={gWord} x={960} y={360} w={600} h={250} top="SCHIZŌ" grk="σχίζω" en="to tear, to split open" />
          <Gp o={fi(f, gTwice)}>
            <Line u w={2.4} c="#C99A4A" d="M360,720 L1560,720" p={pr(f, gTwice, 30)} />
            <text x={360} y={780} textAnchor="middle" fill={TXT.ivory} fontFamily="Cinzel" fontSize={26}>MARK 1</text>
            <text x={1560} y={780} textAnchor="middle" fill={TXT.ivory} fontFamily="Cinzel" fontSize={26}>MARK 16</text>
            {[[420, '1:10'], [1490, '15:38']].map(([x, t], i) => (
              <g key={i} opacity={fi(f, gTwice + 30 + i * 20)}>
                <circle cx={x as number} cy={720} r={60} fill="url(#halo)" />
                <circle cx={x as number} cy={720} r={12} fill="#FFE2A0" filter="url(#lglow)" />
                <text x={x as number} y={680} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={34}>{t}</text>
              </g>
            ))}
          </Gp>
        </Gp>
        <Gp o={win(f, gBap, gSec + 6)}>
          <Ground id="g6g2" />
          <SkyTear x={960} y={150} w={760} t={eio(ramp(f, gSky, 40))} />
          <River y={GY - 10} f={f} />
          {F(f, gBap, gSec + 6, JP(960, {head: ez(f, gSky, 0, -20, 20), y: GY + 60}))}
          <rect x={0} y={GY + 4} width={1920} height={120} fill="#15110c" opacity={0.85} />
          <River y={GY + 20} f={f} />
          {F(f, gBap + 10, gSec + 6, DP(1300, {beard: 'long', hair: 'long', flip: true, head: -10}))}
          <Dove x={960} y={ez(f, gSky + 20, 230, 400, 50)} s={0.7} f={f} o={fi(f, gSky + 20)} />
        </Gp>
        <Gp o={win(f, gSec, gBook + 6)}>
          <Ground id="g6g3" />
          <Dark o={0.3} />
          <CrossHill x={760} y={GY} s={1} />
          <Curtain id="g6d" f={f} x={1500} top={420} bottom={GY} w={300} tear={1} open={0.8} cher={0.8} />
          {F(f, gCent, gBook + 6, SP(1080, {hair: 'helmet', prop: 'spear', flip: true, head: -14, beard: 'short'}))}
        </Gp>
        <Gp o={fi(f, gBook)}>
          <Card f={f} a={gBook} x={540} y={300} w={640} h={200} top="MARK 1:10" big="HEAVEN TORN" />
          <Card f={f} a={gBook + 20} x={1380} y={300} w={640} h={200} top="MARK 15:38" big="CURTAIN TORN" />
          <Gp o={fi(f, gDown)}>
            <SkyTear x={540} y={470} w={320} t={1} />
            <Arrow x0={540} y0={500} x1={540} y1={720} p={pr(f, gDown + 10, 20)} />
            <text x={540} y={790} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={30} letterSpacing={3}>GOD COMES DOWN</text>
          </Gp>
          <Gp o={fi(f, gUp)}>
            <Curtain id="g6m" f={f} x={1380} top={450} bottom={720} w={200} tear={1} open={0.9} cher={0} />
            <Arrow x0={1180} y0={620} x1={1310} y1={620} p={pr(f, gUp + 10, 20)} />
            <text x={1380} y={790} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={30} letterSpacing={3}>WE COME TO HIM</text>
          </Gp>
          <Gp o={fi(f, gBoth)}>
            <text x={540} y={880} textAnchor="middle" fill={TXT.ivory} fontFamily="Corm" fontStyle="italic" fontSize={46}>“You are my Son”</text>
            <text x={1380} y={880} textAnchor="middle" fill={TXT.ivory} fontFamily="Corm" fontStyle="italic" fontSize={46}>“the Son of God”</text>
          </Gp>
        </Gp>
      </>,
      html: <>
        <Ref f={f} a={g0} b={gMan} y={40}>MATTHEW AND MARK BOTH SAY IT</Ref>
        <Note f={f} a={gMan} b={gTop} y={40} size={44}>a man starts at the bottom</Note>
        <Big f={f} a={gTop + 10} b={gMark} y={30} size={56} c={TXT.gold}>ONLY GOD COULD REACH THE TOP</Big>
        <Note f={f} a={gMark} b={gWord} y={200} size={46}>a clue that is easy to miss in English</Note>
        <Note f={f} a={gTwice + 10} b={gBap} y={850} size={44}>only twice in the whole Gospel</Note>
        <Q f={f} a={gSky} b={gVoice} refText="MARK 1:10" eng="“…he saw heaven being *torn open* and the Spirit descending on him like a dove.”" keys={[at('saw heaven being torn open') + 24]} y={30} size={46} />
        <Q f={f} a={gVoice} b={gSec} refText="MARK 1:11" eng="“You are *my Son*, whom I love.”" keys={[at('You are my Son') + 8]} y={30} />
        <Ref f={f} a={gSec} b={gCent} y={60}>MARK 15:38 · THE SECOND TIME</Ref>
        <Q f={f} a={gCent + 20} b={gBook} refText="MARK 15:39" eng="“Surely this man was *the Son of God*!”" keys={[at('was the Son of God')]} y={60} />
        <Ref f={f} a={gBook} b={gEnd} y={120}>TWO TEARINGS</Ref>
      </>,
    };
  });
}

// 7 HEBREWS 10, THE GUARDS SPLIT, THE TREE OF LIFE ---------------------------------------------
{
  const h0 = at('So what did it mean'), hQ = at('Therefore, brothers and sisters'), hRead = at('Read that slowly'), hBody = at('When his body was torn'), hBlood = at('The blood the high priest carried'),
    hGuard = at('And the guards woven into that curtain'), hSplit = at('were split right down the middle'), hRev = at('At the very end of the Bible'), hNo = at('this time nobody is standing guard'), hEnd = at('There is another side');
  push(h0, (f) => ({
    svg: <>
      <Spot id="h7" x={960} y={560} r={860} />
      <Gp o={win(f, h0, hRev + 6)}>
        <Ground id="h7g" />
        <Curtain id="h7c" f={f} tear={1} open={1} light={1} />
        <g opacity={win(f, hRead, hGuard)}>
          <Line w={3} c="#FFF3D6" d={`M950,${GY} L950,250 L970,250 L970,${GY} M880,350 L1040,350 L1040,370 L880,370 Z`} p={pr(f, hRead + 10, 40)} />
          <circle cx={960} cy={360} r={180} fill="url(#halo)" opacity={fi(f, hBody)} />
        </g>
        <circle cx={760} cy={560} r={200} fill="url(#halo)" opacity={win(f, hGuard + 20, hRev)} /><circle cx={1160} cy={560} r={200} fill="url(#halo)" opacity={win(f, hGuard + 30, hRev)} />
      </Gp>
      <Gp o={fi(f, hRev)}>
        <Ground id="h7g2" />
        <LifeTree x={760} y={GY} s={1.05} p={pr(f, hRev, 40)} glow={1} />
        <Beam x={760} w={340} o={0.75} f={f} />
        {[0, 1, 2, 3].map((k) => WK(f, hRev + 30, undefined, hRev + 40 + k * 10, hNo + 60 + k * 10, 1980 + k * 140, 1060 + k * 130, PPL(0, {m: k === 1 ? 'silver' : 'bronze', sc: 0.26 - k * 0.01}), 'rw' + k, 66))}
      </Gp>
    </>,
    html: <>
      <Note f={f} a={h0 + 6} b={hQ} y={40} size={46}>so what did it mean?</Note>
      <Q f={f} a={hQ} b={hRead} refText="HEBREWS 10:19–20" eng="“Therefore, brothers and sisters, since we have confidence to enter the Most Holy Place by the blood of Jesus, by a new and living way opened for us *through the curtain, that is, his body*.”" keys={[at('through the curtain, that is, his body')]} y={20} size={44} />
      <Note f={f} a={hRead} b={hBody} y={60} size={44}>the curtain, a picture of his body</Note>
      <Note f={f} a={hBody} b={hBlood} y={60} size={44}>torn together</Note>
      <Note f={f} a={hBlood} b={hGuard} y={60} size={44}>once a year, pointing to once for all</Note>
      <Big f={f} a={hSplit} b={hRev} y={30} size={56} c={TXT.gold}>THE GUARDS, SPLIT DOWN THE MIDDLE</Big>
      <Ref f={f} a={hRev + 10} b={hNo} y={80}>REVELATION 22 · THE TREE OF LIFE</Ref>
      <Big f={f} a={hNo} b={hEnd} y={80} size={60} c={TXT.gold}>NOBODY STANDING GUARD</Big>
    </>,
  }));
}

// 8 AD 70 ---------------------------------------------------------------------------------------
{
  const i0 = at('There is another side'), iQ = at('Do you see all these great buildings'), iForty = at('Forty years later'), iSign = at('The torn curtain was a sign'),
    iSac = at('The sacrifices and the priesthood'), iCame = at('and once he came'), iEnd = at('Think about what that means for you');
  push(i0, (f) => {
    const fall = eio(ramp(f, iForty + 40, 60));
    return {
      svg: <>
        <Spot id="i8" x={960} y={560} r={860} />
        <Gp o={win(f, i0, iSign + 6)}>
          <Ground id="i8g" />
          <g transform={`translate(0 ${fall * 70}) rotate(${fall * 2.5} 1240 ${GY})`} opacity={1 - 0.6 * fall}><Temple x={1240} y={GY} s={1} p={pr(f, i0, 40)} /></g>
          <Flames x0={900} x1={1600} y={GY} f={f} h={200} o={fi(f, iForty + 10, 30)} />
          <Gp o={win(f, i0, iForty + 6)}>
            {F(f, i0 + 10, iForty + 6, JP(380, {arm: ezArm(f, iQ, [-5, -36], [-100, -10], 14)}))}
            {[0, 1, 2].map((k) => F(f, i0 + 16 + k * 6, iForty + 6, BP(540 + k * 120, {sc: 0.27, head: -12, m: 'gold'}), 'dc' + k))}
          </Gp>
        </Gp>
        <Gp o={win(f, iSign, iSac + 6)}>
          <Ground id="i8g2" />
          <Curtain id="i8c" f={f} tear={1} open={1} light={0.9} />
        </Gp>
        <Gp o={fi(f, iSac)}>
          <Ground id="i8g3" />
          <g opacity={1 - 0.75 * fi(f, iCame, 40)}>
            <Altar x={560} y={GY} s={1} />
            {F(f, iSac, undefined, PRIEST(760, {flip: true}))}
          </g>
          <Beam x={1300} w={320} o={fi(f, iCame)} f={f} />
          {F(f, iCame, undefined, JP(1300, {}))}
        </Gp>
      </>,
      html: <>
        <Note f={f} a={i0 + 6} b={iQ} y={60} size={46}>Jesus had warned about it</Note>
        <Q f={f} a={iQ} b={iForty} refText="MARK 13:2" eng="“Do you see all these great buildings? *Not one stone here will be left on another*; every one will be thrown down.”" keys={[at('Not one stone here')]} y={40} />
        <Big f={f} a={iForty} b={iSign} y={60} size={90} c={TXT.gold}>AD 70</Big>
        <Note f={f} a={iSign} b={iSac} y={40} size={44}>the old system had finished its work</Note>
        <Note f={f} a={iSac} b={iEnd} y={110} size={46}>the shadow gave way to the real thing</Note>
      </>,
    };
  });
}

// 9 FOR YOU -------------------------------------------------------------------------------------
{
  const j0 = at('Think about what that means for you'), jWent = at('one man went in on their behalf'), jWait = at('everyone waited to see'), jToday = at('Today the Bible invites you'),
    jQ = at('Let us then approach'), jNeed = at('You do not need someone else'), jWall = at('If you have ever felt like God'), jSays = at('the curtain says otherwise'),
    jTorn = at('It was torn from the top'), jSew = at('nobody has ever been able to sew'), jEnd = at('Thank you for watching');
  push(j0, (f) => {
    const tear2 = tearAt(f, jSays, 70);
    return {
      svg: <>
        <Spot id="j9" x={960} y={560} r={860} />
        <Gp o={win(f, j0, jToday + 6)}>
          <Ground id="j9g" />
          <Curtain id="j9c" f={f} x={620} w={620} light={0.35} />
          {WK(f, j0, undefined, jWent, jWent + 60, 1100, 700, PRIEST(0, {o: 1 - fi(f, jWent + 50, 20)}), 'hp')}
          {[0, 1, 2, 3, 4].map((k) => F(f, j0 + 6 + k * 5, jToday + 6, PPL(1180 + k * 140, {flip: true, sc: 0.25, head: f > jWait ? ez(f, jWait + k * 8, 0, 10, 20) : 0}), 'cw' + k))}
        </Gp>
        <Gp o={win(f, jToday, jWall + 6)}>
          <Ground id="j9g2" />
          <Throne x={960} y={GY - 10} s={0.8} o={0.55 * fi(f, jQ)} />
          <Curtain id="j9t" f={f} tear={1} open={1} part={0.12} light={1} />
          {WK(f, jToday, undefined, jToday + 20, jQ + 20, 1800, 1010, PPL(0, {sc: 0.27}), 'yw', 66)}
        </Gp>
        <Gp o={fi(f, jWall)}>
          <Ground id="j9g3" />
          <Curtain id="j9w" f={f} tear={tear2} open={eio(ramp(f, jSays + 40, 50))} light={1} />
          <Beam x={960} w={260} o={0.8 * fi(f, jSays)} f={f} bottom={260} />
          {F(f, jWall, undefined, PPL(1260, {robe: 'kneel', flip: true, bend: ez(f, jSays + 50, 24, 4, 20), head: ez(f, jSays + 50, 28, -10, 20)}))}
        </Gp>
      </>,
      html: <>
        <Note f={f} a={j0 + 6} b={jWent} y={60} size={46}>for more than a thousand years</Note>
        <Note f={f} a={jWent} b={jWait} y={60} size={44}>one man went in for everyone</Note>
        <Note f={f} a={jWait} b={jToday} y={60} size={44}>and everyone waited</Note>
        <Big f={f} a={jToday} b={jQ} y={40} size={60} c={TXT.gold}>WALK STRAIGHT IN</Big>
        <Q f={f} a={jQ} b={jNeed} refText="HEBREWS 4:16" eng="“Let us then approach God’s throne of grace *with confidence*, so that we may receive mercy and find grace to help us in our time of need.”" keys={[at('throne of grace with confidence') + 18]} y={30} size={46} />
        <Note f={f} a={jNeed} b={jWall} y={60} size={44}>no go-between, no waiting for the right day</Note>
        <Note f={f} a={jWall + 6} b={jSays} y={60} size={44}>too holy to bother with your mess?</Note>
        <Big f={f} a={jTorn} b={jSew} y={30} size={60} c={TXT.gold}>TORN FROM THE TOP</Big>
        <Note f={f} a={jSew} b={jEnd} y={40} size={46}>never sewn back together</Note>
      </>,
    };
  });
}

// OUTRO -----------------------------------------------------------------------------------------
{
  const k0 = at('Thank you for watching'), kLike = at('Like the video'), kLove = at('And always remember'), kSee = at('See you on the next one');
  push(k0, (f) => ({
    svg: <>
      <Spot id="k10" x={960} y={560} r={860} />
      <Ground id="k10g" />
      <Curtain id="k10c" f={f} tear={1} open={1} part={0.18} light={1} />
      <Beam x={960} w={300} o={0.8} f={f} />
      {F(f, k0, undefined, JP(960, {arm: ezArm(f, kLove, [-5, -36], [-60, -10], 14)}))}
    </>,
    html: <>
      <Note f={f} a={k0 + 4} b={kLike} y={60} size={46}>thank you for watching</Note>
      <Big f={f} a={kLike} b={kLove} y={50} size={56} c={TXT.gold}>LIKE · SUBSCRIBE · SHARE</Big>
      <Big f={f} a={kLove} b={kSee} y={50} size={66} c={TXT.gold}>JESUS LOVES YOU</Big>
      <Note f={f} a={kSee} y={60} size={50}>see you on the next one</Note>
    </>,
  }));
}
