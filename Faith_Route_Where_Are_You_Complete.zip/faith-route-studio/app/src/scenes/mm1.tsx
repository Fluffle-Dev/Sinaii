import React from 'react';
import {at, win, fi, kf, ramp, eio, eout, clamp} from '../lib';
import {Fig, FigP, Line, Tent, Pyramids, Throne, Colonnade, Table, Fire, TXT} from '../fig';
import {Ref, Big, Note, Name} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Mountain} from '../extra';
import {Book, Scroll, Stars, SnakePole, Shelf} from '../props';
import {JP, DP, BP, SP, F, Gp, pr, ez, ezArm, turn, walkX} from '../kit';
import {Beam, Card, Q, Arrow} from '../covprops';
import {Incense} from '../tcprops';
import {Michael, Devil, Body, Slope, slopeY, Summit, SUMMIT, Vista, Bush, Rock, BookRow, Codex, Fragments, CaseFile, CaseRow, ChargeList, Shrine, Valley, TimeBar} from '../mmprops';

export const MM1: Scene[] = [];
const push = (start: number, render: Scene['render']) => MM1.push({start, render});

/* ---------------- cast + helpers ---------------- */
export const MOSES = (x: number, o: Partial<FigP> = {}) => DP(x, {beard: 'long', hair: 'cloth', mantle: true, prop: 'staff', ...o});
export const YMOSES = (x: number, o: Partial<FigP> = {}) => DP(x, {beard: 'short', hair: 'cloth', ...o});
export const PPL = (x: number, o: Partial<FigP> = {}) => BP(x, {sc: 0.27, ...o});
export const REST: [number, number] = [-5, -36];
/** walking figure between t0..t1, faces direction of travel */
export const WK = (f: number, a: number, b: number | undefined, t0: number, t1: number, x0: number, x1: number, p: FigP, k?: string | number, stride = 70) => {
  const w = walkX(f, t0, t1, x0, x1, stride);
  return <Fig key={k} {...p} x={w.x} walk={w.walk} wa={w.wa} face={p.face ?? (x1 >= x0 ? 1 : -1)} o={(p.o ?? 1) * win(f, a, b, 16)} />;
};
/** devil walking in/out */
export const DW = (f: number, t0: number, t1: number, x0: number, x1: number, extra: Partial<FigP> & {o?: number; smoke?: number; face?: number} = {}) => {
  const w = walkX(f, t0, t1, x0, x1, 64);
  return <Devil x={w.x} y={GY} f={f} walk={w.walk} wa={w.wa} face={extra.face ?? (x1 >= x0 ? 1 : -1)} {...extra} />;
};
/** Michael descending at t */
export const descend = (f: number, t: number, h = 280, d = 46) => -h * (1 - eio(ramp(f, t, d)));
export const Night: React.FC<{o?: number}> = ({o = 1}) => (o > 0.001 ? <><rect width={1920} height={1080} fill="#040302" opacity={0.5 * o} /><Stars o={0.7 * o} seed={11} n={70} y1={500} /></> : null);
/** the recurring night set on Mount Nebo with the body in the middle */
export const NeboSet: React.FC<{f: number; id: string; body?: number; glow?: number; bx?: number}> = ({f, id, body = 1, glow = 0.5, bx = 960}) => (
  <>
    <Night />
    <Spot id={id} x={bx} y={660} r={760} a={0.5} />
    <Mountain x={300} y={GY} s={0.8} o={0.28} />
    <Mountain x={1640} y={GY} s={0.62} o={0.2} />
    <Ground id={id + 'g'} cx={bx} />
    <Body x={bx} y={GY} s={0.95} o={body} glow={glow} />
  </>
);
/** strike pose: two blows at t and t+28 */
export const strike = (f: number, t: number): [number, number] => {
  if (f < t) return REST;
  const k = f - t;
  if (k < 10) return ezArm(f, t, REST, [-150, -20], 10);
  if (k < 18) return ezArm(f, t + 10, [-150, -20], [-55, -30], 7);
  if (k < 28) return ezArm(f, t + 18, [-55, -30], [-150, -20], 10);
  if (k < 36) return ezArm(f, t + 28, [-150, -20], [-55, -30], 7);
  return ezArm(f, t + 46, [-55, -30], REST, 14);
};
export const ROW1: CaseRow = {tag: 'JUDE 9', acc: 'THE DEVIL', who: 'MOSES', charge: 'MURDER', ans: 'THE LORD REBUKE YOU'};
export const ROW2: CaseRow = {tag: 'ZECH 3', acc: 'SATAN', who: 'JOSHUA', charge: 'FILTHY CLOTHES', ans: 'THE LORD REBUKE YOU'};
export const ROW3: CaseRow = {tag: 'ROM 8', acc: 'THE ACCUSER', who: 'YOU', charge: 'THE LIST', ans: 'GOD JUSTIFIES'};

// 0 TITLE QUESTION -------------------------------------------------------------------------------
{
  const aM = at('archangel Michael'), aD = at('fight the devil'), aB = at('the dead body of Moses');
  push(0, (f) => ({
    svg: <>
      <NeboSet f={f} id="s0" body={fi(f, 0, 30)} glow={0.6} />
      <Michael x={600} y={GY + descend(f, aM - 6)} f={f} o={fi(f, aM - 6, 20)} />
      <Devil x={1340} y={GY} f={f} flip o={fi(f, aD, 26)} arm={ezArm(f, aB, REST, [-80, -10], 14)} />
    </>,
    html: <>
      <Note f={f} a={2} y={60} size={48}>why did the archangel fight the devil</Note>
      <Big f={f} a={aB} y={130} size={64} c={TXT.gold}>OVER THE BODY OF MOSES?</Big>
    </>,
  }));
}

// 1 HOOK ----------------------------------------------------------------------------------------
{
  const b0 = at('Most people picture'), bOld = at('An old man climbs'), bLooks = at('looks out over a land'), bDies = at('and dies with nobody there'),
    bLetter = at('But a letter near the very back'), bShort = at('one so short you can read'), bFar = at('says that mountain was far from quiet'),
    bHeav = at('Heaven’s chief angel'), bStood = at('stood over that body'), bWhat = at('So what did the devil want'), bWhy = at('and why did an archangel refuse'), bEnd = at('Start where the Old Testament');
  push(b0, (f) => {
    const w = walkX(f, bOld, bLooks - 6, 300, 1220, 64);
    const dv = walkX(f, bWhat, bWhat + 34, 1340, 1260, 60);
    return {
      svg: <>
        <Gp o={win(f, b0, bLooks + 4)}>
          <Spot id="s1a" x={900} y={560} r={860} />
          <Slope p={pr(f, b0, 40)} />
          <Beam x={1320} w={240} o={0.55 * fi(f, b0 + 20, 30)} f={f} bottom={420} />
          <Fig {...MOSES(0, {head: f < bOld ? -12 : 0})} x={w.x} y={slopeY(w.x)} walk={w.walk} wa={w.wa} face={1} />
        </Gp>
        <Gp o={win(f, bLooks, bLetter + 4)}>
          <Spot id="s1b" x={700} y={520} r={900} />
          <Vista f={f} p={pr(f, bLooks, 50)} lab={0} />
          <Summit />
          <Beam x={SUMMIT.x} w={200} o={0.8 * fi(f, bDies, 30)} f={f} bottom={SUMMIT.y} />
          <Fig {...MOSES(SUMMIT.x, {sc: 0.2, y: SUMMIT.y, head: ez(f, bDies + 10, -4, 24, 24), bend: ez(f, bDies + 10, 0, 10, 24)})} />
        </Gp>
        <BookRow f={f} a={bLetter} b={bFar + 4} y={720} />
        <Gp o={fi(f, bFar)}>
          <NeboSet f={f} id="s1d" glow={0.55} />
          <Michael x={600} y={GY + descend(f, bHeav)} f={f} o={fi(f, bHeav, 20)} arm={ezArm(f, bStood + 14, REST, [-62, -22], 14)} />
          <Devil x={dv.x} y={GY} f={f} walk={dv.walk} wa={dv.wa} face={-1} o={fi(f, bHeav + 16, 30)} arm={ezArm(f, bStood, REST, [-80, -10], 14)} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={b0 + 6} b={bOld} y={90} size={48}>the quietest ending in the Old Testament</Note>
        <Note f={f} a={bOld} b={bLooks} y={90} size={48}>an old man climbs a mountain alone</Note>
        <Note f={f} a={bLooks + 6} b={bDies} y={110} size={48}>a land he will never enter</Note>
        <Note f={f} a={bDies} b={bLetter} y={110} size={48}>nobody there except God</Note>
        <Note f={f} a={bShort} b={bFar} y={170} size={46}>one chapter, about three minutes long</Note>
        <Note f={f} a={bFar + 6} b={bHeav} y={100} size={48}>far from quiet</Note>
        <Note f={f} a={bHeav} b={bWhat} y={100} size={46}>heaven’s chief angel · the devil himself</Note>
        <Big f={f} a={bWhat + 12} b={bWhy} y={100} size={56} c={TXT.gold}>WHAT DID HE WANT WITH A DEAD MAN?</Big>
        <Big f={f} a={bWhy + 10} b={bEnd} y={100} size={56} c={TXT.gold}>WHY NOT ONE HARSH WORD?</Big>
      </>,
    };
  });
}

// 2 MOUNT NEBO ----------------------------------------------------------------------------------
{
  const c0 = at('Start where the Old Testament'), cAge = at('Moses was a hundred'), cShow = at('showed him the whole promised land'), cGil = at('from the hills of Gilead'),
    cJer = at('to Jericho, the City of Palms'), cTold = at('Then God told him'), cQ = at('I have let you see it'), cEarl = at('Earlier in the wilderness'),
    cStruck = at('Moses had struck a rock'), cCost = at('and that act of disobedience'), cLast = at('The last chapter of Deuteronomy'), cQ2 = at('And Moses the servant of the LORD died'),
    cBur = at('He buried him in Moab'), cNone = at('but to this day no one knows'), cEnd = at('That passage holds two strange');
  push(c0, (f) => {
    const w = walkX(f, cAge + 6, cShow - 4, 560, 1220, 64);
    return {
      svg: <>
        <Gp o={win(f, c0, cAge + 4)}>
          <Spot id="s2a" x={960} y={600} r={800} />
          <Ground id="s2ag" />
          <Book x={960} y={GY - 30} s={1.25} p={pr(f, c0, 40)} />
          <Beam x={960} w={320} o={0.6} f={f} />
        </Gp>
        <Gp o={win(f, cAge, cShow + 4)}>
          <Spot id="s2b" x={900} y={560} r={860} />
          <Slope />
          <Beam x={1320} w={240} o={0.7} f={f} bottom={420} />
          <Fig {...MOSES(0)} x={w.x} y={slopeY(w.x)} walk={w.walk} wa={w.wa} face={1} />
        </Gp>
        <Gp o={win(f, cShow, cEarl + 4)}>
          <Spot id="s2c" x={900} y={520} r={900} />
          <Vista f={f} p={pr(f, cShow, 40)} gilead={fi(f, cGil)} jericho={fi(f, cJer)} jordan={fi(f, cShow + 20)} />
          <Summit />
          <Beam x={SUMMIT.x} w={200} o={0.75 * fi(f, cTold, 20)} f={f} bottom={SUMMIT.y} />
          <Fig {...MOSES(SUMMIT.x, {sc: 0.2, y: SUMMIT.y, head: -4})} />
        </Gp>
        <Gp o={win(f, cEarl, cLast + 4)}>
          <Spot id="s2d" x={1000} y={600} r={800} />
          <Ground id="s2dg" />
          <Rock x={1180} y={GY} s={1.05} water={fi(f, cStruck + 44, 20)} f={f} crack={pr(f, cStruck + 36, 10)} />
          <Fig {...MOSES(820, {arm: strike(f, cStruck + 8), bend: f > cStruck + 8 && f < cStruck + 50 ? 6 : 0})} />
          {[0, 1, 2].map((k) => F(f, cEarl + 10 + k * 6, undefined, PPL(1580 + k * 120, {flip: true, sc: 0.24, head: 6}), 'p' + k))}
          <Gp o={fi(f, cCost, 20) * 0.45}><rect width={1920} height={1080} fill="#050302" /></Gp>
        </Gp>
        <Gp o={win(f, cLast, cBur + 4)}>
          <Spot id="s2e" x={700} y={520} r={900} a={0.45} />
          <Vista f={f} lab={0} o={0.6} />
          <Summit />
          <Beam x={SUMMIT.x} w={220} o={0.9} f={f} bottom={SUMMIT.y} />
          <Fig {...MOSES(SUMMIT.x, {sc: 0.2, y: SUMMIT.y, head: 24, bend: 12})} />
        </Gp>
        <Gp o={fi(f, cBur)}>
          <Spot id="s2f" x={1060} y={760} r={760} a={0.5} />
          <Valley f={f} grave={1} seal={eio(ramp(f, cNone + 10, 40))} q={fi(f, cNone + 30)} />
          <Beam x={1060} w={260} o={0.85 * (1 - 0.6 * fi(f, cNone + 10, 40))} f={f} bottom={866} />
        </Gp>
      </>,
      html: <>
        <Big f={f} a={c0 + 4} b={cAge - 4} y={120} size={64} c={TXT.gold}>DEUTERONOMY 34</Big>
        <Note f={f} a={c0 + 14} b={cAge - 4} y={210} size={46}>where the Old Testament leaves it</Note>
        <Big f={f} a={cAge + 16} b={cShow} y={100} size={58} c={TXT.gold}>MOSES · 120 YEARS OLD</Big>
        <Name f={f} a={cShow + 10} b={cEarl} x={440} y={900} en="MOUNT NEBO" />
        <Q f={f} a={cQ} b={cEarl} refText="DEUTERONOMY 34:4" eng="“I have let you see it with your eyes, but *you will not cross over into it*.”" keys={[at('you will not cross over')]} y={60} />
        <Ref f={f} a={cEarl} b={cStruck} y={80}>NUMBERS 20 · THE WILDERNESS</Ref>
        <Note f={f} a={cStruck} b={cCost} y={110} size={48}>God told him only to speak to it</Note>
        <Big f={f} a={cCost} b={cLast} y={110} size={64} c={TXT.gold}>IT COST HIM THE LAND</Big>
        <Q f={f} a={cQ2} b={cBur} refText="DEUTERONOMY 34:5" eng="“And Moses the servant of the LORD *died there in Moab*, as the LORD had said.”" keys={[at('died there in Moab')]} y={60} />
        <Q f={f} a={cBur} b={cEnd} refText="DEUTERONOMY 34:6" eng="“He buried him in Moab, in the valley opposite Beth Peor, but to this day *no one knows where his grave is*.”" keys={[at('no one knows where his grave is')]} y={50} />
      </>,
    };
  });
}

// 3 TWO STRANGE DETAILS -------------------------------------------------------------------------
{
  const d0 = at('That passage holds two strange'), dHe = at('The word he points back to God'), dOnly = at('which makes Moses the only person'), dRab = at('The rabbis of the Talmud'),
    dMouth = at('the Hebrew literally says he died at the mouth'), dKiss = at('with a kiss'), dSec = at('The second detail is the hidden grave'), dWept = at('Israel wept for Moses'),
    dNob = at('yet nobody could ever visit'), dHold = at('Hold on to that hidden grave'), dEnd = at('For more than a thousand years');
  push(d0, (f) => ({
    svg: <>
      <Gp o={win(f, d0, dRab + 4)}>
        <Spot id="s3a" x={1060} y={760} r={760} a={0.5} />
        <Valley f={f} grave={1} />
        <Beam x={1060} w={280} o={0.9} f={f} bottom={866} />
      </Gp>
      <Gp o={win(f, dRab, dSec + 4)}>
        <Night o={0.6} />
        <Spot id="s3b" x={960} y={660} r={760} a={0.5} />
        <Ground id="s3bg" />
        <Body x={960} y={GY} s={1.05} glow={0.5} />
        <Beam x={960} w={300} o={0.8} f={f} />
        <circle cx={960 - 200} cy={GY - 120} r={60 + 90 * eout(ramp(f, dKiss, 40))} fill="url(#halo)" opacity={2 * win(f, dKiss, dKiss + 50, 20)} />
        <Card f={f} a={dMouth} b={dSec + 4} x={960} y={330} w={640} h={270} top="AL PI ADONAI" heb="עַל־פִּי יְהוָה" en="at the mouth of the LORD" />
      </Gp>
      <Gp o={win(f, dSec, dWept + 4)}>
        <Spot id="s3c" x={1060} y={760} r={760} a={0.5} />
        <Valley f={f} grave={1} seal={1} label={1} />
      </Gp>
      <Gp o={win(f, dWept, dNob + 4)}>
        <Spot id="s3d" x={960} y={600} r={820} />
        <Ground id="s3dg" />
        {[[300, 0.55], [560, 0.7], [1500, 0.6]].map(([x, s], i) => <Tent key={i} x={x} y={GY} s={s} o={0.6} />)}
        {[0, 1, 2, 3, 4].map((k) => F(f, dWept + k * 5, undefined, (k % 2 ? BP : DP)(720 + k * 120, {sc: 0.27, beard: k % 2 ? 'none' : 'short', hair: k % 2 ? 'veil' : 'cloth', head: 22, bend: 8, arm: k === 1 || k === 3 ? [-80, -130] : REST, reach: k === 1 || k === 3 ? 0.5 : 1}), 'w' + k))}
      </Gp>
      <Gp o={fi(f, dNob)}>
        <Spot id="s3e" x={1060} y={760} r={760} a={0.5} />
        <Valley f={f} grave={1} seal={1} q={fi(f, dNob + 10)} label={1} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={d0 + 6} b={dHe} y={100} size={48}>two strange details</Note>
      <Big f={f} a={dHe + 6} b={dRab} y={100} size={72} c={TXT.gold}>HE BURIED HIM</Big>
      <Note f={f} a={dOnly} b={dRab} y={200} size={44}>the only person in the Bible buried by God himself</Note>
      <Ref f={f} a={dRab} b={dSec} y={70}>THE TALMUD · BAVA BATRA 17a</Ref>
      <Note f={f} a={dKiss} b={dSec} y={900} size={46}>taken with a kiss</Note>
      <Ref f={f} a={dSec + 4} b={dWept} y={80}>THE SECOND DETAIL · THE HIDDEN GRAVE</Ref>
      <Note f={f} a={dWept + 12} b={dNob} y={140} size={48}>Israel wept for thirty days</Note>
      <Note f={f} a={dNob} b={dHold} y={110} size={48}>nobody could visit his tomb</Note>
      <Big f={f} a={dHold} b={dEnd} y={100} size={56} c={TXT.gold}>HOLD ON TO THAT HIDDEN GRAVE</Big>
    </>,
  }));
}

// 4 JUDE ----------------------------------------------------------------------------------------
{
  const e0 = at('For more than a thousand years'), eJude = at('Then a man named Jude'), eServ = at('He introduces himself as a servant'), eBro = at('which is why he is usually identified'),
    eLet = at('His letter is a single chapter'), eWarn = at('written to warn churches'), eMid = at('In the middle of that warning'), eQ = at('But even the archangel Michael'), eEnd = at('Jude mentions the fight');
  push(e0, (f) => ({
    svg: <>
      <TimeBar f={f} a={e0} b={eJude + 4} l="MOSES" r="JUDE" mid="more than a thousand years" />
      <Gp o={win(f, e0 - 6, eJude + 4, 12)}>
        <circle cx={360} cy={420} r={200} fill="url(#halo)" opacity={0.7} />
        <Fig {...MOSES(360, {sc: 0.22, y: 578})} />
        <circle cx={1560} cy={420} r={200} fill="url(#halo)" opacity={0.7 * fi(f, e0 + 20, 20)} />
        <Fig {...DP(1560, {sc: 0.22, y: 578, flip: true, beard: 'short', hair: 'cloth', o: fi(f, e0 + 20, 20)})} />
      </Gp>
      <Gp o={win(f, eJude, eLet + 4)}>
        <Spot id="s4b" x={960} y={620} r={800} />
        <Ground id="s4bg" />
        <Table x={1080} y={GY} w={520} p={pr(f, eJude, 30)} />
        <Scroll x={1040} y={GY - 150} s={0.36} />
        <Fire x={1260} y={GY - 134} s={0.45} f={f} />
        <Fig {...DP(740, {robe: 'seat', bench: true, beard: 'short', hair: 'cloth', arm: [-62, -48], head: 10})} />
        <Gp o={fi(f, eBro, 30) * 0.5}><Fig {...JP(330, {o: 0.6})} /></Gp>
      </Gp>
      <Gp o={win(f, eLet, eMid + 4)}>
        <Spot id="s4c" x={960} y={600} r={820} />
        <Ground id="s4cg" />
        <Scroll x={600} y={GY - 120} s={1.3} p={pr(f, eLet, 30)} />
        <Card f={f} a={eLet + 10} b={eWarn} x={1300} y={460} w={520} h={260} top="JUDE" big="25 VERSES" en="one chapter" />
        {[0, 1, 2].map((k) => F(f, eWarn + k * 6, undefined, BP(1180 + k * 190, {flip: true, sc: 0.29, head: -16, arm: k === 1 ? [-150, -30] : [-100, -40]}), 'tw' + k))}
      </Gp>
      <Gp o={fi(f, eMid)}>
        <NeboSet f={f} id="s4d" glow={0.5} />
        <Michael x={620} y={GY} f={f} sc={0.3} />
        <Devil x={1320} y={GY} f={f} flip sc={0.3} arm={[-80, -10]} />
      </Gp>
    </>,
    html: <>
      <Name f={f} a={eJude + 10} b={eLet} x={740} y={900} en="JUDE" />
      <Note f={f} a={eServ} b={eBro} y={100} size={46}>a servant of Jesus Christ · a brother of James</Note>
      <Note f={f} a={eBro} b={eLet} y={100} size={46}>one of the brothers of Jesus</Note>
      <Ref f={f} a={eBro + 10} b={eLet} y={190}>MATTHEW 13:55</Ref>
      <Note f={f} a={eWarn} b={eMid} y={100} size={46}>teachers who mocked spiritual powers</Note>
      <Q f={f} a={eQ} b={eEnd} refText="JUDE 9" eng="“But even the archangel Michael, when he was *disputing with the devil about the body of Moses*, did not himself dare to condemn him for slander but said, *‘The Lord rebuke you!’*”" keys={[at('disputing with the devil'), at('said The Lord rebuke you')]} y={30} size={46} />
    </>,
  }));
}

// 5 ORIGEN, CLEMENT, CERIANI --------------------------------------------------------------------
{
  const f0 = at('Jude mentions the fight'), fOri = at('Origen, a Christian teacher'), fAss = at('called the Assumption of Moses'), fCle = at('and Clement of Alexandria'),
    fFru = at('The frustrating part'), fLat = at('It is a Latin manuscript'), fPub = at('and published in'), fEnd = at('and its ending is missing'), fWhat = at('What we know about those lost pages'), fEnd2 = at('One caution before');
  push(f0, (f) => ({
    svg: <>
      <Gp o={win(f, f0, fOri + 4)}>
        <Spot id="s5a" x={960} y={620} r={800} />
        <Ground id="s5ag" />
        <Fig {...DP(640, {beard: 'short', hair: 'cloth', arm: [-70, -40]})} />
        <Scroll x={760} y={GY - 300} s={0.32} />
        {[0, 1, 2, 3].map((k) => F(f, f0 + 8 + k * 5, undefined, (k % 2 ? BP : DP)(980 + k * 170, {robe: 'seat', flip: true, sc: 0.27, head: 8, beard: k % 2 ? 'none' : 'short'}), 'l' + k))}
      </Gp>
      <Gp o={win(f, fOri, fFru + 4)}>
        <Spot id="s5b" x={960} y={620} r={820} />
        <Ground id="s5bg" />
        {F(f, fOri, undefined, DP(560, {robe: 'seat', bench: true, beard: 'long', hair: 'cloth', arm: [-60, -50], head: 8}))}
        <Scroll x={720} y={GY - 260} s={0.3} o={fi(f, fOri + 10)} />
        {F(f, fCle, undefined, DP(1360, {robe: 'seat', bench: true, beard: 'long', hair: 'cap', flip: true, arm: [-60, -50], head: 8}))}
        <Card f={f} a={fAss} x={960} y={360} w={660} h={210} top="THE ASSUMPTION OF MOSES" en="a Jewish book" />
      </Gp>
      <Gp o={win(f, fFru, fWhat + 4)}>
        <Spot id="s5c" x={960} y={620} r={820} />
        <Colonnade x={960} y={GY} w={1180} h={600} n={5} o={0.35} />
        <Ground id="s5cg" />
        <Shelf x={960} y={GY - 520} s={0.8} o={0.4} />
        <Codex x={960} y={GY - 70} s={1.15} p={pr(f, fFru, 30)} torn={eio(ramp(f, fEnd, 30))} q={fi(f, fEnd + 24)} />
        <circle cx={960} cy={GY - 200} r={260} fill="url(#halo)" opacity={0.6} />
        {F(f, fLat, undefined, BP(1500, {flip: true, sc: 0.28, arm: [-60, -40], hair: 'bare', beard: 'short'}))}
        <Fire x={1418} y={GY - 196} s={0.3} f={f} o={fi(f, fLat + 10)} />
      </Gp>
      <Gp o={fi(f, fWhat)}>
        <Spot id="s5d" x={960} y={620} r={820} />
        <Ground id="s5dg" />
        <Codex x={640} y={GY - 70} s={1} torn={1} q={1} />
        <Fragments x={1320} y={GY - 300} p={eio(ramp(f, fWhat + 10, 110))} s={0.72} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={f0 + 6} b={fOri} y={100} size={48}>his readers already knew the story</Note>
      <Name f={f} a={fOri + 8} b={fFru} x={560} y={900} en="ORIGEN · ABOUT AD 230" />
      <Name f={f} a={fCle + 8} b={fFru} x={1360} y={900} en="CLEMENT OF ALEXANDRIA" />
      <Note f={f} a={fFru} b={fLat} y={100} size={48}>only one copy survived</Note>
      <Name f={f} a={fLat + 6} b={fWhat} x={960} y={900} en="AMBROSIAN LIBRARY · MILAN" />
      <Big f={f} a={fPub} b={fEnd} y={90} size={96} c={TXT.gold}>1861</Big>
      <Note f={f} a={fEnd} b={fWhat} y={100} size={48}>the ending is missing</Note>
      <Note f={f} a={fWhat + 6} b={fEnd2} y={100} size={46}>pieced together from early Christian writers</Note>
    </>,
  }));
}

// 6 ONE CAUTION ---------------------------------------------------------------------------------
{
  const g0 = at('One caution before'), gJude = at('Jude quoting a book does not'), gPaul = at('any more than Paul quoting Greek poets'), gHoly = at('The Holy Spirit let this one scene'),
    gRest = at('while the rest of that old book'), gEnd = at('So what was the argument about');
  push(g0, (f) => {
    const mv = eio(ramp(f, gHoly + 10, 60));
    return {
      svg: <>
        <Gp o={win(f, g0, gPaul + 4) + fi(f, gHoly)}>
          <Spot id="s6a" x={960} y={620} r={820} />
          <Ground id="s6ag" />
          <Book x={600} y={GY - 40} s={0.95} />
          <Beam x={600} w={300} o={0.55 + 0.3 * fi(f, gHoly + 40)} f={f} />
          <text x={600} y={GY + 56} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={36} letterSpacing={6}>THE BIBLE</text>
          <Codex x={1320} y={GY - 40} s={0.85} torn={1} o={0.75 - 0.4 * fi(f, gRest, 30)} />
          <text x={1320} y={GY + 56} textAnchor="middle" fill={TXT.dim} fontFamily="Cinzel" fontSize={30} letterSpacing={4} opacity={0.9 - 0.4 * fi(f, gRest, 30)}>THE ASSUMPTION OF MOSES</text>
          <g opacity={win(f, gHoly + 4, undefined)}>
            <g transform={`translate(${1320 - 720 * mv} ${-160 - 60 * Math.sin(mv * Math.PI)})`}>
              <ellipse cx={0} cy={GY - 230} rx={170} ry={90} fill="url(#halo)" />
              <rect x={-130} y={GY - 290} width={260} height={120} fill="#000" opacity={0.55} stroke="#F1CD86" strokeWidth={2} />
              <text x={0} y={GY - 236} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={34} letterSpacing={4}>JUDE 9</text>
              <text x={0} y={GY - 198} textAnchor="middle" fill={TXT.ivory} fontFamily="Corm" fontStyle="italic" fontSize={28}>one scene</text>
            </g>
          </g>
        </Gp>
        <Gp o={win(f, gPaul, gHoly + 4)}>
          <Spot id="s6b" x={1100} y={600} r={820} />
          <Ground id="s6bg" />
          <Colonnade x={1380} y={GY} w={620} h={420} n={4} p={pr(f, gPaul, 30)} />
          <Line u w={2.2} p={pr(f, gPaul + 10, 30)} d={`M1050,${GY - 420} L1380,${GY - 540} L1710,${GY - 420} Z`} />
          <Fig {...DP(700, {beard: 'short', hair: 'bare', arm: ezArm(f, gPaul + 10, REST, [-110, -20], 14)})} />
          {[0, 1, 2].map((k) => F(f, gPaul + 8 + k * 5, undefined, BP(960 + k * 130, {flip: true, sc: 0.27, head: -4}), 'g' + k))}
        </Gp>
      </>,
      html: <>
        <Note f={f} a={g0 + 6} b={gJude} y={100} size={48}>one caution</Note>
        <Note f={f} a={gJude} b={gPaul} y={100} size={46}>quoting a book does not make it scripture</Note>
        <Ref f={f} a={gPaul} b={gHoly} y={70}>ACTS 17:28 · PAUL IN ATHENS</Ref>
        <Note f={f} a={gPaul + 10} b={gHoly} y={150} size={46}>quoting Greek poets</Note>
        <Note f={f} a={gHoly + 6} b={gRest} y={100} size={46}>one scene let into the New Testament</Note>
        <Note f={f} a={gRest} b={gEnd} y={100} size={46}>the rest stays outside the Bible</Note>
      </>,
    };
  });
}

// 7 THE ARGUMENT --------------------------------------------------------------------------------
{
  const h0 = at('So what was the argument about'), hPiece = at('Piecing those early reports'), hBau = at('Richard Bauckham'), hDeut = at('Deuteronomy says God buried Moses'),
    hThru = at('he did it through Michael'), hObj = at('The devil showed up to object'), hCase = at('his whole case rested on one fact'), hMur = at('that Moses was a murderer'),
    hForty = at('Forty years before the burning bush'), hSeen = at('Moses had seen an Egyptian'), hQ = at('Looking this way and that'), hKill = at('he killed the Egyptian'),
    hSand = at('and hid him in the sand'), hArg = at('The devil argued that a man'), hDem = at('and he demanded the body'), hEnd = at('That fits everything else');
  push(h0, (f) => {
    const mw = walkX(f, hQ + 46, hKill - 4, 520, 1150, 70);
    const face = f < hQ + 6 ? 1 : f < hQ + 24 ? turn(f, hQ + 6, 1, 10) : turn(f, hQ + 24, -1, 10);
    const fall = eio(ramp(f, hKill + 4, 18));
    const beat = f < hKill ? Math.max(0, Math.sin(f / 7)) : 0;
    const dv = walkX(f, hDem, hDem + 30, 1290, 1230, 60);
    return {
      svg: <>
        <Gp o={win(f, h0, hDeut + 4)}>
          <Spot id="s7a" x={960} y={600} r={820} />
          <Fragments x={960} y={GY - 280} p={eio(ramp(f, hPiece, 110))} s={0.95} />
        </Gp>
        <Gp o={win(f, hDeut, hCase + 4)}>
          <NeboSet f={f} id="s7b" glow={0.55} />
          <Beam x={960} w={300} o={0.7 * fi(f, hDeut, 20)} f={f} />
          <Michael x={620} y={GY + descend(f, hThru)} f={f} o={fi(f, hThru, 20)} />
          {DW(f, hObj, hObj + 70, 1960, 1360, {o: fi(f, hObj, 20)})}
        </Gp>
        <Gp o={win(f, hCase, hForty + 4)}>
          <Spot id="s7c" x={960} y={560} r={860} />
          <CaseFile f={f} o={1} y0={500} rows={[{...ROW1, chargeO: fi(f, hMur), ansO: 0, hl: 1}]} />
        </Gp>
        <Gp o={win(f, hForty, hSeen + 4)}>
          <Spot id="s7d" x={1100} y={600} r={820} />
          <Ground id="s7dg" />
          <Bush x={1250} y={GY} f={f} s={1.05} />
          <Fig {...MOSES(760, {robe: 'kneel', head: -6, prop: null})} />
          <Arrow x0={1200} y0={300} x1={720} y1={300} p={pr(f, hForty + 10, 30)} />
        </Gp>
        <Gp o={win(f, hSeen, hArg + 4)}>
          <Spot id="s7e" x={1000} y={600} r={820} />
          <Pyramids x={1560} y={GY} s={1.1} o={0.5} />
          <Ground id="s7eg" />
          <g opacity={1 - fi(f, hSand + 30, 30)}>
            <g transform={`rotate(${80 * fall} 1380 ${GY})`}><Fig {...BP(1380, {flip: true, hair: 'helmet', beard: 'none', prop: 'staff', arm: f < hKill ? [-150 + 90 * beat, -30] : REST, sc: 0.31})} /></g>
          </g>
          <Fig {...BP(1180, {robe: 'stoop', bend: 30, head: 22, sc: 0.29, o: 1 - fi(f, hKill + 30, 30)})} />
          <Fig {...YMOSES(0)} x={mw.x} walk={mw.walk} wa={mw.wa} face={f < hQ + 46 ? face : 1} arm={f > hKill - 6 ? ezArm(f, hKill - 6, REST, [-100, -20], 6) : REST} />
          <circle cx={1300} cy={GY - 220} r={150} fill="url(#halo)" opacity={1.6 * win(f, hKill, hKill + 24, 8)} />
          <path d={`M1240,${GY} C1320,${GY - 60 * eio(ramp(f, hSand, 40))} 1560,${GY - 60 * eio(ramp(f, hSand, 40))} 1640,${GY} Z`} fill="#1a120a" />
          <Line u w={2} c="#C9A36A" d={`M1240,${GY} C1320,${GY - 60 * eio(ramp(f, hSand, 40))} 1560,${GY - 60 * eio(ramp(f, hSand, 40))} 1640,${GY}`} o={fi(f, hSand)} />
        </Gp>
        <Gp o={fi(f, hArg)}>
          <NeboSet f={f} id="s7f" glow={0.5} />
          <Michael x={680} y={GY} f={f} arm={[-62, -22]} />
          <Devil x={dv.x} y={GY} f={f} walk={dv.walk} wa={dv.wa} face={-1} arm={f < hDem ? [-80, -10] : ezArm(f, hDem, [-80, -10], [-72, -2], 12)} />
        </Gp>
      </>,
      html: <>
        <Big f={f} a={h0 + 4} b={hPiece} y={110} size={64} c={TXT.gold}>THE ARGUMENT</Big>
        <Note f={f} a={hPiece + 12} b={hDeut} y={100} size={46}>piecing the early reports together</Note>
        <Name f={f} a={hBau} b={hDeut} x={960} y={920} en="RICHARD BAUCKHAM · NEW TESTAMENT SCHOLAR" />
        <Note f={f} a={hDeut + 6} b={hObj} y={100} size={46}>God buried Moses through Michael</Note>
        <Note f={f} a={hObj} b={hCase} y={100} size={46}>the devil objects</Note>
        <Note f={f} a={hMur + 10} b={hForty} y={720} size={46}>one fact</Note>
        <Ref f={f} a={hForty} b={hSeen} y={80}>EXODUS 3 · THE BURNING BUSH</Ref>
        <Note f={f} a={hForty + 10} b={hSeen} y={180} size={48}>forty years before this</Note>
        <Ref f={f} a={hSeen} b={hQ} y={80}>EXODUS 2 · EGYPT</Ref>
        <Q f={f} a={hQ} b={hArg} refText="EXODUS 2:12" eng="“Looking this way and that and seeing no one, *he killed the Egyptian* and hid him in the sand.”" keys={[hKill]} y={50} />
        <Note f={f} a={hArg + 6} b={hDem} y={100} size={48}>blood on his hands</Note>
        <Big f={f} a={hDem} b={hEnd} y={100} size={60} c={TXT.gold}>HE DEMANDED THE BODY</Big>
      </>,
    };
  });
}

// 8 THE ACCUSER ---------------------------------------------------------------------------------
{
  const i0 = at('That fits everything else'), iSat = at('Satan is a Hebrew word'), iCourt = at('the kind of opponent who stands up in court'), iRev = at('and Revelation calls him'),
    iNot = at('Notice what makes this accusation'), iTrue = at('It was true'), iKill = at('Moses really had killed that man'), iRock = at('and he really had disobeyed'),
    iWhen = at('When the devil accuses God’s people'), iRec = at('because our real record'), iEnd = at('There is a second explanation');
  push(i0, (f) => ({
    svg: <>
      <Gp o={win(f, i0, iCourt + 4)}>
        <Spot id="s8a" x={1200} y={620} r={760} a={0.45} />
        <Ground id="s8ag" cx={1200} />
        <Devil x={1300} y={GY} f={f} flip sc={0.36} />
        <Card f={f} a={iSat} x={620} y={430} w={620} h={280} top="HA-SATAN" heb="הַשָּׂטָן" en="the adversary, the accuser" />
      </Gp>
      <Gp o={win(f, iCourt, iNot + 4)}>
        <Spot id="s8b" x={960} y={600} r={820} />
        <Ground id="s8bg" />
        <Throne x={960} y={GY - 6} s={1.05} p={pr(f, iCourt, 30)} />
        <Beam x={960} w={300} o={0.8} f={f} />
        <Fig {...BP(720, {sc: 0.29, head: 20, bend: 6})} />
        <Devil x={1260} y={GY} f={f} flip arm={ezArm(f, iCourt + 10, REST, [-80, -10], 14)} />
      </Gp>
      <Gp o={fi(f, iNot)}>
        <Spot id="s8c" x={1100} y={600} r={820} a={0.5} />
        <Ground id="s8cg" />
        <Devil x={1500} y={GY} f={f} flip arm={[-60, -30]} />
        <ChargeList x={880} y={250} w={560} L={560} p={eio(ramp(f, iNot + 6, 40))} items={['KILLED AN EGYPTIAN · EX 2', 'STRUCK THE ROCK · NUM 20']} itemO={[fi(f, iKill), fi(f, iRock)]} checks={[fi(f, iKill + 20), fi(f, iRock + 20)]} more={ramp(f, iWhen, 70)} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={i0 + 6} b={iSat} y={100} size={48}>it fits everything else the Bible says</Note>
      <Note f={f} a={iCourt} b={iRev} y={100} size={48}>an accuser in court</Note>
      <Q f={f} a={iRev} b={iNot} refText="REVELATION 12:10" eng="“…*the accuser of our brothers and sisters*, who accuses them before our God day and night…”" keys={[at('the accuser of our brothers')]} y={50} />
      <Note f={f} a={iNot} b={iTrue} y={90} size={46}>what makes it dangerous</Note>
      <Big f={f} a={iTrue} b={iWhen} y={80} size={72} c={TXT.gold}>IT WAS TRUE</Big>
      <Note f={f} a={iWhen} b={iRec} y={90} size={46}>he rarely needs to invent anything</Note>
      <Note f={f} a={iRec} b={iEnd} y={90} size={46}>our real record gives him plenty</Note>
    </>,
  }));
}

// 9 THE SECOND EXPLANATION ----------------------------------------------------------------------
{
  const j0 = at('There is a second explanation'), jHab = at('Israel had a long habit'), jSnake = at('Moses once made a bronze snake'), jCent = at('and centuries later King Hezekiah'),
    jSmash = at('had to smash it'), jQ = at('as Second Kings puts it'), jNation = at('A nation that burned incense'), jView = at('On this view the devil wanted'),
    jSecret = at('and God buried it in secret'), jNever = at('The Bible never states this reason'), jBoth = at('Both explanations show the same enemy'), jEnd = at('Now look at who God sent');
  push(j0, (f) => {
    const kw = walkX(f, jCent + 16, jSmash - 8, 1960, 1240, 66);
    const brk = eio(ramp(f, jSmash + 4, 30));
    return {
      svg: <>
        <Gp o={win(f, j0, jSnake + 4)}>
          <Spot id="s9a" x={1060} y={760} r={760} a={0.5} />
          <Valley f={f} grave={1} seal={1} q={1} />
        </Gp>
        <Gp o={win(f, jSnake, jNation + 4)}>
          <Spot id="s9b" x={960} y={600} r={820} />
          <Ground id="s9bg" />
          <defs>
            <clipPath id="s9t"><rect x={600} y={0} width={700} height={GY - 300} /></clipPath>
            <clipPath id="s9u"><rect x={600} y={GY - 300} width={700} height={400} /></clipPath>
          </defs>
          <g clipPath="url(#s9t)"><g transform={`translate(${70 * brk} ${300 * brk * brk}) rotate(${48 * brk} 960 ${GY - 300})`} opacity={1 - 0.7 * brk}><SnakePole x={960} y={GY} s={1.05} /></g></g>
          <g clipPath="url(#s9u)"><SnakePole x={960} y={GY} s={1.05} /></g>
          <circle cx={960} cy={GY - 300} r={160} fill="url(#halo)" opacity={1.6 * win(f, jSmash + 2, jSmash + 26, 8)} />
          {F(f, jSnake, jCent + 10, MOSES(700, {head: -14}), 'mo')}
          <Incense x={960} y={GY - 120} f={f} amt={0.9 * win(f, jCent + 6, jSmash + 10)} w={420} />
          {[0, 1, 2].map((k) => F(f, jCent + 8 + k * 5, undefined, PPL(560 + k * 130, {robe: 'kneel', bend: 26, head: 20, o: 1 - fi(f, jSmash + 10, 20) * 0.5}), 'k' + k))}
          <Fig {...SP(0, {crown: true, beard: 'short', o: fi(f, jCent + 16, 20)})} x={kw.x} walk={kw.walk} wa={kw.wa} face={-1} arm={f < jSmash - 8 ? REST : f < jSmash + 2 ? ezArm(f, jSmash - 8, REST, [-160, -20], 8) : ezArm(f, jSmash + 2, [-160, -20], [-70, -30], 6)} />
        </Gp>
        <Gp o={win(f, jNation, jSecret + 4)}>
          <Night o={0.6} />
          <Spot id="s9c" x={960} y={640} r={800} a={0.5} />
          <Ground id="s9cg" />
          <Shrine x={960} y={GY} s={1} p={pr(f, jNation, 30)} />
          <circle cx={960} cy={GY - 200} r={260} fill="url(#halo)" opacity={0.5} />
          {[0, 1, 2, 3].map((k) => F(f, jNation + 10 + k * 5, undefined, PPL([520, 640, 1280, 1400][k], {robe: 'kneel', bend: 24, head: 16, flip: k > 1, o: 0.5}), 'pg' + k))}
          <Incense x={960} y={GY - 80} f={f} amt={0.5} w={300} />
          <Devil x={1640} y={GY} f={f} flip o={fi(f, jView, 24)} arm={ezArm(f, jView + 10, REST, [-60, 10], 14)} />
        </Gp>
        <Gp o={win(f, jSecret, jBoth + 4)}>
          <Spot id="s9d" x={1060} y={760} r={760} a={0.5} />
          <Valley f={f} grave={1} seal={eio(ramp(f, jSecret + 30, 40))} q={fi(f, jNever)} />
          <Beam x={1060} w={260} o={0.85} f={f} bottom={866} />
        </Gp>
        <Gp o={fi(f, jBoth)}>
          <Spot id="s9e" x={960} y={600} r={820} a={0.5} />
          <Ground id="s9eg" />
          <Card f={f} a={jBoth + 6} x={480} y={440} w={520} h={240} top="SHAME HIM" en="the murder charge" />
          <Card f={f} a={jBoth + 20} x={1440} y={440} w={520} h={240} top="MAKE AN IDOL OF HIM" en="a shrine over his bones" />
          <Devil x={960} y={GY} f={f} sc={0.33} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={j0 + 6} b={jHab} y={100} size={48}>a second explanation</Note>
        <Note f={f} a={jHab} b={jSnake} y={100} size={48}>turning holy things into idols</Note>
        <Ref f={f} a={jSnake + 12} b={jCent} y={70}>NUMBERS 21 · THE BRONZE SNAKE</Ref>
        <Note f={f} a={jCent} b={jQ} y={90} size={46}>centuries later, King Hezekiah</Note>
        <Q f={f} a={jQ} b={jNation} refText="2 KINGS 18:4" eng="“…up to that time *the Israelites had been burning incense to it*.”" keys={[at('had been burning incense to it')]} y={60} />
        <Note f={f} a={jNation + 6} b={jView} y={100} size={46}>a shrine over the bones of Moses?</Note>
        <Note f={f} a={jView} b={jSecret} y={100} size={46}>the devil wanted that body found</Note>
        <Note f={f} a={jSecret} b={jNever} y={100} size={48}>God buried it in secret</Note>
        <Note f={f} a={jNever} b={jBoth} y={100} size={48}>a wise guess</Note>
        <Note f={f} a={jBoth} b={jEnd} y={110} size={48}>the same enemy at work</Note>
      </>,
    };
  });
}
