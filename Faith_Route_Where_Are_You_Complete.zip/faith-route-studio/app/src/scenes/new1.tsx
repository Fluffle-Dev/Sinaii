// TEMPLATE for a new video. Copy the patterns from jz1.tsx / jz2.tsx.
import React from 'react';
import {at, win, fi, ramp, eio} from '../lib';
import {Fig, TXT} from '../fig';
import {Big, Note} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {JP, BP, F, Gp, ez, ezArm} from '../kit';
import {Beam, Q} from '../covprops';

export const NEW1: Scene[] = [];
const push = (start: number, render: Scene['render']) => NEW1.push({start, render});
const REST: [number, number] = [-5, -36];

// 0 TITLE: something on screen from frame 0
{
  const a = at('FIRST FEW WORDS OF THE RECORDING');
  push(0, (f) => ({
    svg: <>
      <Spot id="n0" x={960} y={600} r={880} />
      <Ground id="n0g" />
      <Beam x={960} w={300} o={0.8} f={f} />
      <Fig {...JP(960, {arm: ezArm(f, a + 20, REST, [-60, -10], 16)})} />
    </>,
    html: <>
      <Big f={f} a={0} y={110} size={72} c={TXT.gold}>TITLE QUESTION?</Big>
    </>,
  }));
}
