import React from 'react';
import {at, win, fi, ramp, eio, clamp} from '../lib';
import {Fig, FigP, Line, Throne, Table, Sun, Moon, Fire, TXT} from '../fig';
import {Ref, Big, Note} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Mountain, River, Dove} from '../extra';
import {Scroll, Tomb, CrossHill} from '../props';
import {JP, DP, BP, SP, F, Gp, pr, ez, ezArm, walkX} from '../kit';
import {Beam, Q} from '../covprops';
import {Temple, Incense} from '../tcprops';
import {Michael, Bush} from '../mmprops';
import {Palace, LampStand, ClayLamp, Cell, Whirl, Cloak, Fortress, Platter, Split} from '../jzprops';
import {REST, ELI, JOHN, JEZ, HDIAS, AHAB, HEROD, GIRL, PPL, Night, WK, Court, Wild} from './jz1';

export const JZ2: Scene[] = [];
const push = (start: number, render: Scene['render']) => JZ2.push({start, render});

/** Herod's banquet: table, guests, Herod and Herodias */
const Banquet: React.FC<{f: number; id: string; hHead?: number; hArm?: [number, number]; queen?: number; guests?: number}> = ({f, id, hHead = 0, hArm = REST, queen = 1, guests = 1}) => (
  <>
    <Court f={f} id={id} night={0.35} throne={0} />
    <Table x={660} y={GY} w={1000} />
    <ClayLamp x={560} y={GY - 132} f={f} />
    <ClayLamp x={990} y={GY - 132} f={f + 30} />
    <Gp o={guests}>
      {[0, 1, 2].map((k) => <Fig key={k} {...SP(260 + k * 130, {robe: 'seat', bench: true, sc: 0.25, mantle: false, beard: k % 2 ? 'short' : 'long', head: 4})} />)}
      {[0, 1].map((k) => <Fig key={'r' + k} {...SP(1660 + k * 120, {sc: 0.25, mantle: false, beard: 'short', flip: true, o: 0.8})} />)}
    </Gp>
    <Fig {...HEROD(720, {robe: 'seat', bench: true, head: hHead, arm: hArm})} />
    <Gp o={queen}><Fig {...HDIAS(900, {robe: 'seat', bench: true})} /></Gp>
  </>
);
/** prison with John */
const Prison: React.FC<{f: number; id: string; pose?: Partial<FigP>; x?: number}> = ({f, id, pose = {}, x = 820}) => (
  <>
    <Spot id={id} x={960} y={620} r={860} />
    <Cell />
    <Ground id={id + 'g'} />
    <Fig {...JOHN(x, {robe: 'seat', head: 8, ...pose})} />
  </>
);

// 18 FOUR HUNDRED YEARS, ZECHARIAH --------------------------------------------------------------
{
  const a0 = at('For four hundred years after'), aAng = at('Then an angel appeared'), aSon = at('told him his barren wife'), aDesc = at('And the angel described'), aQ = at('And he will go on before'), aEnd = at('That son was John the Baptist');
  push(a0, (f) => ({
    svg: <>
      <Gp o={win(f, a0, aAng + 4)}>
        <Night o={0.6} />
        <Spot id="y18a" x={960} y={560} r={900} a={0.4} />
        <Mountain x={600} y={GY} s={1} o={0.25} />
        <Ground id="y18ag" />
        {[0, 1, 2].map((k) => F(f, a0 + 10 + k * 8, undefined, PPL(700 + k * 260, {head: -16, sc: 0.25}), 'w' + k))}
      </Gp>
      <Gp o={fi(f, aAng)}>
        <Spot id="y18b" x={960} y={600} r={880} />
        <Temple x={960} y={GY} s={0.8} o={0.45} />
        <Ground id="y18bg" />
        <Incense x={900} y={GY - 140} f={f} amt={1} />
        <Fig {...BP(760, {beard: 'long', mantle: true, sc: 0.3, head: ez(f, aAng + 20, 0, -10, 16)})} />
        <Michael x={1180} y={GY} sc={0.31} f={f} spread={0.85} flip o={fi(f, aAng, 24)} arm={ezArm(f, aSon, REST, [-60, -20], 16)} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={a0 + 6} b={aAng} y={90} size={48}>four hundred years of silence</Note>
      <Note f={f} a={aAng + 6} b={aDesc} y={90} size={48}>Zechariah, in the temple</Note>
      <Q f={f} a={aQ - 4} b={aEnd} refText="LUKE 1:17" eng="“And he will go on before the Lord, *in the spirit and power of Elijah*.”" keys={[at('in the spirit and power of Elijah', 2)]} y={60} />
    </>,
  }));
}

// 19 HE LOOKED LIKE HIM -------------------------------------------------------------------------
{
  const b0 = at('That son was John the Baptist'), bLook = at('He looked like him'), bQ = at('John’s clothes were made'), bAny = at('Anyone in Israel who knew'), bSig = at('The hair garment and the leather'), bEnd = at('Jesus removed all doubt');
  push(b0, (f) => {
    const L = <><Spot id="y19l" x={960} y={600} r={760} /><Mountain x={960} y={GY} s={0.9} o={0.25} /><Ground id="y19lg" /><Fig {...ELI(960, {flip: true})} /></>;
    const R = <><Spot id="y19r" x={960} y={600} r={760} /><River y={GY - 10} f={f} o={0.5} /><Ground id="y19rg" /><Fig {...JOHN(960)} /></>;
    return {
      svg: <>
        <Gp o={win(f, b0, bAny + 4)}>
          <Spot id="y19a" x={960} y={620} r={880} />
          <River y={GY - 10} f={f} o={0.6} />
          <Ground id="y19ag" />
          <Fig {...JOHN(960, {arm: ezArm(f, b0 + 30, REST, [-80, -20], 16)})} />
          {[0, 1, 2, 3].map((k) => F(f, b0 + 10 + k * 5, undefined, PPL(280 + k * 120 + (k > 1 ? 920 : 0), {sc: 0.25, flip: k > 1, head: -4}), 'c' + k))}
        </Gp>
        <Gp o={fi(f, bAny)}>
          <Split left={L} right={R} labL="ELIJAH" labR="JOHN" />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={b0 + 6} b={bLook} y={90} size={48}>John the Baptist</Note>
        <Q f={f} a={bQ - 4} b={bAny} refText="MATTHEW 3:4" eng="“John’s clothes were made of camel’s hair, and *he had a leather belt around his waist*.”" keys={[at('he had a leather belt around his waist')]} y={60} />
        <Note f={f} a={bSig} b={bEnd} y={90} size={48}>the hair garment and the leather belt</Note>
      </>,
    };
  });
}

// 20 HE IS THE ELIJAH ---------------------------------------------------------------------------
{
  const c0 = at('Jesus removed all doubt'), cQ = at('And if you are willing'), cEnd = at('So if John stands');
  push(c0, (f) => ({
    svg: <>
      <Spot id="y20" x={960} y={620} r={880} />
      <Mountain x={1500} y={GY} s={0.8} o={0.25} />
      <Ground id="y20g" />
      <Fig {...JP(1100, {flip: true, arm: ezArm(f, cQ, REST, [-50, -20], 16)})} />
      {[0, 1, 2, 3, 4].map((k) => F(f, c0 + k * 4, undefined, PPL(260 + k * 140, {sc: 0.25, robe: k % 2 ? 'seat' : 'stand', head: -6}), 'd' + k))}
    </>,
    html: <>
      <Q f={f} a={cQ - 6} b={cEnd} refText="MATTHEW 11:14" eng="“And if you are willing to accept it, *he is the Elijah who was to come*.”" keys={[at('he is the Elijah who was to come')]} y={60} />
    </>,
  }));
}

// 21 WHO STANDS IN JEZEBEL'S PLACE --------------------------------------------------------------
{
  const d0 = at('So if John stands'), dWho = at('Who stands in Jezebel’s place'), dEnd = at('John lived in the days');
  push(d0, (f) => {
    const L = <><Court f={f} id="y21l" throne={0} /><Fig {...JEZ(960, {flip: true})} /></>;
    const R = <><Court f={f} id="y21r" throne={0} night={0.6} /><Fig {...HDIAS(960, {flip: true, o: 0.25 + 0.75 * fi(f, dWho + 20, 30)})} /></>;
    return {
      svg: <Split left={L} right={R} labL="JEZEBEL" labR="?" />,
      html: <Note f={f} a={dWho - 4} b={dEnd} y={90} size={50}>who stands in Jezebel’s place?</Note>,
    };
  });
}

// 22 HEROD AND HERODIAS -------------------------------------------------------------------------
{
  const e0 = at('John lived in the days'), eTook = at('Herod had taken Herodias'), eJohn = at('And John, like Elijah before him'), eQ = at('For John had been saying'), eEnd = at('Now watch how closely');
  push(e0, (f) => ({
    svg: <>
      <Gp o={win(f, e0, eJohn + 4)}>
        <Court f={f} id="y22a" tx={1080} />
        <Fig {...HEROD(1090, {robe: 'seat', bench: true, flip: true})} />
        {F(f, eTook, undefined, HDIAS(1300, {flip: true}))}
        {WK(f, eTook, undefined, eTook + 20, eJohn, 700, 120, SP(0, {crown: false, beard: 'short', sc: 0.3, face: -1}))}
      </Gp>
      <Gp o={fi(f, eJohn)}>
        <Court f={f} id="y22b" tx={1180} />
        <Fig {...HEROD(1190, {robe: 'seat', bench: true, flip: true, head: ez(f, eQ, 0, 6, 20)})} />
        <Fig {...HDIAS(1420, {flip: true, head: -4})} />
        {WK(f, eJohn, undefined, eJohn, eJohn + 70, 80, 720, JOHN(0, {face: 1}))}
        <Fig {...JOHN(720, {o: 0})} />
        <Gp o={fi(f, eQ)}><Fig {...JOHN(720, {arm: [-80, -10]})} /></Gp>
        {[0, 1].map((k) => <Fig key={k} {...BP(1640 + k * 120, {flip: true, prop: 'spear', sc: 0.28})} />)}
      </Gp>
    </>,
    html: <>
      <Note f={f} a={e0 + 6} b={eTook} y={90} size={48}>Herod Antipas, ruler of Galilee</Note>
      <Note f={f} a={eTook + 4} b={eJohn} y={90} size={48}>he took his brother Philip’s wife</Note>
      <Q f={f} a={eQ - 4} b={eEnd} refText="MARK 6:18" eng="“For John had been saying to Herod, ‘*It is not lawful for you to have your brother’s wife*.’”" keys={[at('It is not lawful for you')]} y={50} />
    </>,
  }));
}

// 23 SIDE BY SIDE -------------------------------------------------------------------------------
{
  const g0 = at('Now watch how closely'), gEnd = at('Mark tells us, “So Herodias');
  push(g0, (f) => {
    const L = <><Court f={f} id="y23l" tx={1180} /><Fig {...AHAB(1190, {robe: 'seat', bench: true, flip: true})} /><Fig {...JEZ(1420, {flip: true})} /><Fig {...ELI(700)} /></>;
    const R = <><Court f={f} id="y23r" tx={1180} /><Fig {...HEROD(1190, {robe: 'seat', bench: true, flip: true})} /><Fig {...HDIAS(1420, {flip: true})} /><Fig {...JOHN(700)} /></>;
    return {svg: <Split left={L} right={R} labL="1 KINGS" labR="MARK 6" />, html: <Note f={f} a={g0 + 4} b={gEnd} y={90} size={50}>watch how closely it follows</Note>};
  });
}

// 24 THE GRUDGE ---------------------------------------------------------------------------------
{
  const h0 = at('Mark tells us, “So Herodias'), hThere = at('There it is again'), hMark = at('Mark even adds that'), hAhab = at('Ahab knew Elijah spoke'), hHerod = at('Herod knew John was holy'), hEnd = at('And like Jezebel with Naboth');
  push(h0, (f) => {
    const L = <><Court f={f} id="y24l" tx={1180} /><Fig {...AHAB(1190, {robe: 'seat', bench: true, flip: true, head: 10})} /><Fig {...JEZ(1420, {flip: true, arm: [-60, -20]})} /><Fig {...ELI(640)} /></>;
    const R = <><Spot id="y24r" x={960} y={620} r={760} /><Cell win={1200} /><Ground id="y24rg" /><Fig {...JOHN(760, {robe: 'seat'})} /><Fig {...HEROD(1150, {flip: true, head: 8})} /></>;
    return {
      svg: <>
        <Gp o={win(f, h0, hThere + 4)}>
          <Court f={f} id="y24a" night={0.4} throne={0} />
          <Fig {...HDIAS(760, {head: 6, arm: [-60, -14]})} />
          <Fig {...HEROD(1120, {flip: true, arm: ezArm(f, h0 + 120, REST, [-50, -10], 16)})} />
          <LampStand x={1460} y={GY} f={f} />
        </Gp>
        <Gp o={win(f, hThere, hMark + 4)}>
          <Court f={f} id="y24b" night={0.4} throne={0} />
          <Fig {...HDIAS(560, {head: 6})} />
          <Fig {...HEROD(960, {head: 10})} />
          <Fig {...JOHN(1360, {flip: true})} />
        </Gp>
        <Gp o={win(f, hMark, hAhab + 4)}>
          <Prison f={f} id="y24c" pose={{arm: [-60, -20], head: 0}} x={780} />
          <Fig {...HEROD(1180, {flip: true, robe: 'seat', bench: true, head: 12})} />
        </Gp>
        <Gp o={fi(f, hAhab)}>
          <Split left={L} right={R} labL="AHAB" labR="HEROD" dimL={fi(f, hHerod, 20) * 0.6} dimR={(1 - fi(f, hHerod, 20)) * 0.6} />
        </Gp>
      </>,
      html: <>
        <Q f={f} a={h0 + 4} b={hThere} refText="MARK 6:19–20" eng="“So Herodias nursed a grudge against John and wanted to kill him. But she was not able to, because *Herod feared John and protected him*, knowing him to be a righteous and holy man.”" keys={[at('Herod feared John and protected him')]} y={30} size={44} />
        <Note f={f} a={hThere + 6} b={hMark} y={90} size={48}>a queen who wants a prophet dead, and a weak king in the middle</Note>
        <Note f={f} a={hMark + 6} b={hAhab} y={90} size={48}>greatly puzzled, yet he liked to listen to him</Note>
        <Note f={f} a={hAhab + 4} b={hHerod} y={90} size={46}>Ahab knew, and let Jezebel rule his house</Note>
        <Note f={f} a={hHerod + 4} b={hEnd} y={90} size={46}>Herod knew, and kept him in chains</Note>
      </>,
    };
  });
}

// 25 THE BANQUET --------------------------------------------------------------------------------
{
  const i0 = at('And like Jezebel with Naboth'), iMom = at('She only needed the right moment'), iMark = at('Mark writes, “Finally'), iBan = at('Herod threw a birthday banquet'), iDance = at('Herodias’ daughter danced'), iPleased = at('and the king was so pleased'), iQ = at('Whatever you ask I will give'), iEnd = at('The girl went out to her mother');
  push(i0, (f) => {
    const dx = 1320 + Math.sin((f - iDance) / 18) * 110;
    return {
      svg: <>
        <Gp o={win(f, i0, iBan + 4)}>
          <Court f={f} id="y25a" night={0.55} throne={0} />
          <LampStand x={1300} y={GY} f={f} />
          <Fig {...HDIAS(960, {flip: true, head: ez(f, iMom, 0, 8, 20)})} />
        </Gp>
        <Gp o={fi(f, iBan)}>
          <Banquet f={f} id="y25b" hArm={f > iQ - 10 ? ezArm(f, iQ - 10, REST, [-60, -10], 14) : REST} />
          <Gp o={fi(f, iDance - 10, 20)}>
            <Fig {...GIRL(dx, {face: Math.tanh(4 * Math.cos((f - iDance) / 18)), arm: [-70 + Math.sin(f / 12) * 20, -90]})} />
          </Gp>
        </Gp>
      </>,
      html: <>
        <Note f={f} a={i0 + 6} b={iMom} y={90} size={48}>she never held the sword herself</Note>
        <Q f={f} a={iMark} b={iBan} refText="MARK 6:21" eng="“*Finally the opportune time came*.”" keys={[iMark + 20]} y={60} />
        <Note f={f} a={iBan + 6} b={iDance} y={60} size={46}>a birthday banquet for the leading men of Galilee</Note>
        <Q f={f} a={iQ - 6} b={iEnd} refText="MARK 6:23" eng="“*Whatever you ask I will give you*, up to half my kingdom.”" keys={[iQ]} y={40} />
      </>,
    };
  });
}

// 26 THE HEAD OF JOHN ---------------------------------------------------------------------------
{
  const k0 = at('The girl went out to her mother'), kNo = at('Herodias did not need time'), kQ = at('The head of John the Baptist'), kEnd = at('Here is the line that stood out');
  push(k0, (f) => ({
    svg: <>
      <Court f={f} id="y26" night={0.5} throne={0} />
      <LampStand x={1460} y={GY} f={f} />
      <Fig {...HDIAS(1100, {flip: true, head: 10, arm: ezArm(f, kQ - 6, REST, [-40, -20], 12)})} />
      {WK(f, k0, undefined, k0, k0 + 60, 200, 760, GIRL(0, {face: 1}))}
      <Fig {...GIRL(760, {o: 0})} />
    </>,
    html: <>
      <Note f={f} a={k0 + 6} b={kQ - 6} y={90} size={48}>“What shall I ask for?”</Note>
      <Big f={f} a={kQ - 4} b={kEnd} y={110} size={60} c={TXT.ember}>“THE HEAD OF JOHN THE BAPTIST”</Big>
    </>,
  }));
}

// 27 DISTRESSED, BUT -----------------------------------------------------------------------------
{
  const l0 = at('Here is the line that stood out'), lQ = at('The king was greatly distressed'), lSent = at('So he sent an executioner'), lJos = at('The historian Josephus tells'), lEnd = at('Now go back to that first night');
  push(l0, (f) => ({
    svg: <>
      <Gp o={win(f, l0, lSent + 4)}>
        <Banquet f={f} id="y27a" hHead={ez(f, lQ, 0, 20, 30)} />
        <Fig {...GIRL(1300, {flip: true})} />
      </Gp>
      <Gp o={win(f, lSent, lJos + 4)}>
        <Prison f={f} id="y27b" pose={{robe: 'kneel', head: -12, arm: [-30, -60]}} x={760} />
        <Gp o={fi(f, lSent + 20, 30)}>
          <path d="M1640,860 L1640,420 L1920,420 L1920,860 Z" fill="#000" opacity={0.45} />
          {WK(f, lSent + 20, undefined, lSent + 20, lSent + 110, 2000, 1760, BP(0, {face: -1, prop: 'spear', o: 0.7}))}
        </Gp>
      </Gp>
      <Gp o={fi(f, lJos)}>
        <Night o={0.5} />
        <Spot id="y27c" x={960} y={560} r={900} a={0.5} />
        <Fortress x={960} y={GY} s={1.1} p={pr(f, lJos, 40)} />
        <Ground id="y27cg" />
        <River y={GY + 30} x0={0} x1={500} f={f} o={0.4} />
      </Gp>
    </>,
    html: <>
      <Q f={f} a={lQ - 4} b={lSent} refText="MARK 6:26" eng="“The king was greatly distressed, but *because of his oaths and his dinner guests*, he did not want to refuse her.”" keys={[at('because of his oaths and his dinner')]} y={40} size={46} />
      <Note f={f} a={lSent + 6} b={lJos} y={90} size={48}>an executioner, sent to the prison</Note>
      <Ref f={f} a={lJos + 6} b={lEnd} y={90} size={34}>MACHAERUS · JOSEPHUS, ANTIQUITIES 18</Ref>
    </>,
  }));
}

// 28 THE OATH CARRIED OUT -----------------------------------------------------------------------
{
  const m0 = at('Now go back to that first night'), mFail = at('She failed. Nine hundred'), mOath = at('The oath Jezebel could not keep'), mEnd = at('So did Jezebel eventually kill Elijah? Well');
  push(m0, (f) => {
    const L = <><Court f={f} id="y28l" night={0.7} throne={0} /><Fig {...JEZ(960, {flip: true, arm: [-80, -20]})} /><LampStand x={1300} y={GY} f={f} /></>;
    const R = <><Court f={f} id="y28r" night={0.5} throne={0} /><Fig {...HDIAS(1100, {flip: true, head: 6})} />{WK(f, mFail, undefined, mFail + 10, mFail + 80, 400, 860, GIRL(0, {face: 1, arm: [-60, -70]}))}<Platter x={ez(f, mFail + 10, 470, 930, 70)} y={GY - 300} s={0.9} o={fi(f, mFail + 10)} /></>;
    return {
      svg: <Split left={L} right={R} labL="THE OATH SWORN" labR="THE OATH KEPT" labO={fi(f, mOath - 20)} dimL={fi(f, mFail, 30) * 0.5} />,
      html: <>
        <Note f={f} a={m0 + 6} b={mFail} y={90} size={46}>an oath of death by the sword</Note>
        <Note f={f} a={mFail + 6} b={mOath} y={90} size={46}>by the sword, because of an oath, at a queen’s request</Note>
        <Big f={f} a={mOath + 4} b={mEnd} y={110} size={54} c={TXT.ember}>FINALLY CARRIED OUT</Big>
      </>,
    };
  });
}

// 29 WELL, KINDA --------------------------------------------------------------------------------
{
  const n0 = at('So did Jezebel eventually kill Elijah? Well'), nK = at('kinda'), nEnd = at('Jesus seemed to see it');
  push(n0, (f) => ({
    svg: <>
      <Prison f={f} id="y29" pose={{robe: 'kneel', head: -14, arm: [-30, -60]}} x={900} />
      <Beam x={900} w={260} o={0.4} f={f} bottom={GY - 40} />
    </>,
    html: <>
      <Note f={f} a={n0 + 4} b={nK} y={90} size={50}>so did Jezebel eventually kill Elijah?</Note>
      <Big f={f} a={nK - 4} b={nEnd} y={110} size={80} c={TXT.gold}>WELL, KINDA.</Big>
    </>,
  }));
}

// 30 TRANSFIGURATION ----------------------------------------------------------------------------
{
  const o0 = at('Jesus seemed to see it'), oAfter = at('After the Transfiguration'), oQ = at('But I tell you, Elijah has already'), oChill = at('And then He added'), oQ2 = at('In the same way the Son of Man'), oEnd = at('Jesus was telling them the pattern');
  push(o0, (f) => ({
    svg: <>
      <Gp o={fi(f, oQ - 16, 16)}>
        <Spot id="y30b" x={960} y={620} r={880} />
        <Mountain x={1500} y={GY} s={1} o={0.3} />
        <Ground id="y30bg" />
        {WK(f, oQ, undefined, oQ - 20, oQ + 100, 1500, 1160, JP(0, {face: -1}))}
        {[0, 1, 2].map((k) => WK(f, oQ, undefined, oQ - 20, oQ + 100, 1800 + k * 130, 1400 + k * 130, DP(0, {beard: 'short', sc: 0.28, face: -1}), 'dd' + k))}
        <Gp o={fi(f, oQ2, 30)}><CrossHill x={360} y={GY} s={0.6} o={0.4} /></Gp>
      </Gp>
      <Gp o={win(f, o0, oQ + 4)}>
        <Spot id="y30a" x={960} y={520} r={900} />
        <Mountain x={960} y={GY} s={1.6} o={0.3} />
        <Ground id="y30ag" />
        <Beam x={960} w={360} o={0.9} f={f} bottom={GY - 260} />
        <Fig {...JP(960, {y: GY - 260, sc: 0.26})} />
        <Fig {...ELI(1180, {y: GY - 220, sc: 0.22, flip: true, o: 0.55})} />
        <Fig {...DP(740, {y: GY - 220, sc: 0.22, beard: 'long', o: 0.55})} />
        {[0, 1, 2].map((k) => <Fig key={k} {...DP(560 + k * 400, {robe: 'kneel', head: 18, sc: 0.24, beard: 'short', flip: k === 2})} />)}
      </Gp>
    </>,
    html: <>
      <Note f={f} a={o0 + 6} b={oAfter} y={90} size={48}>Jesus saw it the same way</Note>
      <Ref f={f} a={oAfter} b={oQ} y={90} size={34}>AFTER THE TRANSFIGURATION</Ref>
      <Q f={f} a={oQ - 4} b={oChill} refText="MATTHEW 17:12" eng="“But I tell you, Elijah has already come, and they did not recognize him, but *have done to him everything they wished*.”" keys={[at('have done to him everything they wished')]} y={40} size={46} />
      <Q f={f} a={oQ2 - 6} b={oEnd} refText="MATTHEW 17:12" eng="“*In the same way the Son of Man is going to suffer* at their hands.”" keys={[oQ2]} y={60} />
    </>,
  }));
}

// 31 HEROD MEETS JESUS --------------------------------------------------------------------------
{
  const p0 = at('Jesus was telling them the pattern'), pSame = at('The same Herod who killed John'), pMock = at('and then mock Him'), pFore = at('The forerunner had been killed'), pEnd = at('And the pattern does not even stop');
  push(p0, (f) => ({
    svg: <>
      <Court f={f} id="y31" tx={1300} night={0.3} />
      <Fig {...HEROD(1310, {robe: 'seat', bench: true, flip: true, arm: ezArm(f, pSame + 40, REST, [-60, -20], 14), head: f > pMock ? -6 : 0})} />
      <Fig {...JP(760, {head: 8})} />
      {[0, 1].map((k) => F(f, pSame + 10 + k * 8, undefined, BP(460 - k * 140, {prop: 'spear', sc: 0.29}), 's' + k))}
      {[0, 1].map((k) => F(f, pMock, undefined, BP(1000 + k * 120, {flip: true, sc: 0.28, arm: [-70, -40]}), 'm' + k))}
    </>,
    html: <>
      <Note f={f} a={p0 + 6} b={pSame} y={90} size={48}>the pattern was not finished</Note>
      <Note f={f} a={pSame + 6} b={pMock} y={90} size={48}>the same Herod, face to face with Jesus</Note>
      <Note f={f} a={pMock + 4} b={pFore} y={90} size={48}>he mocked Him, and sent Him back to Pilate</Note>
      <Note f={f} a={pFore + 4} b={pEnd} y={90} size={46}>the One John pointed to, walking toward the same power</Note>
    </>,
  }));
}

// 32 THYATIRA -----------------------------------------------------------------------------------
{
  const q0 = at('And the pattern does not even stop'), qRisen = at('the risen Jesus speaks'), qQ = at('Nevertheless, I have this against'), qReal = at('This was a real woman'), qThou = at('A thousand years after Jezebel'), qEnd = at('So what do we do with all');
  push(q0, (f) => ({
    svg: <>
      <Gp o={win(f, q0, qReal + 4)}>
        <Night o={0.3} />
        <Spot id="y32a" x={960} y={480} r={900} />
        <Ground id="y32ag" />
        <Beam x={960} w={360} o={0.9 * fi(f, qRisen - 10, 30)} f={f} />
        <Fig {...JP(960, {arm: ezArm(f, qQ, REST, [-50, -10], 16)})} o={fi(f, qRisen - 10, 30)} />
        <Ref f={f} a={q0} y={1010} size={30}>REVELATION 2 · THYATIRA</Ref>
      </Gp>
      <Gp o={win(f, qReal, qThou + 4)}>
        <Night o={0.4} />
        <Spot id="y32b" x={960} y={620} r={880} />
        <Ground id="y32bg" />
        <ClayLamp x={1500} y={GY - 120} f={f} />
        <Fig {...BP(1160, {hair: 'veil', beard: 'none', sc: 0.29, flip: true, arm: [-70, -20]})} />
        {[0, 1, 2, 3, 4].map((k) => <Fig key={k} {...PPL(300 + k * 150, {robe: 'seat', bench: true, sc: 0.24, head: -4})} />)}
      </Gp>
      <Gp o={fi(f, qThou)}>
        <Split left={<><Court f={f} id="y32l" throne={0} /><Fig {...JEZ(960, {flip: true})} /></>} right={<><Night o={0.4} /><Spot id="y32r" x={960} y={620} r={760} /><Ground id="y32rg" /><Fig {...BP(960, {hair: 'veil', beard: 'none', sc: 0.29, flip: true, arm: [-70, -20]})} /></>} labL="1 KINGS" labR="REVELATION" />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={q0 + 6} b={qQ - 6} y={90} size={48}>a name that should sound familiar</Note>
      <Q f={f} a={qQ - 4} b={qReal} refText="REVELATION 2:20" eng="“Nevertheless, I have this against you: *You tolerate that woman Jezebel*, who calls herself a prophet.”" keys={[at('You tolerate that woman Jezebel')]} y={50} />
      <Note f={f} a={qReal + 6} b={qThou} y={90} size={46}>a real woman, leading God’s people the same way</Note>
      <Note f={f} a={qThou + 6} b={qEnd} y={90} size={46}>a pattern that keeps coming back</Note>
    </>,
  }));
}

// 33-34 HEROD IN THE ROOM -----------------------------------------------------------------------
{
  const r0 = at('So what do we do with all'), r1 = at('First, I think we need'), rNever = at('Most of us will never be Jezebel'), rHerod = at('But it is very easy to be Herod'), rLiked = at('Herod liked listening to John'), rChose = at('he chose his reputation'),
    rRoom = at('Every one of us has stood'), rAsk = at('The question this story asks'), rWho = at('who are you more afraid'), rEnd = at('Second, if you have ever stood');
  push(r0, (f) => ({
    svg: <>
      <Gp o={win(f, r0, rRoom + 4)}>
        <Banquet f={f} id="y33a" hHead={f > rChose ? ez(f, rChose, 0, 18, 30) : 0} queen={1} guests={1} />
      </Gp>
      <Gp o={fi(f, rRoom)}>
        <Spot id="y33b" x={960} y={620} r={880} />
        <Palace f={f} lamps={0} />
        <Ground id="y33bg" />
        <Fig {...BP(960, {head: ez(f, rWho, 0, 14, 30)})} />
        {[0, 1, 2, 3, 4, 5].map((k) => F(f, rRoom + k * 4, undefined, PPL(k < 3 ? 260 + k * 150 : 1360 + (k - 3) * 150, {sc: 0.26, flip: k >= 3}), 'r' + k))}
      </Gp>
    </>,
    html: <>
      <Note f={f} a={r1 + 6} b={rNever} y={90} size={48}>who are we really in this story?</Note>
      <Note f={f} a={rNever} b={rHerod} y={90} size={50}>most of us will never be Jezebel</Note>
      <Big f={f} a={rHerod} b={rLiked} y={110} size={64} c={TXT.ember}>IT IS EASY TO BE HEROD</Big>
      <Note f={f} a={rLiked} b={rChose} y={90} size={48}>he liked listening, and knew John was right</Note>
      <Note f={f} a={rChose} b={rRoom} y={90} size={48}>he chose his guests over the truth</Note>
      <Note f={f} a={rRoom + 4} b={rWho - 6} y={90} size={48}>the right thing is clear, and the crowd is watching</Note>
      <Big f={f} a={rWho - 4} b={rEnd} y={110} size={54} c={TXT.gold}>WHO ARE YOU MORE AFRAID TO DISAPPOINT?</Big>
    </>,
  }));
}

// 35 GOOD COMPANY -------------------------------------------------------------------------------
{
  const s0 = at('Second, if you have ever stood'), sEli = at('Elijah sat under a broom bush'), sJohn = at('John sat in Herod’s prison'), sEven = at('Even the greatest prophets'), sListen = at('And listen to what Jesus said'), sQ = at('Truly I tell you, among'), sHon = at('He honored John in the very'), sGod = at('God is not ashamed of you'), sEnd = at('And third, the story does not end');
  push(s0, (f) => {
    const L = <><Wild f={f} id="y35l" bush={1} bx={1100} night={0.3} /><Fig {...ELI(940, {robe: 'seat', head: 22, bend: 12})} /></>;
    const R = <><Spot id="y35r" x={960} y={620} r={760} /><Cell win={1200} /><Ground id="y35rg" /><Fig {...JOHN(860, {robe: 'seat', head: 14})} /></>;
    return {
      svg: <>
        <Gp o={win(f, s0, sListen + 4)}>
          <Gp o={1 - fi(f, sEli, 20)}>
            <Spot id="y35a" x={960} y={620} r={860} />
            <Ground id="y35ag" />
            <Fig {...BP(960, {robe: 'seat', head: 18, bend: 10})} />
          </Gp>
          <Gp o={fi(f, sEli, 20)}><Split left={L} right={R} labL="UNDER THE BROOM BUSH" labR="IN HEROD’S PRISON" dimR={1 - fi(f, sJohn, 20)} /></Gp>
        </Gp>
        <Gp o={win(f, sListen, sGod + 4)}>
          <Spot id="y35b" x={960} y={620} r={880} />
          <Ground id="y35bg" />
          <Fig {...JP(1100, {flip: true, arm: ezArm(f, sQ, REST, [-50, -20], 16)})} />
          {[0, 1].map((k) => <Fig key={k} {...PPL(620 + k * 160, {head: 4})} />)}
          {[0, 1, 2].map((k) => F(f, sListen + k * 5, undefined, PPL(1400 + k * 140, {flip: true, sc: 0.25}), 'cr' + k))}
        </Gp>
        <Gp o={fi(f, sGod)}>
          <Spot id="y35c" x={960} y={620} r={860} />
          <Ground id="y35cg" />
          <Beam x={960} w={320} o={0.85 * fi(f, sGod, 30)} f={f} />
          <Fig {...BP(960, {robe: 'seat', head: ez(f, sGod, 18, -4, 30)})} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={s0 + 6} b={sEli} y={90} size={48}>if you stood for the truth and ended up worn out</Note>
        <Q f={f} a={sJohn + 20} b={sListen} refText="MATTHEW 11:3" eng="“*Are you the one who is to come*, or should we expect someone else?”" keys={[at('Are you the one who is to come')]} y={50} />
        <Q f={f} a={sQ - 4} b={sGod} refText="MATTHEW 11:11" eng="“Truly I tell you, among those born of women *there has not risen anyone greater than John the Baptist*.”" keys={[at('there has not risen anyone greater')]} y={50} />
        <Big f={f} a={sGod + 4} b={sEnd} y={110} size={54} c={TXT.gold}>NOT ASHAMED OF YOU ON YOUR WEAKEST DAY</Big>
      </>,
    };
  });
}

// 36 THE MESSAGE ----------------------------------------------------------------------------------
{
  const t0 = at('And third, the story does not end'), tSil = at('Jezebel can silence a messenger'), tCarr = at('Elijah was carried up'), tJohn = at('John was killed in a prison'), tPoint = at('which was to point to Jesus'), tWhen = at('And when the powers of this world'), tThree = at('Three days later the tomb'), tEnd = at('That is why the pattern breaks');
  push(t0, (f) => ({
    svg: <>
      <Gp o={win(f, t0, tCarr + 4)}>
        <Prison f={f} id="y36a" pose={{robe: 'kneel', head: -12, arm: [-30, -60]}} x={900} />
        <Beam x={900} w={300} o={0.7 * fi(f, tSil, 30)} f={f} bottom={GY - 40} />
      </Gp>
      <Gp o={win(f, tCarr, tJohn + 4)}>
        <Spot id="y36b" x={960} y={480} r={900} />
        <Mountain x={420} y={GY} s={0.8} o={0.3} />
        <Mountain x={1520} y={GY} s={0.7} o={0.25} />
        <Ground id="y36bg" />
        <Fig {...DP(640, {beard: 'short', head: -16, arm: [-120, -160]})} />
        <Whirl x={960} y={GY} f={f} h={900} />
        <Fig {...ELI(960, {y: GY - 300 - 200 * eio(ramp(f, tCarr, 80)), sc: 0.24})} />
      </Gp>
      <Gp o={win(f, tJohn, tWhen + 4)}>
        <Spot id="y36c" x={960} y={620} r={880} />
        <River y={GY - 10} f={f} o={0.6} />
        <Ground id="y36cg" />
        <Fig {...JOHN(700, {arm: ezArm(f, tPoint - 20, REST, [-80, -10], 16)})} />
        {F(f, tPoint - 30, undefined, JP(1300, {flip: true}))}
        <Beam x={1300} w={300} o={0.8 * fi(f, tPoint - 20, 30)} f={f} />
      </Gp>
      <Gp o={win(f, tWhen, tThree + 4)}>
        <Night o={0.5} />
        <Spot id="y36d" x={960} y={600} r={860} a={0.5} />
        <CrossHill x={960} y={GY} s={1.1} p={pr(f, tWhen, 40)} />
        <Ground id="y36dg" />
      </Gp>
      <Gp o={fi(f, tThree)}>
        <Spot id="y36e" x={960} y={600} r={900} />
        <Ground id="y36eg" />
        <Tomb x={760} y={GY} s={1} roll={eio(ramp(f, tThree + 6, 40))} />
        <Beam x={1260} w={320} o={0.9 * fi(f, tThree + 30, 30)} f={f} />
        {F(f, tThree + 30, undefined, JP(1260))}
      </Gp>
    </>,
    html: <>
      <Note f={f} a={t0 + 6} b={tSil} y={90} size={48}>the story does not end with a platter</Note>
      <Big f={f} a={tSil + 4} b={tCarr} y={110} size={54} c={TXT.gold}>SHE CANNOT SILENCE THE MESSAGE</Big>
      <Note f={f} a={tJohn + 4} b={tPoint - 20} y={90} size={48}>his whole life had one purpose</Note>
      <Note f={f} a={tPoint - 20} b={tWhen} y={90} size={48}>to point to Jesus</Note>
      <Note f={f} a={tWhen + 6} b={tThree} y={90} size={48}>the grave could not hold Him</Note>
      <Note f={f} a={tThree + 6} b={tEnd} y={90} size={50}>three days later, the tomb was empty</Note>
    </>,
  }));
}

// 37 THE PATTERN BREAKS -------------------------------------------------------------------------
{
  const u0 = at('That is why the pattern breaks'), uWins = at('Jezebel wins some battles'), uNever = at('She never wins the war'), uEnd = at('So Jezebel eventually killed Elijah. Well');
  push(u0, (f) => ({
    svg: <>
      <Spot id="y37" x={960} y={600} r={900} />
      <Ground id="y37g" />
      <Beam x={1180} w={340} o={0.9} f={f} />
      <Fig {...JP(1180)} />
      <Fig {...JEZ(560, {flip: false, head: 10})} o={1 - fi(f, uNever, 40) * 0.8} />
    </>,
    html: <>
      <Note f={f} a={u0 + 4} b={uWins} y={90} size={50}>why the pattern breaks</Note>
      <Note f={f} a={uWins} b={uNever} y={90} size={50}>she wins some battles in every generation</Note>
      <Big f={f} a={uNever} b={uEnd} y={110} size={68} c={TXT.gold}>SHE NEVER WINS THE WAR</Big>
    </>,
  }));
}

// 38 THE CLOSING LINE ---------------------------------------------------------------------------
{
  const v0 = at('So Jezebel eventually killed Elijah. Well'), vBut = at('But Elijah’s whole job'), vEnd = at('Let me know what you think about this');
  push(v0, (f) => {
    const L = <><Spot id="y38l" x={960} y={600} r={760} /><Mountain x={960} y={GY} s={0.9} o={0.25} /><Ground id="y38lg" /><Fig {...ELI(960, {arm: ezArm(f, vBut, REST, [-80, -10], 16)})} /></>;
    const R = <><Spot id="y38r" x={960} y={600} r={760} /><Ground id="y38rg" /><Beam x={960} w={320} o={0.9 * fi(f, vBut, 30)} f={f} /><Fig {...JP(960, {flip: true, o: 0.4 + 0.6 * fi(f, vBut, 30)})} /></>;
    return {
      svg: <Split left={L} right={R} labL="ELIJAH" labR="JESUS" labO={fi(f, vBut + 20)} />,
      html: <>
        <Note f={f} a={v0 + 4} b={vBut} y={90} size={50}>so Jezebel eventually killed Elijah</Note>
        <Note f={f} a={vBut + 4} b={vEnd} y={60} size={46}>his whole job was to point to Someone she could never keep in the grave</Note>
      </>,
    };
  });
}

// 39 OUTRO --------------------------------------------------------------------------------------
{
  const w0 = at('Let me know what you think about this'), wLike = at('Please like, subscribe'), wThank = at('Thank you so much for watching'), wLove = at('And always remember'), wSee = at('See you on the next one');
  push(w0, (f) => ({
    svg: <>
      <Spot id="y39" x={960} y={600} r={880} />
      <Ground id="y39g" />
      <Beam x={960} w={320} o={0.85} f={f} />
      {F(f, w0, undefined, JP(960, {arm: ezArm(f, wLove, REST, [-60, -10], 14)}))}
    </>,
    html: <>
      <Note f={f} a={w0 + 4} b={wLike} y={90} size={50}>let me know what you think</Note>
      <Big f={f} a={wLike} b={wLove} y={90} size={56} c={TXT.gold}>LIKE · SUBSCRIBE · SHARE</Big>
      <Big f={f} a={wLove} b={wSee} y={90} size={66} c={TXT.gold}>JESUS LOVES YOU</Big>
      <Note f={f} a={wSee} y={90} size={50}>see you on the next one</Note>
    </>,
  }));
}
