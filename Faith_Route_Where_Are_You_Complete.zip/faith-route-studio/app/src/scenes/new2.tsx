import {Scene} from '../stage';
export const NEW2: Scene[] = [];
