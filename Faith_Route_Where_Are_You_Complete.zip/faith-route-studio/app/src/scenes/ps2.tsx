import React from 'react';
import {at, win, fi, kf, ramp, eio, eout, clamp} from '../lib';
import {Fig, FigP, Line, Lion, Wolf, Sun, Moon, Bed, TXT} from '../fig';
import {Ref, Big, Note} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Mountain, Dove, Stones} from '../extra';
import {Book, Scroll, Window, Olive, CrossHill, Tomb} from '../props';
import {JP, DP, BP, SP, F, Gp, pr, ez, ezArm, turn, walkX} from '../kit';
import {Beam, Card, Q} from '../covprops';
import {LifeTree} from '../tcprops';
import {Michael, Devil, Dragon, Rock, Clouds} from '../mmprops';
import {Fire} from '../fig';
import {Pinnacle, pinTop, PsalmCol, C, Serpent, DotGrid, PathRoad, Net, Plaque, Legions} from '../psprops';
import {REST, PPL, Night, WK, DW, Zm, PinSet, Wild} from './ps1';

export const PS2: Scene[] = [];
const push = (start: number, render: Scene['render']) => PS2.push({start, render});

/** two-column comparison of the verse, html layer */
const LINES = ['He will command his angels concerning you', 'to guard you in all your ways;', 'they will lift you up in their hands,', 'so that you will not strike your foot against a stone.'];
const Compare: React.FC<{f: number; a: number; b?: number; gone: number; luke?: number}> = ({f, a, b, gone, luke = 0}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const col = (title: string, c: string, devil: boolean, d: number) => (
    <div style={{width: 760, opacity: fi(f, a + d, 18)}}>
      <div style={{fontFamily: 'Cinzel', fontSize: 38, letterSpacing: '0.24em', color: c, marginBottom: 26}}>{title}</div>
      {LINES.map((l, i) => {
        const mid = i === 1;
        const style: React.CSSProperties = {fontFamily: 'Corm', fontStyle: 'italic', fontSize: 50, lineHeight: 1.3, color: TXT.ivory, marginBottom: 14, minHeight: 66};
        if (mid && !devil) return <div key={i} style={{...style, color: TXT.gold, textShadow: '0 0 18px #E9BE6E88'}}>{l}</div>;
        if (mid && devil) return <div key={i} style={{...style, color: TXT.ember, opacity: 1 - gone, textDecoration: 'line-through'}}>{luke > 0.5 ? 'to guard you carefully;' : l}</div>;
        return <div key={i} style={style}>{l}</div>;
      })}
    </div>
  );
  return (
    <div style={{position: 'absolute', left: 120, top: 200, width: 1680, display: 'flex', justifyContent: 'space-between', textAlign: 'center', opacity: o}}>
      {col('PSALM 91:11–12', TXT.gold, false, 0)}
      {col('THE DEVIL’S VERSION', TXT.ember, true, 16)}
    </div>
  );
};

// 15 SIDE BY SIDE -------------------------------------------------------------------------------
{
  const a0 = at('Now let us put the devil’s version'), aPs = at('Psalm 91 says, “For he will command'), aMat = at('In Matthew’s account'), aVan = at('The middle has vanished'),
    aLuke = at('Luke’s account keeps the words'), aYet = at('yet even there the phrase'), aBoth = at('In both gospels'), aEnd = at('Those four words carry');
  push(a0, (f) => ({
    svg: <>
      <Gp o={win(f, a0, aPs + 4)}>
        <PinSet f={f} id="q15a" z={1.2} scroll={1} dArm={[-70, -20]} />
      </Gp>
      <Gp o={win(f, aPs, aMat + 4)}>
        <Spot id="q15b" x={960} y={640} r={860} />
        <Ground id="q15bg" />
        <Beam x={960} w={360} o={0.8} f={f} />
        <Book x={960} y={GY - 10} s={1.1} p={pr(f, aPs, 40)} />
      </Gp>
      <Gp o={win(f, aMat, aBoth + 4)}>
        <Spot id="q15c" x={960} y={540} r={980} />
        <Line w={1.6} c="#E3B465" o={0.5} d="M960,190 L960,760 M961,190 L961,760" />
      </Gp>
      <Gp o={fi(f, aBoth)}>
        <Spot id="q15d" x={960} y={520} r={900} />
        <PsalmCol f={f} o={1} y={170} rows={(v) => (v === 11 || v === 12 ? {c: C.ember, o: 1, glow: 1} : {o: 0.35})} ways={{c: C.gold, o: 1, glow: 1, strike: pr(f, aBoth + 20, 18)}} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={a0 + 6} b={aPs} y={60} size={48}>what he left out, and why</Note>
      <Q f={f} a={aPs + 4} b={aMat} refText="PSALM 91:11–12" eng="“For he will command his angels concerning you *to guard you in all your ways*; they will lift you up in their hands, so that you will not strike your foot against a stone.”" keys={[at('to guard you in all your ways', 1)]} y={40} size={46} />
      <Compare f={f} a={aMat} b={aBoth} gone={eio(ramp(f, aVan, 24)) * (1 - fi(f, aLuke, 10)) + fi(f, aYet + 10, 20) * 0.6} luke={fi(f, aLuke + 10, 6)} />
      <Note f={f} a={aMat + 6} b={aVan} y={820} size={46}>Matthew 4:6</Note>
      <Big f={f} a={aVan + 6} b={aLuke} y={860} size={60} c={TXT.ember}>THE MIDDLE HAS VANISHED</Big>
      <Note f={f} a={aLuke + 6} b={aBoth} y={820} size={46}>Luke 4:10 keeps “to guard you carefully” and still drops “in all your ways”</Note>
    </>,
  }));
}

// 16 THE ROAD -----------------------------------------------------------------------------------
{
  const b0 = at('Those four words carry'), bAll = at('All through the Psalms'), bTrav = at('is a promise for a traveler'), bCov = at('It covers the stones'),
    bRem = at('The devil removed the road'), bWith = at('Without those words'), bWithT = at('With those words, it sounds'), bJump = at('Jumping off the temple to force'), bStunt = at('It was a stunt'), bEnd = at('Then comes the second cut');
  push(b0, (f) => {
    const w = walkX(f, bTrav - 10, bCov + 60, 300, 1500, 66);
    const w2 = walkX(f, bWithT, bJump, 400, 1300, 66);
    const fall = eio(clamp((f - bWith - 20) / 50));
    return {
      svg: <>
        <Gp o={win(f, b0, bAll + 4)}>
          <Spot id="q16a" x={960} y={560} r={860} />
          <Card f={f} a={b0} x={960} y={540} w={900} h={260} top="PSALM 91:11" big="IN ALL YOUR WAYS" hl={1} />
        </Gp>
        <Gp o={win(f, bAll, bRem + 4)}>
          <Spot id="q16b" x={w.x} y={620} r={820} />
          <Mountain x={420} y={GY} s={0.8} o={0.3} />
          <Mountain x={1500} y={GY} s={0.7} o={0.25} />
          <PathRoad p={pr(f, bAll, 40)} lit={0.5 + 0.5 * fi(f, bCov, 20)} />
          <Beam x={w.x} w={260} o={0.6} f={f} />
          <Fig {...JP(0)} x={w.x} walk={w.walk} wa={w.wa} face={1} />
        </Gp>
        <Gp o={win(f, bRem, bWithT + 4)}>
          <Spot id="q16c" x={960} y={560} r={860} c="#7a3420" a={0.45} />
          <PathRoad o={1 - fi(f, bRem + 10, 30)} />
          <Net x={960} y={820} w={760} p={pr(f, bWith, 30)} />
          <Fig {...JP(960, {y: 300 + 400 * fall, sc: 0.22, o: 0.75 * fi(f, bWith + 10)})} />
        </Gp>
        <Gp o={win(f, bWithT, bJump + 4)}>
          <Spot id="q16d" x={w2.x} y={620} r={820} />
          <Mountain x={1500} y={GY} s={0.7} o={0.25} />
          <PathRoad />
          <Beam x={w2.x - 120} w={320} o={0.85} f={f} />
          <Fig {...JP(0)} x={w2.x} walk={w2.walk} wa={w2.wa} face={1} />
        </Gp>
        <Gp o={fi(f, bJump)}>
          <PinSet f={f} id="q16e" z={1.3} scroll={fi(f, bStunt)} dArm={ezArm(f, bStunt, REST, [-70, -20], 14)} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={b0 + 10} b={bAll} y={760} size={48}>four words carry the whole promise</Note>
        <Note f={f} a={bAll + 6} b={bTrav} y={110} size={48}>the path you walk with God</Note>
        <Note f={f} a={bTrav} b={bCov} y={110} size={48}>a traveler walking where his Father sent him</Note>
        <Big f={f} a={bCov} b={bRem} y={120} size={60} c={TXT.gold}>THE STONES ON THAT ROAD</Big>
        <Big f={f} a={bRem + 4} b={bWith} y={120} size={60} c={TXT.ember}>HE REMOVED THE ROAD</Big>
        <Note f={f} a={bWith + 6} b={bWithT} y={110} size={48}>a safety net under any leap you choose</Note>
        <Note f={f} a={bWithT + 6} b={bJump} y={110} size={48}>a Father walking beside His son</Note>
        <Note f={f} a={bJump + 6} b={bStunt} y={60} size={48}>never one of the ways God planned</Note>
        <Big f={f} a={bStunt} b={bEnd} y={80} size={60} c={TXT.ember}>A STUNT WRITTEN BY THE DEVIL</Big>
      </>,
    };
  });
}

// 17 THE SECOND CUT -----------------------------------------------------------------------------
{
  const c0 = at('Then comes the second cut'), cLook = at('Look at the very next verse'), cQ = at('You will tread on the lion'), cEnd = at('The Hebrew word for serpent');
  push(c0, (f) => ({
    svg: <>
      <Gp o={win(f, c0, cQ + 4)}>
        <Spot id="q17a" x={960} y={520} r={900} />
        <PsalmCol f={f} o={1} y={170} rows={(v) => (v === 13 ? {c: C.gold, o: 1, glow: fi(f, cLook + 10)} : v === 11 || v === 12 ? {c: C.ember, o: 0.8} : {o: 0.3})} ways={{c: C.ember, o: 0.4, strike: 1}} stop={1} stopLab={1} />
      </Gp>
      <Gp o={fi(f, cQ)}>
        <Spot id="q17b" x={960} y={640} r={820} />
        <Ground id="q17bg" />
        <Beam x={960} w={300} o={0.7} f={f} />
        <Lion x={600} y={GY} s={1.05} flip />
        <Serpent x={1080} y={GY} s={1.2} f={f} rear={0.6} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={c0 + 6} b={cLook} y={960} size={46}>the second cut, even more revealing</Note>
      <Note f={f} a={cLook + 6} b={cQ} y={960} size={46}>the verse he never got to</Note>
      <Q f={f} a={cQ} b={cEnd} refText="PSALM 91:13" eng="“You will tread on the lion and the cobra; you will trample the great lion and *the serpent*.”" keys={[at('the great lion and the serpent') + 30]} y={50} />
    </>,
  }));
}

// 18 TANNIN, THE DRAGON -------------------------------------------------------------------------
{
  const d0 = at('The Hebrew word for serpent'), dDr = at('can also mean dragon'), dLast = at('Now go to the last book'), dRev = at('Revelation describes'), dQ = at('That ancient serpent called'), dEnd = at('And go back to the very first');
  push(d0, (f) => ({
    svg: <>
      <Gp o={win(f, d0, dLast + 4)}>
        <Spot id="q18a" x={960} y={560} r={860} />
        <Ground id="q18ag" />
        <Serpent x={560} y={GY} s={1.1} f={f} rear={0.3} o={0.8} />
        <Card f={f} a={d0 - 10} x={960} y={460} w={760} h={340} top="PSALM 91:13" heb="תַּנִּין" big="TANNIN" en="serpent · dragon" hl={fi(f, dDr)} />
      </Gp>
      <Gp o={fi(f, dLast)}>
        <Night o={0.5} />
        <Spot id="q18b" x={960} y={560} r={860} c="#7a3420" a={0.45} />
        <Clouds y={300} o={0.5} f={f} />
        <Dragon x={1080} y={ez(f, dQ + 30, 600, 700, 40)} s={0.9} f={f} rot={ez(f, dQ + 30, 0, 8, 40)} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={dLast + 6} b={dRev} y={90} size={48}>the last book of the Bible</Note>
      <Q f={f} a={dRev} b={dEnd} refText="REVELATION 12:9" eng="“…the great dragon… *that ancient serpent called the devil, or Satan*”" keys={[dQ]} y={60} />
    </>,
  }));
}

// 19 EDEN -----------------------------------------------------------------------------------------
{
  const e0 = at('And go back to the very first'), eGod = at('God spoke to the serpent'), eQ = at('And I will put enmity'), eEnd = at('From Genesis onward');
  push(e0, (f) => ({
    svg: <>
      <Spot id="q19" x={960} y={600} r={860} />
      <Ground id="q19g" />
      <LifeTree x={760} y={GY} s={1.1} p={pr(f, e0, 40)} glow={0.6} />
      <Serpent x={1000} y={GY} s={1.1} f={f} rear={0.4 + 0.3 * fi(f, eGod)} />
      <Beam x={1240} w={260} o={0.6 * fi(f, eGod, 30)} f={f} />
    </>,
    html: <>
      <Note f={f} a={e0 + 6} b={eQ - 4} y={90} size={48}>the very first book</Note>
      <Q f={f} a={eQ - 4} b={eEnd} refText="GENESIS 3:15" eng="“And I will put enmity between you and the woman, and between your offspring and hers; *he will crush your head*, and you will strike his heel.”" keys={[at('he will crush your head', 1)]} y={40} size={46} />
    </>,
  }));
}

// 20 WAITING FOR THE ONE ------------------------------------------------------------------------
{
  const g0 = at('From Genesis onward'), gRead = at('The devil read Psalm 91 out loud'), gSil = at('and then he went silent'), gQuo = at('He quoted the promise of rescue'), gSkip = at('and skipped the promise'), gEnd = at('Remember that line from Mark');
  push(g0, (f) => ({
    svg: <>
      <Gp o={win(f, g0, gRead + 4)}>
        <Spot id="q20a" x={960} y={620} r={900} />
        <Ground id="q20ag" />
        <Beam x={960} w={300} o={0.5} f={f} />
        {Array.from({length: 7}, (_, i) => F(f, g0 + i * 5, undefined, PPL(220 + i * 240, {sc: 0.24 + (i % 2) * 0.02, head: -18, flip: i > 3}), 'q' + i))}
      </Gp>
      <Gp o={fi(f, gRead)}>
        <Spot id="q20b" x={960} y={520} r={900} />
        <PsalmCol f={f} o={1} y={170} stop={pr(f, gSil, 20)} stopLab={fi(f, gSil + 20)}
          rows={(v) => {
            const cur = gRead + (v - 9) * 22;
            if (v <= 12) return {c: fi(f, cur, 8) > 0.5 ? C.ember : C.ivory, o: v >= 11 ? 1 : 0.5, glow: v >= 11 ? fi(f, gQuo, 16) : 0};
            return {c: C.gold, o: 0.25 + 0.75 * fi(f, gSkip, 16), glow: v === 13 ? fi(f, gSkip, 16) : 0};
          }} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={g0 + 6} b={gRead} y={110} size={48}>someone who would put his foot on the serpent</Note>
      <Note f={f} a={gQuo + 6} b={gSkip} y={960} size={46}>he quoted the promise of rescue</Note>
      <Note f={f} a={gSkip + 6} b={gEnd} y={960} size={46}>and skipped the promise of his own defeat</Note>
    </>,
  }));
}

// 21 ALREADY STANDING IN IT ---------------------------------------------------------------------
{
  const h0 = at('Remember that line from Mark'), hFor = at('For forty days he had already'), hBea = at('The beasts of verse 13'), hAng = at('and the angels of verse 11'), hOne = at('The devil was quoting the promise to'), hEnd = at('Look at how Jesus answers');
  push(h0, (f) => ({
    svg: <>
      <Gp o={win(f, h0, hOne + 4)}>
        <Wild f={f} id="q21a" beasts={1} angels={1} />
        <Beam x={960} w={300} o={0.6 * fi(f, hFor, 30)} f={f} />
        <Fig {...JP(960, {robe: 'seat', bench: true, head: 6})} />
      </Gp>
      <Gp o={fi(f, hOne)}>
        <PinSet f={f} id="q21b" z={1.35} beam={fi(f, hOne + 20, 30)} scroll={1} dArm={[-70, -20]} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={h0 + 6} b={hFor} y={90} size={48}>with the wild animals, and angels attended him</Note>
      <Big f={f} a={hFor + 6} b={hBea} y={110} size={56} c={TXT.gold}>ALREADY LIVING INSIDE PSALM 91</Big>
      <Note f={f} a={hBea} b={hOne} y={730} x={480} size={44}>verse 13</Note>
      <Note f={f} a={hAng} b={hOne} y={350} x={1290} size={44}>verse 11</Note>
      <Note f={f} a={hOne + 6} b={hEnd} y={60} size={46}>quoting the promise to the one man already standing in it</Note>
    </>,
  }));
}

// 22 IT IS ALSO WRITTEN -------------------------------------------------------------------------
{
  const i0 = at('Look at how Jesus answers'), iSets = at('He simply sets another verse'), iQ = at('It is also written'), iEnd = at('That line comes from Deuteronomy');
  push(i0, (f) => ({
    svg: <>
      <Gp o={win(f, i0, iSets + 4)}>
        <PinSet f={f} id="q22a" z={1.5} scroll={1} dArm={[-70, -20]} jArm={ezArm(f, i0 + 20, REST, [-40, -20], 14)} />
      </Gp>
      <Gp o={fi(f, iSets)}>
        <Spot id="q22b" x={960} y={560} r={860} />
        <Card f={f} a={iSets} x={560} y={600} w={640} h={260} top="PSALM 91" en="what the devil quoted" />
        <Card f={f} a={iSets + 20} x={1360} y={600} w={640} h={260} top="DEUTERONOMY 6" en="what Jesus set beside it" hl={1} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={i0 + 6} b={iSets} y={60} size={48}>no argument about grammar</Note>
      <Q f={f} a={iQ - 4} b={iEnd} refText="MATTHEW 4:7" eng="“It is also written: ‘*Do not put the Lord your God to the test*.’”" keys={[at('Do not put the Lord your God to the test', 1)]} y={70} />
    </>,
  }));
}

// 23 MASSAH -------------------------------------------------------------------------------------
{
  const j0 = at('That line comes from Deuteronomy'), jFull = at('Do not put the Lord your God to the test as'), jMas = at('Massah was a place'), jEx = at('The book of Exodus says'), jEnd = at('Listen closely to that question');
  push(j0, (f) => ({
    svg: <>
      <Spot id="q23a" x={960} y={620} r={880} />
      <Ground id="q23ag" />
      <Mountain x={1500} y={GY} s={0.7} o={0.25} />
      <Gp o={win(f, j0, jMas + 4)}>
        <Beam x={860} w={340} o={0.8} f={f} />
        <Book x={860} y={GY - 10} s={1} />
        <Fig {...JP(1240, {flip: true, head: 6})} />
      </Gp>
      <Gp o={fi(f, jMas)}>
        <Rock x={1500} y={GY} s={0.9} />
        <Fig {...DP(1180, {beard: 'long', hair: 'cloth', mantle: true, prop: 'staff', flip: true, head: 6})} />
        {[0, 1, 2, 3, 4].map((k) => F(f, jMas + 10 + k * 5, undefined, PPL(260 + k * 150, {arm: ezArm(f, jMas + 40 + k * 4, REST, [-150, -20], 12), head: -8}), 'm' + k))}
      </Gp>
    </>,
    html: <>
      <Q f={f} a={jFull - 4} b={jMas} refText="DEUTERONOMY 6:16" eng="“Do not put the Lord your God to the test *as you did at Massah*.”" keys={[at('as you did at Massah')]} y={60} />
      <Note f={f} a={jMas + 6} b={jEx} y={110} size={48}>no water, and Israel turned on Moses</Note>
      <Q f={f} a={jEx} b={jEnd} refText="EXODUS 17:7" eng="“…they tested the Lord saying, ‘*Is the Lord among us or not?*’”" keys={[at('Is the Lord among us or not')]} y={60} />
    </>,
  }));
}

// 24 FORTY YEARS, FORTY DAYS --------------------------------------------------------------------
{
  const k0 = at('Listen closely to that question'), kIf = at('If you are the Son of God, prove it'), kIs = at('Israel spent forty years'), kJ = at('Jesus spent forty days'), kWhere = at('Where Israel stumbled'), kEnd = at('Jumping would have meant');
  push(k0, (f) => ({
    svg: <>
      <Gp o={win(f, k0, kIs + 4)}>
        <Spot id="q24a" x={960} y={560} r={860} />
        <Card f={f} a={k0 + 6} x={560} y={540} w={680} h={260} top="MASSAH" en="“Is the Lord among us or not?”" />
        <Card f={f} a={kIf} x={1360} y={540} w={680} h={260} top="THE TEMPLE" en="“If you are the Son of God…”" hl={1} />
      </Gp>
      <Gp o={fi(f, kIs)}>
        <Spot id="q24b" x={960} y={560} r={900} />
        <DotGrid f={f} a={kIs} x={560} y={330} c={TXT.bronze} label="40 YEARS" sub="kept asking God to prove Himself" dur={50} dim={fi(f, kWhere)} />
        <DotGrid f={f} a={kJ} x={1360} y={330} c={C.gold} label="40 DAYS" sub="refused to ask even once" dur={50} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={k0 + 10} b={kIf} y={130} size={48}>the devil’s question in different clothes</Note>
      <Big f={f} a={kIf} b={kIs} y={140} size={60} c={TXT.ember}>PROVE IT</Big>
      <Big f={f} a={kWhere} b={kEnd} y={130} size={56} c={TXT.gold}>WHERE ISRAEL STUMBLED, HE STOOD</Big>
    </>,
  }));
}

// 25 HE KNEW HE WAS LOVED -----------------------------------------------------------------------
{
  const l0 = at('Jumping would have meant'), lKnew = at('Jesus already knew he was loved'), lHeard = at('He had heard it at the Jordan'), lEnd = at('After one more temptation');
  push(l0, (f) => ({
    svg: <>
      <PinSet f={f} id="q25" z={ez(f, l0, 1.25, 1.5, lEnd - l0)} beam={fi(f, lKnew, 30)} scroll={1} dArm={[-70, -20]} jHead={ez(f, lKnew, 0, -12, 20)} />
      <Dove x={pinTop().x} y={150} s={0.6} f={f} o={0.7 * fi(f, lHeard, 24)} />
    </>,
    html: <>
      <Note f={f} a={l0 + 6} b={lKnew} y={60} size={46}>as if his Father’s love needed checking</Note>
      <Big f={f} a={lKnew} b={lHeard} y={80} size={60} c={TXT.gold}>HE KNEW HE WAS LOVED</Big>
      <Note f={f} a={lHeard + 4} b={lEnd} y={940} size={46}>“This is my Son, whom I love”</Note>
    </>,
  }));
}

// 26 THE ANGELS CAME ANYWAY ---------------------------------------------------------------------
{
  const m0 = at('After one more temptation'), mQ = at('Then the devil left him, and angels'), mRead = at('Read that slowly'), mAny = at('The angels came anyway'), mVery = at('The very promise the devil tried'), mNever = at('Psalm 91 was never broken'), mEnd = at('Luke adds a quiet warning');
  push(m0, (f) => ({
    svg: <>
      <Gp o={win(f, m0, mNever + 4)}>
        <Wild f={f} id="q26a" night={0.35} />
        <Beam x={960} w={360} o={0.8 * fi(f, mAny, 30)} f={f} />
        <Fig {...JP(960, {head: -4})} />
        {DW(f, mQ + 10, mQ + 80, 1300, 1980, {o: 1 - fi(f, mQ + 60, 20)})}
        <Michael x={680} y={GY + (-300) * (1 - eio(ramp(f, mQ + 40, 50)))} sc={0.28} f={f} o={fi(f, mQ + 40, 20)} spread={0.8} arm={[-40, -40]} />
        <Michael x={1240} y={GY + (-300) * (1 - eio(ramp(f, mQ + 56, 50)))} sc={0.28} f={f} flip o={fi(f, mQ + 56, 20)} spread={0.8} arm={[-40, -40]} />
      </Gp>
      <Gp o={fi(f, mNever)}>
        <Spot id="q26b" x={960} y={520} r={900} />
        <PsalmCol f={f} o={1} y={170} rows={(v) => (v === 11 || v === 12 ? {c: C.gold, o: 1, glow: 1} : {o: 0.4})} ways={{c: C.gold, o: 1, glow: 1}} />
      </Gp>
    </>,
    html: <>
      <Q f={f} a={mQ - 4} b={mRead + 10} refText="MATTHEW 4:11" eng="“Then the devil left him, and *angels came and attended him*.”" keys={[at('angels came and attended him')]} y={60} />
      <Big f={f} a={mAny} b={mVery} y={110} size={64} c={TXT.gold}>THE ANGELS CAME ANYWAY</Big>
      <Note f={f} a={mVery} b={mNever} y={110} size={48}>in God’s time, after he refused to force it</Note>
      <Note f={f} a={mNever + 10} b={mEnd} y={960} size={46}>fulfilled by the Father, on the Father’s schedule</Note>
    </>,
  }));
}

// 27 AN OPPORTUNE TIME --------------------------------------------------------------------------
{
  const n0 = at('Luke adds a quiet warning'), nQ = at('When the devil had finished all'), nFight = at('The fight was not over'), nEnd = at('That opportune time came');
  push(n0, (f) => ({
    svg: <>
      <Night o={0.7} />
      <Spot id="q27" x={960} y={620} r={800} a={0.45} c="#7a3420" />
      <Moon x={420} y={300} r={34} o={0.6} />
      <Mountain x={480} y={GY} s={0.8} o={0.3} />
      <Mountain x={1560} y={GY} s={0.6} o={0.22} />
      <Stones x={700} y={GY} o={0.7} lit={-1} />
      <Ground id="q27g" />
      {DW(f, n0 + 10, nEnd, 900, 1500, {head: -6})}
    </>,
    html: <>
      <Q f={f} a={nQ - 4} b={nFight} refText="LUKE 4:13" eng="“When the devil had finished all this tempting, he left him *until an opportune time*.”" keys={[at('until an opportune time')]} y={60} />
      <Big f={f} a={nFight} b={nEnd} y={110} size={60} c={TXT.ember}>NOT OVER YET</Big>
    </>,
  }));
}

// 28 GETHSEMANE ---------------------------------------------------------------------------------
{
  const o0 = at('That opportune time came'), oPet = at('When Peter drew a sword'), oQ = at('Do you think I cannot call'), oLeg = at('more than twelve legions'), oOnce = at('Once again the angels of Psalm 91'),
    oRoad = at('Once again Jesus chose the road'), oCross = at('and this time the road led'), oEnd = at('At the cross, it looked');
  push(o0, (f) => ({
    svg: <>
      <Gp o={win(f, o0, oCross + 4)}>
        <Night o={0.8} />
        <Spot id="q28" x={880} y={640} r={820} a={0.5} />
        <Olive x={280} y={GY} s={1.1} o={0.6} />
        <Olive x={1700} y={GY} s={0.9} o={0.5} />
        <Ground id="q28g" cx={880} />
        <Legions f={f - oLeg} o={fi(f, oLeg, 30) * (1 - 0.5 * fi(f, oRoad, 30))} y={300} />
        <Fig {...JP(820, {arm: ezArm(f, oQ, REST, [-40, -20], 14)})} />
        <Fig {...DP(560, {beard: 'short', prop: 'spear', arm: ezArm(f, oPet, REST, [-110, -10], 12)})} />
        {[0, 1, 2].map((k) => <React.Fragment key={k}>{F(f, o0 + 10 + k * 6, undefined, SP(1220 + k * 150, {flip: true, sc: 0.3, hair: 'helmet', beard: 'short', mantle: false, prop: 'spear'}))}</React.Fragment>)}
        <Fire x={1160} y={GY - 360} s={0.5} f={f} o={0.8} />
      </Gp>
      <Gp o={fi(f, oCross)}>
        <Spot id="q28b" x={960} y={600} r={860} />
        <CrossHill x={960} y={GY} s={1.1} p={pr(f, oCross, 40)} />
        <Ground id="q28bg" />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={o0 + 6} b={oPet} y={90} size={48}>the night Jesus was arrested</Note>
      <Q f={f} a={oQ - 4} b={oOnce} refText="MATTHEW 26:53" eng="“Do you think I cannot call on my Father, and he will at once put at my disposal *more than twelve legions of angels*?”" keys={[oLeg]} y={40} size={46} />
      <Note f={f} a={oOnce} b={oRoad} y={960} size={46}>the angels of Psalm 91, within reach again</Note>
      <Note f={f} a={oRoad + 4} b={oCross} y={960} size={46}>he chose the road his Father had given him</Note>
      <Big f={f} a={oCross + 10} b={oEnd} y={110} size={60} c={TXT.gold}>THE ROAD LED TO A CROSS</Big>
    </>,
  }));
}

// 29 HEEL AND HEAD ------------------------------------------------------------------------------
{
  const p0 = at('At the cross, it looked'), pStr = at('He struck the heel'), pThree = at('Three days later'), pHead = at('and the head of the serpent'), pHeb = at('The book of Hebrews says'), pEnd = at('Now we can finally read');
  push(p0, (f) => {
    const lunge = f < pStr ? 0 : f < pStr + 14 ? eio(ramp(f, pStr, 8)) : 1 - eio(ramp(f, pStr + 14, 10));
    const cr = eio(ramp(f, pHead + 10, 14));
    return {
      svg: <>
        <Spot id="q29b" x={960} y={600} r={900} />
        <Ground id="q29bg" />
        <Gp o={win(f, p0, pThree + 4)}>
          <Night o={0.55} />
          <Spot id="q29a" x={960} y={600} r={860} a={0.35} c="#8a4a24" />
          <CrossHill x={960} y={GY} s={1.1} />
          <Serpent x={560 + 80 * lunge} y={GY} s={1.1} f={f} rear={0.4 + 0.3 * lunge} />
        </Gp>
        <Gp o={fi(f, pThree)}>
          <Tomb x={560} y={GY} s={1} roll={eio(ramp(f, pThree + 6, 40))} />
          <Beam x={1180} w={340} o={0.9 * fi(f, pHead - 10, 30)} f={f} />
          <Serpent x={1840} y={GY} s={1.1} f={f} rear={0.5 * (1 - cr)} crush={cr} eye={1 - cr} flip />
          {F(f, pHead, undefined, JP(1230, {head: 6}))}
        </Gp>
      </>,
      html: <>
        <Note f={f} a={p0 + 6} b={pStr} y={90} size={48}>it looked as though the serpent had won</Note>
        <Big f={f} a={pStr} b={pThree} y={110} size={60} c={TXT.ember}>HE STRUCK THE HEEL</Big>
        <Note f={f} a={pThree + 6} b={pHead} y={90} size={48}>three days later, the tomb was empty</Note>
        <Big f={f} a={pHead + 6} b={pHeb} y={110} size={60} c={TXT.gold}>THE HEAD WAS CRUSHED</Big>
        <Q f={f} a={pHeb} b={pEnd} refText="HEBREWS 2:14" eng="“…so that by his death he might break *the power of him who holds the power of death*…”" keys={[at('the power of the one who held')]} y={60} />
      </>,
    };
  });
}

// 30 THE ENDING HE SKIPPED ----------------------------------------------------------------------
{
  const q0 = at('Now we can finally read'), qGod = at('God Himself starts speaking'), qQ = at('Because he loves me,’ says'), qCall = at('He will call on me'), qLong = at('With long life I will satisfy'), qEnd = at('The final word of the psalm');
  push(q0, (f) => ({
    svg: <>
      <Gp o={win(f, q0, qQ + 4)}>
        <Spot id="q30a" x={960} y={520} r={900} />
        <PsalmCol f={f} o={1} y={170} stop={1 - fi(f, q0 + 20, 20)} rows={(v) => (v >= 14 ? {c: C.gold, o: 0.3 + 0.7 * fi(f, qGod + (v - 14) * 10, 16), glow: fi(f, qGod + (v - 14) * 10, 16)} : {o: 0.35})} />
      </Gp>
      <Gp o={fi(f, qQ)}>
        <Spot id="q30b" x={960} y={640} r={860} />
        <Ground id="q30bg" />
        <Beam x={960} w={380} o={0.9} f={f} />
        <Fig {...JP(960, {arm: ezArm(f, qCall, REST, [-60, -10], 16), arm2: null})} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={q0 + 6} b={qGod} y={960} size={46}>the ending he never wanted anyone to hear</Note>
      <Note f={f} a={qGod + 6} b={qQ} y={960} size={46}>here God Himself starts speaking</Note>
      <Q f={f} a={qQ - 6} b={qEnd} refText="PSALM 91:14–16" eng="“‘Because he loves me,’ says the Lord, ‘*I will rescue him*; I will protect him, for he acknowledges my name. He will call on me, and I will answer him; I will be with him in trouble, I will deliver him and honor him. With long life I will satisfy him and *show him my salvation*.’”" keys={[at('I will rescue him'), at('show him my salvation')]} y={20} size={42} />
    </>,
  }));
}

// 31 YESHUATI -----------------------------------------------------------------------------------
{
  const r0 = at('The final word of the psalm'), rRoot = at('It comes from the same root'), rPoint = at('The psalm the devil tried to use'), rEarly = at('Early Christians understood'), rEnd = at('So why did the devil never finish');
  push(r0, (f) => ({
    svg: <>
      <Gp o={win(f, r0, rPoint + 4)}>
        <Spot id="q31a" x={960} y={560} r={900} />
        <Card f={f} a={r0 + 10} x={560} y={540} w={640} h={340} top="PSALM 91:16" heb="יְשׁוּעָתִי" big="YESHUATI" en="my salvation" />
        <Card f={f} a={rRoot + 20} x={1360} y={540} w={640} h={340} top="THE NAME" heb="יֵשׁוּעַ" big="YESHUA" en="Jesus" hl={fi(f, rRoot + 50)} />
        <Line w={2.4} c="#E3B465" p={pr(f, rRoot + 10, 20)} d="M890,540 L1030,540 M1010,526 L1030,540 L1010,554" u />
      </Gp>
      <Gp o={fi(f, rPoint)}>
        <Spot id="q31b" x={960} y={620} r={860} />
        <Ground id="q31bg" />
      </Gp>
      <Gp o={win(f, rPoint, rEarly + 4)}>
        <Beam x={960} w={380} o={0.9} f={f} />
        <Fig {...JP(960)} />
      </Gp>
      <Gp o={fi(f, rEarly)}>
        <Plaque x={960} y={GY + 40} w={620} h={800} p={pr(f, rEarly, 40)} />
        <Lion x={1080} y={GY - 20} s={0.62} m="gold" flip o={fi(f, rEarly + 30)} />
        <Serpent x={690} y={GY - 20} s={0.55} f={0} m="gold" crush={1} eye={0} o={fi(f, rEarly + 30)} />
        <Fig {...JP(960, {y: GY - 92, sc: 0.3, o: fi(f, rEarly + 20)})} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={r0 + 6} b={rRoot} y={120} size={48}>the final word of the psalm</Note>
      <Note f={f} a={rRoot + 6} b={rPoint} y={830} size={46}>from the same root as the name of Jesus</Note>
      <Big f={f} a={rPoint + 6} b={rEarly} y={110} size={56} c={TXT.gold}>IT ENDS BY POINTING STRAIGHT AT HIM</Big>
      <Note f={f} a={rEarly + 10} b={rEnd} y={60} size={46}>carved over a thousand years ago, from verse 13</Note>
    </>,
  }));
}

// 32 THE ANSWER ---------------------------------------------------------------------------------
{
  const s0 = at('So why did the devil never finish'), sBec = at('Because the rest of the psalm'), sEnd = at('And he still works the same way');
  push(s0, (f) => ({
    svg: <>
      <Spot id="q32" x={960} y={520} r={900} />
      <PsalmCol f={f} o={1} y={170} rows={(v) => (v >= 13 ? {c: C.gold, o: 1, glow: fi(f, sBec, 20)} : {o: 0.55})} ways={{c: C.gold, o: 1}} />
    </>,
    html: <>
      <Big f={f} a={sBec + 10} b={sEnd} y={40} size={56} c={TXT.gold}>THE STORY OF HOW HE LOSES</Big>
    </>,
  }));
}

// 33 HALF A VERSE -------------------------------------------------------------------------------
{
  const t0 = at('And he still works the same way'), tRare = at('He rarely tells you'), tHalf = at('He hands you half a verse'), tTake = at('He will take “God will protect you”'), tTell = at('He will tell you that trouble'),
    tWhile = at('while the psalm itself says'), tNever = at('The promise was never that'), tProm = at('The promise is that God'), tEnd = at('That is why the whole verse matters');
  push(t0, (f) => {
    const room = (id: string, beam: number) => (
      <>
        <Night o={0.75} />
        <Spot id={id} x={760} y={620} r={760} a={0.5} />
        <Window x={1540} y={560} s={0.72} o={0.55} />
        <Moon x={1620} y={420} r={30} o={0.6} />
        <Ground id={id + 'g'} cx={760} />
        <Bed x={420} y={GY} w={440} o={0.7} />
        {beam > 0 ? <Beam x={700} w={300} o={0.9 * beam} f={f} /> : null}
      </>
    );
    return {
      svg: <>
        <Gp o={win(f, t0, tProm + 4)}>{room('q33a', 0)}</Gp>
        <Gp o={win(f, t0, tProm + 4)}>
          <Fig {...BP(640, {robe: 'seat', bench: true, head: ez(f, tTell, 10, 20, 20), bend: 8})} />
          {DW(f, t0 + 10, t0 + 80, 1980, 1240, {face: -1, arm: ezArm(f, tHalf, REST, [-70, -14], 14)})}
          <g opacity={fi(f, tHalf + 10)}><Scroll x={1060} y={ez(f, tHalf + 10, GY - 330, GY - 360, 20)} s={0.18} /><rect x={1086} y={GY - 410} width={40} height={64} fill="#0a0705" /></g>
        </Gp>
        <Gp o={fi(f, tProm)}>
          {room('q33b', fi(f, tProm, 30))}
          <Fig {...BP(640, {robe: 'seat', bench: true, head: ez(f, tProm, 20, -4, 20)})} />
          <Fig {...JP(860, {flip: true, o: 0.7 * fi(f, tProm + 20, 30), arm: [-40, -30]})} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={t0 + 6} b={tRare} y={90} size={48}>he still works the same way</Note>
        <Note f={f} a={tRare} b={tHalf} y={90} size={48}>rarely something with no truth in it</Note>
        <Big f={f} a={tHalf} b={tTake} y={110} size={64} c={TXT.ember}>HALF A VERSE</Big>
        <Note f={f} a={tTake} b={tTell} y={90} size={46}>“God will protect you” … without walking in His ways</Note>
        <Note f={f} a={tTell} b={tWhile} y={90} size={48}>“trouble means God has left you”</Note>
        <Q f={f} a={tWhile} b={tProm} refText="PSALM 91:15" eng="“*I will be with him in trouble*”" keys={[at('I will be with him in trouble', 2)]} y={60} />
        <Big f={f} a={tProm + 6} b={tEnd} y={90} size={56} c={TXT.gold}>RIGHT THERE INSIDE IT WITH YOU</Big>
      </>,
    };
  });
}

// 34 THE WHOLE VERSE ----------------------------------------------------------------------------
{
  const u0 = at('That is why the whole verse matters'), uWhen = at('When Jesus was tempted, he did not'), uYou = at('You can do the same'), uSounds = at('When something sounds like a promise'), uEnd = at('And here is the part that belongs');
  push(u0, (f) => ({
    svg: <>
      <Gp o={win(f, u0, uYou + 4)}>
        <PinSet f={f} id="q34a" z={1.4} scroll={1} dArm={[-70, -20]} jArm={[-40, -20]} beam={0.7} />
      </Gp>
      <Gp o={fi(f, uYou)}>
        <Spot id="q34b" x={960} y={640} r={860} />
        <Ground id="q34bg" />
        <Beam x={900} w={320} o={0.6 + 0.3 * fi(f, uSounds, 30)} f={f} />
        <Fig {...BP(760, {arm: [-60, -40], head: 10})} />
        <Book x={1000} y={GY - 300} s={0.4} />
      </Gp>
    </>,
    html: <>
      <Big f={f} a={u0 + 6} b={uWhen} y={80} size={60} c={TXT.gold}>THE WHOLE VERSE MATTERS</Big>
      <Note f={f} a={uWhen} b={uYou} y={60} size={48}>he answered with the rest of the Scriptures</Note>
      <Note f={f} a={uYou + 6} b={uSounds} y={110} size={48}>you can do the same</Note>
      <Note f={f} a={uSounds} b={uEnd} y={110} size={46}>pushed toward pride or fear? read the verses around it</Note>
    </>,
  }));
}

// 35 UNDER YOUR FEET ----------------------------------------------------------------------------
{
  const v0 = at('And here is the part that belongs'), vQ = at('I have given you authority'), vPaul = at('Paul wrote to the church'), vSkip = at('The verse the devil skipped'), vEnd = at('So the next time fear');
  push(v0, (f) => {
    const cr = eio(ramp(f, vPaul + 30, 16));
    return {
      svg: <>
        <Gp o={win(f, v0, vSkip + 4)}>
          <Spot id="q35a" x={960} y={640} r={860} />
          <Ground id="q35ag" />
          <Beam x={1000} w={340} o={0.8} f={f} />
          <Serpent x={1580} y={GY} s={1} f={f} rear={0.5 * (1 - cr)} crush={cr} eye={1 - cr} flip />
          <Fig {...DP(1000, {beard: 'short', hair: 'cloth', head: 8})} />
        </Gp>
        <Gp o={fi(f, vSkip)}>
          <Spot id="q35b" x={960} y={520} r={900} />
          <PsalmCol f={f} o={1} y={170} rows={(v) => ({c: C.gold, o: 0.6 + 0.4 * fi(f, vSkip + v * 3), glow: v === 13 ? 1 : 0})} ways={{c: C.gold, o: 1}} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={v0 + 6} b={vQ} y={90} size={48}>the part that belongs to you</Note>
        <Q f={f} a={vQ - 4} b={vPaul} refText="LUKE 10:19" eng="“I have given you authority *to trample on snakes and scorpions* and to overcome all the power of the enemy.”" keys={[at('to trample on snakes')]} y={50} />
        <Q f={f} a={vPaul + 10} b={vSkip} refText="ROMANS 16:20" eng="“The God of peace will soon *crush Satan under your feet*.”" keys={[at('crush Satan under your feet')]} y={60} />
        <Note f={f} a={vSkip + 20} b={vEnd} y={960} size={46}>finished by Jesus, and being finished in everyone who belongs to him</Note>
      </>,
    };
  });
}

// 36 FINISH THE PSALM ---------------------------------------------------------------------------
{
  const w0 = at('So the next time fear'), wRem = at('remember the temple'), wEnd = at('If this video blessed you');
  push(w0, (f) => ({
    svg: <>
      <PinSet f={f} id="q36" z={1.1} devil={1 - fi(f, wRem, 30)} beam={fi(f, wRem, 30)} dusk={0.8} />
    </>,
    html: <>
      <Note f={f} a={w0 + 6} b={wRem} y={60} size={48}>when fear whispers half a promise</Note>
      <Big f={f} a={wRem + 10} b={wEnd} y={90} size={72} c={TXT.gold}>FINISH THE PSALM</Big>
    </>,
  }));
}

// 37 OUTRO --------------------------------------------------------------------------------------
{
  const r0 = at('If this video blessed you'), rLike = at('please like, subscribe'), rLove = at('And always remember'), rSee = at('See you on the next one');
  push(r0, (f) => ({
    svg: <>
      <Spot id="q37" x={960} y={600} r={860} />
      <Ground id="q37g" />
      <Beam x={960} w={320} o={0.85} f={f} />
      {F(f, r0, undefined, JP(960, {arm: ezArm(f, rLove, REST, [-60, -10], 14)}))}
    </>,
    html: <>
      <Note f={f} a={r0 + 4} b={rLike} y={90} size={48}>if this video blessed you</Note>
      <Big f={f} a={rLike} b={rLove} y={80} size={56} c={TXT.gold}>LIKE · SUBSCRIBE · SHARE</Big>
      <Big f={f} a={rLove} b={rSee} y={80} size={66} c={TXT.gold}>JESUS LOVES YOU</Big>
      <Note f={f} a={rSee} y={90} size={50}>see you on the next one</Note>
    </>,
  }));
}
