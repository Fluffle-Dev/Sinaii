import React from 'react';
import {at, win, fi, kf, ramp, eio, eout, clamp} from '../lib';
import {Fig, FigP, Line, Tent, Throne, Colonnade, Bed, Moon, Sheep, TXT} from '../fig';
import {Ref, Big, Note, Name} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Mountain} from '../extra';
import {Scroll, CrossHill, Window, Waves} from '../props';
import {JP, DP, BP, SP, F, Gp, pr, ez, ezArm, turn, walkX} from '../kit';
import {Beam, Card, Q} from '../covprops';
import {Michael, Devil, Body, Slope, slopeY, Summit, SUMMIT, Vista, Dragon, Clouds, CaseFile, ChargeList, Brand, Valley, TimeBar, WordBoxes} from '../mmprops';
import {MOSES, PPL, REST, WK, DW, descend, Night, NeboSet, ROW1, ROW2, ROW3} from './mm1';

export const MM2: Scene[] = [];
const push = (start: number, render: Scene['render']) => MM2.push({start, render});

/** courtroom frame: two pillars and a beam */
const Hall: React.FC<{f: number; beam?: number; bx?: number}> = ({f, beam = 1, bx = 960}) => (
  <>
    <Colonnade x={960} y={GY} w={1500} h={640} n={2} o={0.3} />
    <Beam x={bx} w={320} o={0.8 * beam} f={f} />
  </>
);
/** Joshua the high priest: stained (st) bronze robe, then clean gold (clean) */
const Joshua: React.FC<{x: number; st: number; clean: number; flip?: boolean}> = ({x, st, clean, flip = true}) => {
  const base = {x, y: GY, sc: 0.31, hair: 'cap' as const, beard: 'long' as const, flip, head: 6};
  const stains: [number, number, number][] = [[-30, -190, 22], [18, -150, 17], [-14, -96, 26], [26, -60, 15], [-36, -40, 14], [8, -230, 12], [30, -120, 10]];
  const blob = (cx: number, cy: number, r: number, k: number) => { let d = ''; for (let i = 0; i < 9; i++) { const a = (i / 9) * Math.PI * 2, rr = r * (0.6 + 0.4 * Math.abs(Math.sin(k * 3.7 + i * 1.9))); d += `${i ? 'L' : 'M'}${cx + Math.cos(a) * rr * 1.2},${cy + Math.sin(a) * rr * 0.8} `; } return d + 'Z'; };
  return (
    <g>
      <g opacity={1 - clean}>
        <Fig {...base} m="bronze" bend={8} head={14} />
        <g opacity={st}>{stains.map(([dx, dy, r], i) => <path key={i} d={blob(x + dx, GY + dy, r, i + 1)} fill="#6b5232" opacity={0.7} />)}<path d={`M${x - 30},${GY - 170} C${x - 20},${GY - 120} ${x - 34},${GY - 80} ${x - 24},${GY - 30} M${x + 20},${GY - 200} C${x + 30},${GY - 150} ${x + 16},${GY - 100} ${x + 26},${GY - 50}`} fill="none" stroke="#5a4428" strokeWidth={5} opacity={0.6} strokeLinecap="round" /></g>
      </g>
      <g opacity={clean}>
        <ellipse cx={x} cy={GY - 240} rx={190} ry={300} fill="url(#halo)" opacity={1} />
        <Fig {...base} m="gold" mantle />
      </g>
    </g>
  );
};

// 10 WHO GOD SENT -------------------------------------------------------------------------------
{
  const k0 = at('Now look at who God sent'), kName = at('Michael’s name is a question'), kOnly = at('He is the only angel'), kDan = at('the book of Daniel describes'),
    kSo = at('So the guardian of Israel'), kIf = at('If any creature had the rank'), kEnd = at('And yet Jude says');
  push(k0, (f) => {
    const dv = walkX(f, kIf + 4, kIf + 30, 1300, 1380, 60);
    return {
      svg: <>
        <Gp o={win(f, k0, kOnly + 4)}>
          <Spot id="m10a" x={1200} y={600} r={820} />
          <Ground id="m10ag" cx={1200} />
          <Beam x={1250} w={340} o={0.85} f={f} />
          <Michael x={1250} y={GY} f={f} sc={0.38} />
          <Card f={f} a={kName} x={600} y={440} w={640} h={290} top="MICHAEL" heb="מִיכָאֵל" en="Who is like God?" />
        </Gp>
        <Gp o={win(f, kOnly, kSo + 4)}>
          <Spot id="m10b" x={1000} y={600} r={860} />
          <Ground id="m10bg" />
          {[[220, 0.55], [430, 0.7], [660, 0.6], [860, 0.5]].map(([x, s], i) => <Tent key={i} x={x} y={GY} s={s} o={0.75} />)}
          {[0, 1, 2].map((k) => F(f, kOnly + 6 + k * 5, undefined, PPL(340 + k * 220, {sc: 0.22, o: 0.85}), 'pe' + k))}
          <Beam x={1360} w={300} o={0.75} f={f} />
          <Michael x={1360} y={GY} f={f} flip prop="spear" hair="helmet" sc={0.36} />
        </Gp>
        <Gp o={fi(f, kSo)}>
          <NeboSet f={f} id="m10c" glow={0.5} />
          <Michael x={640} y={GY} f={f} prop="spear" spread={ez(f, kIf, 0.8, 1, 20)} arm={ezArm(f, kIf + 6, REST, [-150, -20], 16)} />
          <Devil x={dv.x} y={GY} f={f} walk={dv.walk} wa={dv.wa} face={-1} head={ez(f, kIf + 6, 0, -14, 16)} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={k0 + 6} b={kName} y={100} size={48}>who God sent to that grave</Note>
        <Ref f={f} a={kOnly} b={kDan} y={70}>THE ONLY ARCHANGEL · JUDE 9</Ref>
        <Q f={f} a={kDan} b={kSo} refText="DANIEL 12:1" eng="“At that time Michael, *the great prince who protects your people*, will arise.”" keys={[at('the great prince who protects')]} y={60} />
        <Note f={f} a={kSo + 6} b={kIf} y={100} size={48}>the guardian of Israel, face to face with the enemy</Note>
        <Note f={f} a={kIf + 6} b={kEnd} y={100} size={48}>the rank and the right</Note>
      </>,
    };
  });
}

// 11 FOUR WORDS ---------------------------------------------------------------------------------
{
  const l0 = at('And yet Jude says'), lTr = at('Michael traded no insults'), lFour = at('His whole answer was four words'), lBor = at('and he had borrowed it'), lEnd = at('About five hundred years before Jesus');
  push(l0, (f) => ({
    svg: <>
      <Gp o={win(f, l0, lFour + 4)}>
        <NeboSet f={f} id="m11a" glow={0.5} />
        <Michael x={640} y={GY} f={f} prop="spear" spread={ez(f, l0 + 10, 1, 0.55, 30)} arm={ezArm(f, l0 + 10, [-150, -20], REST, 20)} head={ez(f, lTr, 0, 10, 20)} />
        <Devil x={1380} y={GY} f={f} flip />
      </Gp>
      <Gp o={fi(f, lFour)}>
        <Spot id="m11b" x={960} y={560} r={860} />
        <WordBoxes f={f} a={lFour} words={['THE', 'LORD', 'REBUKE', 'YOU']} keys={[lFour + 16, lFour + 26, lFour + 36, lFour + 46]} y={540} />
      </Gp>
    </>,
    html: <>
      <Q f={f} a={l0} b={lFour} refText="JUDE 9" eng="“…did not himself dare to *condemn him for slander*…”" keys={[at('condemn him for slander', 2)]} y={60} />
      <Note f={f} a={lTr} b={lFour} y={240} size={46}>no insults, no verdict of his own</Note>
      <Note f={f} a={lFour} b={lBor} y={300} size={48}>his whole answer</Note>
      <Note f={f} a={lBor} b={lEnd} y={300} size={48}>borrowed</Note>
      <Ref f={f} a={lBor + 10} b={lEnd} y={720}>ZECHARIAH 3:2</Ref>
    </>,
  }));
}

// 12 ZECHARIAH 3 --------------------------------------------------------------------------------
{
  const m0 = at('About five hundred years before Jesus'), mShown = at('was shown a courtroom'), mQ = at('Then he showed me Joshua'), mFil = at('Joshua was wearing filthy clothes'),
    mOnce = at('so once again the accuser'), mList = at('Listen to the way God answers'), mQ2 = at('The LORD rebuke you, Satan'), mBrand = at('Is not this man a burning stick'),
    mRests = at('God’s answer rests on his own choice'), mTaken = at('the filthy clothes are taken away'), mQ3 = at('See, I have taken away your sin'), mEnd = at('So when Michael stood over');
  push(m0, (f) => {
    const clean = eio(ramp(f, mTaken + 10, 24));
    return {
      svg: <>
        <Gp o={win(f, m0, mShown + 4)}>
          <Spot id="m12a" x={1000} y={600} r={820} />
          <Ground id="m12ag" />
          <Beam x={1250} w={320} o={0.7} f={f} />
          <Fig {...DP(760, {beard: 'long', hair: 'cloth', head: -14, arm: ezArm(f, m0 + 20, REST, [-70, -30], 14)})} />
        </Gp>
        <Gp o={win(f, mShown, mOnce + 4) + win(f, mList, mBrand + 4)}>
          <Spot id="m12b" x={960} y={600} r={860} />
          <Ground id="m12bg" />
          <Hall f={f} beam={0.6 + 0.4 * fi(f, mList)} />
          <Michael x={560} y={GY} f={f} glow={0.6} />
          <Joshua x={960} st={fi(f, mFil, 20)} clean={0} />
          <Devil x={1340} y={GY} f={f} flip arm={ezArm(f, mQ + 30, REST, [-80, -10], 14)} />
        </Gp>
        <Gp o={win(f, mOnce, mList + 4)}>
          <Spot id="m12c" x={960} y={560} r={860} />
          <CaseFile f={f} o={1} y0={420} rows={[{...ROW1, ansO: 0, dim: 1}, {...ROW2, ansO: 0, hl: 1, o: fi(f, mOnce + 6)}]} />
        </Gp>
        <Gp o={win(f, mBrand, mRests + 4)}>
          <Spot id="m12d" x={960} y={640} r={760} a={0.5} />
          <Ground id="m12dg" />
          <Brand x={960} y={GY - 20} f={f} t={ramp(f, mBrand + 16, 40)} s={1.15} />
        </Gp>
        <Gp o={win(f, mRests, mTaken + 4)}>
          <Spot id="m12e" x={960} y={560} r={860} />
          <Card f={f} a={mRests} x={560} y={500} w={600} h={250} top="CHOSEN" en="“who has chosen Jerusalem”" />
          <Card f={f} a={mRests + 16} x={1360} y={500} w={600} h={250} top="RESCUED" en="“snatched from the fire”" />
        </Gp>
        <Gp o={fi(f, mTaken)}>
          <Spot id="m12f" x={960} y={600} r={860} />
          <Ground id="m12fg" />
          <Hall f={f} beam={1} />
          <Michael x={560} y={GY} f={f} glow={0.6} />
          <Joshua x={960} st={1} clean={clean} />
          <circle cx={960} cy={GY - 260} r={240} fill="url(#halo)" opacity={1.6 * win(f, mTaken + 10, mTaken + 40, 10)} />
          <Devil x={1340 + 120 * eio(ramp(f, mTaken + 6, 40))} y={GY} f={f} flip o={1 - fi(f, mTaken + 6, 40)} />
        </Gp>
      </>,
      html: <>
        <Name f={f} a={m0 + 10} b={mShown} x={760} y={900} en="ZECHARIAH · ABOUT 520 BC" />
        <Q f={f} a={mQ} b={mFil} refText="ZECHARIAH 3:1" eng="“Then he showed me *Joshua the high priest* standing before the angel of the LORD, and *Satan standing at his right side* to accuse him.”" keys={[at('Joshua the high priest'), at('Satan standing at his right side')]} y={40} size={46} />
        <Note f={f} a={mFil} b={mOnce} y={100} size={48}>filthy clothes</Note>
        <Note f={f} a={mList} b={mQ2} y={100} size={48}>listen to how God answers</Note>
        <Q f={f} a={mQ2} b={mRests} refText="ZECHARIAH 3:2" eng="“*The LORD rebuke you, Satan!* The LORD, who has chosen Jerusalem, rebuke you! Is not this man *a burning stick snatched from the fire*?”" keys={[mQ2, at('a burning stick snatched')]} y={30} size={44} />
        <Q f={f} a={mQ3} b={mEnd} refText="ZECHARIAH 3:4" eng="“See, *I have taken away your sin*, and I will put fine garments on you.”" keys={[at('I have taken away your sin')]} y={60} />
      </>,
    };
  });
}

// 13 QUOTING THE JUDGE --------------------------------------------------------------------------
{
  const n0 = at('So when Michael stood over'), nSaid = at('said The Lord rebuke you', 2), nQuot = at('he was quoting the judge'), nHigher = at('He was telling the devil that this case'),
    nOld = at('In the old account the devil withdrew'), nFin = at('and Michael finished the burial'), nGrave = at('in a grave nobody has ever found'), nLesson = at('That is Jude’s lesson'),
    nIf = at('If an archangel handles'), nOwn = at('Our own strength was never'), nQ = at('Submit yourselves, then, to God'), nFlee = at('and he will flee from you'), nEnd = at('Michael and the devil meet one more time');
  push(n0, (f) => {
    const out = walkX(f, nOld + 18, nOld + 96, 1320, 1980, 66);
    const fl = walkX(f, nFlee, nFlee + 70, 1320, 1980, 70);
    const lower = eio(ramp(f, nFin + 6, 60));
    return {
      svg: <>
        <Gp o={win(f, n0, nQuot + 4)}>
          <NeboSet f={f} id="m13a" glow={0.5} />
          <Michael x={640} y={GY} f={f} arm={ezArm(f, nSaid - 6, REST, [-165, -8], 14)} />
          <Beam x={1320} w={280} o={0.8 * fi(f, nSaid + 10, 20)} f={f} />
          <Devil x={1320} y={GY} f={f} flip head={ez(f, nSaid + 12, 0, 14, 14)} bend={ez(f, nSaid + 12, 0, 8, 14)} />
        </Gp>
        <Gp o={win(f, nQuot, nOld + 4)}>
          <Spot id="m13b" x={960} y={560} r={860} />
          <CaseFile f={f} o={1} y0={400} rows={[{...ROW1, ansO: fi(f, nQuot + 10), hl: 1}, {...ROW2, dim: 1}]} />
        </Gp>
        <Gp o={win(f, nOld, nGrave + 4)}>
          <NeboSet f={f} id="m13c" glow={0.6} body={0} />
          <Body x={960} y={GY + 60 * lower} s={0.95} o={1 - lower} glow={0.7} />
          <Beam x={960} w={300} o={0.85 * fi(f, nFin, 20)} f={f} />
          <Michael x={640} y={GY} f={f} arm={ezArm(f, nFin, REST, [-70, -40], 16)} head={ez(f, nFin, 0, 14, 16)} />
          <Devil x={out.x} y={GY} f={f} walk={out.walk} wa={out.wa} face={f < nOld + 4 ? -1 : turn(f, nOld + 4, -1, 12)} o={1 - fi(f, nOld + 60, 40)} />
        </Gp>
        <Gp o={win(f, nGrave, nLesson + 4)}>
          <Spot id="m13d" x={1060} y={760} r={760} a={0.5} />
          <Valley f={f} grave={1} seal={eio(ramp(f, nGrave, 30))} q={fi(f, nGrave + 20)} />
        </Gp>
        <Gp o={win(f, nLesson, nOwn + 4)}>
          <Spot id="m13e" x={960} y={600} r={860} />
          <Ground id="m13eg" />
          {[0, 1, 2].map((k) => F(f, nLesson + k * 5, undefined, BP(380 + k * 170, {sc: 0.29, head: -18, arm: k === 1 ? [-160, -30] : [-110, -50], beard: k === 2 ? 'none' : 'short'}), 'lt' + k))}
          <Beam x={1360} w={300} o={0.8} f={f} />
          <Michael x={1360} y={GY} f={f} flip spread={0.5} head={8} />
        </Gp>
        <Gp o={fi(f, nOwn)}>
          <Spot id="m13f" x={900} y={600} r={860} />
          <Ground id="m13fg" />
          <Beam x={820} w={300} o={0.85} f={f} />
          <Fig {...DP(820, {robe: 'kneel', bend: ez(f, nQ, 0, 20, 20), head: ez(f, nQ, 0, 24, 20), beard: 'short', hair: 'cloth'})} />
          <Devil x={fl.x} y={GY} f={f} walk={fl.walk} wa={fl.wa} face={f < nFlee - 6 ? -1 : turn(f, nFlee - 6, -1, 10)} o={1 - fi(f, nFlee + 40, 30)} />
        </Gp>
      </>,
      html: <>
        <Big f={f} a={nSaid} b={nQuot} y={100} size={60} c={TXT.gold}>“THE LORD REBUKE YOU”</Big>
        <Note f={f} a={nQuot + 10} b={nHigher} y={760} size={48}>quoting the judge</Note>
        <Note f={f} a={nHigher} b={nOld} y={760} size={46}>this case belongs to a higher court</Note>
        <Note f={f} a={nOld + 6} b={nFin} y={100} size={48}>the devil withdrew</Note>
        <Note f={f} a={nFin} b={nGrave} y={100} size={48}>Michael finished the burial</Note>
        <Note f={f} a={nGrave + 10} b={nLesson} y={100} size={48}>a grave nobody has ever found</Note>
        <Note f={f} a={nLesson} b={nIf} y={100} size={46}>Jude’s lesson for the loud teachers</Note>
        <Note f={f} a={nIf} b={nOwn} y={100} size={46}>no idea what they are playing with</Note>
        <Note f={f} a={nOwn} b={nQ} y={100} size={48}>our strength was never the weapon</Note>
        <Q f={f} a={nQ} b={nEnd} refText="JAMES 4:7" eng="“*Submit yourselves*, then, to God. *Resist the devil, and he will flee from you*.”" keys={[nQ, at('Resist the devil, and he will flee')]} y={60} />
      </>,
    };
  });
}

// 14 REVELATION 12 ------------------------------------------------------------------------------
{
  const o0 = at('Michael and the devil meet one more time'), oQ = at('Then war broke out in heaven'), oFought = at('Michael and his angels fought'), oNot = at('But he was not strong enough'),
    oVoice = at('A loud voice then announces'), oQ2 = at('They triumphed over him'), oLamb = at('by the blood of the Lamb'), oQuar = at('The quarrel beside a grave in Moab'),
    oEnds = at('and that fight ends with the accuser'), oEnd = at('So who won the argument');
  push(o0, (f) => {
    const adv = 150 * eio(ramp(f, oFought + 6, 50));
    const fallD = eio(ramp(f, oNot + 10, 60));
    const fall2 = eio(ramp(f, oVoice + 4, 90));
    const thrown = eio(ramp(f, oEnds + 10, 50));
    const HY = 930;
    return {
      svg: <>
        <Gp o={win(f, o0, oVoice + 4)}>
          <Spot id="m14a" x={960} y={520} r={900} />
          {[[200, 0.23, 0.6], [360, 0.25, 0.75]].map(([x, s, o], i) => <Michael key={i} x={x + adv} y={HY} f={f + i * 20} sc={s} o={o} prop="spear" hair="helmet" glow={0.3} arm={[-120, -40]} />)}
          <Michael x={560 + adv} y={HY} f={f} sc={0.28} prop="spear" hair="helmet" arm={ezArm(f, oFought, REST, [-130, -40], 14)} />
          <Dragon x={1360 + 120 * fallD} y={800 + 520 * fallD} s={0.72} f={f} rot={24 * fallD} o={1 - 0.9 * fallD} />
          <Clouds y={1010} f={f} />
        </Gp>
        <Gp o={win(f, oVoice, oQuar + 4)}>
          <Spot id="m14b" x={960} y={560} r={860} />
          <Clouds y={1010} f={f} seed={8} />
          <g opacity={1 - fi(f, oQ2 - 10, 20)}>
            <Michael x={560} y={HY} f={f} sc={0.28} prop="spear" hair="helmet" arm={[-150, -20]} />
            <ellipse cx={1240} cy={HY + 20} rx={260} ry={60} fill="#7a2414" opacity={0.35 * fi(f, oVoice + 40, 30)} filter="url(#soft)" />
            <g transform={`translate(${1200 + 120 * fall2} ${-220 + 1240 * fall2}) rotate(${60 * fall2} 0 ${GY - 300})`}><Devil x={0} y={GY} f={f} smoke={0} /></g>
          </g>
          <Gp o={fi(f, oQ2)}>
            <Beam x={960} w={320} o={0.85} f={f} bottom={HY} />
            <ellipse cx={960} cy={HY - 160} rx={360} ry={230} fill="url(#halo)" opacity={1} />
            <Sheep x={960} y={HY} s={1.9} m="gold" lamb />
          </Gp>
        </Gp>
        <Gp o={win(f, oQuar, oEnds + 4)}>
          <Spot id="m14c" x={960} y={560} r={860} />
          <Line u w={2.4} p={pr(f, oQuar, 40)} c="#E3B465" d="M400,560 L1520,560" />
          {[[460, 'JUDE 9', 'a grave in Moab'], [960, 'ZECHARIAH 3', 'a courtroom'], [1460, 'REVELATION 12', 'war in heaven']].map(([x, t, s], i) => (
            <g key={i} opacity={fi(f, oQuar + 10 + i * 14)}>
              <circle cx={x as number} cy={560} r={60} fill="url(#halo)" /><circle cx={x as number} cy={560} r={13} fill="#FFE2A0" filter="url(#lglow)" />
              <text x={x as number} y={640} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={38} letterSpacing={4}>{t}</text>
              <text x={x as number} y={690} textAnchor="middle" fill={TXT.ivory} fontFamily="Corm" fontStyle="italic" fontSize={36}>{s}</text>
            </g>
          ))}
        </Gp>
        <Gp o={fi(f, oEnds)}>
          <Spot id="m14d" x={960} y={600} r={860} />
          <Ground id="m14dg" />
          <Hall f={f} />
          <Throne x={960} y={GY - 6} s={1.05} />
          <g transform={`rotate(${40 * thrown} ${1320 + 600 * thrown} ${GY})`}><Devil x={1320 + 600 * thrown} y={GY} f={f} flip o={1 - thrown} /></g>
        </Gp>
      </>,
      html: <>
        <Ref f={f} a={o0} b={oQ} y={70}>REVELATION 12</Ref>
        <Note f={f} a={o0 + 6} b={oQ} y={150} size={48}>one more meeting</Note>
        <Q f={f} a={oQ} b={oVoice} refText="REVELATION 12:7–8" eng="“Then war broke out in heaven. *Michael and his angels fought against the dragon*, and the dragon and his angels fought back. But he was *not strong enough*, and they lost their place in heaven.”" keys={[oFought, at('not strong enough')]} y={30} size={42} />
        <Note f={f} a={oVoice + 4} b={oQ2} y={100} size={48}>the accuser hurled down</Note>
        <Q f={f} a={oQ2} b={oQuar} refText="REVELATION 12:11" eng="“They triumphed over him *by the blood of the Lamb* and by the word of their testimony.”" keys={[oLamb]} y={60} />
        <Note f={f} a={oQuar + 6} b={oEnds} y={300} size={48}>an early round in a very long fight</Note>
        <Note f={f} a={oEnds + 6} b={oEnd} y={100} size={48}>thrown out of the courtroom</Note>
      </>,
    };
  });
}

// 15 WHO WON ------------------------------------------------------------------------------------
{
  const p0 = at('So who won the argument'), pBack = at('To find out, go back'), pMore = at('More than twelve hundred years'), pJesus = at('Jesus took three disciples'),
    pQ = at('Two men, Moses and Elijah'), pMan = at('The man the devil called a murderer'), pIn = at('inside the land he was once'), pGreek = at('And the Greek word Luke uses'),
    pLead = at('The leader of the first exodus'), pGreat = at('a greater one, the rescue'), pEnd = at('Which brings this to you');
  push(p0, (f) => {
    const wj = walkX(f, pJesus + 4, pQ - 6, 300, 1120, 66);
    const ds = [0, 1, 2].map((k) => walkX(f, pJesus + 14 + k * 8, pQ + 4 + k * 8, 140 - k * 120, 960 - k * 130, 66));
    const part = eio(ramp(f, pLead + 10, 40));
    return {
      svg: <>
        <Gp o={win(f, p0, pMore + 4)}>
          <Spot id="m15a" x={1060} y={760} r={760} a={0.5} />
          <Valley f={f} grave={1} seal={1} q={fi(f, pBack + 10)} />
        </Gp>
        <TimeBar f={f} a={pMore} b={pJesus + 4} l="MOAB" r="THE MOUNTAIN" mid="more than twelve hundred years" />
        <Gp o={win(f, pJesus, pQ + 4)}>
          <Spot id="m15b" x={900} y={560} r={860} />
          <Slope />
          <Fig {...JP(0)} x={wj.x} y={slopeY(wj.x)} walk={wj.walk} wa={wj.wa} face={1} />
          {ds.map((d, k) => <Fig key={k} {...DP(0, {sc: 0.27, beard: k === 2 ? 'none' : 'short', hair: 'cloth'})} x={d.x} y={slopeY(d.x)} walk={d.walk} wa={d.wa} face={1} />)}
        </Gp>
        <Gp o={win(f, pQ, pIn + 4)}>
          <Spot id="m15c" x={960} y={600} r={860} a={0.7} />
          <Mountain x={960} y={GY} s={1.4} o={0.45} />
          <Ground id="m15cg" />
          <ellipse cx={960} cy={GY - 260} rx={420} ry={420} fill="url(#halo)" opacity={1} />
          <ellipse cx={960} cy={GY - 280} rx={170} ry={300} fill="#FFF3D6" opacity={0.18} filter="url(#soft)" />
          <Beam x={960} w={380} o={1} f={f} />
          <Fig {...JP(960, {sc: 0.34})} />
          <g opacity={fi(f, pQ + 20, 24)}>
            <ellipse cx={620} cy={GY - 240} rx={200 + 60 * win(f, pMan, pIn, 16)} ry={300} fill="url(#halo)" opacity={0.8 + 0.6 * win(f, pMan, pIn, 16)} />
            <Fig {...MOSES(620, {prop: 'staff'})} />
          </g>
          <g opacity={fi(f, pQ + 30, 24)}>
            <ellipse cx={1300} cy={GY - 240} rx={200} ry={300} fill="url(#halo)" opacity={0.8} />
            <Fig {...DP(1300, {flip: true, beard: 'long', hair: 'cloth', mantle: true})} />
          </g>
          {[0, 1, 2].map((k) => F(f, pQ + 40 + k * 5, undefined, DP(1600 + k * 110, {robe: 'kneel', sc: 0.22, flip: true, head: 22, bend: 18, beard: k === 2 ? 'none' : 'short'}), 'dk' + k))}
        </Gp>
        <Gp o={win(f, pIn, pGreek + 4)}>
          <Spot id="m15d" x={900} y={520} r={900} />
          <Vista f={f} dot={eio(ramp(f, pIn + 6, 60))} gilead={0.6} />
          <Summit />
          <text x={1500} y={540} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={36} letterSpacing={5} opacity={fi(f, pIn + 60)}>INSIDE THE LAND</text>
        </Gp>
        <Gp o={win(f, pGreek, pGreat + 4)}>
          <Spot id="m15e" x={960} y={560} r={860} />
          <Card f={f} a={pGreek} x={960} y={280} w={640} h={270} top="EXODOS" grk="ἔξοδος" en="departure, the way out" />
          <Gp o={fi(f, pLead)}>
            <g transform={`translate(${-part * 300} 0)`}><Waves y={GY - 40} x0={0} x1={960} o={0.7} /><Waves y={GY + 30} x0={0} x1={960} o={0.5} /></g>
            <g transform={`translate(${part * 300} 0)`}><Waves y={GY - 40} x0={960} x1={1920} o={0.7} /><Waves y={GY + 30} x0={960} x1={1920} o={0.5} /></g>
            <Fig {...MOSES(960, {sc: 0.22, arm: ezArm(f, pLead + 6, REST, [-150, -20], 14)})} />
          </Gp>
        </Gp>
        <Gp o={fi(f, pGreat)}>
          <Spot id="m15f" x={960} y={600} r={860} />
          <Ground id="m15fg" />
          <CrossHill x={960} y={GY} s={1} p={pr(f, pGreat, 40)} />
          <Beam x={960} w={300} o={0.85} f={f} bottom={GY - 120} />
        </Gp>
      </>,
      html: <>
        <Big f={f} a={p0 + 4} b={pBack} y={110} size={84} c={TXT.gold}>WHO WON?</Big>
        <Note f={f} a={pBack} b={pMore} y={110} size={48}>back to the hidden grave</Note>
        <Q f={f} a={pQ} b={pIn} refText="LUKE 9:30–31" eng="“Two men, Moses and Elijah, *appeared in glorious splendor*, talking with Jesus. They spoke about *his departure*, which he was about to bring to fulfillment at Jerusalem.”" keys={[at('appeared in glorious splendor'), at('They spoke about his departure') + 18]} y={30} size={44} />
        <Note f={f} a={pMan} b={pIn} y={920} size={44}>the man the devil called a murderer</Note>
        <Note f={f} a={pLead} b={pGreat} y={930} size={46}>the leader of the first exodus</Note>
        <Note f={f} a={pGreat} b={pEnd} y={110} size={48}>a greater exodus, won at the cross</Note>
      </>,
    };
  });
}

// 16 THE ACCUSER AND YOU ------------------------------------------------------------------------
{
  const q0 = at('Which brings this to you'), qQuiet = at('He still shows up in the quiet hours'), qAcc = at('much of the list is accurate'), qTry = at('If you try to answer him'),
    qMoses = at('because Moses could not win'), qPaul = at('Paul gives you a better answer'), qQ = at('Who will bring any charge'), qJust = at('It is God who justifies'),
    qNo = at('Who then is the one who condemns'), qSame = at('It is the same word God used'), qChrist = at('Paul goes on to say'), qRight = at('is at the right hand of God'),
    qNever = at('You were never asked to win'), qAns = at('Answer the accuser the way Michael did'), qSon = at('whose Son died for the very things'), qLost = at('The devil argued over Moses and lost'),
    qYou = at('and he will lose the argument over you'), qEnd = at('If this video blessed you');
  const ITEMS = ['WORDS YOU REGRET', 'PROMISES BROKEN', 'WHAT NO ONE KNOWS'];
  push(q0, (f) => {
    const dIn = walkX(f, q0 + 20, q0 + 90, 1980, 1400, 64);
    const dLeave = walkX(f, qLost + 10, qLost + 90, 1300, 1980, 66);
    const dGone = walkX(f, qYou + 6, qYou + 70, 1400, 1980, 70);
    const room = (id: string, beam: number, extra?: React.ReactNode) => (
      <>
        <Night o={0.75} />
        <Spot id={id} x={760} y={620} r={760} a={0.5} />
        <Window x={1540} y={560} s={0.72} o={0.55} />
        <Moon x={1620} y={420} r={30} o={0.6} />
        <Ground id={id + 'g'} cx={760} />
        <Bed x={420} y={GY} w={440} o={0.7} />
        {beam > 0 ? <Beam x={700} w={280} o={0.85 * beam} f={f} /> : null}
        {extra}
      </>
    );
    return {
      svg: <>
        <Gp o={win(f, q0, qPaul + 4)}>{room('m16a', 0)}</Gp>
        <Gp o={win(f, q0, qTry + 4)}>
          <Fig {...DP(600, {robe: 'seat', bench: true, head: 18, bend: 8, beard: 'short', hair: 'cloth'})} />
          <Devil x={dIn.x} y={GY} f={f} walk={dIn.walk} wa={dIn.wa} face={-1} arm={[-60, -30]} />
          <ChargeList x={1010} y={190} w={460} L={600} p={eio(ramp(f, qQuiet + 6, 50))} items={ITEMS} itemO={ITEMS.map((_, i) => fi(f, qQuiet + 24 + i * 10))} checks={ITEMS.map((_, i) => fi(f, qAcc + 6 + i * 8))} more={ramp(f, qQuiet + 50, 80)} />
        </Gp>
        <Gp o={win(f, qTry, qPaul + 4)}>
          <Fig {...DP(640, {beard: 'short', hair: 'cloth', arm: [-62, -40], head: 6})} />
          <Scroll x={760} y={GY - 300} s={0.2} />
          <Devil x={1400} y={GY} f={f} flip arm={[-60, -30]} />
          <ChargeList x={1010} y={190} w={460} L={600} p={1} items={ITEMS} checks={[1, 1, 1]} more={1} />
        </Gp>
        <Gp o={win(f, qPaul, qSame + 4)}>
          <Spot id="m16c" x={960} y={600} r={860} />
          <Ground id="m16cg" />
          <Hall f={f} beam={fi(f, qJust, 20)} bx={760} />
          <Fig {...DP(760, {beard: 'short', hair: 'cloth', head: ez(f, qJust, 6, -10, 20)})} />
          <Devil x={1320} y={GY} f={f} flip o={1 - 0.6 * fi(f, qNo, 30)} />
        </Gp>
        <Gp o={win(f, qSame, qChrist + 4)}>
          <Spot id="m16d" x={960} y={560} r={860} />
          <Card f={f} a={qSame} x={560} y={480} w={620} h={250} top="ZECHARIAH 3:2" en="“who has chosen Jerusalem”" />
          <Card f={f} a={qSame + 14} x={1360} y={480} w={620} h={250} top="ROMANS 8:33" en="“those whom God has chosen”" />
        </Gp>
        <Gp o={win(f, qChrist, qNever + 4)}>
          <Spot id="m16e" x={960} y={600} r={860} />
          <Ground id="m16eg" />
          <Throne x={840} y={GY - 6} s={1.1} />
          <Beam x={840} w={320} o={0.9} f={f} />
          <ellipse cx={1140} cy={GY - 250} rx={200} ry={300} fill="url(#halo)" opacity={0.9} />
          <Fig {...JP(1140, {flip: true, arm: ezArm(f, qRight, REST, [-100, -30], 16), head: -6})} />
        </Gp>
        <Gp o={win(f, qNever, qAns + 4)}>
          <Spot id="m16f" x={960} y={560} r={860} />
          <CaseFile f={f} o={1} rows={[{...ROW1, dim: 1}, {...ROW2, dim: 1}, {...ROW3, ansO: fi(f, qNever + 24), hl: 1}]} />
        </Gp>
        <Gp o={win(f, qAns, qLost + 4)}>
          {room('m16g', fi(f, qAns + 10, 20))}
          <Fig {...DP(700, {beard: 'short', hair: 'cloth', arm: ezArm(f, qAns + 10, REST, [-165, -6], 16), head: ez(f, qAns + 10, 0, -16, 16)})} />
          <Line u w={3} c="#FFF0C8" o={fi(f, qSon + 20, 30)} d={`M700,150 L700,420 M610,240 L790,240`} />
          <Devil x={1400} y={GY} f={f} flip arm={[-60, -30]} head={ez(f, qSon, 0, 12, 20)} />
          <ChargeList x={1010} y={190} w={460} L={600} p={1} items={ITEMS} checks={[1, 1, 1]} more={1} burn={eio(ramp(f, qSon + 10, 70))} o={1 - fi(f, qSon + 70, 20)} />
        </Gp>
        <Gp o={win(f, qLost, qYou + 4)}>
          <NeboSet f={f} id="m16h" glow={0.6} />
          <Michael x={640} y={GY} f={f} />
          <Devil x={dLeave.x} y={GY} f={f} walk={dLeave.walk} wa={dLeave.wa} face={f < qLost + 6 ? -1 : turn(f, qLost + 6, -1, 10)} />
        </Gp>
        <Gp o={fi(f, qYou)}>
          {room('m16i', 1)}
          <Fig {...DP(700, {beard: 'short', hair: 'cloth', head: -8})} />
          <Devil x={dGone.x} y={GY} f={f} walk={dGone.walk} wa={dGone.wa} face={f < qYou + 2 ? -1 : turn(f, qYou + 2, -1, 8)} o={1 - fi(f, qYou + 40, 30)} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={q0 + 6} b={qQuiet} y={90} size={48}>he has not changed his method</Note>
        <Note f={f} a={qQuiet} b={qAcc} y={90} size={48}>the quiet hours, with a list</Note>
        <Note f={f} a={qAcc} b={qTry - 6} y={90} size={48}>much of it is accurate</Note>
        <Note f={f} a={qTry + 10} b={qMoses - 4} y={90} size={48}>answer with your own record and you lose</Note>
        <Note f={f} a={qMoses + 10} b={qPaul} y={90} size={46}>Moses could not, and neither could a high priest</Note>
        <Ref f={f} a={qPaul} b={qQ} y={80}>ROMANS 8</Ref>
        <Q f={f} a={qQ} b={qSame} refText="ROMANS 8:33–34" eng="“Who will bring any charge against those whom God has *chosen*? *It is God who justifies.* Who then is the one who condemns? *No one.*”" keys={[at('whom God has chosen') + 14, qJust, qNo + 30]} y={30} size={46} />
        <Big f={f} a={qSame + 20} b={qChrist} y={180} size={72} c={TXT.gold}>CHOSEN</Big>
        <Note f={f} a={qChrist + 6} b={qRight} y={100} size={48}>Christ Jesus, who died and was raised</Note>
        <Note f={f} a={qRight} b={qNever} y={100} size={48}>at the right hand of God, interceding for us</Note>
        <Note f={f} a={qNever} b={qAns} y={860} size={46}>you were never asked to win it yourself</Note>
        <Note f={f} a={qAns + 6} b={qSon} y={90} size={46}>point past yourself to the Lord who chose you</Note>
        <Note f={f} a={qSon} b={qLost} y={90} size={46}>his Son died for the very things on that list</Note>
        <Note f={f} a={qLost} b={qYou} y={100} size={48}>he argued over Moses and lost</Note>
        <Big f={f} a={qYou} b={qEnd} y={90} size={52} c={TXT.gold}>HE WILL LOSE THE ARGUMENT OVER YOU</Big>
      </>,
    };
  });
}

// 17 OUTRO --------------------------------------------------------------------------------------
{
  const r0 = at('If this video blessed you'), rLike = at('like it, subscribe'), rLove = at('And always remember'), rSee = at('See you on the next one');
  push(r0, (f) => ({
    svg: <>
      <Spot id="m17" x={960} y={600} r={860} />
      <Ground id="m17g" />
      <Beam x={960} w={320} o={0.85} f={f} />
      {F(f, r0, undefined, JP(960, {arm: ezArm(f, rLove, REST, [-60, -10], 14)}))}
    </>,
    html: <>
      <Note f={f} a={r0 + 4} b={rLike} y={90} size={48}>if this video blessed you</Note>
      <Big f={f} a={rLike} b={rLove} y={80} size={56} c={TXT.gold}>LIKE · SUBSCRIBE · SHARE</Big>
      <Big f={f} a={rLove} b={rSee} y={80} size={66} c={TXT.gold}>JESUS LOVES YOU</Big>
      <Note f={f} a={rSee} y={90} size={50}>see you on the next one</Note>
    </>,
  }));
}
