import React from 'react';
import {at, win, fi, ramp, eio, clamp} from '../lib';
import {Fig, FigP, Line, Throne, Table, Bed, Sun, Moon, Fire, TXT} from '../fig';
import {Ref, Big, Note} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Mountain, River, Bread, Jar, Stones} from '../extra';
import {Scroll, Stars} from '../props';
import {Vine} from '../figprops';
import {JP, DP, BP, SP, F, Gp, pr, ez, ezArm, turn, walkX} from '../kit';
import {Beam, Q, City} from '../covprops';
import {Michael, Bush} from '../mmprops';
import {Palace, LampStand, ClayLamp, Pillar, Cave, StoneAltar, Cell, Chariot, Whirl, Cloak, Letter, Coast, Split} from '../jzprops';

export const JZ1: Scene[] = [];
const push = (start: number, render: Scene['render']) => JZ1.push({start, render});

/* ---------------- cast ---------------- */
export const REST: [number, number] = [-5, -36];
export const ELI = (x: number, o: Partial<FigP> = {}) => DP(x, {hair: 'long', beard: 'long', mantle: true, ...o});
export const JOHN = ELI;
export const JEZ = (x: number, o: Partial<FigP> = {}) => SP(x, {hair: 'veil', beard: 'none', crown: true, sc: 0.3, mantle: false, ...o});
export const HDIAS = JEZ;
export const AHAB = (x: number, o: Partial<FigP> = {}) => SP(x, {crown: true, beard: 'short', ...o});
export const HEROD = (x: number, o: Partial<FigP> = {}) => SP(x, {crown: true, beard: 'short', wide: 1.08, ...o});
export const GIRL = (x: number, o: Partial<FigP> = {}) => BP(x, {hair: 'veil', beard: 'none', sc: 0.25, ...o});
export const PPL = (x: number, o: Partial<FigP> = {}) => BP(x, {sc: 0.27, ...o});
export const Night: React.FC<{o?: number}> = ({o = 1}) => (o > 0.001 ? <><rect width={1920} height={1080} fill="#040302" opacity={0.5 * o} /><Stars o={0.7 * o} seed={13} n={60} y1={480} /></> : null);
/** walking figure */
export const WK = (f: number, a: number, b: number | undefined, t0: number, t1: number, x0: number, x1: number, p: FigP, k?: string | number, stride = 70) => {
  const w = walkX(f, t0, t1, x0, x1, stride);
  return <Fig key={k} {...p} x={w.x} walk={w.walk} wa={w.wa} face={p.face ?? (x1 >= x0 ? 1 : -1)} o={(p.o ?? 1) * win(f, a, b, 16)} />;
};
/** palace set, shared by both eras */
export const Court: React.FC<{f: number; id: string; night?: number; throne?: number; tx?: number}> = ({f, id, night = 0, throne = 1, tx = 1380}) => (
  <>
    <Night o={night} />
    <Spot id={id} x={960} y={560} r={920} a={0.5} />
    <Palace f={f} />
    <Ground id={id + 'g'} />
    {throne > 0 ? <Throne x={tx} y={GY} o={throne} /> : null}
  </>
);
export const Wild: React.FC<{f: number; id: string; night?: number; bush?: number; bx?: number}> = ({f, id, night = 0.3, bush = 0, bx = 1100}) => (
  <>
    <Night o={night} />
    <Spot id={id} x={960} y={640} r={860} a={0.5} />
    <Mountain x={380} y={GY} s={0.75} o={0.3} />
    <Mountain x={1580} y={GY} s={0.6} o={0.22} />
    <Ground id={id + 'g'} />
    <Stones x={1500} y={GY} o={0.8} />
    {bush > 0 ? <Bush x={bx} y={GY} s={1.1} f={f} fire={0} o={bush} /> : null}
  </>
);

// 0 TITLE ---------------------------------------------------------------------------------------
{
  const aE = at('eventually kill Elijah');
  push(0, (f) => ({
    svg: <>
      <Court f={f} id="z0" night={0.4} throne={0} />
      <Fig {...JEZ(1240, {flip: true, arm: ezArm(f, aE, REST, [-80, -20], 16)})} />
      {F(f, aE - 10, undefined, ELI(640, {head: 4}))}
    </>,
    html: <>
      <Note f={f} a={0} y={50} size={50}>did Jezebel eventually</Note>
      <Big f={f} a={aE - 6} y={150} size={92} c={TXT.gold}>KILL ELIJAH?</Big>
    </>,
  }));
}

// 1 THE MESSAGE AFTER CARMEL --------------------------------------------------------------------
{
  const b0 = at('The message arrived the night'), bWatch = at('Elijah had just watched God'), bBrook = at('and the prophets of Baal had been'), bServ = at('Then a servant from the palace'),
    bQueen = at('Queen Jezebel had sworn'), bQ = at('May the gods deal with me'), bEnd = at('Like one of them. Elijah knew');
  push(b0, (f) => ({
    svg: <>
      <Gp o={win(f, b0, bQueen + 4)}>
        <Night o={0.55} />
        <Spot id="z1a" x={900} y={620} r={880} a={0.5} />
        <Mountain x={900} y={GY - 10} s={1.3} o={0.35} />
        <Ground id="z1ag" />
        <River y={GY + 40} f={f} o={0.5 * fi(f, bBrook, 20)} />
        <StoneAltar x={640} y={GY} f={f} fire={0.55} />
        <Fig {...ELI(940, {flip: true, head: ez(f, bWatch, 0, -10, 20), arm: ezArm(f, bWatch, REST, [-40, -60], 16)})} />
        {[0, 1, 2, 3].map((k) => F(f, b0 + 6 + k * 5, bServ, PPL(240 + k * 110, {robe: 'kneel', head: 16, sc: 0.24}), 'k' + k))}
        {WK(f, bServ, undefined, bServ, bServ + 70, 1960, 1260, PPL(0, {face: -1}))}
        <Fig {...ELI(940, {o: 0})} />
      </Gp>
      <Gp o={fi(f, bQueen)}>
        <Court f={f} id="z1b" night={0.6} tx={1240} />
        <Pillar x={300} y={GY} s={1.1} o={0.9} />
        <Fig {...JEZ(1240, {robe: 'seat', bench: true, arm: ezArm(f, bQ, REST, [-80, -10], 16), flip: true})} />
        <Fig {...PPL(820, {head: 14})} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={b0 + 6} b={bWatch} y={80} size={48}>the night after the fire fell on Mount Carmel</Note>
      <Note f={f} a={bServ + 10} b={bQueen} y={80} size={48}>a servant from the palace</Note>
      <Q f={f} a={bQ - 4} b={bEnd} refText="1 KINGS 19:2" eng="“May the gods deal with me, be it ever so severely, if by this time tomorrow I do not make *your life like that of one of them*.”" keys={[at('your life like that of one of them')]} y={40} size={46} />
    </>,
  }));
}

// 2 LIKE ONE OF THEM ----------------------------------------------------------------------------
{
  const c0 = at('Like one of them. Elijah knew'), cSw = at('had died by the sword'), cProm = at('Jezebel was promising him'), cEnd = at('She never got him');
  push(c0, (f) => ({
    svg: <>
      <Night o={0.6} />
      <Spot id="z2" x={900} y={620} r={760} a={0.5} />
      <Ground id="z2g" />
      <Sun x={1560} y={ez(f, cProm, 640, 820, 90)} r={46} o={0.7 * (1 - fi(f, cProm + 60, 30))} />
      <Fig {...ELI(860, {sc: 0.42, y: GY + 60, head: ez(f, c0 + 20, 0, 12, 20), arm: REST})} />
      {WK(f, c0, undefined, c0 + 10, c0 + 90, 1240, 1980, PPL(0, {face: 1}))}
    </>,
    html: <>
      <Big f={f} a={c0 + 4} b={cSw} y={90} size={64} c={TXT.ember}>“LIKE ONE OF THEM”</Big>
      <Note f={f} a={cSw} b={cProm} y={90} size={50}>they had died by the sword</Note>
      <Note f={f} a={cProm + 4} b={cEnd} y={90} size={50}>the same death, within a day</Note>
    </>,
  }));
}

// 3 SHE NEVER GOT HIM ---------------------------------------------------------------------------
{
  const d0 = at('She never got him'), dYears = at('and years later he left'), dJez = at('Jezebel died with her oath'), dEnd = at('Or at least, that is how');
  push(d0, (f) => ({
    svg: <>
      <Gp o={win(f, d0, dYears + 4)}>
        <Wild f={f} id="z3a" night={0.5} />
        {WK(f, d0, undefined, d0 + 4, dYears + 10, 200, 1700, ELI(0), 'e', 90)}
      </Gp>
      <Gp o={win(f, dYears, dJez + 4)}>
        <Spot id="z3b" x={960} y={520} r={900} />
        <Clouds2 />
        <Fig {...ELI(ez(f, dYears, 760, 1180, 90) - 190, {y: ez(f, dYears, 760, 520, 90) - 40, sc: 0.2})} />
        <Chariot x={ez(f, dYears, 760, 1180, 90)} y={ez(f, dYears, 760, 520, 90)} s={1.3} f={f} />
      </Gp>
      <Gp o={fi(f, dJez)}>
        <Court f={f} id="z3c" night={0.7} />
        <Fig {...JEZ(1000, {head: 10, flip: true})} />
        <LampStand x={760} y={GY} f={f} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={d0 + 4} b={dYears} y={90} size={50}>Elijah ran, and God hid him</Note>
      <Note f={f} a={dYears + 8} b={dJez} y={90} size={50}>a chariot of fire</Note>
      <Note f={f} a={dJez + 4} b={dEnd} y={90} size={50}>her oath unkept</Note>
    </>,
  }));
}
const Clouds2: React.FC = () => <Line w={1.4} o={0.4} d="M0,300 C200,260 380,300 520,270 C700,230 900,290 1100,260 C1300,230 1500,280 1700,250 L1920,240 M0,380 C260,350 460,390 700,360 C950,330 1200,380 1450,350 L1920,330" />;

// 4 NINE HUNDRED YEARS LATER --------------------------------------------------------------------
{
  const e0 = at('Or at least, that is how'), eCell = at('in a prison cell'), eMan = at('a man who came in the spirit'), eSw = at('was put to death by the sword'), eQueen = at('And the one who wanted him dead'), eEnd = at('Before we go any further');
  push(e0, (f) => ({
    svg: <>
      <Gp o={win(f, e0, eQueen + 4)}>
        <Spot id="z4a" x={960} y={620} r={860} />
        <Cell light={fi(f, eCell, 30)} />
        <Ground id="z4ag" />
        <Fig {...JOHN(820, {robe: 'kneel', head: -10, arm: [-30, -60]})} />
        <Gp o={fi(f, eSw, 20)}>
          <path d="M1700,860 L1700,420 L1920,420 L1920,860 Z" fill="#000" opacity={0.4} />
          <Fig {...BP(1820, {flip: true, prop: 'spear', sc: 0.3, o: 0.6})} />
        </Gp>
      </Gp>
      <Gp o={fi(f, eQueen)}>
        <Court f={f} id="z4b" night={0.5} throne={0} />
        <Fig {...HDIAS(960, {flip: true, head: 4})} />
        <LampStand x={1300} y={GY} f={f} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={e0 + 6} b={eCell} y={90} size={50}>or at least, that is how it looks</Note>
      <Ref f={f} a={eCell} b={eQueen} y={90} size={34}>NINE HUNDRED YEARS LATER</Ref>
      <Note f={f} a={eMan} b={eQueen} y={150} size={48}>in the spirit and power of Elijah</Note>
      <Note f={f} a={eQueen + 6} b={eEnd} y={90} size={50}>and the one who wanted him dead was a queen</Note>
    </>,
  }));
}

// 5 WALK WITH ME --------------------------------------------------------------------------------
{
  const g0 = at('Before we go any further'), gObs = at('What I am about to share'), gNever = at('Scripture never calls this second'), gMore = at('But the more I read'), gWalk = at('So walk with me'), gEnd = at('Let us start with the first queen');
  push(g0, (f) => {
    const L = <><Spot id="z5l" x={960} y={560} r={760} /><Palace f={f} /><Ground id="z5lg" /><Fig {...AHAB(820)} /><Fig {...JEZ(1100, {flip: true})} /></>;
    const R = <><Spot id="z5r" x={960} y={560} r={760} /><Palace f={f} /><Ground id="z5rg" /><Fig {...HEROD(820)} /><Fig {...HDIAS(1100, {flip: true})} /></>;
    const w = walkX(f, gWalk, gEnd + 40, 300, 1200, 70);
    return {
      svg: <>
        <Gp o={win(f, g0, gNever + 4)}>
          <Spot id="z5a" x={960} y={620} r={860} />
          <Ground id="z5ag" />
          <ClayLamp x={1220} y={GY - 140} f={f} s={1.4} />
          <Table x={1150} y={GY} w={420} />
          <Scroll x={1100} y={GY - 160} s={0.3} />
          <Fig {...BP(820, {robe: 'seat', bench: true, head: 14, arm: [-40, -50]})} />
        </Gp>
        <Gp o={win(f, gNever, gWalk + 4)}>
          <Split left={L} right={R} labL="FIRST QUEEN" labR="SECOND QUEEN" labO={fi(f, gNever + 20)} />
        </Gp>
        <Gp o={fi(f, gWalk)}>
          <Spot id="z5c" x={w.x} y={620} r={820} />
          <Mountain x={1500} y={GY} s={0.7} o={0.25} />
          <Ground id="z5cg" />
          <Fig {...BP(0)} x={w.x} walk={w.walk} wa={w.wa} face={1} />
          <Fig {...BP(0, {sc: 0.28, hair: 'veil', beard: 'none'})} x={w.x - 180} walk={w.walk + 0.4} wa={w.wa} face={1} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={g0 + 6} b={gObs} y={90} size={50}>let me be honest with you</Note>
        <Note f={f} a={gObs} b={gNever} y={90} size={48}>my own observation from studying the Bible</Note>
        <Note f={f} a={gNever + 6} b={gMore} y={60} size={46}>Scripture never calls her Jezebel</Note>
        <Note f={f} a={gMore} b={gWalk} y={60} size={46}>but the pattern is there</Note>
        <Big f={f} a={gWalk + 4} b={gEnd} y={110} size={64} c={TXT.gold}>WALK WITH ME</Big>
      </>,
    };
  });
}

// 6 THE FIRST QUEEN -----------------------------------------------------------------------------
{
  const h0 = at('Let us start with the first queen'), hMar = at('and she married Ahab'), hBaal = at('She brought the worship of Baal'), hObad = at('The Bible says that while Jezebel'), hHid = at('a man named Obadiah hid'), hEnd = at('Ahab was weak, and Jezebel');
  push(h0, (f) => ({
    svg: <>
      <Gp o={win(f, h0, hMar + 4)}>
        <Spot id="z6a" x={1100} y={620} r={880} />
        <Coast f={f} />
        <Ground id="z6ag" />
        <City x={600} y={GY} s={1.1} />
        {WK(f, h0, undefined, h0 + 10, hMar + 10, 980, 1260, JEZ(0, {face: 1}))}
      </Gp>
      <Gp o={win(f, hMar, hBaal + 4)}>
        <Court f={f} id="z6b" throne={0} />
        <Fig {...AHAB(820, {arm: ezArm(f, hMar + 20, REST, [-30, -10], 16)})} />
        {WK(f, hMar, undefined, hMar, hMar + 60, 1500, 1080, JEZ(0, {face: -1}))}
        {[0, 1, 2].map((k) => F(f, hMar + 10 + k * 6, undefined, PPL(260 + k * 130, {sc: 0.24}), 'g' + k))}
      </Gp>
      <Gp o={win(f, hBaal, hObad + 4)}>
        <Court f={f} id="z6c" throne={0} night={0.3} />
        <Pillar x={960} y={GY} s={1.3} p={pr(f, hBaal, 30)} />
        <Fig {...JEZ(1260, {flip: true, arm: [-60, -20]})} />
        {[0, 1, 2, 3].map((k) => F(f, hBaal + 20 + k * 6, undefined, PPL(330 + k * 120, {robe: 'kneel', head: 18, sc: 0.25}), 'b' + k))}
      </Gp>
      <Gp o={fi(f, hObad)}>
        <Night o={0.4} />
        <Spot id="z6d" x={960} y={640} r={860} />
        <Cave x={760} y={GY} s={1} glow={0.8} />
        <Ground id="z6dg" />
        {[0, 1, 2, 3, 4].map((k) => F(f, hObad + 10 + k * 5, undefined, BP(600 + k * 80, {sc: 0.2, robe: k % 2 ? 'seat' : 'stand', bench: k % 2 === 1, o: 0.8}), 'p' + k))}
        {WK(f, hHid, undefined, hHid, hHid + 80, 1900, 1240, BP(0, {face: -1, arm: [-50, -30]}))}
        <g opacity={fi(f, hHid + 60)}><Bread x={1150} y={GY - 6} s={0.7} /><Jar x={1210} y={GY} s={0.6} /></g>
      </Gp>
    </>,
    html: <>
      <Note f={f} a={h0 + 6} b={hMar} y={90} size={48}>daughter of the king of the Sidonians</Note>
      <Note f={f} a={hMar + 6} b={hBaal} y={90} size={48}>she married Ahab, king of Israel</Note>
      <Note f={f} a={hBaal + 6} b={hObad} y={90} size={48}>she brought the worship of Baal</Note>
      <Note f={f} a={hObad + 6} b={hHid} y={90} size={48}>killing off the Lord’s prophets</Note>
      <Note f={f} a={hHid + 6} b={hEnd} y={90} size={48}>Obadiah hid a hundred of them in caves</Note>
    </>,
  }));
}

// 7 NABOTH'S VINEYARD ---------------------------------------------------------------------------
{
  const i0 = at('Ahab was weak, and Jezebel'), iSulk = at('When Ahab sulked'), iWrote = at('Jezebel wrote letters'), iFalse = at('and arranged for false witnesses'), iGot = at('Ahab got his vineyard'), iSum = at('The Bible gives him one'), iEnd = at('Into that palace walked Elijah');
  push(i0, (f) => ({
    svg: <>
      <Gp o={win(f, i0, iWrote + 4)}>
        <Spot id="z7a" x={960} y={620} r={880} />
        <Ground id="z7ag" />
        <Vine x={1300} y={GY} s={0.9} fr={1} />
        <Vine x={1640} y={GY} s={0.75} fr={1} o={0.8} />
        <Fig {...BP(1460, {beard: 'long', flip: true, head: 4})} />
        <Bed x={260} y={GY} w={460} />
        <Fig {...AHAB(560, {robe: 'seat', bench: true, head: 20, bend: 10})} />
      </Gp>
      <Gp o={win(f, iWrote, iFalse + 4)}>
        <Court f={f} id="z7b" night={0.5} throne={0} />
        <Table x={1000} y={GY} w={480} />
        <ClayLamp x={1120} y={GY - 132} f={f} />
        <Fig {...JEZ(800, {robe: 'seat', bench: true, head: 14, arm: [-50, -40]})} />
        <Letter x={980} y={GY - 150} s={0.9} seal={fi(f, iWrote + 50, 10)} />
      </Gp>
      <Gp o={win(f, iFalse, iGot + 4)}>
        <Spot id="z7c" x={960} y={620} r={880} />
        <City x={1500} y={GY} s={0.9} o={0.6} />
        <Ground id="z7cg" />
        <Fig {...BP(1000, {beard: 'long', head: 8})} />
        <Fig {...PPL(620, {arm: ezArm(f, iFalse + 20, REST, [-90, -10], 12)})} />
        <Fig {...PPL(440, {arm: ezArm(f, iFalse + 30, REST, [-90, -10], 12)})} />
        {[0, 1, 2].map((k) => F(f, iFalse + 10 + k * 6, undefined, SP(1260 + k * 150, {flip: true, sc: 0.28, beard: 'long', mantle: false}), 'el' + k))}
      </Gp>
      <Gp o={fi(f, iGot)}>
        <Spot id="z7d" x={960} y={620} r={880} />
        <Ground id="z7dg" />
        <Vine x={700} y={GY} s={0.9} fr={1} />
        <Vine x={1300} y={GY} s={0.8} fr={1} />
        {WK(f, iGot, undefined, iGot, iSum + 30, 1800, 1000, AHAB(0, {face: -1}))}
      </Gp>
    </>,
    html: <>
      <Note f={f} a={i0 + 6} b={iSulk} y={90} size={50}>Ahab was weak</Note>
      <Note f={f} a={iSulk + 6} b={iWrote} y={90} size={48}>Naboth would not sell his vineyard</Note>
      <Note f={f} a={iWrote + 6} b={iFalse} y={90} size={48}>letters in Ahab’s name, sealed with his seal</Note>
      <Note f={f} a={iFalse + 6} b={iGot} y={90} size={48}>false witnesses</Note>
      <Q f={f} a={iSum + 20} b={iEnd} refText="1 KINGS 21:25" eng="“There was never anyone like Ahab, who sold himself to do evil in the eyes of the Lord, *urged on by Jezebel his wife*.”" keys={[at('urged on by Jezebel his wife')]} y={50} />
    </>,
  }));
}

// 8 TROUBLER OF ISRAEL, CARMEL ------------------------------------------------------------------
{
  const j0 = at('Into that palace walked Elijah'), jQ = at('Is that you, you troubler'), jTold = at('Elijah told him the trouble'), jCar = at('Then came Mount Carmel'), jFire = at('and God answered with fire'), jEnd = at('That should have been the end');
  push(j0, (f) => ({
    svg: <>
      <Gp o={win(f, j0, jCar + 4)}>
        <Court f={f} id="z8a" tx={1380} />
        <Fig {...AHAB(1390, {robe: 'seat', bench: true, flip: true, arm: ezArm(f, jQ, REST, [-80, -10], 14)})} />
        {WK(f, j0, undefined, j0, j0 + 80, 100, 760, ELI(0, {face: 1}))}
        <Fig {...ELI(760, {o: 0})} />
        <Gp o={fi(f, jTold)}><Fig {...ELI(760, {arm: [-70, -10]})} /></Gp>
      </Gp>
      <Gp o={fi(f, jCar)}>
        <Spot id="z8b" x={960} y={600} r={900} />
        <Mountain x={960} y={GY - 10} s={1.4} o={0.3} />
        <Ground id="z8bg" />
        <Beam x={760} w={300} o={fi(f, jFire, 10)} f={f} bottom={GY - 140} />
        <StoneAltar x={760} y={GY} f={f} fire={fi(f, jFire + 6, 10)} />
        <Fig {...ELI(1040, {flip: true, head: -14, arm: [-30, -70]})} />
        {[0, 1, 2, 3, 4].map((k) => F(f, jCar + 10 + k * 4, undefined, PPL(1300 + k * 110, {flip: true, sc: 0.24, robe: f > jFire + 20 ? 'kneel' : 'stand', head: f > jFire + 20 ? 18 : 0}), 'c' + k))}
        {[0, 1, 2].map((k) => F(f, jCar + 10 + k * 4, undefined, BP(160 + k * 120, {sc: 0.24, o: 0.7, dim: 0.4}), 'bp' + k))}
      </Gp>
    </>,
    html: <>
      <Q f={f} a={jQ - 4} b={jTold} refText="1 KINGS 18:17" eng="“Is that you, *you troubler of Israel*?”" keys={[at('you troubler of Israel')]} y={60} />
      <Note f={f} a={jTold + 4} b={jCar} y={90} size={48}>the trouble came from Ahab’s own house</Note>
      <Ref f={f} a={jCar} b={jEnd} y={90} size={34}>MOUNT CARMEL</Ref>
    </>,
  }));
}

// 9 THE NIGHT OF THE OATH -----------------------------------------------------------------------
{
  const k0 = at('That should have been the end'), kNight = at('Instead, it was the night'), kEnd = at('What happened next');
  push(k0, (f) => ({
    svg: <>
      <Court f={f} id="z9" night={0.7} throne={0} />
      <LampStand x={1340} y={GY} f={f} />
      <Fig {...JEZ(1080, {flip: true, arm: ezArm(f, kNight, REST, [-80, -20], 16)})} />
      {WK(f, kNight, undefined, kNight + 20, kEnd + 20, 900, 100, PPL(0, {face: -1}))}
    </>,
    html: <>
      <Note f={f} a={k0 + 6} b={kNight} y={90} size={50}>the end of Jezebel’s power?</Note>
      <Big f={f} a={kNight + 4} b={kEnd} y={110} size={64} c={TXT.ember}>THE NIGHT OF THE OATH</Big>
    </>,
  }));
}

// 10 HE RAN FOR HIS LIFE ------------------------------------------------------------------------
{
  const l0 = at('What happened next'), lAfr = at('Elijah was afraid and ran'), lSouth = at('He traveled south'), lLeft = at('left his servant behind'), lBush = at('There he sat down under a broom'), lQ = at('I have had enough, Lord'), lEnd = at('Jezebel never laid a hand');
  push(l0, (f) => ({
    svg: <>
      <Gp o={win(f, l0, lLeft + 4)}>
        <Wild f={f} id="z10a" night={0.55} />
        {WK(f, l0, undefined, lAfr - 10, lLeft + 10, 1800, 200, ELI(0, {face: -1}), 'r', 95)}
        {WK(f, l0, undefined, lAfr - 10, lLeft + 10, 1980, 380, PPL(0, {face: -1}), 's', 95)}
      </Gp>
      <Gp o={win(f, lLeft, lBush + 4)}>
        <Wild f={f} id="z10b" night={0.35} />
        <Fig {...PPL(400, {head: 6})} />
        {WK(f, lLeft, undefined, lLeft + 10, lBush + 10, 560, 1500, ELI(0, {face: 1}))}
      </Gp>
      <Gp o={fi(f, lBush)}>
        <Wild f={f} id="z10c" night={0.3} bush={1} bx={1100} />
        <Fig {...ELI(940, {robe: 'seat', bench: false, head: ez(f, lQ, 10, 24, 30), bend: 12})} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={l0 + 6} b={lAfr} y={90} size={48}>one of the most human moments in Scripture</Note>
      <Q f={f} a={lAfr - 4} b={lSouth} refText="1 KINGS 19:3" eng="“Elijah was afraid and *ran for his life*.”" keys={[at('ran for his life')]} y={60} />
      <Note f={f} a={lSouth + 4} b={lBush} y={90} size={48}>south, then a day alone into the wilderness</Note>
      <Q f={f} a={lQ - 4} b={lEnd} refText="1 KINGS 19:4" eng="“I have had enough, Lord,” he said. “*Take my life*; I am no better than my ancestors.”" keys={[at('Take my life')]} y={50} />
    </>,
  }));
}

// 11 ONE VOICE ----------------------------------------------------------------------------------
{
  const m0 = at('Jezebel never laid a hand'), mSome = at('Sometimes one voice'), mEnd = at('Look at what God did next');
  push(m0, (f) => ({
    svg: <>
      <Wild f={f} id="z11" night={0.45} bush={1} bx={1100} />
      <Fig {...ELI(1000, {robe: 'seat', head: 26, bend: 14, sc: 0.36, y: GY + 30})} />
      <Gp o={0.35 * fi(f, mSome, 30)}><Fig {...JEZ(400, {flip: false, o: 0.5, dim: 0.5})} /></Gp>
    </>,
    html: <>
      <Note f={f} a={m0 + 6} b={mSome} y={90} size={48}>she never laid a hand on him</Note>
      <Big f={f} a={mSome + 4} b={mEnd} y={110} size={56} c={TXT.gold}>SOMETIMES ONE VOICE IS ENOUGH</Big>
    </>,
  }));
}

// 12 GET UP AND EAT -----------------------------------------------------------------------------
{
  const n0 = at('Look at what God did next'), nLay = at('Elijah lay down and fell asleep'), nGet = at('Get up and eat', 1), nBread = at('There was bread baked'), nAte = at('Elijah ate and slept again'), nQ2 = at('Get up and eat, for the journey'), nEnd = at('Then God led him to Mount Horeb');
  push(n0, (f) => {
    const sit = f > nGet + 10 && f < nAte + 20 || f > nQ2 + 10;
    return {
      svg: <>
        <Wild f={f} id="z12" night={0.3} bush={1} bx={1250} />
        <Beam x={1100} w={300} o={0.6 * fi(f, nGet - 10, 30)} f={f} />
        {sit ? <Fig {...ELI(820, {robe: 'seat', head: 6, arm: [-40, -50]})} /> : <g transform={`translate(1000 ${GY}) rotate(-90) translate(-1000 ${-GY})`}><Fig {...ELI(1000, {y: GY + 40, head: 0, sc: 0.28})} /></g>}
        <Michael x={1560} y={GY} sc={0.3} f={f} spread={0.7} flip o={fi(f, nGet - 20, 24) * (1 - 0.6 * clamp((f - nAte) / 20) * (f < nQ2 - 20 ? 1 : 0))} arm={ezArm(f, nGet - 10, REST, [-70, -30], 14)} />
        <g opacity={fi(f, nBread)}><Bread x={560} y={GY - 4} s={0.7} /><Jar x={480} y={GY} s={0.6} /><Fire x={640} y={GY} s={0.3} f={f} o={0.6} /></g>
      </>,
      html: <>
        <Note f={f} a={n0 + 6} b={nLay} y={90} size={50}>he did not lecture him</Note>
        <Q f={f} a={nGet - 6} b={nBread} refText="1 KINGS 19:5" eng="“All at once an angel touched him and said, ‘*Get up and eat*.’”" keys={[nGet]} y={60} />
        <Note f={f} a={nBread + 4} b={nQ2} y={90} size={48}>bread baked over hot coals, and a jar of water</Note>
        <Q f={f} a={nQ2 - 4} b={nEnd} refText="1 KINGS 19:7" eng="“Get up and eat, for *the journey is too much for you*.”" keys={[at('the journey is too much for you')]} y={60} />
      </>,
    };
  });
}

// 13 HOREB ----------------------------------------------------------------------------------------
{
  const o0 = at('Then God led him to Mount Horeb'), oWind = at('A great wind tore'), oQuake = at('After the wind came an earthquake'), oFire = at('and after the earthquake came a fire'), oWhis = at('And after the fire came a gentle'), oMet = at('God met his worn out prophet'), oEnd = at('Elijah’s story never ends');
  push(o0, (f) => {
    const shake = f > oQuake && f < oFire ? Math.sin(f * 1.7) * 6 * (1 - clamp((f - oQuake) / (oFire - oQuake))) : 0;
    const wind = f > oWind && f < oWhis ? 1 : 0;
    return {
      svg: <>
        <g transform={`translate(${shake} 0)`}>
          <Night o={0.4} />
          <Spot id="z13" x={960} y={620} r={880} a={0.5} />
          <Mountain x={1300} y={GY} s={1.5} o={0.35} />
          <Cave x={720} y={GY} s={1} glow={0.4 + 0.5 * fi(f, oWhis, 30)} />
          <Ground id="z13g" />
          <Gp o={wind * fi(f, oWind, 10)}><Line w={1.6} c="#E9BE6E" o={0.5} d={Array.from({length: 7}, (_, k) => { const x = ((f * 26 + k * 300) % 2300) - 200, y = 260 + k * 70; return `M${x},${y} C${x + 120},${y - 20} ${x + 240},${y + 20} ${x + 380},${y}`; }).join(' ')} u /></Gp>
          <Gp o={win(f, oFire, oWhis + 4)}><Fire x={1300} y={GY} s={1.4} f={f} /><Fire x={1500} y={GY} s={1} f={f + 20} /></Gp>
          <Beam x={720} w={260} o={0.7 * fi(f, oWhis, 40)} f={f} bottom={GY - 40} />
          <Fig {...ELI(720, {y: GY - 4, head: f > oWhis ? 18 : 6, arm: f > oWhis ? ezArm(f, oWhis + 10, REST, [-120, -150], 20) : REST, sc: 0.28})} />
        </g>
      </>,
      html: <>
        <Ref f={f} a={o0 + 4} b={oWind} y={90} size={34}>MOUNT HOREB</Ref>
        <Note f={f} a={oWind + 4} b={oQuake} y={90} size={48}>the Lord was not in the wind</Note>
        <Note f={f} a={oQuake + 4} b={oFire} y={90} size={48}>not in the earthquake</Note>
        <Note f={f} a={oFire + 4} b={oWhis} y={90} size={48}>not in the fire</Note>
        <Q f={f} a={oWhis - 4} b={oEnd} refText="1 KINGS 19:12" eng="“And after the fire came *a gentle whisper*.”" keys={[at('a gentle whisper')]} y={60} />
      </>,
    };
  });
}

// 14 THE WHIRLWIND ------------------------------------------------------------------------------
{
  const q0 = at('Elijah’s story never ends'), qHair = at('a garment of hair'), qOne = at('And one day, as he walked'), qChar = at('a chariot of fire and horses'), qUp = at('and Elijah went up to heaven'), qEnd = at('Jezebel’s oath had failed');
  push(q0, (f) => {
    const w = walkX(f, q0, qChar, 300, 820, 70);
    const sep = eio(ramp(f, qChar, 30));
    const rise = eio(ramp(f, qUp - 10, 70));
    return {
      svg: <>
        <Spot id="z14" x={960} y={560} r={920} />
        <Mountain x={1500} y={GY} s={0.8} o={0.25} />
        <River y={GY - 10} x0={1300} x1={1920} f={f} o={0.4} />
        <Ground id="z14g" />
        <Whirl x={820} y={GY} f={f} o={fi(f, qUp - 20, 30)} />
        <Chariot x={1080} y={GY - 120 - 200 * rise} s={1.4} f={f} o={fi(f, qChar - 6, 14)} />
        <Fig {...ELI(0)} x={f < qChar ? w.x : 820 - 60 * sep} y={GY - 520 * rise} walk={f < qChar ? w.walk : 0} wa={f < qChar ? w.wa : 0} face={1} sc={0.31 - 0.08 * rise} />
        <Fig {...DP(0, {beard: 'short'})} x={f < qChar ? w.x - 190 : 630 - 200 * sep} walk={f < qChar ? w.walk + 0.5 : 0} wa={f < qChar ? w.wa : 0} face={1} head={-16 * sep} arm={ezArm(f, qUp, REST, [-120, -160], 20)} />
        <Cloak x={820 - 40 * rise} y={GY - 520 * rise + 300 * clamp((f - qUp - 40) / 60) + 160} rot={30 * rise} s={0.55} o={fi(f, qUp + 30, 20)} />
      </>,
      html: <>
        <Q f={f} a={qHair - 10} b={qOne} refText="2 KINGS 1:8" eng="“He had *a garment of hair* and had *a leather belt around his waist*.”" keys={[qHair, at('a leather belt around his waist', 1)]} y={60} />
        <Q f={f} a={qChar - 6} b={qEnd} refText="2 KINGS 2:11" eng="“…a chariot of fire and horses of fire appeared and separated the two of them, and *Elijah went up to heaven in a whirlwind*.”" keys={[qUp]} y={40} size={46} />
      </>,
    };
  });
}

// 15 HER OATH FAILED ----------------------------------------------------------------------------
{
  const r0 = at('Jezebel’s oath had failed'), rEnd2 = at('Her own end came later'), rGone = at('and Elijah was gone'), rOver = at('It looked like the story was over'), rEnd = at('Then, at the very end of the Old');
  push(r0, (f) => ({
    svg: <>
      <Gp o={fi(f, rGone - 16, 16)}>
        <Spot id="z15b" x={960} y={480} r={900} />
        <Ground id="z15bg" />
        <Whirl x={960} y={GY} f={f} o={0.5} h={900} />
        <Fig {...DP(820, {beard: 'short', head: -14})} />
        <Cloak x={980} y={GY - 40} rot={4} s={0.6} />
      </Gp>
      <Gp o={win(f, r0, rGone + 4)}>
        <Court f={f} id="z15a" night={0.6} throne={0} />
        <Fig {...JEZ(960, {flip: true, head: ez(f, rEnd2, 10, 22, 30)})} o={1 - 0.6 * fi(f, rEnd2 + 30, 40)} />
        <LampStand x={1300} y={GY} f={f} o={1 - 0.6 * fi(f, rEnd2 + 30, 40)} />
      </Gp>
    </>,
    html: <>
      <Big f={f} a={r0 + 4} b={rEnd2} y={110} size={60} c={TXT.ember}>HER OATH HAD FAILED</Big>
      <Note f={f} a={rEnd2 + 4} b={rGone} y={90} size={46}>her end came, as the Lord had said</Note>
      <Note f={f} a={rGone + 4} b={rOver} y={90} size={48}>gone where no sword could follow</Note>
      <Note f={f} a={rOver} b={rEnd} y={90} size={48}>the story looked over</Note>
    </>,
  }));
}

// 16 MALACHI ------------------------------------------------------------------------------------
{
  const s0 = at('Then, at the very end of the Old'), sQ = at('See, I will send the prophet'), sBack = at('Elijah was coming back'), sEnd = at('For four hundred years after');
  push(s0, (f) => ({
    svg: <>
      <Gp o={win(f, s0, sBack + 4)}>
        <Night o={0.5} />
        <Spot id="z16" x={960} y={620} r={820} />
        <Ground id="z16g" />
        <Table x={1100} y={GY} w={460} />
        <ClayLamp x={1240} y={GY - 132} f={f} s={1.2} />
        <Scroll x={1080} y={GY - 150} s={0.3} p={pr(f, sQ, 60)} />
        <Fig {...BP(820, {beard: 'long', robe: 'seat', bench: true, head: 14, arm: [-50, -40]})} />
      </Gp>
      <Gp o={fi(f, sBack)}>
        <Spot id="z16b" x={960} y={480} r={900} />
        <Ground id="z16bg" />
        <Whirl x={960} y={GY} f={f} o={0.5} h={900} />
        <Cloak x={960} y={GY - 40} rot={4} s={0.6} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={s0 + 6} b={sQ - 6} y={90} size={48}>the very end of the Old Testament</Note>
      <Q f={f} a={sQ - 6} b={sBack} refText="MALACHI 4:5" eng="“See, *I will send the prophet Elijah to you* before that great and dreadful day of the Lord comes.”" keys={[at('I will send the prophet Elijah')]} y={50} />
      <Big f={f} a={sBack} b={sEnd} y={110} size={72} c={TXT.gold}>ELIJAH WAS COMING BACK</Big>
    </>,
  }));
}
