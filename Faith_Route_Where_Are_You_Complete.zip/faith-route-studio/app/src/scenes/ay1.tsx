import React from 'react';
import {at, win, fi, ramp, eio} from '../lib';
import {Fig, FigP, Line, Table, Fire, Sheep, TXT} from '../fig';
import {Ref, Big, Note, Name, Verse} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Mountain, Jar, Stones, Door} from '../extra';
import {Scroll, Stars, Olive} from '../props';
import {FigTree, Soil} from '../figprops';
import {Smoke} from '../famprops';
import {DP, BP, SP, Gp, pr, ez, ezArm, turn, walkX} from '../kit';
import {Beam, Q, City, Card} from '../covprops';
import {Michael} from '../mmprops';
import {Serpent} from '../psprops';
import {ClayLamp, Cave, Split} from '../jzprops';
import {QuestionTrack, Tent, Spring, ArcLink, BloodPulse, HalfAnswer, VowelMorph} from '../ayprops';

export const AY1: Scene[] = [];
const push = (start: number, render: Scene['render']) => AY1.push({start, render});

/* ---------------- cast & reusable sets ---------------- */
export const REST: [number, number] = [-5, -36];
export const ADAM = (x: number, o: Partial<FigP> = {}) => DP(x, {hair: 'long', beard: 'short', mantle: false, sc: 0.31, ...o});
export const EVE = (x: number, o: Partial<FigP> = {}) => DP(x, {hair: 'long', beard: 'none', mantle: false, sc: 0.285, ...o});
export const CAIN = (x: number, o: Partial<FigP> = {}) => BP(x, {hair: 'cap', beard: 'short', sc: 0.31, ...o});
export const ABEL = (x: number, o: Partial<FigP> = {}) => DP(x, {hair: 'cloth', beard: 'short', prop: 'crook', sc: 0.3, ...o});
export const ABRAHAM = (x: number, o: Partial<FigP> = {}) => DP(x, {hair: 'cloth', beard: 'long', mantle: true, sc: 0.32, ...o});
export const SARAH = (x: number, o: Partial<FigP> = {}) => SP(x, {hair: 'veil', beard: 'none', mantle: false, sc: 0.295, ...o});
export const HAGAR = (x: number, o: Partial<FigP> = {}) => BP(x, {hair: 'veil', beard: 'none', sc: 0.275, ...o});
export const ELI = (x: number, o: Partial<FigP> = {}) => DP(x, {hair: 'long', beard: 'long', mantle: true, sc: 0.32, ...o});
export const JEZ = (x: number, o: Partial<FigP> = {}) => SP(x, {hair: 'veil', beard: 'none', crown: true, sc: 0.3, mantle: false, ...o});
export const PPL = (x: number, o: Partial<FigP> = {}) => BP(x, {sc: 0.27, ...o});
export const ELDER = (x: number, o: Partial<FigP> = {}) => SP(x, {hair: 'cloth', beard: 'long', sc: 0.29, mantle: true, ...o});

export const Night: React.FC<{o?: number}> = ({o = 1}) =>
  o > 0.001 ? (
    <>
      <rect width={1920} height={1080} fill="#040302" opacity={0.5 * o} />
      <Stars o={0.68 * o} seed={17} n={58} y1={480} />
    </>
  ) : null;

export const WK = (
  f: number,
  a: number,
  b: number | undefined,
  t0: number,
  t1: number,
  x0: number,
  x1: number,
  p: FigP,
  k?: string | number,
  stride = 70,
) => {
  const w = walkX(f, t0, t1, x0, x1, stride);
  return <Fig key={k} {...p} x={w.x} walk={w.walk} wa={w.wa} face={p.face ?? (x1 >= x0 ? 1 : -1)} o={(p.o ?? 1) * win(f, a, b, 16)} />;
};

export const GardenSet: React.FC<{id: string; night?: number; cx?: number}> = ({id, night = 0.2, cx = 960}) => (
  <>
    <Night o={night} />
    <Spot id={id} x={cx} y={560} r={920} a={0.55} />
    <Olive x={310} y={GY} s={1.05} o={0.45} />
    <FigTree x={1560} y={GY} s={1.1} leaf={1} fruit={1} o={0.65} seed={9} />
    <FigTree x={1320} y={GY} s={0.95} leaf={1} fruit={0} o={0.55} seed={4} />
    <Ground id={id + 'g'} cx={cx} />
  </>
);

export const FieldSet: React.FC<{id: string; night?: number; cx?: number}> = ({id, night = 0.25, cx = 960}) => (
  <>
    <Night o={night} />
    <Spot id={id} x={cx} y={620} r={880} a={0.5} />
    <Mountain x={360} y={GY} s={0.85} o={0.28} />
    <Mountain x={1580} y={GY} s={0.65} o={0.22} />
    <Soil x={960} y={GY} o={0.75} />
    <Ground id={id + 'g'} cx={cx} />
  </>
);

export const DesertSet: React.FC<{id: string; night?: number; cx?: number}> = ({id, night = 0.25, cx = 960}) => (
  <>
    <Night o={night} />
    <Spot id={id} x={cx} y={600} r={900} a={0.54} />
    <Mountain x={340} y={GY} s={0.8} o={0.32} />
    <Mountain x={1540} y={GY} s={0.7} o={0.26} />
    <Ground id={id + 'g'} cx={cx} />
    <Stones x={1480} y={GY} o={0.75} />
    <Stones x={320} y={GY} o={0.6} />
  </>
);

// SCENE 0: COLD OPEN
{
  const a0 = 0;
  const aPull = at('In the third chapter of Genesis');
  const aWhere = at('Where are you', 1);
  const aKnows = at('God knows where Adam is');
  const aFour = at('In a garden in an open field');
  const aField = at('in an open field');
  const aSpring = at('beside a desert spring');
  const aCave = at('at the mouth of a cave', 1);
  const aRead = at('And when you read those four scenes');
  const aEnd = at('Start in the garden');

  push(a0, (f) => ({
    svg: (
      <>
        <Gp o={win(f, a0, aFour + 4)}>
          <GardenSet id="ay0a" night={0.22} cx={780} />
          <Beam x={560} w={300} o={0.78 * fi(f, a0 + 6, 26)} f={f} />
          <Gp o={win(f, a0, aWhere + 6)}>
            {WK(f, a0, aWhere + 6, aPull, aWhere, 920, 1260, ADAM(0, {face: -1, head: 10}), 'ad0')}
            {WK(f, a0, aWhere + 6, aPull + 6, aWhere, 1020, 1360, EVE(0, {face: -1, head: 12}), 'ev0')}
          </Gp>
          <Gp o={fi(f, aWhere, 16)}>
            <Fig {...ADAM(1270, {flip: true, robe: 'stoop', head: 16, bend: 14, arm: [-30, -45]})} />
            <Fig {...EVE(1390, {flip: true, robe: 'stoop', head: 18, bend: 14, arm: [-25, -45]})} />
            <FigTree x={1180} y={GY} s={1.08} leaf={1} fruit={0} o={0.85} seed={12} />
            <Beam x={1270} w={340} o={0.55 * fi(f, aKnows, 24)} f={f} />
          </Gp>
        </Gp>

        <Gp o={fi(f, aFour)}>
          <Spot id="ay0b" x={960} y={560} r={960} a={0.55} />
          <Ground id="ay0bg" />
          <Gp o={fi(f, aFour, 14)}>
            <FigTree x={260} y={GY} s={0.72} leaf={1} o={0.65} seed={3} />
            <Fig {...ADAM(310, {sc: 0.25, robe: 'stoop', head: 14})} />
            <Beam x={310} w={170} o={0.45 * fi(f, aRead, 20)} f={f} />
          </Gp>
          <Gp o={fi(f, aField, 14)}>
            <Soil x={740} y={GY} o={0.7} />
            <Fig {...CAIN(740, {sc: 0.25, flip: true, head: 10})} />
            <Beam x={740} w={170} o={0.45 * fi(f, aRead, 20)} f={f} />
          </Gp>
          <Gp o={fi(f, aSpring, 14)}>
            <Spring x={1180} y={GY} f={f} s={0.65} />
            <Fig {...HAGAR(1130, {sc: 0.23, robe: 'seat', head: 12})} />
            <Beam x={1160} w={170} o={0.45 * fi(f, aRead, 20)} f={f} />
          </Gp>
          <Gp o={fi(f, aCave, 14)}>
            <Cave x={1610} y={GY} s={0.48} glow={0.3} />
            <Fig {...ELI(1610, {sc: 0.25, flip: true, head: 14})} />
            <Beam x={1610} w={170} o={0.45 * fi(f, aRead, 20)} f={f} />
          </Gp>
          <QuestionTrack active={4} o={fi(f, aRead, 18)} />
        </Gp>
      </>
    ),
    html: (
      <>
        <Note f={f} a={a0 + 6} b={aPull} y={80} size={50}>the first words God speaks after something goes wrong</Note>
        <Big f={f} a={a0 + 42} b={aPull} y={200} size={74} c={TXT.gold}>A QUESTION</Big>
        <Note f={f} a={aPull} b={aWhere} y={85} size={46}>Adam and Eve pull back into the trees</Note>
        <Big f={f} a={aWhere} b={aKnows} y={175} size={86} c={TXT.gold}>“WHERE ARE YOU?”</Big>
        <Note f={f} a={aKnows} b={aFour} y={85} size={48}>He made the trees Adam is standing behind</Note>
        <Ref f={f} a={aFour} b={aRead} y={76} size={30}>FOUR HIDING PLACES · ONE QUESTION</Ref>
        <Note f={f} a={aRead} b={aEnd} y={80} size={48}>why He asks instead of telling</Note>
      </>
    ),
  }));
}

// SCENE 1: START IN THE GARDEN — FIG LEAVES & AYEKAH
{
  const a0 = at('Start in the garden');
  const aSew = at('They sew fig leaves');
  const aEng = at('In English it takes three words');
  const aHeb = at('In Hebrew it is a single word');
  const aEnd = at('Ancient Hebrew scrolls');

  push(a0, (f) => ({
    svg: (
      <>
        <GardenSet id="ay1" night={0.22} cx={960} />
        <QuestionTrack active={1} />
        <Gp o={win(f, a0, aSew + 6)}>
          <FigTree x={960} y={GY} s={1.15} leaf={1} fruit={1} seed={5} />
          <Fig {...ADAM(780, {arm: ezArm(f, a0 + 18, [-60, -70], [-25, -45], 24), head: ez(f, a0 + 30, -8, 16, 20)})} />
          <Fig {...EVE(1130, {flip: true, arm: ezArm(f, a0 + 18, [-55, -65], [-25, -45], 24), head: ez(f, a0 + 30, -6, 16, 20)})} />
        </Gp>
        <Gp o={fi(f, aSew, 16)}>
          <Beam x={520} w={300} o={0.8 * fi(f, aEng - 18, 22)} f={f} />
          <Fig {...ADAM(1260, {flip: true, robe: 'stoop', head: 18, bend: 14, arm: [-30, -45]})} />
          <Fig {...EVE(1390, {flip: true, robe: 'stoop', head: 18, bend: 14, arm: [-28, -45]})} />
          <FigTree x={1150} y={GY} s={1.06} leaf={1} o={0.82} seed={11} />
        </Gp>
        <Card f={f} a={aEng} b={aEnd} x={520} y={370} w={420} h={170} top="ENGLISH · 3 WORDS" en="“Where are you?”" />
        <Card f={f} a={aHeb} b={aEnd} x={1020} y={370} w={420} h={195} top="HEBREW · 1 WORD" heb="אַיֶּכָּה" en="Ayekah" hl={1} />
      </>
    ),
    html: (
      <>
        <Ref f={f} a={a0 + 4} b={aEng} y={62} size={28}>GENESIS 3:7–9</Ref>
        <Note f={f} a={a0 + 12} b={aSew} y={118} size={46}>for the first time, they know they are naked</Note>
        <Note f={f} a={aSew} b={aEng} y={118} size={46}>they sew fig leaves together and hide among the trees</Note>
      </>
    ),
  }));
}

// SCENE 2: ANCIENT HEBREW SCROLLS — AYEKAH TO EICHAH
{
  const a0 = at('Ancient Hebrew scrolls');
  const aDots = at('take the vowel dots off');
  const aEichah = at('Put different vowels under them');
  const aEnd = at('Eichah is the opening word');

  push(a0, (f) => ({
    svg: (
      <>
        <Spot id="ay2" x={960} y={560} r={900} a={0.55} />
        <Ground id="ay2g" />
        <QuestionTrack active={1} />
        <Table x={960} y={GY} w={680} />
        <ClayLamp x={960} y={GY - 134} f={f} s={1.35} />
        <Scroll x={840} y={GY - 165} s={0.34} />
        <Scroll x={1080} y={GY - 165} s={0.34} />
        <Fig {...ELDER(640, {robe: 'seat', bench: true, head: 14, arm: ezArm(f, aDots, [-35, -45], [-65, -25], 20)})} />
        <Fig {...PPL(1280, {flip: true, robe: 'seat', bench: true, beard: 'short', head: 14, arm: ezArm(f, aEichah, REST, [-60, -30], 20)})} />
        <Fig {...PPL(460, {sc: 0.27, head: 8, o: 0.78})} />
      </>
    ),
    html: <VowelMorph f={f} a={a0 + 6} aBare={aDots} aSwap={aEichah} b={aEnd} />,
  }));
}

// SCENE 3: LAMENTATIONS — RUINS OF JERUSALEM & MOURNING CROWD
{
  const a0 = at('Eichah is the opening word');
  const aHow = at('It means how');
  const aEnd = at('Ancient Jewish commentators');

  push(a0, (f) => ({
    svg: (
      <>
        <Night o={0.58} />
        <Spot id="ay3" x={960} y={620} r={940} a={0.5} c="#7d4a28" />
        <City x={960} y={GY} s={1.32} o={0.78} />
        <Smoke x={680} y={GY - 260} f={f} o={0.7} />
        <Smoke x={1180} y={GY - 290} f={f + 40} o={0.65} />
        <Fire x={760} y={GY - 120} s={0.7} f={f} o={0.65} />
        <Fire x={1250} y={GY - 110} s={0.6} f={f + 22} o={0.55} />
        <Ground id="ay3g" />
        <QuestionTrack active={1} />
        <Fig {...ELI(480, {robe: 'seat', bench: true, head: 22, bend: 10, arm: [-40, -50]})} />
        <Scroll x={560} y={GY - 40} s={0.28} />
        <Fig {...PPL(780, {robe: 'kneel', head: 22, sc: 0.27})} />
        <Fig {...PPL(930, {hair: 'veil', beard: 'none', robe: 'kneel', head: 20, sc: 0.25, flip: true})} />
        <Fig {...PPL(1120, {robe: 'stoop', head: 18, bend: 14, sc: 0.27, flip: true})} />
        <Fig {...PPL(1300, {hair: 'veil', beard: 'none', sc: 0.26, head: 16, flip: true})} />
        <Fig {...PPL(1460, {robe: 'kneel', head: 20, sc: 0.26, flip: true})} />
      </>
    ),
    html: (
      <>
        <Verse
          f={f}
          a={a0 + 6}
          b={aEnd}
          e={aHow}
          refText="LAMENTATIONS 1:1"
          orig="אֵיכָה יָשְׁבָה בָדָד הָעִיר"
          origKey={[0]}
          eng="*How* deserted lies the city, once so full of people."
          keys={[aHow]}
          y={58}
        />
      </>
    ),
  }));
}

// SCENE 4: RASHI & THE SOUND OF GRIEF
{
  const a0 = at('Ancient Jewish commentators');
  const aRashi = at('eleventh-century scholar Rashi');
  const aGrief = at('And under the question sits the sound of grief');
  const aEnd = at('Adam steps out');

  push(a0, (f) => ({
    svg: (
      <>
        <Spot id="ay4" x={960} y={560} r={920} a={0.52} />
        <Ground id="ay4g" />
        <QuestionTrack active={1} />

        <Gp o={win(f, a0, aRashi + 6)}>
          <Card f={f} a={a0} b={aRashi + 6} x={580} y={400} w={420} h={210} top="GENESIS 3:9" heb="אַיֶּכָּה" en="“Where are you?”" hl={0.6} />
          <Card f={f} a={a0 + 10} b={aRashi + 6} x={1340} y={400} w={420} h={210} top="LAMENTATIONS 1:1" heb="אֵיכָה" en="“How could this be?”" hl={0.6} />
          <ArcLink f={f} a={a0 + 16} b={aRashi + 6} x1={580} x2={1340} y={290} lift={105} />
          <Table x={960} y={GY} w={560} />
          <ClayLamp x={960} y={GY - 134} f={f} s={1.2} />
          <Fig {...ELDER(640, {robe: 'seat', bench: true, head: -6, arm: [-55, -25]})} />
          <Fig {...ELDER(1280, {flip: true, robe: 'seat', bench: true, head: -6, arm: [-55, -25]})} />
        </Gp>

        <Gp o={fi(f, aRashi, 16)}>
          <Door x={960} y={GY} open={eio(ramp(f, aRashi + 10, 42))} />
          <Beam x={960} w={300} o={0.78 * fi(f, aRashi + 14, 24)} f={f} />
          <FigTree x={1500} y={GY} s={0.95} leaf={1} o={0.5} seed={8} />
          {WK(f, aRashi, aGrief + 6, aRashi + 22, aGrief, 1340, 1080, ADAM(0, {face: -1, head: 12}), 'adr')}
          <Gp o={fi(f, aGrief, 14)}>
            <Fig {...ADAM(1080, {flip: true, head: 22, bend: 8, arm: REST})} />
            <Fig {...EVE(1230, {flip: true, head: 20, bend: 6, arm: REST, o: 0.88})} />
          </Gp>
        </Gp>
      </>
    ),
    html: (
      <>
        <Note f={f} a={a0 + 6} b={aRashi} y={76} size={46}>identical consonants on the scroll</Note>
        <Ref f={f} a={aRashi + 4} b={aGrief} y={64} size={28}>RASHI · 11TH CENTURY</Ref>
        <Note f={f} a={aRashi + 14} b={aGrief} y={120} size={46}>asked gently, just to open a conversation</Note>
        <Note f={f} a={aGrief + 6} b={aEnd} y={76} size={48}>under the question sits the sound of grief</Note>
        <Big f={f} a={aGrief + 48} b={aEnd} y={195} size={62} c={TXT.gold}>“LOOK AT WHERE YOU HAVE ENDED UP.”</Big>
      </>
    ),
  }));
}

// SCENE 5: THE BLAME CHAIN — ADAM -> EVE -> SERPENT
{
  const a0 = at('Adam steps out');
  const aWife = at('points at his wife');
  const aSerp = at('She points at the serpent');
  const aEnd = at('One chapter later', 1);

  push(a0, (f) => ({
    svg: (
      <>
        <GardenSet id="ay5" night={0.25} cx={960} />
        <QuestionTrack active={1} />
        <Beam x={320} w={260} o={0.82} f={f} />
        <Fig {...ADAM(660, {arm: ezArm(f, aWife - 8, REST, [-86, -12], 14), head: ez(f, aWife - 8, 6, 0, 12)})} />
        <Fig {...EVE(1050, {arm: ezArm(f, aSerp - 8, REST, [-78, -22], 14), head: ez(f, aSerp - 8, 6, 14, 12)})} />
        <Serpent x={1440} y={GY} s={1.15} f={f} m="ember" rear={eio(ramp(f, aSerp - 12, 24))} flip />
        <Line d="M775,650 L945,650" p={pr(f, aWife, 20)} c="#E3B465" w={2.4} o={fi(f, aWife, 10)} u />
        <Line d="M1155,690 L1350,750" p={pr(f, aSerp, 20)} c="#E2785A" w={2.4} o={fi(f, aSerp, 10)} />
      </>
    ),
    html: (
      <>
        <Name f={f} a={a0} b={aEnd} x={660} y={878} en="ADAM" />
        <Name f={f} a={a0} b={aEnd} x={1050} y={878} en="EVE" />
        <Name f={f} a={aSerp - 10} b={aEnd} x={1440} y={878} en="SERPENT" c={TXT.ember} />
        <Note f={f} a={a0 + 6} b={aSerp} y={85} size={48}>Adam immediately points at his wife</Note>
        <Note f={f} a={aSerp} b={aEnd} y={85} size={48}>neither of them will stand in the spot where God found them</Note>
      </>
    ),
  }));
}

// SCENE 6: CAIN & ABEL — TWO WALK OUT, ONE COMES BACK
{
  const a0 = at('One chapter later', 1);
  const aField = at('They go out into a field together');
  const aOnly = at('and only Cain comes back');
  const aEnd = at('Then God speaks to Cain');

  push(a0, (f) => ({
    svg: (
      <>
        <FieldSet id="ay6" night={0.22 + 0.22 * fi(f, aOnly, 24)} cx={960} />
        <QuestionTrack active={2} />
        <Gp o={win(f, a0, aOnly + 6)}>
          <Fig {...ADAM(290, {sc: 0.28, o: 0.65})} />
          <Fig {...EVE(400, {sc: 0.26, o: 0.65})} />
          <Sheep x={1340} y={GY} s={0.75} graze />
          <Sheep x={1460} y={GY} s={0.68} lamb flip />
          {WK(f, a0, aOnly + 6, aField, aOnly, 720, 1140, CAIN(0, {face: 1}), 'ca6')}
          {WK(f, a0, aOnly + 6, aField + 4, aOnly, 850, 1270, ABEL(0, {face: 1}), 'ab6')}
        </Gp>
        <Gp o={fi(f, aOnly, 16)}>
          <Sheep x={1420} y={GY} s={0.7} flip o={0.55} />
          <Sheep x={1540} y={GY} s={0.62} lamb o={0.5} />
          {WK(f, aOnly, aEnd, aOnly, aEnd, 1340, 820, CAIN(0, {face: -1, head: 14, bend: 8}), 'ca6b')}
        </Gp>
      </>
    ),
    html: (
      <>
        <Ref f={f} a={a0 + 4} b={aOnly} y={64} size={28}>GENESIS 4:8</Ref>
        <Note f={f} a={a0 + 12} b={aOnly} y={118} size={48}>two brothers go out into a field together</Note>
        <Note f={f} a={aOnly} b={aEnd} y={90} size={50}>only Cain comes back — nobody saw what happened</Note>
      </>
    ),
  }));
}

// SCENE 7: EI HEVEL ACHICHA — SAME ROOT WORD & SPLIT PROGRESSION
{
  const a0 = at('Then God speaks to Cain');
  const aWhere = at('Where is Abel your brother');
  const aCh3 = at('In chapter three God asked Adam');
  const aFirst = at('First a man hides from God');
  const aEnd = at('God already knows Abel is dead');

  push(a0, (f) => {
    const L = (
      <>
        <GardenSet id="ay7l" night={0.25} cx={960} />
        <Beam x={720} w={260} o={0.78} f={f} />
        <Fig {...ADAM(1140, {flip: true, robe: 'stoop', head: 16})} />
      </>
    );
    const R = (
      <>
        <FieldSet id="ay7r" night={0.32} cx={960} />
        <Beam x={720} w={260} o={0.78} f={f} />
        <Fig {...CAIN(1120, {flip: true, head: 8})} />
      </>
    );
    return {
      svg: (
        <>
          <Gp o={win(f, a0, aCh3 + 6)}>
            <FieldSet id="ay7a" night={0.3} cx={960} />
            <Beam x={620} w={290} o={0.85} f={f} />
            <Fig {...CAIN(1160, {flip: true, head: 6})} />
            <Card f={f} a={a0 + 18} b={aCh3 + 6} x={480} y={400} w={340} h={160} top="GEN 3:9" heb="אַיֶּכָּה" />
            <ArcLink f={f} a={aWhere - 10} b={aCh3 + 6} x1={480} x2={960} y={310} lift={80} />
          </Gp>
          <Gp o={fi(f, aCh3, 16)}>
            <Split left={L} right={R} labL="GEN 3 · WHERE ARE YOU?" labR="GEN 4 · WHERE IS YOUR BROTHER?" labO={fi(f, aCh3 + 12)} />
          </Gp>
          <QuestionTrack active={2} />
        </>
      ),
      html: (
        <>
          <Verse
            f={f}
            a={a0 + 6}
            b={aCh3}
            e={aWhere}
            refText="GENESIS 4:9"
            orig="אֵי הֶבֶל אָחִיךָ"
            origKey={[0]}
            eng="*Where* is Abel, your brother?"
            keys={[aWhere]}
            y={56}
          />
          <Note f={f} a={aCh3 + 6} b={aFirst} y={56} size={46}>from hiding yourself to hiding what you did to another person</Note>
          <Big f={f} a={aFirst} b={aEnd} y={136} size={52} c={TXT.gold}>HIDE FROM GOD · HIDE FROM YOUR BROTHER</Big>
        </>
      ),
    };
  });
}

// SCENE 8: BLOOD CRYING OUT & CAIN'S REFUSAL
{
  const a0 = at('God already knows Abel is dead');
  const aBlood = at('blood is crying out from the ground');
  const aRef = at('Cain refuses');
  const aKeep = at('Am I my brothers keeper');
  const aStops = at('God stops asking', 1);
  const aEnd = at('Twelve chapters later');

  push(a0, (f) => ({
    svg: (
      <>
        <FieldSet id="ay8" night={0.38} cx={960} />
        <QuestionTrack active={2} />
        <Beam x={560} w={280} o={0.82} f={f} />
        <BloodPulse x={960} y={GY} f={f} o={fi(f, aBlood - 10, 20)} />
        <Gp o={win(f, a0, aStops + 6)}>
          <Fig
            {...CAIN(1160, {
              face: turn(f, aRef + 12, -1, 16),
              arm: ezArm(f, aKeep - 8, REST, [-82, -18], 14),
              head: ez(f, aRef, 6, -4, 14),
            })}
          />
        </Gp>
        <Gp o={fi(f, aStops, 16)}>
          {WK(f, aStops, aEnd, aStops, aEnd, 1160, 1740, CAIN(0, {face: 1, head: 10}), 'ca8w')}
        </Gp>
      </>
    ),
    html: (
      <>
        <Q
          f={f}
          a={a0 + 6}
          b={aRef}
          refText="GENESIS 4:10"
          eng="“Your brother’s *blood cries out* to me from the ground.”"
          keys={[aBlood]}
          y={64}
        />
        <Big f={f} a={aKeep - 6} b={aStops} y={160} size={64} c={TXT.ember}>“AM I MY BROTHER’S KEEPER?”</Big>
        <Note f={f} a={aStops} b={aEnd} y={88} size={48}>God stops asking and tells him what the ground already knows</Note>
      </>
    ),
  }));
}

// SCENE 9: HAGAR IN ABRAHAM'S HOUSEHOLD — HARSH TREATMENT & FLIGHT
{
  const a0 = at('Twelve chapters later');
  const aHag = at('Hagar is an Egyptian slave');
  const aPreg = at('When Hagar gets pregnant');
  const aRun = at('Hagar runs', 1);
  const aEnd = at('Pregnant and alone');

  push(a0, (f) => ({
    svg: (
      <>
        <DesertSet id="ay9" night={0.18 + 0.25 * fi(f, aRun, 20)} cx={960} />
        <QuestionTrack active={3} />
        <Tent x={640} y={GY} s={1.08} />
        <Olive x={1560} y={GY} s={0.9} o={0.55} />
        <Jar x={440} y={GY} s={0.75} />
        <Fig {...PPL(290, {sc: 0.24, o: 0.65})} />
        <Fig {...PPL(390, {hair: 'veil', beard: 'none', sc: 0.23, o: 0.6})} />
        <Fig {...PPL(1460, {flip: true, sc: 0.24, o: 0.55})} />
        <Fig {...ABRAHAM(700, {head: ez(f, aPreg, 0, 12, 18)})} />
        <Fig {...SARAH(940, {arm: ezArm(f, aPreg + 10, REST, [-86, -12], 16), head: ez(f, aPreg, 0, -4, 14)})} />
        <Gp o={win(f, a0, aRun + 6)}>
          <Fig {...HAGAR(1200, {flip: true, head: ez(f, aPreg, 4, 16, 18), bend: ez(f, aPreg, 0, 8, 18)})} />
        </Gp>
        <Gp o={fi(f, aRun, 14)}>
          {WK(f, aRun, aEnd, aRun, aEnd, 1220, 1820, HAGAR(0, {face: 1, head: 14, bend: 8}), 'hg9')}
        </Gp>
      </>
    ),
    html: (
      <>
        <Ref f={f} a={a0 + 4} b={aHag} y={64} size={30}>GENESIS 16 · THE SCENE TURNS AROUND</Ref>
        <Note f={f} a={aHag} b={aPreg} y={84} size={48}>Hagar, an Egyptian slave in Abraham’s house</Note>
        <Note f={f} a={aPreg} b={aEnd} y={84} size={48}>treated so harshly that she runs into the desert</Note>
        <Name f={f} a={aHag} b={aRun} x={700} y={878} en="ABRAHAM" />
        <Name f={f} a={aHag} b={aRun} x={940} y={878} en="SARAH" c={TXT.silver} />
        <Name f={f} a={aHag} b={aRun} x={1200} y={878} en="HAGAR" c={TXT.bronze} />
      </>
    ),
  }));
}

// SCENE 10: THE SPRING ON THE ROAD TO SHUR — GOD CALLS HER BY NAME
{
  const a0 = at('Pregnant and alone');
  const aAng = at('That is where the angel of the Lord');
  const aName = at('Notice the very first word he says Hagar');
  const aNever = at('neither Abraham nor Sarah');
  const aCalls = at('God calls her by name');
  const aEnd = at('Then He uses our word again');

  push(a0, (f) => ({
    svg: (
      <>
        <DesertSet id="ay10" night={0.34} cx={960} />
        <QuestionTrack active={3} />
        <Spring x={960} y={GY} f={f} s={1.08} />
        <Gp o={win(f, a0, aAng + 6)}>
          {WK(f, a0, aAng + 6, a0, aAng - 10, 260, 720, HAGAR(0, {face: 1, head: 16, bend: 12}), 'hg10')}
        </Gp>
        <Gp o={fi(f, aAng, 16)}>
          <Fig {...HAGAR(740, {robe: 'seat', head: ez(f, aName, 16, -10, 18), arm: REST})} />
          <Beam x={1220} w={300} o={0.82 * fi(f, aAng, 24)} f={f} />
          <Michael x={1220} y={GY} sc={0.33} flip spread={0.85} f={f} glow={0.65} o={fi(f, aAng + 6, 22)} />
        </Gp>
      </>
    ),
    html: (
      <>
        <Ref f={f} a={a0 + 4} b={aAng} y={64} size={28}>THE ROAD TO SHUR</Ref>
        <Note f={f} a={a0 + 12} b={aAng} y={118} size={46}>alone beside a spring of water</Note>
        <Note f={f} a={aNever} b={aCalls} y={84} size={46} c={TXT.dim}>
          <span style={{textDecoration: 'line-through'}}>“the slave woman”</span>
        </Note>
        <Big f={f} a={aCalls - 6} b={aEnd} y={145} size={78} c={TXT.gold}>הָגָר · HAGAR</Big>
        <Note f={f} a={aCalls + 10} b={aEnd} y={210} size={44}>God calls her by name</Note>
      </>
    ),
  }));
}

// SCENE 11: HALF-ANSWER, PLAIN TRUTH & EL ROI
{
  const a0 = at('Then He uses our word again');
  const aAns = at('Listen to how Hagar answers');
  const aBlank = at('leaves the second half blank');
  const aUnl = at('Unlike Adam Hagar does not blame');
  const aProm = at('God promises her a son');
  const aElRoi = at('El Roi');
  const aEnd = at('Centuries later the pattern comes back');

  push(a0, (f) => ({
    svg: (
      <>
        <DesertSet id="ay11" night={0.28} cx={960} />
        <QuestionTrack active={3} />
        <Gp o={win(f, a0, aUnl + 6)}>
          <Spring x={960} y={GY} f={f} s={1.08} />
          <Fig {...HAGAR(740, {robe: 'seat', head: -8, arm: ezArm(f, aAns + 10, REST, [-45, -30], 16)})} />
          <Beam x={1220} w={290} o={0.8} f={f} />
          <Michael x={1220} y={GY} sc={0.33} flip spread={0.8} f={f} glow={0.6} />
        </Gp>
        <Gp o={fi(f, aUnl, 16)}>
          <Fig {...ADAM(360, {sc: 0.27, arm: [-80, -15], dim: 0.72})} />
          <Fig {...CAIN(610, {sc: 0.27, flip: true, dim: 0.72})} />
          <Spring x={1220} y={GY} f={f} s={0.95} />
          <Beam x={1120} w={320} o={0.88} f={f} />
          <Fig {...HAGAR(1080, {sc: 0.3, m: 'gold', head: ez(f, aElRoi - 10, 0, -14, 18), arm: ezArm(f, aElRoi - 10, REST, [-55, -55], 20)})} />
          <Michael x={1440} y={GY} sc={0.31} flip spread={0.9} f={f} glow={0.6} o={fi(f, aProm, 18)} />
        </Gp>
      </>
    ),
    html: (
      <>
        <Verse
          f={f}
          a={a0 + 4}
          b={aAns}
          e={aAns - 12}
          refText="GENESIS 16:8"
          orig="אֵי־מִזֶּה בָאת וְאָנָה תֵלֵכִי"
          origKey={[0, 2]}
          eng="*Where* have you come from, and *where* are you going?"
          keys={[a0 + 26, a0 + 58]}
          y={58}
        />
        <HalfAnswer f={f} a={aAns} aBlank={aBlank} b={aUnl} />
        <Name f={f} a={aUnl} b={aEnd} x={360} y={878} en="ADAM · BLAMED" c={TXT.dim} />
        <Name f={f} a={aUnl} b={aEnd} x={610} y={878} en="CAIN · LIED" c={TXT.dim} />
        <Name f={f} a={aUnl} b={aEnd} x={1080} y={878} en="HAGAR · TRUTH" c={TXT.gold} />
        <Note f={f} a={aUnl} b={aElRoi} y={76} size={48}>she tells the plain truth — and God gives her a future</Note>
        <Verse
          f={f}
          a={aElRoi - 10}
          b={aEnd}
          e={aEnd - 15}
          refText="GENESIS 16:13"
          orig="אֵל רֳאִי"
          origKey={[0, 1]}
          eng="*El Roi* — the God who sees me."
          keys={[aElRoi]}
          y={58}
        />
      </>
    ),
  }));
}
