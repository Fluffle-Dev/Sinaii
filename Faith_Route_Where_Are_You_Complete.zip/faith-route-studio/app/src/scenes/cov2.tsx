import React from 'react';
import {at, win, fi, kf, ramp, eio, eout} from '../lib';
import {Fig, FigP, Line, Tent, Throne, Colonnade, Table, TXT} from '../fig';
import {Ref, Big, Note, Name} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Altar, Wings} from '../extra';
import {Book, Stars, Scroll} from '../props';
import {Tablets, Baby} from '../famprops';
import {JP, DP, BP, SP, F, Gp, pr, ez, ezArm, turn, walkX} from '../kit';
import {Beam, Card, Q, Arch, StoneK, Beast, Firepot, Cup, Heart, Chain, Cycle, Arrow} from '../covprops';
import {MOSES, PPL, PROPH, WK, stones, Night, Pieces} from './cov1';

export const CV2: Scene[] = [];
const push = (start: number, render: Scene['render']) => CV2.push({start, render});

const DAVID = (x: number, o: Partial<FigP> = {}) => DP(x, {crown: true, beard: 'short', mantle: true, ...o});
const KINGB = (x: number, o: Partial<FigP> = {}) => SP(x, {crown: true, beard: 'short', ...o});
const PHIN = (x: number, o: Partial<FigP> = {}) => DP(x, {hair: 'cap', beard: 'short', prop: 'spear', ...o});
const MARY = (x: number, o: Partial<FigP> = {}) => DP(x, {hair: 'veil', beard: 'none', sc: 0.29, ...o});
const ALL6 = {adam: 1, noah: 1, abr: 1, sinai: 1, phin: 1, david: 1};

/** tablets that break: b 0..1 */
const BrokenTablets: React.FC<{x: number; y: number; s?: number; b: number; o?: number}> = ({x, y, s = 1, b, o = 1}) => (
  <g opacity={o}>
    <defs>
      <clipPath id="tbL"><rect x={x - 400} y={y - 500} width={400} height={600} /></clipPath>
      <clipPath id="tbR"><rect x={x} y={y - 500} width={400} height={600} /></clipPath>
    </defs>
    <g transform={`translate(${-b * 90} ${b * 160}) rotate(${-b * 28} ${x} ${y})`}><g clipPath="url(#tbL)"><Tablets x={x} y={y} s={s} /></g></g>
    <g transform={`translate(${b * 90} ${b * 170}) rotate(${b * 32} ${x} ${y})`}><g clipPath="url(#tbR)"><Tablets x={x} y={y} s={s} /></g></g>
  </g>
);

// 16 A DIFFERENT SHAPE, THE CALF ----------------------------------------------------------------
{
  const q0 = at('This covenant had a different shape'), qNoah = at('With Noah and Abraham'), qSin = at('At Sinai, the people made promises'), qWeeks = at('And within weeks'),
    qSmash = at('he smashed the tablets'), qEnd = at('The rest of the Old Testament', 2);
  push(q0, (f) => ({
    svg: <>
      <Spot id="q16" x={960} y={600} r={820} />
      <Ground id="q16g" />
      <Gp o={win(f, q0, qNoah + 6)}>
        <Arch f={f} n={stones(f, {adam: q0 - 30, noah: q0 - 30, abr: q0 - 30, sinai: q0 + 16})} hl="sinai" dimOthers={1} />
      </Gp>
      <Gp o={win(f, qNoah, qWeeks + 6)}>
        <Card f={f} a={qNoah} x={620} y={420} w={520} h={270} top="NOAH · ABRAHAM" en="God carries the weight" />
        <Arrow x0={460} y0={580} x1={780} y1={580} p={pr(f, qNoah + 20, 20)} />
        <text x={620} y={640} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={26} letterSpacing={4} opacity={fi(f, qNoah + 30)}>GOD PROMISES</text>
        <Card f={f} a={qSin} x={1300} y={420} w={520} h={270} top="SINAI" en="the people promise too" hl={fi(f, qSin + 10)} />
        <Arrow x0={1140} y0={570} x1={1460} y1={570} p={pr(f, qSin + 16, 20)} />
        <Arrow x0={1460} y0={610} x1={1140} y1={610} p={pr(f, qSin + 30, 20)} />
        <text x={1300} y={670} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={26} letterSpacing={4} opacity={fi(f, qSin + 40)}>BOTH SIDES PROMISE</text>
      </Gp>
      <Gp o={fi(f, qWeeks)}>
        <Altar x={1180} y={GY} s={0.9} />
        <Beast x={1180} y={GY - 108} s={0.6} kind="heifer" m="bronze" o={fi(f, qWeeks + 10)} />
        {[0, 1, 2].map((k) => F(f, qWeeks + 20 + k * 6, undefined, PPL(1480 + k * 130, {flip: true, robe: 'kneel', bend: ez(f, qWeeks + 40, 0, 34, 20), head: 24}), 'cb' + k))}
        {WK(f, qWeeks + 30, undefined, qWeeks + 30, qSmash - 10, 200, 640, MOSES(0, {prop: null, arm: [-150, -20]}), 'ms')}
        <BrokenTablets x={kf(f, [[qWeeks + 30, 260], [qSmash - 10, 700]], qSmash - qWeeks - 40)} y={GY - 520} s={0.42} b={eio(ramp(f, qSmash + 10, 24))} o={fi(f, qWeeks + 30) * (1 - fi(f, qEnd - 30, 30) * 0)} />
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={q0} b={qNoah}>SINAI · A DIFFERENT SHAPE</Ref>
      <Ref f={f} a={qWeeks} b={qSmash}>WITHIN WEEKS · A GOLDEN CALF</Ref>
      <Note f={f} a={qSmash} b={qEnd} y={140} size={44}>the tablets smashed at the foot of the mountain</Note>
    </>,
  }));
}

// 17 THE CYCLE, THE HEART ----------------------------------------------------------------------
{
  const r0 = at('The rest of the Old Testament', 2), rProm = at('Israel promised to obey'), rProp = at('each time God sent prophets'), rLaw = at('The law itself was good'), rHeart = at('The problem was the human heart'), rEnd = at('Along the way, God made');
  push(r0, (f) => ({
    svg: <>
      <Spot id="r17" x={960} y={560} r={820} />
      <Gp o={win(f, r0, rLaw + 4)}>
        <Cycle f={f} a={r0} b={rLaw + 4} x={960} y={600} r={230} labels={['PROMISE', 'BREAK', 'PROPHETS']} spin={(f < rProm ? -1 : f < at('and then broke the covenant') ? 0 : f < rProp ? 1 : 2 + Math.floor((f - rProp) / 50) * 1)} />
      </Gp>
      <Gp o={fi(f, rLaw)}>
        <Ground id="r17g" />
        <Tablets x={620} y={GY - 120} s={0.9} />
        <Beam x={620} w={300} o={0.6} f={f} />
        <Heart x={1300} y={GY - 300} s={1.2} t={0} p={pr(f, rHeart, 40)} o={fi(f, rHeart)} />
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={r0} b={rLaw}>AGAIN AND AGAIN</Ref>
      <Note f={f} a={rLaw} b={rHeart} y={140} size={46}>the law was good and holy</Note>
      <Big f={f} a={rHeart} b={rEnd} y={200} size={72} c={TXT.gold}>THE HUMAN HEART</Big>
    </>,
  }));
}

// 18 PHINEHAS ----------------------------------------------------------------------------------
{
  const s0 = at('Along the way, God made'), sPri = at('The first was with a priest'), sQ = at('Therefore tell him I am making'), sProm = at('God promised his people a priest'), sEnd = at('The second was with a king');
  push(s0, (f) => ({
    svg: <>
      <Spot id="s18" x={960} y={600} r={820} />
      <Ground id="s18g" />
      <Gp o={win(f, s0, sPri + 6)}>
        <Arch f={f} n={{adam: 1, noah: 1, abr: 1, sinai: 1}} lab={1} sub={1} o={0.9} />
      </Gp>
      <Gp o={win(f, sPri, sProm + 6)}>
        <Beam x={960} w={300} o={0.85} f={f} />
        {F(f, sPri, sProm + 6, PHIN(960, {}))}
        {[0, 1, 2].map((k) => F(f, sPri + 10 + k * 5, sProm + 6, PPL(420 + k * 120, {o: 0.6, head: 8}), 'ph' + k))}
      </Gp>
      <Gp o={fi(f, sProm)}>
        <Arch f={f} n={stones(f, {adam: sProm - 30, noah: sProm - 30, abr: sProm - 30, sinai: sProm - 30, phin: sProm + 16})} hl="phin" dimOthers={1} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={s0 + 6} b={sPri} y={130} size={46}>two covenants that are easy to miss</Note>
      <Name f={f} a={sPri + 10} b={sQ} x={960} y={900} en="PHINEHAS · THE PRIEST" />
      <Q f={f} a={sQ} b={sProm} refText="NUMBERS 25:12–13" eng="“Therefore tell him I am making my *covenant of peace* with him. He and his descendants will have a covenant of a *lasting priesthood*.”" keys={[at('covenant of peace'), at('lasting priesthood', 1)]} />
      <Note f={f} a={sProm + 10} b={sEnd} y={110} size={44}>a priest to stand between them and judgment</Note>
    </>,
  }));
}

// 19-20 DAVID WANTS TO BUILD -------------------------------------------------------------------
{
  const t0 = at('The second was with a king'), tDav = at('David had become king'), tArk = at('the ark of God was still kept'), tBuild = at('So he decided to build God'),
    tNat = at('the prophet Nathan'), tTurn = at('God turned the plan around'), tEnd = at('The LORD declares to you');
  push(t0, (f) => ({
    svg: <>
      <Spot id="t19" x={900} y={600} r={820} />
      <Ground id="t19g" />
      <Colonnade x={620} y={GY} w={520} h={520} n={3} p={pr(f, t0, 40)} o={0.75} />
      {F(f, t0, undefined, DAVID(620, {robe: 'seat', bench: true, head: f < tArk ? 0 : ez(f, tArk, 0, -6, 14)}))}
      <Gp o={win(f, tArk, tBuild + 10)}>
        <Tent x={1420} y={GY} s={0.8} p={pr(f, tArk, 30)} />
        <rect x={1390} y={GY - 50} width={60} height={40} fill="#0c0905" stroke="#E8B455" strokeWidth={2} opacity={fi(f, tArk + 20)} />
      </Gp>
      <Gp o={win(f, tBuild + 10, tTurn + 10)}>
        <g opacity={0.5}><Colonnade x={1420} y={GY} w={420} h={480} n={4} door p={pr(f, tBuild, 50)} /></g>
      </Gp>
      {WK(f, tNat, undefined, tNat + 10, tNat + 80, 1980, 1180, PROPH(0, {}), 'nt')}
      <Beam x={1180} w={260} o={0.5 * fi(f, tTurn)} f={f} />
    </>,
    html: <>
      <Ref f={f} a={t0} b={tDav}>A COVENANT WITH A KING</Ref>
      <Name f={f} a={tDav} b={tArk} x={620} y={900} en="DAVID · A PALACE OF CEDAR" />
      <Note f={f} a={tArk} b={tBuild} y={140} size={44}>the ark of God still in a tent</Note>
      <Note f={f} a={tBuild} b={tNat} y={140} size={44}>David plans to build God a house</Note>
      <Name f={f} a={tNat + 50} b={tTurn} x={1180} y={900} en="NATHAN THE PROPHET" />
      <Big f={f} a={tTurn} b={tEnd} y={200} size={60} c={TXT.gold}>GOD WILL BUILD DAVID A HOUSE</Big>
    </>,
  }));
}

// 21 THE HOUSE OF DAVID ------------------------------------------------------------------------
{
  const u0 = at('The LORD declares to you'), uDyn = at('He was talking about a family line'), uQ = at('When your days are over'), uQ2 = at('He is the one who will build'),
    uLine = at('And then the line that would keep'), uQ3 = at('Your house and your kingdom will endure'), uPs = at('A psalm later calls this'), uQ4 = at('I have made a covenant with my chosen one'), uEnd = at('For a while it looked like');
  push(u0, (f) => ({
    svg: <>
      <Spot id="u21" x={760} y={620} r={820} />
      <Ground id="u21g" cx={760} />
      <Gp o={win(f, u0, uQ3 + 6)}>
        {F(f, u0, uQ3 + 6, DAVID(420, {}))}
        {Array.from({length: 7}, (_, k) => F(f, uDyn + 10 + k * 8, uQ3 + 6, DP(640 + k * 175 - k * k * 4, {crown: true, beard: 'short', sc: 0.27 - k * 0.022, o: 0.95 - k * 0.09}), 'dy' + k))}
      </Gp>
      <Gp o={win(f, uQ3, uPs + 30)}>
        <Throne x={960} y={GY} s={1.25} p={pr(f, uQ3, 40)} />
        <Beam x={960} w={360} o={0.9} f={f} />
      </Gp>
      <Gp o={fi(f, uPs + 10)}>
        <Arch f={f} n={stones(f, {adam: uPs, noah: uPs, abr: uPs, sinai: uPs, phin: uPs, david: uPs + 40})} hl="david" dimOthers={1} />
      </Gp>
    </>,
    html: <>
      <Q f={f} a={u0} b={uDyn} refText="2 SAMUEL 7:11" eng="“The LORD declares to you that the LORD himself will *establish a house* for you.”" keys={[at('establish a house for you')]} y={110} />
      <Ref f={f} a={uDyn} b={uQ}>A FAMILY LINE · A DYNASTY</Ref>
      <Q f={f} a={uQ} b={uQ2} refText="2 SAMUEL 7:12" eng="“When your days are over and you rest with your ancestors, I will raise up your offspring to succeed you, your own flesh and blood, and I will *establish his kingdom*.”" keys={[at('establish his kingdom')]} size={48} />
      <Q f={f} a={uQ2} b={uLine} refText="2 SAMUEL 7:13" eng="“He is the one who will build a house for my Name, and I will establish the throne of his kingdom *forever*.”" keys={[at('of his kingdom forever') + 18]} />
      <Note f={f} a={uLine} b={uQ3} y={140} size={44}>the line Israel would hope on for a thousand years</Note>
      <Q f={f} a={uQ3} b={uPs} refText="2 SAMUEL 7:16" eng="“Your house and your kingdom will endure forever before me; your throne will be *established forever*.”" keys={[at('established forever')]} />
      <Q f={f} a={uPs + 10} b={uEnd} refText="PSALM 89:3" eng="“You said, ‘I have made a covenant with my chosen one, I have sworn to *David my servant*.’”" keys={[at('David my servant')]} y={80} size={48} />
    </>,
  }));
}

// 22 COLLAPSE ----------------------------------------------------------------------------------
{
  const v0 = at('For a while it looked like'), vSol = at('David’s son Solomon'), vKings = at('But the kings who came after him'), vSplit = at('The kingdom split in two'),
    vBab = at('Babylon destroyed Jerusalem'), vChain = at('carried the last king'), vNo = at('There was no throne left'), vSeem = at('It seemed as if every covenant'), vEnd = at('And in that darkness');
  push(v0, (f) => {
    const fall = eio(ramp(f, vBab + 10, 40));
    return {
      svg: <>
        <Spot id="v22" x={960} y={600} r={820} a={0.6 - 0.25 * fi(f, vBab)} />
        <Ground id="v22g" />
        <Gp o={win(f, v0, vChain + 10)}>
          <g transform={`translate(0 ${fall * 60}) rotate(${fall * 3} 1250 ${GY})`} opacity={1 - 0.7 * fall}>
            <Colonnade x={1250} y={GY} w={560} h={520} n={4} door p={pr(f, vSol, 50)} />
          </g>
          {F(f, vSol, vKings + 10, DP(620, {crown: true, beard: 'short', mantle: true}), 'sol')}
          {[0, 1, 2].map((k) => F(f, vKings + k * 8, vChain + 10, KINGB(380 + k * 210, {face: turn(f, vKings + 30 + k * 8, 1, 14)}), 'kg' + k))}
          <Gp o={fi(f, vSplit)}><Line u w={2.6} d={`M960,120 L930,360 L990,560 L950,${GY}`} p={pr(f, vSplit, 24)} c="#C67D41" /></Gp>
        </Gp>
        <Gp o={win(f, vChain, vSeem + 10)}>
          {WK(f, vChain, vSeem + 10, vChain + 10, vSeem, 1100, 260, BP(0, {hair: 'helmet', prop: 'spear'}), 'sd')}
          {WK(f, vChain, vSeem + 10, vChain + 14, vSeem + 4, 1300, 460, KINGB(0, {head: 16, arm: [-30, -50]}), 'kc')}
          <Chain x0={walkX(f, vChain + 10, vSeem, 1100, 260).x + 30} y0={GY - 300} x1={walkX(f, vChain + 14, vSeem + 4, 1300, 460).x - 20} y1={GY - 260} o={0.9} />
          <g opacity={fi(f, vNo)}><Throne x={1380} y={GY} s={1} /></g>
        </Gp>
        <Gp o={fi(f, vSeem)}>
          <Arch f={f} n={ALL6} shake={fi(f, vSeem, 20)} scatter={0.06 * eio(ramp(f, vSeem + 30, 60))} o={1 - 0.45 * ramp(f, vSeem + 30, 60)} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={v0 + 6} b={vSol} y={140} size={44}>for a while it looked like it was coming true</Note>
        <Name f={f} a={vSol + 10} b={vKings} x={620} y={900} en="SOLOMON BUILDS THE TEMPLE" />
        <Note f={f} a={vKings} b={vSplit} y={140} size={44}>the kings turn away</Note>
        <Ref f={f} a={vSplit} b={vBab}>THE KINGDOM SPLITS</Ref>
        <Big f={f} a={vBab} b={vNo} y={200} size={64} c={TXT.gold}>586 BC · BABYLON</Big>
        <Note f={f} a={vNo} b={vSeem} y={140} size={44}>no throne, no temple</Note>
        <Note f={f} a={vSeem + 10} b={vEnd} y={110} size={44}>every covenant collapsed at once?</Note>
      </>,
    };
  });
}

// 23-24 THE NEW COVENANT PROMISED ---------------------------------------------------------------
{
  const w0 = at('And in that darkness'), wQ = at('The days are coming'), wExp = at('He explained how this one'), wQ2 = at('I will put my law in their minds'), wSame = at('That same phrase returns'),
    wQ3 = at('For I will forgive their wickedness'), x0 = at('The prophet Ezekiel saw it too'), xQ = at('I will give you a new heart'), xProb = at('The problem with the old covenant'), xNew = at('In the new covenant, God himself'), xEnd = at('Then came centuries of silence');
  push(w0, (f) => {
    const up = wQ - 10;
    return {
      svg: <>
        <Spot id="w23" x={960} y={620} r={820} a={0.4 + 0.2 * fi(f, up)} />
        <Ground id="w23g" />
        <Gp o={win(f, w0, x0 + 6)}>
          <g opacity={0.35}><Colonnade x={1400} y={GY} w={400} h={300} n={3} /></g>
          <Beam x={860} w={300} o={0.85 * fi(f, up, 30)} f={f} />
          {F(f, w0, x0 + 6, PROPH(860, {arm: ezArm(f, up, [-80, -130], [-5, -36], 16), reach: ez(f, up, 0.5, 1, 16), head: ez(f, up, 18, -10, 16)}))}
        </Gp>
        <Gp o={fi(f, x0)}>
          <Heart x={960} y={GY - 330} s={1.4} t={eio(ramp(f, xNew, 40))} />
          <Beam x={960} w={360} o={0.8 * fi(f, xNew)} f={f} />
        </Gp>
      </>,
      html: <>
        <Name f={f} a={w0 + 10} b={wQ} x={860} y={900} en="JEREMIAH" />
        <Q f={f} a={wQ} b={wExp} refText="JEREMIAH 31:31" eng="“‘The days are coming,’ declares the LORD, ‘when I will make a *new covenant* with the people of Israel and with the people of Judah.’”" keys={[at('new covenant with the people')]} />
        <Q f={f} a={wQ2} b={wQ3} refText="JEREMIAH 31:33" eng="“I will put my law in their minds and *write it on their hearts*. *I will be their God*, and they will be my people.”" keys={[at('write it on their hearts'), at('I will be their God')]} />
        <Q f={f} a={wQ3} b={x0} refText="JEREMIAH 31:34" eng="“For I will forgive their wickedness and will *remember their sins no more*.”" keys={[at('remember their sins no more')]} />
        <Note f={f} a={wExp} b={wQ2} y={140} size={44}>different from Sinai</Note>
        <Q f={f} a={xQ} b={xProb} refText="EZEKIEL 36:26" eng="“I will give you a *new heart* and put a new spirit in you.”" keys={[at('new heart and put')]} y={110} />
        <Note f={f} a={xProb} b={xNew} y={140} size={44}>hearts of stone that could not keep it</Note>
        <Big f={f} a={xNew + 10} b={xEnd} y={200} size={60} c={TXT.gold}>GOD HIMSELF CHANGES THE HEART</Big>
      </>,
    };
  });
}

// 25 SILENCE, ZECHARIAH ------------------------------------------------------------------------
{
  const y0 = at('Then came centuries of silence'), yZech = at('an old priest named Zechariah'), yQ = at('to remember his holy covenant'), yNot = at('The covenants had not been forgotten'), yEnd = at('The very first verse');
  push(y0, (f) => {
    const arm = ezArm(f, yZech + 20, [-5, -36], [-50, -70], 14);
    return {
      svg: <>
        <Spot id="y25" x={960} y={620} r={820} a={0.35 + 0.25 * fi(f, yZech)} />
        <Ground id="y25g" />
        <Gp o={win(f, y0, yZech + 6)}>
          <Stars o={0.5} seed={31} n={50} y1={480} />
          <Scroll x={960} y={GY - 120} s={1.1} o={0.6} p={pr(f, y0, 40)} />
        </Gp>
        <Gp o={win(f, yZech, yNot + 6)}>
          <Beam x={960} w={300} o={0.8 * fi(f, yZech + 20)} f={f} />
          {F(f, yZech, yNot + 6, DP(960, {hair: 'cap', beard: 'long', arm, head: ez(f, yZech + 20, 0, -12, 14)}))}
          <Baby x={1046} y={GY - 360} s={0.9} o={fi(f, yZech + 26)} />
        </Gp>
        <Gp o={fi(f, yNot)}>
          <Arch f={f} n={ALL6} lab={1} sub={1} />
          <circle cx={960} cy={560} r={200} fill="url(#halo)" opacity={0.8 * fi(f, yNot + 20)} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={y0 + 6} b={yZech} y={140} size={46}>centuries of silence</Note>
        <Name f={f} a={yZech + 10} b={yQ} x={960} y={900} en="ZECHARIAH AND HIS SON JOHN" />
        <Q f={f} a={yQ - 20} b={yNot} refText="LUKE 1:72–73" eng="“…to remember his *holy covenant*, the oath he swore to our father Abraham.”" keys={[at('his holy covenant')]} y={110} />
        <Note f={f} a={yNot + 10} b={yEnd} y={110} size={44}>about to arrive all at once</Note>
      </>,
    };
  });
}

// 26 MATTHEW 1:1, GABRIEL ----------------------------------------------------------------------
{
  const z0 = at('The very first verse'), zQ = at('This is the genealogy of Jesus'), zDav = at('The son of David, heir'), zAbr = at('The son of Abraham, the one'), zGab = at('When the angel Gabriel'), zQ2 = at('The Lord God will give him'), zEnd = at('And then, on the night before');
  push(z0, (f) => ({
    svg: <>
      <Spot id="z26" x={960} y={600} r={820} />
      <Ground id="z26g" />
      <Gp o={win(f, z0, zGab + 6)}>
        <Book x={960} y={GY - 10} s={1.1} p={pr(f, z0, 40)} lines={1} />
        <Beam x={960} w={300} o={0.6} f={f} />
        <Card f={f} a={zDav} b={zGab + 6} x={450} y={560} w={460} h={240} top="SON OF DAVID" en="heir to the throne" />
        <Card f={f} a={zAbr} b={zGab + 6} x={1470} y={560} w={460} h={240} top="SON OF ABRAHAM" en="blessing for every nation" />
      </Gp>
      <Gp o={fi(f, zGab)}>
        <Beam x={1060} w={300} o={0.7} f={f} />
        {F(f, zGab, undefined, DP(800, {hair: 'bare', beard: 'none', arm: ezArm(f, zGab + 20, [-5, -36], [-90, -20], 14)}))}
        {F(f, zGab + 10, undefined, MARY(1080, {flip: true, head: 10}))}
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={z0} b={zQ}>THE FIRST VERSE OF THE NEW TESTAMENT</Ref>
      <Q f={f} a={zQ} b={zGab} refText="MATTHEW 1:1" eng="“This is the genealogy of Jesus the Messiah the *son of David*, the *son of Abraham*.”" keys={[at('the son of David', 1), at('the son of Abraham', 1)]} y={90} />
      <Name f={f} a={zGab + 20} b={zQ2} x={940} y={900} en="GABRIEL AND MARY" />
      <Q f={f} a={zQ2 - 10} b={zEnd} refText="LUKE 1:32–33" eng="“The Lord God will give him the *throne of his father David*, and he will reign over Jacob’s descendants forever; his kingdom will never end.”" keys={[at('the throne of his father David')]} />
    </>,
  }));
}

// 27 THE CUP -----------------------------------------------------------------------------------
{
  const aa0 = at('And then, on the night before'), aaCup = at('He took a cup of wine'), aaQ = at('This cup is the new covenant in my blood', 1), aaMos = at('Moses had said'), aaCut = at('The covenant Jeremiah promised'), aaEnd = at('Now go back to that dark night');
  push(aa0, (f) => ({
    svg: <>
      <Spot id="aa27" x={960} y={600} r={820} />
      <Ground id="aa27g" />
      <Gp o={win(f, aa0, aaMos + 6)}>
        <Beam x={960} w={300} o={0.8} f={f} />
        <Line u w={2.4} p={pr(f, aa0, 30)} d={`M560,${GY - 200} L1360,${GY - 200} M600,${GY - 200} L600,${GY} M1320,${GY - 200} L1320,${GY}`} />
        {F(f, aa0, aaMos + 6, JP(960, {robe: 'seat', bench: false, arm: ezArm(f, aaCup + 10, [-5, -36], [-60, -80], 14)}))}
        {[0, 1, 2, 3].map((k) => F(f, aa0 + 8 + k * 5, aaMos + 6, BP(k < 2 ? 560 + k * 150 : 1210 + (k - 2) * 150, {robe: 'seat', flip: k >= 2, sc: 0.28, m: 'gold', head: 6}), 'dc' + k))}
        <Cup x={1040} y={ez(f, aaCup + 10, GY - 230, GY - 330, 14)} s={0.8} o={fi(f, aaCup)} />
      </Gp>
      <Gp o={fi(f, aaMos)}>
        <Card f={f} a={aaMos} x={600} y={560} w={600} h={270} top="EXODUS 24:8" en="“the blood of the covenant”" />
        <Card f={f} a={aaMos + 40} x={1320} y={560} w={600} h={270} top="LUKE 22:20" en="“the new covenant in my blood”" hl={fi(f, aaCut)} />
        <Arrow x0={920} y0={560} x1={1000} y1={560} p={pr(f, aaMos + 40, 16)} />
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={aa0} b={aaCup}>THE NIGHT BEFORE HE DIED</Ref>
      <Note f={f} a={aaCup} b={aaQ} y={140} size={44}>listen for Moses behind his words</Note>
      <Q f={f} a={aaQ} b={aaMos} refText="LUKE 22:20" eng="“This cup is the *new covenant in my blood*, which is poured out for you.”" keys={[at('new covenant in my blood', 1)]} y={110} />
      <Big f={f} a={aaCut} b={aaEnd} y={220} size={60} c={TXT.gold}>CUT THAT NIGHT, IN HIS BODY</Big>
    </>,
  }));
}

// 28 THE CURSE BORNE ---------------------------------------------------------------------------
{
  const bb0 = at('Now go back to that dark night'), bbSw = at('God had sworn that he would bear'), bbBroke = at('And it was broken again'), bbHill = at('So on a hill outside Jerusalem'), bbQ = at('Christ redeemed us'), bbFire = at('The fire walked the path alone'), bbEnd = at('Look at how every covenant');
  push(bb0, (f) => {
    const fx = kf(f, [[bb0 + 20, 380], [bbHill, 1500]], bbHill - bb0 - 20);
    return {
      svg: <>
        <Night o={1} />
        <Spot id="bb28" x={960} y={600} r={760} a={0.45} />
        <Ground id="bb28g" />
        <Gp o={1 - fi(f, bbHill, 40)}>
          <Pieces f={f} gap={1} />
          <Firepot x={fx} y={GY} f={f} s={0.7} o={fi(f, bb0 + 10)} />
          {F(f, bb0, bbHill + 30, DP(200, {beard: 'long', hair: 'cloth', robe: 'kneel', bend: 22, head: 30}))}
        </Gp>
        <Gp o={fi(f, bbHill)}>
          <Beam x={960} w={300} o={0.9} f={f} bottom={GY - 120} />
          <g transform={`translate(960 ${GY}) scale(0.95)`} opacity={1}>
            <Line w={2.4} p={pr(f, bbHill, 60)} d="M-560,0 C-300,-60 -140,-120 0,-130 C140,-120 300,-60 560,0 M-10,-130 L-10,-560 L10,-560 L10,-130 M-140,-460 L140,-460 L140,-440 L-140,-440 Z" />
          </g>
          <path d={`M300,${GY + 4} L1620,${GY + 4}`} stroke="#7a2a1c" strokeWidth={5} opacity={0.6 * fi(f, bbFire)} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={bb0 + 6} b={bbSw} y={140} size={44}>back to that dark night</Note>
        <Note f={f} a={bbSw} b={bbBroke} y={140} size={44}>if it is broken, God bears the curse</Note>
        <Note f={f} a={bbBroke} b={bbHill} y={140} size={44}>broken by Israel, and by every one of us</Note>
        <Q f={f} a={bbQ} b={bbEnd} refText="GALATIANS 3:13" eng="“Christ redeemed us from the curse of the law by *becoming a curse for us*.”" keys={[at('becoming a curse for us')]} y={90} />
      </>,
    };
  });
}

// 29 EVERY COVENANT IN HIM ---------------------------------------------------------------------
{
  const cc0 = at('Look at how every covenant'), ccAdam = at('Adam broke faith and brought death'), ccQ = at('For just as through the disobedience'), ccNoah = at('Noah was carried safely'),
    ccAbr = at('Abraham was promised blessing'), ccSin = at('At Sinai the law was written on stone'), ccPh = at('Phinehas was promised'), ccDav = at('David was promised a king'), ccEnd = at('That is why the Bible is called');
  const seq: [StoneK, number][] = [['adam', ccAdam], ['noah', ccNoah], ['abr', ccAbr], ['sinai', ccSin], ['phin', ccPh], ['david', ccDav]];
  push(cc0, (f) => {
    let hl: StoneK | null = null;
    for (const [k, t] of seq) if (f >= t) hl = k;
    const keyT = ccDav + 120;
    if (f >= keyT) hl = 'new';
    return {
      svg: <>
        <Spot id="cc29" x={960} y={640} r={820} />
        <Ground id="cc29g" />
        <Arch f={f} cy={900} R={580} r={410} n={{...ALL6, new: ramp(f, keyT, 26)}} hl={hl} dimOthers={0.8} crack={1 - fi(f, keyT)} />
        <Beam x={960} w={300} o={0.9 * fi(f, keyT + 10, 30)} f={f} bottom={GY} />
        {F(f, keyT + 10, undefined, JP(960, {sc: 0.27}))}
      </>,
      html: <>
        <Note f={f} a={cc0 + 6} b={ccAdam} y={110} size={46}>every covenant comes together in him</Note>
        <Note f={f} a={ccAdam} b={ccQ} y={110} size={44}>Adam brought death</Note>
        <Q f={f} a={ccQ} b={ccNoah} refText="ROMANS 5:19" eng="“For just as through the disobedience of the one man the many were made sinners, so also through the obedience of the one man the many will be *made righteous*.”" keys={[at('made righteous')]} y={40} size={46} />
        <Note f={f} a={ccNoah} b={ccAbr} y={110} size={44}>carried safely through judgment</Note>
        <Note f={f} a={ccAbr} b={ccSin} y={110} size={44}>people from every nation worship Abraham’s God</Note>
        <Note f={f} a={ccSin} b={ccPh} y={110} size={44}>the law written on human hearts</Note>
        <Note f={f} a={ccPh} b={ccDav} y={110} size={44}>our great high priest, who lives forever</Note>
        <Note f={f} a={ccDav} b={keyT} y={110} size={44}>a king who rose to take the throne</Note>
        <Big f={f} a={keyT + 10} b={ccEnd} y={180} size={64} c={TXT.gold}>THE NEW COVENANT · JESUS</Big>
      </>,
    };
  });
}

// 30 ONE STORY ---------------------------------------------------------------------------------
{
  const dd0 = at('That is why the Bible is called'), ddOne = at('It is one long story'), ddBoth = at('until he finally keeps both'), ddEnd = at('So if you have ever felt');
  push(dd0, (f) => ({
    svg: <>
      <Spot id="dd30" x={960} y={600} r={820} />
      <Ground id="dd30g" />
      <Book x={960} y={GY - 10} s={1.2} p={pr(f, dd0, 30)} />
      <Arch f={f} cy={520} R={300} r={205} n={{...ALL6, new: 1}} lab={0} sub={0} o={0.85 * fi(f, ddOne)} />
      <Beam x={960} w={320} o={0.7 * fi(f, ddBoth)} f={f} />
    </>,
    html: <>
      <Big f={f} a={dd0} b={ddOne} y={200} size={64} c={TXT.gold}>OLD TESTAMENT · NEW TESTAMENT</Big>
      <Note f={f} a={ddOne} b={ddBoth} y={120} size={44}>promises made, promises broken</Note>
      <Note f={f} a={ddBoth} b={ddEnd} y={120} size={46} c={TXT.gold}>he keeps both sides of the promise himself</Note>
    </>,
  }));
}

// 31 FOR YOU -----------------------------------------------------------------------------------
{
  const ee0 = at('So if you have ever felt'), eeNew = at('The new covenant does not depend'), eeWalk = at('You do not have to walk the path'), eeHe = at('He already walked it for you'), eeEnd = at('If this video blessed');
  push(ee0, (f) => ({
    svg: <>
      <Spot id="ee31" x={760} y={600} r={820} a={0.45 + 0.2 * fi(f, eeNew)} />
      <Ground id="ee31g" />
      <Gp o={fi(f, eeWalk - 20) * 0.6}><Pieces f={f} gap={1} x0={-60} /></Gp>
      <Beam x={360} w={280} o={0.75 * fi(f, eeNew)} f={f} />
      {F(f, ee0, undefined, BP(360, {robe: 'kneel', bend: ez(f, eeNew + 20, 22, 6, 20), head: ez(f, eeNew + 20, 30, -6, 20)}))}
      {WK(f, eeWalk, undefined, eeWalk + 10, eeHe + 50, 1880, 560, JP(0, {arm: f > eeHe + 50 ? ezArm(f, eeHe + 50, [-5, -36], [-60, -10], 14) : [-5, -36]}), 'jw', 66)}
    </>,
    html: <>
      <Note f={f} a={ee0 + 6} b={eeNew} y={140} size={44}>if you broke your side of the deal</Note>
      <Note f={f} a={eeNew} b={eeWalk} y={140} size={44}>it depends on his blood and his word</Note>
      <Big f={f} a={eeHe} b={eeEnd} y={200} size={64} c={TXT.gold}>HE ALREADY WALKED IT FOR YOU</Big>
    </>,
  }));
}

// 32 OUTRO -------------------------------------------------------------------------------------
{
  const ff0 = at('If this video blessed'), ffLove = at('And always remember'), ffSee = at('See you on the next one');
  push(ff0, (f) => ({
    svg: <>
      <Spot id="ff32" x={960} y={600} r={820} />
      <Ground id="ff32g" />
      <Beam x={960} w={320} o={0.85} f={f} />
      {F(f, ff0, undefined, JP(960, {arm: ezArm(f, ffLove, [-5, -36], [-60, -10], 14)}))}
    </>,
    html: <>
      <Big f={f} a={ff0 + 6} b={ffLove} y={220} size={60} c={TXT.gold}>LIKE · SUBSCRIBE · SHARE</Big>
      <Big f={f} a={ffLove} b={ffSee} y={220} size={72} c={TXT.gold}>JESUS LOVES YOU</Big>
      <Note f={f} a={ffSee} y={180} size={50}>see you on the next one</Note>
    </>,
  }));
}
