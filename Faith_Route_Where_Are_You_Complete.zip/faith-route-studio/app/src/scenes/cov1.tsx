import React from 'react';
import {at, win, fi, kf, ramp, eio, eout} from '../lib';
import {Fig, FigP, Hills, Line, Tent, Pyramids, Throne, Sheep, Colonnade, TXT} from '../fig';
import {Ref, Big, Note, Name} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Altar, Mountain} from '../extra';
import {Book, Stars, Boat, Waves, Ring} from '../props';
import {Tablets} from '../famprops';
import {FigTree, Coins} from '../figprops';
import {JP, DP, BP, SP, F, Gp, pr, ez, ezArm, turn, walkX} from '../kit';
import {Beam, Card, Q, Arch, StoneK, Halves, Beast, Bird, Firepot, Rainbow, Bow, City, Arrow} from '../covprops';

export const CV1: Scene[] = [];
const push = (start: number, render: Scene['render']) => CV1.push({start, render});

/* ---------- cast ---------- */
export const ADAM = (x: number, o: Partial<FigP> = {}) => DP(x, {beard: 'short', hair: 'bare', ...o});
export const EVE = (x: number, o: Partial<FigP> = {}) => DP(x, {beard: 'none', hair: 'long', sc: 0.29, ...o});
export const NOAH = (x: number, o: Partial<FigP> = {}) => DP(x, {beard: 'long', hair: 'cloth', ...o});
export const ABR = (x: number, o: Partial<FigP> = {}) => DP(x, {beard: 'long', hair: 'cloth', prop: 'staff', ...o});
export const SAR = (x: number, o: Partial<FigP> = {}) => DP(x, {beard: 'none', hair: 'veil', sc: 0.29, ...o});
export const MOSES = (x: number, o: Partial<FigP> = {}) => DP(x, {beard: 'long', hair: 'cloth', mantle: true, prop: 'staff', ...o});
export const PPL = (x: number, o: Partial<FigP> = {}) => BP(x, {sc: 0.27, ...o});
export const PROPH = (x: number, o: Partial<FigP> = {}) => DP(x, {beard: 'long', hair: 'cloth', mantle: true, ...o});

/** walking figure: moves x0->x1 between t0..t1, faces direction of travel, visible a..b */
export const WK = (f: number, a: number, b: number | undefined, t0: number, t1: number, x0: number, x1: number, p: FigP, k?: string | number, stride = 70) => {
  const w = walkX(f, t0, t1, x0, x1, stride);
  return <Fig key={k} {...p} x={w.x} walk={w.walk} wa={w.wa} face={p.face ?? (x1 >= x0 ? 1 : -1)} o={(p.o ?? 1) * win(f, a, b, 16)} />;
};
/** arch stones placed by frame: drop each stone at its frame */
export const stones = (f: number, t: Partial<Record<StoneK, number>>, d = 20) => {
  const n: Partial<Record<StoneK, number>> = {};
  for (const k of Object.keys(t) as StoneK[]) n[k] = ramp(f, t[k]!, d);
  return n;
};
/** night sky */
export const Night: React.FC<{o?: number}> = ({o = 1}) => <><rect width={1920} height={1080} fill="#050403" opacity={0.45 * o} /><Stars o={0.75 * o} seed={11} n={70} y1={520} /></>;

/** the covenant night: three animals cut in two, birds, a path of blood. gap 0..1 */
export const Pieces: React.FC<{f: number; gap: number; o?: number; app?: number[]; path?: number; x0?: number}> = ({f, gap, o = 1, app = [1, 1, 1, 1], path = 1, x0 = 0}) => (
  <g opacity={o}>
    <path d={`M${300 + x0},${GY + 4} L${1780 + x0},${GY + 4}`} stroke="#7a2a1c" strokeWidth={5} opacity={0.75} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - path} />
    <path d={`M${300 + x0},${GY + 4} L${1780 + x0},${GY + 4}`} stroke="#9a3a22" strokeWidth={14} opacity={0.18} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - path} filter="url(#lglow)" />
    <Halves id="pc1" x={720 + x0} y={GY} gap={gap * 70}>{() => <Beast x={720 + x0} y={GY} s={0.9} kind="heifer" o={eio(app[0])} />}</Halves>
    <Halves id="pc2" x={1090 + x0} y={GY} gap={gap * 60}>{() => <Beast x={1090 + x0} y={GY} s={0.95} kind="goat" o={eio(app[1])} />}</Halves>
    <Halves id="pc3" x={1420 + x0} y={GY} gap={gap * 60}>{() => <Beast x={1420 + x0} y={GY} s={0.95} kind="ram" o={eio(app[2])} />}</Halves>
    <Bird x={1640 + x0} y={GY} s={1} o={eio(app[3])} />
    <Bird x={1730 + x0} y={GY} s={0.9} o={eio(app[3])} />
  </g>
);

// 0 HOOK --------------------------------------------------------------------------------------
{
  const aLib = at('or maybe a library'), aWord = at('But the word printed'), aTest = at('Testament is an old word'), aOT = at('The Old Testament and the New'),
    aBook = at('The whole book is organized'), aArch = at('like stones in an arch'), aMiss = at('Miss them'), aFol = at('Follow them in order'),
    aSo = at('So what are these covenants'), aWhy = at('why did he walk alone'), aEnd = at('So what exactly is a covenant');
  const order: StoneK[] = ['adam', 'noah', 'abr', 'sinai', 'phin', 'david', 'new'];
  push(0, (f) => {
    const t: Partial<Record<StoneK, number>> = {};
    order.forEach((k, i) => (t[k] = aBook + 20 + i * ((aArch - aBook - 10) / 7)));
    const sc = kf(f, [[0, 0], [aMiss, 1], [aFol, 0]], 24);
    return {
      svg: <>
        <Spot id="h0" x={960} y={560} r={820} />
        <Gp o={win(f, 0, aBook + 6)}>
          <Ground id="h0g" />
          <Book x={960} y={GY - 10} s={1.25} p={pr(f, 0, 40)} lines={fi(f, 8, 40)} />
          <Beam x={960} w={300} o={0.75 * fi(f, 4, 30)} f={f} />
          <Card f={f} a={aTest} b={aOT} x={640} y={330} w={560} h={210} top="TESTAMENT" big="TESTAMENTUM" />
          <Card f={f} a={aTest + 14} b={aOT} x={1280} y={330} w={560} h={210} top="COVENANT" heb="בְּרִית" />
          <text x={960} y={348} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={56} opacity={win(f, aTest + 20, aOT)}>=</text>
          <Card f={f} a={aOT} b={aBook + 6} x={640} y={330} w={560} h={210} top="OLD TESTAMENT" en="the old covenant" />
          <Card f={f} a={aOT + 10} b={aBook + 6} x={1280} y={330} w={560} h={210} top="NEW TESTAMENT" en="the new covenant" />
        </Gp>
        <Gp o={win(f, aBook, aWhy + 4)}>
          <Ground id="h0g2" o={0.6} />
          <Arch f={f} n={stones(f, t, 18)} scatter={sc} lab={0.85} sub={0} o={1 - 0.6 * fi(f, aSo, 30)} />
        </Gp>
        <Gp o={fi(f, aWhy - 4, 24)}>
          <Night />
          <Ground id="h0g3" o={0.7} />
          <Pieces f={f} gap={1} />
          {F(f, aWhy, undefined, ABR(220, {robe: 'kneel', bend: 22, head: 30, prop: null, sc: 0.29}))}
          <Firepot x={kf(f, [[aWhy, 420], [aEnd, 1540]], aEnd - aWhy)} y={GY} f={f} s={0.7} o={fi(f, aWhy + 20, 30)} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={6} b={aLib} y={150} size={44}>a collection of rules?</Note>
        <Note f={f} a={aLib} b={aWord} y={150} size={44}>a library of inspiring stories?</Note>
        <Big f={f} a={aWord + 8} b={aTest} y={250} size={110} c={TXT.gold} ls={0.2}>TESTAMENT</Big>
        <Ref f={f} a={aTest} b={aBook} y={120}>AN OLD WORD FOR COVENANT</Ref>
        <Note f={f} a={aBook + 6} b={aMiss} y={110} size={44}>one promise built on another</Note>
        <Note f={f} a={aMiss} b={aFol} y={110} size={44}>scattered pieces</Note>
        <Big f={f} a={aFol} b={aSo} y={170} size={64} c={TXT.gold}>GENESIS · · · REVELATION</Big>
        <Note f={f} a={aSo} b={aWhy} y={130} size={46}>what are these covenants?</Note>
        <Note f={f} a={aWhy + 10} b={aEnd} y={130} size={44}>a path of blood, one dark night</Note>
      </>,
    };
  });
}

// 1 WHAT IS A COVENANT ------------------------------------------------------------------------
{
  const b0 = at('So what exactly is a covenant'), bCon = at('A contract trades'), bBind = at('A covenant binds'), bKing = at('Kings made them'),
    bFam = at('families made them in marriage'), bHeb = at('The Hebrew phrase'), bCut = at('because the agreement was often'), bHold = at('Hold on to that picture'), bEnd = at('Many Bible teachers');
  push(b0, (f) => {
    const meet = ezArm(f, bBind + 20, [-5, -36], [-62, -14], 14);
    return {
      svg: <>
        <Spot id="b1" x={960} y={600} r={800} />
        <Ground id="b1g" />
        <Gp o={win(f, b0, bKing)}>
          {WK(f, b0, bKing, bBind, bBind + 30, 700, 800, BP(0, {arm: meet}), 'b1a')}
          {WK(f, b0, bKing, bBind, bBind + 30, 1220, 1120, BP(0, {arm: meet, beard: 'long'}), 'b1b')}
          <Gp o={win(f, bCon, bBind + 10)}>
            <Coins x={960} y={GY - 40} t={eout(ramp(f, bCon + 10, 30))} />
          </Gp>
          <Gp o={fi(f, bBind + 30)}>
            <circle cx={960} cy={GY - 300} r={140} fill="url(#halo)" opacity={0.7} />
            <Line u w={2} d={`M800,${GY - 330} C880,${GY - 380} 1040,${GY - 380} 1120,${GY - 330}`} p={pr(f, bBind + 30, 30)} o={0.7} />
          </Gp>
        </Gp>
        <Gp o={win(f, bKing, bFam)}>
          {F(f, bKing, bFam, SP(1180, {robe: 'seat', bench: true, crown: true, flip: true}))}
          {F(f, bKing + 8, bFam, BP(760, {bend: 20, head: 18, arm: [-30, -20]}))}
          <Throne x={1240} y={GY} s={1} p={pr(f, bKing)} o={0.6} />
        </Gp>
        <Gp o={win(f, bFam, bHeb)}>
          {F(f, bFam, bHeb, DP(840, {arm: [-30, -30]}))}
          {F(f, bFam + 6, bHeb, DP(1080, {hair: 'veil', beard: 'none', sc: 0.29, flip: true, arm: [-30, -30]}))}
          <Ring x={960} y={GY - 360} r={56} p={pr(f, bFam + 10, 30)} />
        </Gp>
        <Gp o={fi(f, bHeb)}>
          <Card f={f} a={bHeb} x={960} y={360} w={640} h={270} top="KARAT BERIT" heb="כָּרַת בְּרִית" en="to cut a covenant" />
          <Halves id="b1h" x={960} y={GY} gap={70 * eio(ramp(f, bCut + 20, 30))}>{() => <Beast x={960} y={GY} s={1.1} kind="goat" o={fi(f, bCut)} />}</Halves>
          <Beam x={960} w={360} o={0.5 * fi(f, bHold, 30)} f={f} />
        </Gp>
      </>,
      html: <>
        <Big f={f} a={b0} b={bCon} y={220} size={96} c={TXT.gold} ls={0.2}>COVENANT</Big>
        <Note f={f} a={b0 + 20} b={bCon} y={300} size={42}>far more serious than a contract</Note>
        <Ref f={f} a={bCon} b={bBind} y={160}>CONTRACT · TRADES GOODS</Ref>
        <Ref f={f} a={bBind} b={bKing} y={160}>COVENANT · BINDS PEOPLE TOGETHER</Ref>
        <Note f={f} a={bBind + 30} b={bKing} y={240} size={42}>sealed by an oath and a sign</Note>
        <Ref f={f} a={bKing} b={bFam} y={160}>KINGS AND NATIONS</Ref>
        <Ref f={f} a={bFam} b={bHeb} y={160}>HUSBAND AND WIFE</Ref>
        <Note f={f} a={bHold} b={bEnd} y={540} size={40} c={TXT.gold}>hold on to that picture</Note>
      </>,
    };
  });
}

// 2 ADAM --------------------------------------------------------------------------------------
{
  const c0 = at('Many Bible teachers'), cNev = at('Genesis never actually uses'), cCre = at('God created Adam and Eve'), cCmd = at('You must not eat'),
    cHos = at('Centuries later the prophet Hosea'), cAs = at('As at Adam'), cWhe = at('Whether or not you call'), cBroke = at('The first man broke faith'), cEvery = at('Every covenant that follows is'), cEnd = at('The first time the actual word');
  push(c0, (f) => {
    const face = f < cBroke + 10 ? 1 : turn(f, cBroke + 10, 1, 12);
    const gone = cBroke + 26;
    return {
      svg: <>
        <Spot id="c2" x={1150} y={560} r={800} />
        <Gp o={win(f, c0, cEvery)}>
          <Ground id="c2g" cx={1150} />
          <FigTree x={1320} y={GY} s={0.9} p={pr(f, c0, 50)} leaf={fi(f, c0 + 20, 40) * (1 - 0.8 * ramp(f, cBroke + 10, 60))} fruit={fi(f, cCmd, 30)} wither={ramp(f, cBroke + 10, 60)} />
          <Beam x={1300} w={320} o={0.55 * fi(f, c0 + 10, 30) * (1 - fi(f, cBroke, 40))} f={f} />
          {f < gone
            ? <>
                {WK(f, cCre, cEvery, cCre, cCre + 70, 200, 760, ADAM(0, {face}), 'ad')}
                {WK(f, cCre + 8, cEvery, cCre + 8, cCre + 78, 80, 620, EVE(0, {face}), 'ev')}
              </>
            : <>
                {WK(f, cCre, cEvery, gone, gone + 80, 760, 360, ADAM(0, {head: 12}), 'ad')}
                {WK(f, cCre, cEvery, gone + 6, gone + 86, 620, 220, EVE(0, {head: 12}), 'ev')}
              </>}
        </Gp>
        <Gp o={fi(f, cEvery)}>
          <Ground id="c2g2" o={0.6} />
          <Arch f={f} n={stones(f, {adam: cEvery + 10})} hl="adam" crack={fi(f, cEvery + 30)} />
        </Gp>
      </>,
      html: <>
        <Ref f={f} a={c0} b={cNev}>THE GARDEN OF EDEN</Ref>
        <Note f={f} a={cNev} b={cCre} y={140} size={44}>the word is missing, the shape is there</Note>
        <Ref f={f} a={cCre} b={cCmd}>ONE GARDEN · ONE COMMAND</Ref>
        <Q f={f} a={cCmd} b={cHos} refText="GENESIS 2:17" eng="“You must not eat from the tree of the knowledge of good and evil, for when you eat from it you will *certainly die*.”" keys={[at('certainly die')]} />
        <Q f={f} a={cHos + 6} b={cWhe} refText="HOSEA 6:7" eng="“As at Adam, they have *broken the covenant*.”" keys={[at('broken the covenant')]} y={110} />
        <Note f={f} a={cWhe} b={cBroke} y={140} size={44}>call it what you like</Note>
        <Big f={f} a={cBroke} b={cEvery} y={210} size={70} c={TXT.gold}>FAITH BROKEN · DEATH ENTERS</Big>
        <Note f={f} a={cEvery + 10} b={cEnd} y={110} size={44}>every covenant after this is God’s answer</Note>
      </>,
    };
  });
}

// 3 NOAH --------------------------------------------------------------------------------------
{
  const d0 = at('The first time the actual word'), dVio = at('The earth had become'), dBef = at('But before the rain came'), dQ = at('But I will establish my covenant'),
    dNot = at('Notice that the very first covenant'), dEnd = at('When the waters went down');
  push(d0, (f) => {
    const sea = kf(f, [[dVio, 0], [dVio + 20, 1]], 90);
    return {
      svg: <>
        <Spot id="d3" x={960} y={560} r={820} />
        <Gp o={win(f, d0, dNot)}>
          <Ground id="d3g" />
          <Card f={f} a={d0 + 10} b={dVio} x={960} y={500} w={560} h={260} top="FIRST APPEARANCE" heb="בְּרִית" en="covenant · Genesis 6" />
          <Gp o={win(f, dVio, dBef)}>
            {[0, 1, 2, 3, 4].map((k) => F(f, dVio + k * 5, dBef, BP(380 + k * 290, {prop: k % 2 ? 'spear' : null, hair: k % 2 ? 'helmet' : 'cloth', flip: k % 2 === 1, arm: k % 2 ? [-40, -30] : [-70, -40], bend: 6}), 'v' + k))}
            <rect width={1920} height={1080} fill="#000" opacity={0.3} />
          </Gp>
          <Gp o={fi(f, dBef)}>
            <Beam x={960} w={300} o={0.85} f={f} />
            {F(f, dBef, undefined, NOAH(960, {head: -8}))}
            {[0, 1, 2, 3, 4, 5, 6].map((k) => F(f, dQ + 10 + k * 6, undefined, (k % 2 ? EVE : NOAH)(k < 3 ? 520 + k * 120 : 1160 + (k - 3) * 110, {sc: 0.26, beard: k % 2 ? 'none' : 'short', flip: k >= 3, o: 0.9}), 'fam' + k))}
          </Gp>
        </Gp>
        <Gp o={fi(f, dNot)}>
          <Waves y={GY - 40} o={0.65} />
          <Waves y={GY + 40} o={0.4} />
          <g transform={`translate(0 ${Math.sin(f / 22) * 4})`}><Boat x={960} y={GY - 30} s={1.2} p={pr(f, dNot, 30)} /></g>
          <Beam x={960} w={420} o={0.7} f={f} bottom={GY - 60} />
        </Gp>
        <Gp o={win(f, dVio + 30, dBef) * sea}><Waves y={GY + 30 - 40 * sea} o={0.4} /></Gp>
      </>,
      html: <>
        <Ref f={f} a={d0} b={dVio}>THE DAYS OF NOAH</Ref>
        <Note f={f} a={dVio} b={dBef} y={140} size={44}>the earth was full of violence</Note>
        <Q f={f} a={dQ} b={dNot} refText="GENESIS 6:18" eng="“But I will establish *my covenant* with you, and you will enter the ark, you and your sons and your wife and your sons’ wives with you.”" keys={[at('my covenant with you', 1)]} />
        <Big f={f} a={dNot + 10} b={dEnd} y={210} size={64} c={TXT.gold}>RESCUE IN THE MIDDLE OF JUDGMENT</Big>
      </>,
    };
  });
}

// 4 NOAH AFTER THE FLOOD, RAINBOW ------------------------------------------------------------
{
  const e0 = at('When the waters went down'), eGod = at('God spoke again'), eQ = at('I establish my covenant with you'), eSign = at('Then he gave a sign'), eQ2 = at('I have set my rainbow'), eEnd = at('The Hebrew word for rainbow');
  push(e0, (f) => ({
    svg: <>
      <Spot id="e4" x={960} y={620} r={820} />
      <Rainbow x={960} y={GY} R={640} p={pr(f, eSign + 10, 60)} o={fi(f, eSign + 10)} />
      <Ground id="e4g" />
      <Mountain x={420} y={GY} s={0.8} p={pr(f, e0, 30)} o={0.8} />
      <Boat x={400} y={GY - 300} s={0.55} o={0.9 * fi(f, e0)} />
      {WK(f, e0, undefined, e0 + 20, e0 + 120, 640, 900, NOAH(0, {}), 'no')}
      <Beam x={900} w={300} o={0.6 * win(f, eGod, eSign + 20)} f={f} />
      {[0, 1, 2].map((k) => <Sheep key={k} x={1180 + k * 170} y={GY} s={0.75} m="bronze" o={fi(f, eGod + 20 + k * 8)} graze={k === 1} />)}
      <Beast x={1720} y={GY} s={0.8} kind="heifer" o={fi(f, eGod + 44)} />
    </>,
    html: <>
      <Note f={f} a={e0 + 6} b={eQ} y={140} size={44}>dry ground</Note>
      <Q f={f} a={eQ} b={eSign} refText="GENESIS 9:11" eng="“I establish my covenant with you: *Never again* will all life be destroyed by the waters of a flood; never again will there be a flood to destroy the earth.”" keys={[at('Never again will all')]} y={60} size={48} />
      <Ref f={f} a={eSign} b={eQ2}>THE SIGN</Ref>
      <Q f={f} a={eQ2} b={eEnd} refText="GENESIS 9:13" eng="“I have set my rainbow in the clouds, and it will be *the sign of the covenant* between me and the earth.”" keys={[at('the sign of the covenant', 1)]} y={60} size={48} />
    </>,
  }));
}

// 5 QESHET: THE BOW ---------------------------------------------------------------------------
{
  const f0 = at('The Hebrew word for rainbow'), fMany = at('Many readers have noticed'), fBow = at('A bow hung in the sky'), fHang = at('The Almighty was hanging'),
    fAsk = at('This covenant asked nothing'), fKeep = at('It was a promise to keep'), fEvery = at('Every rainbow you have ever seen'), fEnd = at('But a stable world');
  push(f0, (f) => {
    const rot = ez(f, fBow + 6, 0, -90, 30);
    const by = ez(f, fBow + 6, 600, 470, 30);
    return {
      svg: <>
        <Spot id="f5" x={960} y={560} r={820} />
        <Gp o={win(f, f0, fAsk)}>
          <Card f={f} a={f0 + 6} b={fBow} x={960} y={250} w={560} h={260} top="QESHET" heb="קֶשֶׁת" en="a warrior’s bow" />
          <Bow x={960} y={by} s={0.9} rot={rot} p={pr(f, f0 + 20, 40)} arrow={fi(f, f0 + 50) * (1 - fi(f, fHang + 10, 30))} o={1 - fi(f, fHang + 40, 40)} />
          <Rainbow x={960} y={GY} R={600} p={pr(f, fHang + 30, 60)} o={fi(f, fHang + 30)} />
          <Ground id="f5g" o={fi(f, fBow)} />
          <Gp o={fi(f, fBow + 30)}>
            <Arrow x0={960} y0={620} x1={960} y1={330} p={pr(f, fBow + 30, 24)} o={1 - fi(f, fHang + 20)} />
          </Gp>
        </Gp>
        <Gp o={win(f, fAsk, fEvery)}>
          <Rainbow x={960} y={GY} R={600} />
          <Ground id="f5g2" />
          {F(f, fAsk, fEvery, NOAH(960, {head: -14}))}
          <Hills y={GY} o={0.35} />
        </Gp>
        <Gp o={fi(f, fEvery)}>
          <Ground id="f5g3" o={0.6} />
          <Rainbow x={960} y={GY} R={760} o={0.5} />
          <Arch f={f} n={stones(f, {adam: fEvery - 30, noah: fEvery + 16})} hl="noah" dimOthers={1} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={fMany} b={fBow} y={890} size={42}>the same word as the weapon</Note>
        <Note f={f} a={fBow} b={fHang} y={140} size={44}>pointed away from the earth, toward heaven</Note>
        <Big f={f} a={fHang} b={fAsk} y={200} size={68} c={TXT.gold}>THE WEAPON HUNG UP</Big>
        <Note f={f} a={fAsk} b={fKeep} y={140} size={44}>it asked nothing from Noah</Note>
        <Note f={f} a={fKeep} b={fEvery} y={140} size={44}>keeping the world going until rescue comes</Note>
        <Note f={f} a={fEvery + 10} b={fEnd} y={110} size={44}>every rainbow is a reminder of that oath</Note>
      </>,
    };
  });
}

// 6-7 ABRAM CALLED -----------------------------------------------------------------------------
{
  const g0 = at('But a stable world'), gCho = at('by choosing one man'), h0 = at('Abram was living in a city'), hCall = at('when the LORD called him'),
    hQ = at('I will make you into a great nation'), hQ2 = at('I will bless those who bless you'), hLast = at('That last line is the key'), hWorld = at('meant to reach the whole world'), hEnd = at('Years passed, and Abram');
  push(g0, (f) => ({
    svg: <>
      <Spot id="g6" x={960} y={560} r={820} />
      <Ground id="g6g" />
      <Gp o={win(f, g0, gCho + 10)}>
        <Arch f={f} n={{adam: 1, noah: 1}} lab={1} sub={1} o={0.9} />
      </Gp>
      <Gp o={fi(f, gCho)}>
        <City x={560} y={GY} s={0.9} p={pr(f, h0, 50)} o={0.7 * win(f, h0, hLast)} />
        <Beam x={kf(f, [[gCho, 960], [hQ + 40, 1300]], hLast - hQ - 40)} w={300} o={0.8 * (1 - 0.6 * fi(f, hLast, 30))} f={f} />
        {WK(f, gCho, undefined, hQ + 40, hLast, 960, 1300, ABR(0, {head: f < hQ ? -10 : 0}), 'ab', 64)}
        {WK(f, h0 + 30, undefined, hQ + 48, hLast + 8, 820, 1150, SAR(0, {}), 'sa', 64)}
        {Array.from({length: 9}, (_, k) => F(f, hWorld + k * 4, undefined, PPL(110 + k * 200 + (k > 4 ? 60 : 0), {sc: 0.2, m: k % 3 === 0 ? 'silver' : 'bronze', flip: k > 4, o: 0.85}), 'n' + k))}
      </Gp>
    </>,
    html: <>
      <Note f={f} a={g0 + 6} b={gCho} y={110} size={44}>a stable world, still a broken relationship</Note>
      <Ref f={f} a={gCho} b={h0 + 10}>ONE MAN</Ref>
      <Name f={f} a={h0} b={hCall + 20} x={560} y={900} en="UR · SOUTHERN IRAQ" />
      <Q f={f} a={hCall + 10} b={hQ2} refText="GENESIS 12:2" eng="“I will make you into a *great nation*, and I will bless you; I will make your name great, and you will be a blessing.”" keys={[at('great nation')]} />
      <Q f={f} a={hQ2} b={hLast} refText="GENESIS 12:3" eng="“I will bless those who bless you, and whoever curses you I will curse; and *all peoples on earth* will be blessed through you.”" keys={[at('all peoples on earth', 1)]} />
      <Big f={f} a={hLast + 6} b={hEnd} y={200} size={64} c={TXT.gold}>ONE FAMILY · THE WHOLE WORLD</Big>
    </>,
  }));
}

// 8-9 THE PIECES -------------------------------------------------------------------------------
{
  const i0 = at('Years passed, and Abram'), iAsk = at('he asked God how'), iHere = at('And here the picture'), iHeif = at('a heifer'), iGoat = at('a goat and a ram'), iRam = at('and a ram'),
    iDove = at('along with a dove'), iCut = at('Abram cut the large animals'), iPath = at('with a path of blood'),
    j0 = at('Everyone in that culture knew'), jTwo = at('The two parties of a covenant'), jMay = at('may I be torn apart'), jJer = at('The prophet Jeremiah later describes'), jQ = at('cut the calf in two'), jEnd = at('But that night, something unexpected');
  push(i0, (f) => {
    const arm = f < iAsk ? [-5, -36] as [number, number] : ezArm(f, iAsk + 6, [-5, -36], [-120, -30], 14);
    return {
      svg: <>
        <Night o={1} />
        <Spot id="i8" x={960} y={620} r={820} a={0.45} />
        <Ground id="i8g" />
        <Gp o={win(f, i0, iHere + 20)}>
          {F(f, i0, iHere + 20, ABR(860, {bend: 6, head: f < iAsk ? 8 : ez(f, iAsk + 6, 8, -18, 14), arm, prop: null}))}
          {F(f, i0 + 8, iHere + 20, SAR(1040, {bend: 6, head: 10, flip: true}))}
        </Gp>
        <Gp o={fi(f, iHere)}>
          <Pieces f={f} gap={eio(ramp(f, iCut + 10, 40))} app={[fi(f, iHeif), fi(f, iGoat), fi(f, iRam), fi(f, iDove)]} path={pr(f, iPath, 50)} />
          {f < jTwo
            ? WK(f, iHere, jTwo + 10, iHere + 10, iHere + 60, 860, 420, ABR(0, {}), 'ab2')
            : F(f, iHere, jTwo + 10, ABR(420, {}), 'ab3')}
          {WK(f, jTwo, undefined, jTwo + 10, jQ + 40, 260, 1560, PPL(0, {sc: 0.26}), 'p1', 62)}
          {WK(f, jTwo, undefined, jTwo + 18, jQ + 48, 160, 1460, PPL(0, {sc: 0.26, beard: 'long', m: 'silver'}), 'p2', 62)}
        </Gp>
      </>,
      html: <>
        <Note f={f} a={i0 + 6} b={iAsk} y={140} size={44}>still no son</Note>
        <Note f={f} a={iAsk} b={iHere} y={140} size={44}>how can I know?</Note>
        <Ref f={f} a={iHere} b={iCut}>HEIFER · GOAT · RAM · DOVE · PIGEON</Ref>
        <Ref f={f} a={iCut} b={j0}>CUT IN TWO</Ref>
        <Note f={f} a={iPath} b={j0} y={190} size={44}>a path of blood between the pieces</Note>
        <Note f={f} a={jTwo} b={jMay} y={140} size={44}>both parties walk between the pieces</Note>
        <Big f={f} a={jMay} b={jJer} y={200} size={60} c={TXT.gold}>“MAY I BE TORN APART”</Big>
        <Q f={f} a={jJer + 10} b={jEnd} refText="JEREMIAH 34:18" eng="“…cut the calf in two and then *walked between its pieces*.”" keys={[at('walked between its pieces')]} y={110} />
      </>,
    };
  });
}

// 10-11 THE FIRE PASSES ------------------------------------------------------------------------
{
  const k0 = at('But that night, something unexpected'), kSleep = at('Abram fell into a deep sleep'), kQ = at('When the sun had set'), kFire = at('Fire and smoke are signs'),
    kOnly = at('Only the fire passed through'), kQ2 = at('On that day the LORD made'), l0 = at('God took the whole curse'), lHold = at('Hold on to that, because two thousand'), lHill = at('on a hill outside Jerusalem'), lEnd = at('Later God confirmed the covenant');
  push(k0, (f) => {
    const fx = kf(f, [[kQ + 50, 380], [l0 - 10, 1180], [l0 + 60, 1180]], l0 - kQ - 60);
    return {
      svg: <>
        <Night />
        <Spot id="k10" x={fx} y={GY - 80} r={520} a={0.5} />
        <Ground id="k10g" cx={fx} />
        <Gp o={1 - 0.7 * fi(f, lHill, 40)}><Pieces f={f} gap={1} /></Gp>
        {F(f, k0, lHill + 30, ABR(200, {robe: 'kneel', bend: ez(f, kSleep, 0, 22, 30), head: ez(f, kSleep, 0, 30, 30), prop: null, sc: 0.3}))}
        <Firepot x={fx} y={GY} f={f} s={0.75} o={fi(f, kQ + 40, 30) * (1 - fi(f, lHill + 20, 40))} />
        <Beam x={fx} w={260} o={0.5 * win(f, kFire, kOnly + 40)} f={f} bottom={GY} />
        <g opacity={fi(f, lHill, 50) * 0.75}><CrossHillLite /></g>
      </>,
      html: <>
        <Note f={f} a={k0 + 6} b={kSleep} y={140} size={44}>something unexpected</Note>
        <Note f={f} a={kSleep} b={kQ} y={140} size={44}>Abram falls into a deep sleep</Note>
        <Q f={f} a={kQ} b={kFire} refText="GENESIS 15:17" eng="“When the sun had set and darkness had fallen, a smoking firepot with a blazing torch appeared and *passed between the pieces*.”" keys={[at('passed between the pieces')]} />
        <Note f={f} a={kFire} b={kOnly} y={140} size={44}>fire and smoke · the presence of God</Note>
        <Big f={f} a={kOnly} b={kQ2} y={200} size={64} c={TXT.gold}>ONLY THE FIRE PASSED THROUGH</Big>
        <Q f={f} a={kQ2} b={l0} refText="GENESIS 15:18" eng="“On that day the LORD made a *covenant with Abram*.”" keys={[at('covenant with Abram')]} y={110} />
        <Big f={f} a={l0 + 6} b={lHold} y={200} size={60} c={TXT.gold}>GOD TOOK THE CURSE ON HIMSELF</Big>
        <Note f={f} a={lHold} b={lEnd} y={140} size={44}>two thousand years later…</Note>
      </>,
    };
  });
}
/** faint cross on a distant hill (line art) */
const CrossHillLite: React.FC = () => (
  <g transform={`translate(960 ${GY}) scale(0.9)`}>
    <Line w={2.2} d="M-560,0 C-300,-60 -140,-120 0,-130 C140,-120 300,-60 560,0 M-10,-130 L-10,-560 L10,-560 L10,-130 M-140,-460 L140,-460 L140,-440 L-140,-440 Z" />
  </g>
);

// 12 ABRAHAM -----------------------------------------------------------------------------------
{
  const m0 = at('Later God confirmed the covenant'), mName = at('changed Abram’s name'), mSign = at('and gave a sign to be carried'), mQ = at('I will establish my covenant as an everlasting'),
    mPh = at('That phrase, to be your God'), mEnd = at('Abraham’s family grew');
  push(m0, (f) => ({
    svg: <>
      <Night o={1 - fi(f, mPh, 30)} />
      <Gp o={fi(f, mName + 30) * (1 - fi(f, mPh, 30))}><Stars o={0.8} seed={23} n={160} y1={600} /></Gp>
      <Spot id="m12" x={960} y={600} r={820} a={0.5} />
      <Ground id="m12g" />
      <Gp o={win(f, m0, mPh + 10)}>
        {F(f, m0, mPh + 10, ABR(960, {head: -16, arm: ezArm(f, m0 + 20, [-5, -36], [-100, -40], 14)}))}
        <Beam x={960} w={300} o={0.6} f={f} />
        <Card f={f} a={mName} b={mQ} x={960} y={300} w={600} h={270} top="ABRAHAM" heb="אַבְרָהָם" en="father of many" />
      </Gp>
      <Gp o={fi(f, mPh)}>
        <Arch f={f} n={stones(f, {adam: mPh - 30, noah: mPh - 30, abr: mPh + 20})} hl="abr" dimOthers={1} />
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={m0} b={mName}>THE COVENANT CONFIRMED</Ref>
      <Note f={f} a={mSign} b={mQ} y={480} size={38}>a sign carried in the body</Note>
      <Q f={f} a={mQ} b={mPh} refText="GENESIS 17:7" eng="“I will establish my covenant as an everlasting covenant between me and you and your descendants after you for the generations to come, *to be your God* and the God of your descendants after you.”" keys={[at('to be your God', 1)]} size={48} />
      <Big f={f} a={mPh + 6} b={mEnd} y={170} size={72} c={TXT.gold}>“TO BE YOUR GOD”</Big>
    </>,
  }));
}

// 13 EGYPT, SEA, SINAI -------------------------------------------------------------------------
{
  const n0 = at('Abraham’s family grew'), nSl = at('his descendants were a nation of slaves'), nPl = at('brought them out with plagues'), nSea = at('parted the Red Sea'),
    nMt = at('and then he led them'), nThere = at('There he made the covenant'), nEnd = at('He began by reminding them');
  push(n0, (f) => {
    const part = eio(ramp(f, nSea, 40));
    return {
      svg: <>
        <Spot id="n13" x={960} y={600} r={820} />
        <Ground id="n13g" />
        <Gp o={win(f, n0, nSl + 10)}>
          {Array.from({length: 7}, (_, k) => F(f, n0 + k * 6, nSl + 10, (k % 2 ? SAR : ABR)(420 + k * 180, {sc: 0.24 + (k % 3) * 0.02, prop: null, beard: k % 2 ? 'none' : 'short'}), 'fa' + k))}
        </Gp>
        <Gp o={win(f, nSl, nSea)}>
          <Pyramids x={1300} y={GY} s={1.2} p={pr(f, nSl, 40)} o={0.8} />
          {[0, 1, 2, 3].map((k) => F(f, nSl + k * 6, nSea, PPL(380 + k * 200, {robe: 'stoop', bend: 24, head: 14}), 'sl' + k))}
        </Gp>
        <Gp o={win(f, nSea, nMt + 10)}>
          <g transform={`translate(${-part * 420} 0)`}><Waves y={GY - 120} x0={0} x1={960} o={0.7} /><Waves y={GY - 40} x0={0} x1={960} o={0.5} /></g>
          <g transform={`translate(${part * 420} 0)`}><Waves y={GY - 120} x0={960} x1={1920} o={0.7} /><Waves y={GY - 40} x0={960} x1={1920} o={0.5} /></g>
          {[0, 1, 2, 3, 4].map((k) => WK(f, nSea + 20, nMt + 10, nSea + 30 + k * 8, nMt + 10, 140 - k * 120, 1500 - k * 120, PPL(0, {}), 'w' + k, 64))}
        </Gp>
        <Gp o={fi(f, nMt)}>
          <Mountain x={960} y={GY} s={1.25} p={pr(f, nMt, 40)} />
          <Beam x={950} w={240} o={0.85 * fi(f, nThere - 20)} f={f} bottom={GY - 470} />
          {[0, 1, 2, 3, 4, 5].map((k) => F(f, nMt + 20 + k * 5, undefined, PPL(260 + k * 90 + (k > 2 ? 1060 : 0), {sc: 0.22, flip: k > 2, o: 0.9}), 'sm' + k))}
        </Gp>
      </>,
      html: <>
        <Note f={f} a={n0 + 6} b={nSl} y={140} size={44}>the family grows</Note>
        <Ref f={f} a={nSl} b={nSea}>FOUR HUNDRED YEARS · SLAVES IN EGYPT</Ref>
        <Ref f={f} a={nSea} b={nMt}>THE RED SEA</Ref>
        <Name f={f} a={nMt + 20} b={nEnd} x={960} y={900} en="MOUNT SINAI" />
      </>,
    };
  });
}

// 14 THE OFFER: RESCUE THEN LAW ---------------------------------------------------------------
{
  const o0 = at('He began by reminding them'), oQ = at('Now if you obey me fully'), oQ2 = at('Although the whole earth is mine'), oNot = at('Notice the order here'),
    oDid = at('They did not earn'), oCmd = at('The commandments showed them'), oEnd = at('At Sinai the Almighty spoke');
  push(o0, (f) => ({
    svg: <>
      <Spot id="o14" x={1300} y={560} r={820} />
      <Ground id="o14g" cx={1300} />
      <Gp o={win(f, o0, oNot + 6)}>
        <Mountain x={1440} y={GY} s={0.9} o={0.7} />
        <Beam x={1430} w={200} o={0.7} f={f} bottom={GY - 340} />
        {F(f, o0, oNot + 6, MOSES(1000, {arm: ezArm(f, o0 + 20, [-5, -36], [-90, -20], 14)}))}
        {[0, 1, 2, 3].map((k) => F(f, o0 + 6 + k * 5, oNot + 6, PPL(320 + k * 150, {head: -6}), 'op' + k))}
      </Gp>
      <Gp o={fi(f, oNot)}>
        <Card f={f} a={oNot + 4} x={620} y={560} w={480} h={270} top="FIRST" big="RESCUE" en="out of Egypt" hl={win(f, oDid, oCmd)} />
        <Arrow x0={900} y0={560} x1={1020} y1={560} p={pr(f, oNot + 30, 20)} />
        <Card f={f} a={oNot + 30} x={1300} y={560} w={480} h={270} top="THEN" big="LAW" en="how rescued people live" hl={fi(f, oCmd)} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={o0 + 6} b={oQ} y={140} size={44}>first he reminds them what he has done</Note>
      <Q f={f} a={oQ} b={oQ2} refText="EXODUS 19:5" eng="“Now if you obey me fully and keep my covenant, then out of all nations you will be my *treasured possession*.”" keys={[at('treasured possession')]} />
      <Q f={f} a={oQ2} b={oNot} refText="EXODUS 19:5–6" eng="“Although the whole earth is mine, you will be for me a *kingdom of priests* and a holy nation.”" keys={[at('kingdom of priests')]} />
      <Ref f={f} a={oNot} b={oEnd} y={200}>NOTICE THE ORDER</Ref>
      <Note f={f} a={oDid} b={oCmd} y={790} size={44}>freedom came first</Note>
      <Note f={f} a={oCmd} b={oEnd} y={790} size={44}>the law shows a rescued people how to live</Note>
    </>,
  }));
}

// 15 TABLETS, TABERNACLE, BLOOD -----------------------------------------------------------------
{
  const p0 = at('At Sinai the Almighty spoke'), pTab = at('wrote them on two tablets'), pTab2 = at('gave Moses the instructions'), pCer = at('Then came the ceremony'),
    pQ = at('Then he took the Book of the Covenant'), pMos = at('Moses then took the blood'), pEnd = at('This covenant had a different shape');
  push(p0, (f) => ({
    svg: <>
      <Spot id="p15" x={960} y={600} r={820} />
      <Ground id="p15g" />
      <Gp o={win(f, p0, pCer + 6)}>
        <Beam x={960} w={360} o={0.7} f={f} />
        <Tablets x={960} y={GY - 160} s={1.2} p={pr(f, p0 + 10, 50)} o={fi(f, p0)} />
        <Tent x={1500} y={GY} s={1} p={pr(f, pTab2, 40)} o={fi(f, pTab2)} />
        {F(f, pTab, pCer + 6, MOSES(560, {}))}
      </Gp>
      <Gp o={fi(f, pCer)}>
        <Altar x={960} y={GY} s={1} p={pr(f, pCer, 30)} />
        {F(f, pCer, undefined, MOSES(760, {arm: f < pMos ? ezArm(f, pQ, [-5, -36], [-70, -60], 14) : ezArm(f, pMos + 20, [-70, -60], [-130, -20], 14)}))}
        {[0, 1, 2, 3, 4].map((k) => F(f, pCer + 6 + k * 5, undefined, PPL(1160 + k * 140, {flip: true, head: 6}), 'pp' + k))}
      </Gp>
    </>,
    html: <>
      <Ref f={f} a={p0} b={pTab2}>THE TEN COMMANDMENTS</Ref>
      <Ref f={f} a={pTab2} b={pCer}>TABERNACLE · PRIESTHOOD</Ref>
      <Note f={f} a={pCer} b={pQ} y={140} size={44}>the ceremony that sealed it</Note>
      <Q f={f} a={pQ} b={pMos} refText="EXODUS 24:7" eng="“Then he took the Book of the Covenant and read it to the people. They responded, ‘We will do *everything* the LORD has said; we will obey.’”" keys={[at('We will do everything')]} />
      <Q f={f} a={pMos} b={pEnd} refText="EXODUS 24:8" eng="“Moses then took the blood, sprinkled it on the people and said, ‘This is *the blood of the covenant* that the LORD has made with you in accordance with all these words.’”" keys={[at('This is the blood of the covenant', 1) + 12]} size={48} />
    </>,
  }));
}
