import React from 'react';
import {at, win, fi, kf, ramp, eio, eout, clamp} from '../lib';
import {Fig, FigP, Line, Lion, Wolf, Sun, Moon, TXT} from '../fig';
import {Ref, Big, Note, Name} from '../text';
import {Scene, Spot, Ground, GY} from '../stage';
import {Mountain, Dove, River, Stones, Bread, Jar} from '../extra';
import {Book, Scroll, Stars} from '../props';
import {JP, DP, BP, SP, F, Gp, pr, ez, ezArm, turn, walkX} from '../kit';
import {Beam, Card, Q, City} from '../covprops';
import {Temple} from '../tcprops';
import {Michael, Devil} from '../mmprops';
import {Pinnacle, PIN, pinTop, LookDown, PsalmCol, C, Serpent, DotGrid, Shield, Qumran, ScrollJar} from '../psprops';

export const PS1: Scene[] = [];
const push = (start: number, render: Scene['render']) => PS1.push({start, render});

/* ---------------- shared helpers (also used by ps2) ---------------- */
export const REST: [number, number] = [-5, -36];
export const PPL = (x: number, o: Partial<FigP> = {}) => BP(x, {sc: 0.27, ...o});
export const Night: React.FC<{o?: number}> = ({o = 1}) => (o > 0.001 ? <><rect width={1920} height={1080} fill="#040302" opacity={0.5 * o} /><Stars o={0.7 * o} seed={11} n={70} y1={500} /></> : null);
export const WK = (f: number, a: number, b: number | undefined, t0: number, t1: number, x0: number, x1: number, p: FigP, k?: string | number, stride = 70) => {
  const w = walkX(f, t0, t1, x0, x1, stride);
  return <Fig key={k} {...p} x={w.x} walk={w.walk} wa={w.wa} face={p.face ?? (x1 >= x0 ? 1 : -1)} o={(p.o ?? 1) * win(f, a, b, 16)} />;
};
export const DW = (f: number, t0: number, t1: number, x0: number, x1: number, extra: any = {}) => {
  const w = walkX(f, t0, t1, x0, x1, 64);
  return <Devil x={w.x} y={GY} f={f} walk={w.walk} wa={w.wa} face={extra.face ?? (x1 >= x0 ? 1 : -1)} {...extra} />;
};
/** zoom a group around a point */
export const Zm: React.FC<{cx: number; cy: number; z: number; children: React.ReactNode}> = ({cx, cy, z, children}) => <g transform={`translate(${cx} ${cy}) scale(${z}) translate(${-cx} ${-cy})`}>{children}</g>;
/** the pinnacle set: wall, Jesus on the corner, optional devil beside him */
export const PinSet: React.FC<{f: number; id: string; z?: number; devil?: number; dArm?: [number, number]; jArm?: [number, number]; jHead?: number; dx?: number; beam?: number; wing?: number; p?: number; scroll?: number; dusk?: number}> = ({f, id, z = 1, devil = 1, dArm = REST, jArm = REST, jHead = 0, dx = -88, beam = 0, wing = 0, p = 1, scroll = 0, dusk = 0}) => {
  const t = pinTop(), kz = clamp((z - 1) / 0.5);
  return (
    <>
      <Spot id={id} x={1100 - 100 * kz} y={380 + 300 * kz} r={980} a={0.55} />
      {dusk > 0 ? <Sun x={1640} y={720} r={44} o={dusk} /> : null}
      <g transform={`translate(${t.x + (1000 - t.x) * clamp((z - 1) / 0.5)} ${t.y + (700 - t.y) * clamp((z - 1) / 0.5)}) scale(${z}) translate(${-t.x} ${-t.y})`}>
        <Pinnacle f={f} p={p} wing={wing} />
        {beam > 0 ? <Beam x={t.x} w={200} o={beam} f={f} bottom={t.y} /> : null}
        <Devil x={t.x + dx} y={t.y} sc={0.14} f={f} o={devil} arm={dArm} smoke={0.5} />
        {scroll > 0 ? <g opacity={scroll * devil}><Scroll x={t.x + dx + 34} y={t.y - 120} s={0.1} /></g> : null}
        <Fig {...JP(t.x, {y: t.y, sc: 0.14, flip: true, arm: jArm, head: jHead})} />
      </g>
    </>
  );
};
export const Wild: React.FC<{f: number; id: string; beasts?: number; angels?: number; night?: number}> = ({f, id, beasts = 0, angels = 0, night = 0.5}) => (
  <>
    <Night o={night} />
    <Spot id={id} x={960} y={640} r={820} a={0.5} />
    <Mountain x={420} y={GY} s={0.75} o={0.3} />
    <Mountain x={1560} y={GY} s={0.6} o={0.22} />
    <Ground id={id + 'g'} />
    <Stones x={1240} y={GY} o={0.9} />
    <Stones x={620} y={GY} o={0.7} lit={-1} />
    <Gp o={beasts}>
      <Lion x={300} y={GY} s={0.75} o={0.75} />
      <Wolf x={1680} y={GY} s={0.7} flip o={0.7} />
    </Gp>
    <Gp o={angels}>
      <Michael x={640} y={GY - 40} sc={0.24} f={f} spread={0.7} glow={0.35} o={0.75} />
      <Michael x={1290} y={GY - 40} sc={0.24} f={f} spread={0.7} glow={0.35} flip o={0.75} />
    </Gp>
  </>
);
const all = (st: any) => () => st;

// 0 TITLE QUESTION ------------------------------------------------------------------------------
{
  const aD = at('Why did the devil'), aP = at('quoting Psalm 91');
  push(0, (f) => ({
    svg: <>
      <PinSet f={f} id="p0" z={0.86} devil={fi(f, aD, 20)} scroll={fi(f, aP, 16)} dArm={ezArm(f, aP, REST, [-70, -20], 14)} />
    </>,
    html: <>
      <Note f={f} a={0} y={50} size={46}>why did the devil never finish quoting</Note>
      <Big f={f} a={aP - 4} y={170} size={92} c={TXT.gold}>PSALM 91?</Big>
    </>,
  }));
}

// 1 THE MAN ON THE EDGE -------------------------------------------------------------------------
{
  const b0 = at('Think of a man standing'), bCourt = at('The courtyard is so far'), bEat = at('He has not eaten anything'), bBes = at('Beside him stands the devil'),
    bThief = at('the way a thief holds'), bThrow = at('Throw yourself down,” he says'), bThen = at('Then he quotes Psalm 91 with'), bEnd = at('Except he does not quote');
  push(b0, (f) => ({
    svg: <>
      <Gp o={win(f, b0, bCourt + 4)}>
        <PinSet f={f} id="p1a" z={ez(f, b0, 1, 1.25, 120)} devil={0} />
      </Gp>
      <Gp o={win(f, bCourt, bEat + 4)}>
        <LookDown f={f} zoom={ramp(f, bCourt, 150)} p={pr(f, bCourt, 30)} />
      </Gp>
      <Gp o={win(f, bEat, bBes + 4)}>
        <Wild f={f} id="p1c" night={0.3} />
        <Fig {...JP(760, {robe: 'seat', bench: true, head: 14, bend: 6})} />
        <DotGrid f={f} a={bEat} x={1340} y={330} n={40} cols={8} gap={50} r={13} dur={50} label="FORTY DAYS" />
      </Gp>
      <Gp o={win(f, bBes, bEnd + 4)}>
        <PinSet f={f} id="p1d" z={1.45} devil={fi(f, bBes, 24)} scroll={fi(f, bThief, 16)} dArm={f < bThrow ? ezArm(f, bThief, REST, [-70, -20], 14) : ezArm(f, bThrow, [-70, -20], [-35, -50], 12)} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={b0 + 6} b={bCourt} y={70} size={48}>the highest point of the temple</Note>
      <Note f={f} a={bCourt + 6} b={bEat} y={150} size={48}>the crowds like scattered grains of sand</Note>
      <Note f={f} a={bBes + 6} b={bThief} y={60} size={48}>beside him stands the devil</Note>
      <Note f={f} a={bThief} b={bThrow} y={60} size={46}>a verse held like a borrowed key</Note>
      <Big f={f} a={bThrow} b={bThen} y={90} size={64} c={TXT.ember}>“THROW YOURSELF DOWN”</Big>
      <Note f={f} a={bThen} b={bEnd} y={60} size={48}>and he quotes Psalm 91</Note>
    </>,
  }));
}

// 2 WHAT HE CUT ---------------------------------------------------------------------------------
{
  const c0 = at('Except he does not quote'), cCut = at('He cuts a line out'), cStop = at('he stops just one verse'), cNext = at('That next verse is about'),
    cCrush = at('crushed under someone’s feet'), cName = at('And the serpent in that verse has a name'), cVery = at('It is the very one'), cEnd = at('This is the only moment');
  const read = (v: number) => (v === 11 || v === 12 ? {c: C.ember, o: 1, glow: 1} : v >= 13 ? {o: 0.25} : {o: 0.4});
  push(c0, (f) => {
    const cr = eio(ramp(f, cCrush, 14));
    return {
      svg: <>
        <Gp o={win(f, c0, cNext + 4)}>
          <Spot id="p2a" x={960} y={520} r={900} />
          <PsalmCol f={f} o={1} y={170} rows={read} ways={{c: C.ember, o: 1 - 0.5 * fi(f, cCut + 10), strike: pr(f, cCut + 6, 16)}} stop={pr(f, cStop + 10, 24)} stopLab={fi(f, cStop + 30)} />
        </Gp>
        <Gp o={win(f, cNext, cName + 4)}>
          <Spot id="p2b" x={960} y={640} r={820} />
          <Ground id="p2bg" />
          <Beam x={960} w={300} o={0.7} f={f} />
          <Lion x={560} y={GY} s={1.1} />
          <Serpent x={1720} y={GY} s={1.2} f={f} rear={0.7 * (1 - cr)} crush={cr} flip />
          {F(f, cCrush - 10, undefined, JP(1030, {head: 8}))}
        </Gp>
        <Gp o={win(f, cName, cEnd + 4)}>
          <Night o={0.6} />
          <Spot id="p2c" x={960} y={640} r={760} a={0.45} c="#7a3420" />
          <Ground id="p2cg" />
          <Serpent x={760} y={GY} s={1.2} f={f} rear={0.8} o={1 - fi(f, cVery, 26)} />
          <Devil x={1000} y={GY} f={f} flip o={fi(f, cVery, 26)} arm={[-70, -20]} />
          <Scroll x={880} y={GY - 360} s={0.22} o={fi(f, cVery + 20)} />
        </Gp>
      </>,
      html: <>
        <Note f={f} a={c0 + 8} b={cCut} y={960} size={46}>he did not quote all of it</Note>
        <Note f={f} a={cCut + 6} b={cStop} y={960} size={46}>a line cut out of the middle</Note>
        <Note f={f} a={cStop + 6} b={cNext} y={960} size={46}>and he stops one verse short</Note>
        <Note f={f} a={cNext + 6} b={cCrush} y={90} size={48}>a lion and a serpent</Note>
        <Big f={f} a={cCrush} b={cName} y={110} size={60} c={TXT.gold}>CRUSHED UNDER HIS FEET</Big>
        <Note f={f} a={cName + 6} b={cVery} y={90} size={48}>the serpent has a name</Note>
        <Big f={f} a={cVery + 10} b={cEnd} y={110} size={60} c={TXT.ember}>THE ONE DOING THE QUOTING</Big>
      </>,
    };
  });
}

// 3 IT IS WRITTEN -------------------------------------------------------------------------------
{
  const d0 = at('This is the only moment'), dLeft = at('What he left out tells'), dBy = at('By the end of this video'), dPart = at('and why the part he skipped'), dEnd = at('To understand the temple');
  push(d0, (f) => ({
    svg: <>
      <Gp o={win(f, d0, dLeft + 4)}>
        <Night o={0.5} />
        <Spot id="p3a" x={960} y={620} r={800} a={0.45} c="#7a3420" />
        <Ground id="p3ag" />
        <Devil x={960} y={GY} f={f} arm={ezArm(f, d0 + 10, REST, [-80, -14], 14)} />
        <Scroll x={1090} y={GY - 410} s={0.24} o={fi(f, d0 + 16)} />
      </Gp>
      <Gp o={win(f, dLeft, dPart + 4)}>
        <Spot id="p3b" x={960} y={520} r={900} />
        <PsalmCol f={f} o={1} y={170} rows={(v) => (v >= 13 ? {c: C.gold, o: 0.3 + 0.7 * fi(f, dLeft + 30), glow: fi(f, dLeft + 30)} : v >= 11 ? {o: 0.7} : {o: 0.4})} ways={{c: C.gold, o: 0.3 + 0.7 * fi(f, dLeft + 16), glow: fi(f, dLeft + 16)}} stop={1} stopLab={0.6} />
      </Gp>
      <Gp o={fi(f, dPart)}>
        <Spot id="p3c" x={960} y={620} r={800} />
        <Ground id="p3cg" />
        <Beam x={960} w={300} o={0.85} f={f} />
        <Fig {...BP(960, {arm: ezArm(f, dPart + 10, REST, [-70, -30], 14), head: 6})} />
        <Book x={1060} y={GY - 360} s={0.28} o={fi(f, dPart + 16)} />
      </Gp>
    </>,
    html: <>
      <Big f={f} a={d0 + 10} b={dLeft} y={110} size={72} c={TXT.ember}>“IT IS WRITTEN”</Big>
      <Note f={f} a={dBy} b={dPart} y={980} size={44}>why he could not afford to finish it</Note>
      <Note f={f} a={dPart + 6} b={dEnd} y={90} size={48}>the part God wants you to hold on to</Note>
    </>,
  }));
}

// 4 THE JORDAN ----------------------------------------------------------------------------------
{
  const e0 = at('To understand the temple'), eBap = at('Jesus had just been baptized'), eDove = at('like a dove'), eFather = at('and the Father spoke over him'), eQ = at('This is my Son, whom I love'), eEnd = at('Right after that moment');
  push(e0, (f) => {
    const rise = ez(f, eBap + 30, 70, 0, 30);
    return {
      svg: <>
        <Spot id="p4" x={960} y={600} r={860} />
        <Mountain x={360} y={GY - 40} s={0.7} o={0.25} />
        <River y={GY - 30} f={f} o={0.9} />
        <Ground id="p4g" y={GY + 60} />
        <Beam x={960} w={300} o={0.9 * fi(f, eDove - 10, 30)} f={f} bottom={GY + 20} />
        <Fig {...JP(960, {y: GY + 20 + rise, arm: ezArm(f, eFather, REST, [-20, -40], 16), head: ez(f, eFather, 0, -12, 20)})} />
        <rect x={0} y={GY + 4 + 0} width={1920} height={60} fill="#15110c" opacity={0.72} />
        <River y={GY + 10} f={f + 40} o={0.6} />
        <Dove x={960} y={ez(f, eDove - 20, 120, 420, 50)} s={0.9} f={f} o={fi(f, eDove - 20, 20)} />
        {[0, 1, 2].map((k) => F(f, e0 + 10 + k * 8, undefined, PPL(260 + k * 130, {sc: 0.23, head: 4}), 'w' + k))}
      </>,
      html: <>
        <Note f={f} a={e0 + 6} b={eBap} y={90} size={48}>a few weeks earlier, at the Jordan</Note>
        <Q f={f} a={eQ - 4} b={eEnd} refText="MATTHEW 3:17" eng="“This is my Son, whom I love; *with him I am well pleased*.”" keys={[at('with him I am well pleased')]} y={50} />
      </>,
    };
  });
}

// 5 LED INTO THE WILDERNESS ---------------------------------------------------------------------
{
  const g0 = at('Right after that moment'), gMark = at('Mark adds a detail'), gQ = at('And he was in the wilderness forty'), gWild = at('He was with the wild animals', 1), gAng = at('and angels attended him', 1), gHold = at('Hold on to that little line'), gEnd = at('After forty days without food');
  push(g0, (f) => ({
    svg: <>
      <Gp o={win(f, g0, gMark + 4)}>
        <Spot id="p5a" x={960} y={620} r={860} />
        <Mountain x={1300} y={GY} s={0.9} o={0.35} />
        <Ground id="p5ag" />
        <Beam x={ez(f, g0 + 10, 520, 1360, gMark - g0)} w={240} o={0.5} f={f} />
        {WK(f, g0, undefined, g0 + 10, gMark, 520, 1360, JP(0))}
      </Gp>
      <Gp o={fi(f, gMark)}>
        <Wild f={f} id="p5b" beasts={fi(f, gWild, 30)} angels={fi(f, gAng, 30)} />
        <Fig {...JP(960, {robe: 'seat', bench: true, head: 10})} />
      </Gp>
    </>,
    html: <>
      <Q f={f} a={g0 + 20} b={gMark} refText="MATTHEW 4:1" eng="“Then Jesus was *led by the Spirit* into the wilderness to be tempted by the devil.”" keys={[at('led by the Spirit')]} y={50} />
      <Q f={f} a={gQ} b={gHold} refText="MARK 1:13" eng="“…being tempted by Satan. He was *with the wild animals*, and *angels attended him*.”" keys={[gWild, gAng]} y={50} />
      <Big f={f} a={gHold + 6} b={gEnd} y={100} size={58} c={TXT.gold}>REMEMBER THIS LINE</Big>
    </>,
  }));
}

// 6 THE FIRST TEMPTATION ------------------------------------------------------------------------
{
  const h0 = at('After forty days without food'), hTemp = at('and the tempter came to him'), hQ = at('tell these stones to become bread'), hNot = at('Notice that small word'),
    hOnly = at('Only weeks earlier the Father'), hFirst = at('The devil’s very first move'), hEnd = at('Jesus answered him with Deuteronomy');
  push(h0, (f) => ({
    svg: <>
      <Gp o={win(f, h0, hOnly + 4)}>
        <Wild f={f} id="p6a" night={0.35 + 0.3 * fi(f, hNot, 20)} />
        <Fig {...JP(820, {robe: 'seat', bench: true, head: ez(f, hTemp + 30, 14, -4, 20), bend: 6})} />
        {DW(f, hTemp, hTemp + 70, 1960, 1360, {face: -1, arm: ezArm(f, hQ, REST, [-60, -10], 14)})}
        <g opacity={fi(f, hQ + 20, 30)}><Bread x={1180} y={GY - 20} s={0.9} o={0.55} /></g>
      </Gp>
      <Gp o={win(f, hOnly, hFirst + 4)}>
        <Spot id="p6b" x={960} y={560} r={860} />
        <Card f={f} a={hOnly} x={560} y={540} w={640} h={260} top="THE FATHER" en="“This is my Son”" />
        <Card f={f} a={hOnly + 30} x={1360} y={540} w={640} h={260} top="THE DEVIL" en="“If you are the Son…”" />
      </Gp>
      <Gp o={fi(f, hFirst)}>
        <Spot id="p6c" x={960} y={560} r={860} />
        <Card f={f} a={hFirst - 10} x={960} y={540} w={900} h={300} top="SETTLED" big="THIS IS MY SON ?" hl={fi(f, hFirst + 40)} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={h0 + 6} b={hTemp} y={90} size={48}>forty days without food</Note>
      <Q f={f} a={hQ - 30} b={hNot} refText="MATTHEW 4:3" eng="“*If* you are the Son of God, tell these stones to become bread.”" keys={[hNot]} y={50} />
      <Big f={f} a={hNot} b={hOnly} y={330} size={200} c={TXT.ember}>IF</Big>
      <Note f={f} a={hFirst + 20} b={hEnd} y={820} size={48}>what God settled, turned back into a question</Note>
    </>,
  }));
}

// 7 JESUS ANSWERS -------------------------------------------------------------------------------
{
  const i0 = at('Jesus answered him with Deuteronomy'), iDid = at('He did not perform a miracle'), iStood = at('He simply stood on what'), iEnd = at('And it seems the devil took note');
  push(i0, (f) => ({
    svg: <>
      <Wild f={f} id="p7" night={0.3} />
      <Book x={820} y={GY} s={ez(f, iStood, 0.001, 0.5, 20)} o={fi(f, iStood)} />
      <Beam x={820} w={260} o={0.7 * fi(f, iStood, 20)} f={f} />
      <Fig {...JP(820, {y: GY - 120 * eio(ramp(f, iStood, 20)), head: -4, arm: ezArm(f, i0 + 10, REST, [-40, -20], 14)})} />
      <Devil x={1360} y={GY} f={f} flip arm={ezArm(f, iDid, [-60, -10], REST, 14)} />
      <Stones x={1150} y={GY} o={1} />
    </>,
    html: <>
      <Q f={f} a={i0 + 6} b={iDid} refText="MATTHEW 4:4" eng="“It is written: ‘Man shall not live on bread alone, but on *every word that comes from the mouth of God*.’”" keys={[at('every word that comes from')]} y={40} />
      <Note f={f} a={iDid + 6} b={iStood} y={90} size={48}>no miracle to prove who he was</Note>
      <Note f={f} a={iStood + 6} b={iEnd} y={90} size={48}>he stood on what God had already said</Note>
    </>,
  }));
}

// 8 THE DEVIL TAKES NOTE ------------------------------------------------------------------------
{
  const j0 = at('And it seems the devil took note'), jIf = at('If Scripture was going to be'), jEnd = at('Then the devil took him to the holy city');
  push(j0, (f) => ({
    svg: <>
      <Night o={0.6} />
      <Spot id="p8" x={960} y={620} r={760} a={0.45} c="#7a3420" />
      <Ground id="p8g" />
      <Devil x={1000} y={GY} f={f} flip head={ez(f, j0, 0, 14, 20)} arm={ezArm(f, jIf + 20, REST, [-90, -20], 16)} />
      <Scroll x={ez(f, jIf + 20, 760, 830, 20)} y={ez(f, jIf + 20, GY - 30, GY - 420, 24)} s={0.24} o={fi(f, j0 + 10)} />
      <Fig {...JP(520, {head: 0, o: 0.6})} />
    </>,
    html: <>
      <Note f={f} a={j0 + 6} b={jIf} y={90} size={48}>the devil took note</Note>
      <Big f={f} a={jIf + 10} b={jEnd} y={110} size={60} c={TXT.ember}>HE PICKED UP SCRIPTURE TOO</Big>
    </>,
  }));
}

// 9 THE HOLY CITY -------------------------------------------------------------------------------
{
  const k0 = at('Then the devil took him to the holy city'), kJos = at('The Jewish historian Josephus'), kDiz = at('would feel dizzy'), kVal = at('because the drop fell away'),
    kPub = at('This was the most public'), kLeap = at('If a man leapt from there'), kAll = at('all of Jerusalem would know'), kEnd = at('There is a beautiful detail');
  push(k0, (f) => {
    const fall = clamp((f - kLeap - 10) / 40);
    return {
      svg: <>
        <Gp o={win(f, k0, kJos + 4)}>
          <PinSet f={f} id="p9a" z={ez(f, k0, 0.8, 1, 90)} />
        </Gp>
        <Gp o={win(f, kJos, kDiz + 4)}>
          <Spot id="p9b" x={960} y={560} r={860} />
          <Card f={f} a={kJos} x={960} y={540} w={900} h={300} top="JOSEPHUS · ANTIQUITIES 15" big="LOOKING DOWN" en="from the temple’s southern side" />
        </Gp>
        <Gp o={win(f, kDiz, kPub + 4)}>
          <g transform={`rotate(${Math.sin((f - kDiz) / 26) * 1.2 * fi(f, kDiz)} 960 540)`}><LookDown f={f} zoom={ramp(f, kDiz, 120)} /></g>
        </Gp>
        <Gp o={win(f, kPub, kAll + 4)}>
          <Spot id="p9d" x={960} y={600} r={900} />
          <Ground id="p9dg" />
          <Temple x={960} y={GY} s={0.8} />
          {Array.from({length: 9}, (_, i) => F(f, kPub + i * 3, undefined, PPL(140 + i * 200 + (i > 3 ? 220 : 0), {sc: 0.22, head: -14, flip: i > 4}), 'c' + i))}
          <Gp o={fi(f, kLeap) * (1 - fi(f, kLeap + 70))}>
            <Fig {...JP(960, {y: 260 + 380 * eio(fall), sc: 0.16, o: 0.5})} />
          </Gp>
          <Gp o={fi(f, kLeap + 40, 20)}>
            <Michael x={900} y={GY - 140} sc={0.2} f={f} o={0.55} />
            <Michael x={1030} y={GY - 140} sc={0.2} f={f} flip o={0.55} />
            <Fig {...JP(965, {y: GY - 150, sc: 0.16, o: 0.55})} />
          </Gp>
        </Gp>
        <Gp o={fi(f, kAll)}>
          <Spot id="p9e" x={1300} y={700} r={900} a={0.6} c="#A0602A" />
          <Sun x={1500} y={700} r={60} o={0.9} />
          <City x={960} y={GY} s={1.3} />
          <Ground id="p9eg" cx={1400} />
        </Gp>
      </>,
      html: <>
        <Q f={f} a={k0 + 4} b={kJos} refText="MATTHEW 4:5" eng="“Then the devil took him to the holy city and had him stand on *the highest point of the temple*.”" keys={[at('the highest point of the temple', 2)]} y={30} size={46} />
        <Big f={f} a={kDiz} b={kVal} y={130} size={72} c={TXT.gold}>DIZZY</Big>
        <Note f={f} a={kVal} b={kPub} y={150} size={48}>the drop fell away into the valley</Note>
        <Note f={f} a={kPub + 6} b={kLeap} y={90} size={48}>the most public place in the nation</Note>
        <Note f={f} a={kLeap + 6} b={kAll} y={90} size={48}>caught softly by angels</Note>
        <Big f={f} a={kAll + 6} b={kEnd} y={110} size={60} c={TXT.gold}>ALL JERUSALEM BY SUNSET</Big>
      </>,
    };
  });
}

// 10 PTERUGION ----------------------------------------------------------------------------------
{
  const l0 = at('There is a beautiful detail'), lGr = at('In Greek it is'), lWing = at('little wing', 1), lSo = at('So the devil stands Jesus on the wing'), lQ = at('under his wings you will find refuge'), lEnd = at('Here is what he said');
  push(l0, (f) => ({
    svg: <>
      <Gp o={win(f, l0, lGr + 4)}>
        <PinSet f={f} id="p10z" z={ez(f, l0, 1, 1.3, lGr - l0)} />
      </Gp>
      <Gp o={win(f, lGr, lSo + 4)}>
        <Spot id="p10a" x={960} y={560} r={860} />
        <Card f={f} a={lGr + 4} x={960} y={520} w={760} h={340} top="MATTHEW 4:5" grk="πτερύγιον" big="PTERUGION" en="little wing" hl={fi(f, lWing)} />
      </Gp>
      <Gp o={fi(f, lSo)}>
        <PinSet f={f} id="p10b" z={1.3} wing={fi(f, lSo + 20, 30)} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={l0 + 6} b={lGr} y={60} size={48}>a detail hiding in one word</Note>
      <Note f={f} a={lSo + 6} b={lQ - 10} y={60} size={48}>Jesus stands on the wing of the temple</Note>
      <Q f={f} a={lQ - 10} b={lEnd} refText="PSALM 91:4" eng="“…*under his wings* you will find refuge”" keys={[lQ]} y={40} />
    </>,
  }));
}

// 11 WORD FOR WORD ------------------------------------------------------------------------------
{
  const m0 = at('Here is what he said'), mQ = at('If you are the Son of God,” he said'), mWrit = at('For it is written: ‘He will command'), mEnd = at('To feel the weight');
  push(m0, (f) => ({
    svg: <>
      <PinSet f={f} id="p11" z={ez(f, m0, 1.3, 1.55, mEnd - m0)} scroll={1} dArm={f < mWrit ? ezArm(f, mQ + 20, [-70, -20], [-35, -50], 12) : ezArm(f, mWrit, [-35, -50], [-70, -20], 12)} />
    </>,
    html: <>
      <Note f={f} a={m0 + 4} b={mQ - 4} y={60} size={48}>word for word</Note>
      <Q f={f} a={mQ - 4} b={mEnd} refText="MATTHEW 4:6" eng="“If you are the Son of God,” he said, “*throw yourself down*. For it is written: ‘He will command his angels concerning you, and they will lift you up in their hands, so that you will not strike your foot against a stone.’”" keys={[at('throw yourself down. For')]} y={20} size={42} />
    </>,
  }));
}

// 12 THE SONG OF PROTECTION ---------------------------------------------------------------------
{
  const n0 = at('To feel the weight'), nSong = at('It was their great song'), nOpen = at('It opens with the words'), nProm = at('It promises safety'), nEnd = at('Jewish teachers in the centuries');
  push(n0, (f) => ({
    svg: <>
      <Gp o={win(f, n0, nProm + 4)}>
        <Spot id="p12a" x={960} y={620} r={860} />
        <Ground id="p12ag" />
        <Beam x={960} w={420} o={0.8 * fi(f, nSong, 30)} f={f} />
        {[0, 1, 2, 3, 4].map((k) => F(f, n0 + 8 + k * 6, undefined, PPL(640 + k * 160, {sc: k === 2 ? 0.22 : 0.27, head: -10, arm: [-30, -60]}), 'f' + k))}
      </Gp>
      <Gp o={fi(f, nProm)}>
        <Spot id="p12b" x={960} y={520} r={900} />
        <PsalmCol f={f} o={1} y={170} rows={(v) => ((v === 5 || v === 6) ? {c: C.gold, o: 1, glow: fi(f, nProm + 10)} : v === 1 ? {c: C.gold, o: 0.8} : {o: 0.4})} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={n0 + 6} b={nSong} y={90} size={48}>what this psalm meant to them</Note>
      <Big f={f} a={nSong} b={nOpen} y={110} size={60} c={TXT.gold}>THEIR SONG OF PROTECTION</Big>
      <Q f={f} a={nOpen} b={nProm} refText="PSALM 91:1" eng="“Whoever dwells in *the shelter of the Most High* will rest in the shadow of the Almighty.”" keys={[at('the shelter of the Most High')]} y={50} />
    </>,
  }));
}

// 13 THE SONG OF EVIL SPIRITS -------------------------------------------------------------------
{
  const o0 = at('Jewish teachers in the centuries'), oTal = at('The Talmud records'), oEvil = at('the song of evil spirits'), oPl = at('the song of plagues'), oPeo = at('People recited it'),
    oDSS = at('Among the Dead Sea Scrolls'), oCop = at('where Psalm 91 was copied'), oDem = at('meant to drive away demons'), oEnd = at('So picture the scene again');
  push(o0, (f) => ({
    svg: <>
      <Gp o={win(f, o0, oPeo + 4)}>
        <Spot id="p13a" x={960} y={560} r={900} />
        <Ground id="p13ag" y={900} />
        <Beam x={960} w={300} o={0.6} f={f} bottom={900} />
        <Book x={960} y={900} s={0.9} p={pr(f, o0, 40)} o={0.8} />
        <Fig {...BP(250, {y: 900, robe: 'seat', bench: true, beard: 'long', head: 10, sc: 0.28})} />
        <Fig {...BP(1670, {y: 900, robe: 'seat', bench: true, beard: 'long', head: 10, sc: 0.28, flip: true})} />
        <Card f={f} a={oEvil} x={560} y={460} w={680} h={270} top="SHEVUOT 15B" heb="שיר של פגעים" en="the song of evil spirits" />
        <Card f={f} a={oPl} x={1360} y={460} w={680} h={270} top="ALSO CALLED" heb="שיר של נגעים" en="the song of plagues" />
      </Gp>
      <Gp o={win(f, oPeo, oDSS + 4)}>
        <Night o={0.8} />
        <Spot id="p13b" x={860} y={620} r={760} a={0.5} />
        <Ground id="p13bg" cx={860} />
        <Beam x={820} w={260} o={0.7 * fi(f, oPeo + 20, 30)} f={f} />
        <Fig {...BP(820, {robe: 'kneel', head: -12, arm: [-30, -60]})} />
        <Devil x={ez(f, oPeo + 30, 1300, 1700, 60)} y={GY} f={f} flip o={1 - fi(f, oPeo + 50, 40)} />
      </Gp>
      <Gp o={fi(f, oDSS)}>
        <Spot id="p13c" x={960} y={620} r={860} />
        <Ground id="p13cg" />
        <Qumran x={760} y={GY} s={1.1} p={pr(f, oDSS, 40)} />
        <ScrollJar x={1380} y={GY} s={1.1} lid={eio(ramp(f, oCop - 10, 30))} />
        <ScrollJar x={1540} y={GY} s={0.9} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={o0 + 6} b={oTal} y={110} size={48}>a nickname for this psalm</Note>
      <Note f={f} a={oPeo + 6} b={oDSS} y={90} size={48}>recited when under spiritual attack</Note>
      <Ref f={f} a={oDSS} b={oCop} y={90}>DEAD SEA SCROLLS · CAVE 11</Ref>
      <Note f={f} a={oCop} b={oEnd} y={90} size={48}>copied together with songs against demons</Note>
    </>,
  }));
}

// 14 SHIELD TURNED INTO BAIT --------------------------------------------------------------------
{
  const q0 = at('So picture the scene again'), qVery = at('The devil is quoting the very psalm'), qShield = at('He has taken their shield'), qBait = at('to use it as bait'), qEnd = at('Now let us put the devil’s version');
  push(q0, (f) => ({
    svg: <>
      <Gp o={win(f, q0, qShield + 4)}>
        <PinSet f={f} id="p14a" z={1.4} scroll={1} dArm={[-70, -20]} />
      </Gp>
      <Gp o={fi(f, qShield)}>
        <Night o={0.4} />
        <Spot id="p14b" x={960} y={560} r={820} a={0.5} />
        <Shield x={960} y={520} s={1.3} flip={eio(ramp(f, qBait - 16, 26))} f={f} />
      </Gp>
    </>,
    html: <>
      <Note f={f} a={q0 + 6} b={qVery} y={60} size={48}>picture the scene again</Note>
      <Note f={f} a={qVery} b={qShield} y={60} size={46}>the psalm sung to send evil spirits running</Note>
      <Big f={f} a={qShield + 6} b={qBait} y={930} size={60} c={TXT.gold}>THEIR SHIELD</Big>
      <Big f={f} a={qBait} b={qEnd} y={930} size={60} c={TXT.ember}>TURNED INTO BAIT</Big>
    </>,
  }));
}
