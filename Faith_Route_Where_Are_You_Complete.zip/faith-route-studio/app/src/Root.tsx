import React from 'react';
import {Composition} from 'remotion';
import {Main, DURATION} from './Main';
import {Thumb} from './thumb';
import {Handoff, HANDOFF_FRAMES} from "./handoff";
export const Root: React.FC = () => <>
  <Composition id="Main" component={Main} durationInFrames={DURATION} fps={30} width={1920} height={1080} />
  <Composition id="Thumb" component={Thumb} durationInFrames={1} fps={30} width={1920} height={1080} defaultProps={{v: 1}} />
  <Composition id="Handoff" component={Handoff} durationInFrames={HANDOFF_FRAMES} fps={30} width={1920} height={1080} />
</>;
