import React from 'react';
import * as S from './shapes';
import {nativeActingPose, movingRobe, type ArmPlacement, type NativeMotion, type ActingPose} from './acting';

export type Metal = 'gold' | 'silver' | 'bronze' | 'shadow';
// [hot core, rim, hairline, glow, body]
export const MET: Record<Metal, string[]> = {
  gold: ['#FFE9B4', '#E8B455', '#9C6E2C', '#C98E34', '#0C0905'],
  silver: ['#FFFFFF', '#C9CCD1', '#6E7176', '#9DA1A8', '#0A0A0B'],
  bronze: ['#FFD2A6', '#C67D41', '#7A4320', '#A45E2A', '#0C0806'],
  shadow: ['#FFB592', '#C9472E', '#5E1C10', '#8E3420', '#040202'],
};
export const TXT = {gold: '#E9BE6E', silver: '#D9DCE0', bronze: '#CF915C', ivory: '#ECE3D0', dim: '#8E826E', ember: '#E2785A'};

const Rim: React.FC<{m: Metal; dir: number}> = ({m, dir}) => {
  const c = MET[m];
  return (
    <filter id={`rim_${m}_${dir > 0 ? 'R' : 'L'}`} x="-25%" y="-15%" width="150%" height="130%" colorInterpolationFilters="sRGB">
      <feMorphology in="SourceAlpha" operator="dilate" radius="1.5" result="d1" />
      <feComposite in="d1" in2="SourceAlpha" operator="out" result="hair" />
      <feOffset in="SourceAlpha" dx={dir * 3.6} dy={-1.2} result="o1" />
      <feComposite in="o1" in2="SourceAlpha" operator="out" result="rim" />
      <feOffset in="SourceAlpha" dx={dir * 1.6} dy={-0.5} result="o2" />
      <feComposite in="o2" in2="SourceAlpha" operator="out" result="core" />
      <feFlood floodColor={c[1]} floodOpacity={0.62} /><feComposite in2="hair" operator="in" result="hairC" />
      <feGaussianBlur in="hairC" stdDeviation="2.2" result="hairG" />
      <feFlood floodColor={c[1]} /><feComposite in2="rim" operator="in" result="rimC" />
      <feFlood floodColor={c[0]} /><feComposite in2="core" operator="in" result="coreC" />
      <feGaussianBlur in="rimC" stdDeviation="7" result="glow" />
      <feComponentTransfer in="glow" result="glow2"><feFuncA type="linear" slope="1.15" /></feComponentTransfer>
      <feFlood floodColor={c[4]} /><feComposite in2="SourceAlpha" operator="in" result="body" />
      <feMerge><feMergeNode in="glow2" /><feMergeNode in="hairG" /><feMergeNode in="body" /><feMergeNode in="hairC" /><feMergeNode in="rimC" /><feMergeNode in="coreC" /></feMerge>
    </filter>
  );
};

export const Defs: React.FC = () => (
  <defs>
    {(['gold', 'silver', 'bronze', 'shadow'] as Metal[]).flatMap((m) => [<Rim key={m + 'R'} m={m} dir={1} />, <Rim key={m + 'L'} m={m} dir={-1} />])}
    <filter id="lglow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur in="SourceGraphic" stdDeviation="4" result="b" />
      <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
    </filter>
    <filter id="lglowU" filterUnits="userSpaceOnUse" x="-3000" y="-3000" width="8000" height="8000">
      <feGaussianBlur in="SourceGraphic" stdDeviation="4" result="b" />
      <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
    </filter>
    <filter id="soft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="10" /></filter>
    <filter id="soft3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3" /></filter>
    <radialGradient id="halo"><stop offset="0" stopColor="#B88A44" stopOpacity="0.55" /><stop offset="0.45" stopColor="#8A6430" stopOpacity="0.22" /><stop offset="1" stopColor="#5A3E1C" stopOpacity="0" /></radialGradient>
    <linearGradient id="beam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#E0B868" stopOpacity="0.28" /><stop offset="1" stopColor="#C99A4A" stopOpacity="0.04" /></linearGradient>
    <linearGradient id="goldLine" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F4CF86" /><stop offset="1" stopColor="#B8873E" /></linearGradient>
  </defs>
);

/** one lit cut-out: everything inside becomes one silhouette */
export const Cut: React.FC<{m: Metal; lit: number; tf?: string; o?: number; children: React.ReactNode}> = ({m, lit, tf, o = 1, children}) => (
  <g filter={`url(#rim_${m}_${lit > 0 ? 'R' : 'L'})`} opacity={o}>
    <g transform={tf} fill="#fff">{children}</g>
  </g>
);

const P = (d: string) => <path d={d} />;

// extra shapes
const LOW_SHORT = 'M64,860 C62,1000 60,1150 62,1228 C64,1262 84,1276 120,1276 L300,1276 C330,1276 344,1260 342,1232 C336,1110 322,990 306,860 Z';
const LEG_B = 'M122,1262 L116,1512 L172,1512 L178,1262 Z';
const LEG_F = 'M212,1262 L224,1512 L282,1512 L270,1262 Z';
const SHOE_B = 'M100,1512 C106,1532 156,1540 190,1531 C194,1521 188,1512 176,1512 Z';
const VEIL = 'M276,112 C266,60 216,36 172,40 C122,45 84,80 77,130 L60,700 C58,742 80,762 110,758 C132,754 142,736 142,714 L143,192 C150,154 202,122 276,112 Z';
const MANTLE = 'M70,380 C120,420 200,520 300,640 L306,700 C210,600 130,500 68,450 Z';
const HAND_MITT = 'M-15,-44 L15,-44 L13,146 C24,152 32,166 30,180 C28,196 16,204 4,201 C-8,198 -14,188 -14,176 L-13,146 Z';

export type Pose = {
  robe?: 'stand' | 'seat' | 'kneel' | 'stoop' | 'short';
  bend?: number; head?: number; arm?: [number, number]; arm2?: [number, number] | null; reach?: number; reach2?: number;
};
export type FigP = Pose & {
  x: number; y: number; m: Metal; sc?: number; flip?: boolean; lit?: number; o?: number;
  hair?: 'cloth' | 'long' | 'cap' | 'helmet' | 'veil' | 'bare'; beard?: 'none' | 'short' | 'long';
  crown?: boolean; prop?: 'crook' | 'staff' | 'spear' | null; bench?: boolean; wide?: number; tall?: number; hs?: number; mantle?: boolean;
  dim?: number;
  /** walk phase in steps (float); undefined = standing still */
  walk?: number;
  /** walk amplitude 0..1 (eases a stride in and out) */
  wa?: number;
  /** continuous facing: 1 = right, -1 = left, values between squash through a turn */
  face?: number;
};

const Arm: React.FC<{a: [number, number]; k?: number}> = ({a, k = 1}) => (
  <g transform={`translate(240 350) rotate(${a[0]})`}>
    <g transform={`translate(0 ${350 * k}) rotate(${a[1]})`}><path d={HAND_MITT} /></g>
    <g transform={`scale(1 ${k})`}><path d={S.UP} /></g>
  </g>
);

// The sculpted sleeve and mitten use the original paths. A separate wrist pivot leaves the
// palm free to rotate while the elbow and shoulder follow the hand contact.
function MotionArm({pose,detail}:{pose:ArmPlacement;detail?:string}){
 const {root:r,elbow:e,wrist:w,palmAngle}=pose;
 const segment=(a:number[],b:number[],length:number)=> {
   const dx=b[0]-a[0],dy=b[1]-a[1];
   return `translate(${a[0]} ${a[1]}) rotate(${Math.atan2(dy,dx)*180/Math.PI-90}) scale(1 ${Math.hypot(dx,dy)/length})`;
 };
 if(detail)return <path transform={segment(r,e,350)} d="M-38,0 C-38,-48 38,-48 38,0 L50,338 M-48,334 L-38,0"
    fill="none" stroke={detail} strokeWidth={4.5} opacity={0.65} strokeLinecap="round"/>;
 return <>
   <path transform={segment(e,w,146)} d="M-15,-44 L15,-44 L13,146 Q0,156 -13,146Z"/>
   <path transform={`translate(${w[0]} ${w[1]}) rotate(${palmAngle})`} d="M-13,-3 L13,-3 L13,0 C24,6 32,20 30,34 C28,50 16,58 4,55 C-8,52 -14,42 -14,30Z"/>
   <path transform={segment(r,e,350)} d={S.UP}/>
 </>;
}

/** hand position in drawing space for a pose (for props) */
export function handPt(p: Pose, which: 'near' | 'far' = 'near') {
  const robe = p.robe || 'stand';
  const dy = {stand: 0, short: 0, seat: 230, kneel: 315, stoop: 80}[robe];
  const a = (which === 'near' ? p.arm : p.arm2) || [-5, -36];
  const r = (x: number, y: number, deg: number) => { const t = (deg * Math.PI) / 180; return [x * Math.cos(t) - y * Math.sin(t), x * Math.sin(t) + y * Math.cos(t)]; };
  const k = (which === 'near' ? p.reach : p.reach2) ?? 1;
  let [hx, hy] = r(8, 184, a[1]); hy += 350 * k; [hx, hy] = r(hx, hy, a[0]); hx += 240; hy += 350 + dy;
  const b = p.bend || 0;
  if (b) { const [qx, qy] = r(hx - 290, hy - (905 + dy), b); hx = 290 + qx; hy = 905 + dy + qy; }
  return [hx, hy];
}

export const Fig: React.FC<FigP | {acting:ActingPose}> = (input) => {
  const p: FigP & {motion?:NativeMotion} = 'acting' in input ? nativeActingPose(input.acting) : input;
  const motion=p.motion;
  const {x, y, m, sc = 0.34, flip = false, o = 1, hair = 'cloth', beard = 'short', crown = false, prop = null, bench = false, wide = 1, tall = 1, hs = 1, mantle = false, dim = 0} = p;
  const robe = p.robe || 'stand', bend = p.bend || 0, head = p.head || 0;
  const walking = p.walk !== undefined && (robe === 'stand' || robe === 'short');
  const wa = walking ? (p.wa ?? 1) : 0, ph = walking ? p.walk! * Math.PI : 0, sw = Math.sin(ph) * wa, bob = walking ? (-9 * Math.abs(Math.cos(ph)) + 4) * wa : 0;
  const arm0 = p.arm || [-5, -36], arm: [number, number] = walking ? [arm0[0] + 5 * sw, arm0[1] - 3 * sw] : arm0;
  const arm2 = p.arm2 ? (walking ? [p.arm2[0] - 5 * sw, p.arm2[1]] as [number, number] : p.arm2) : null;
  const fx = p.face !== undefined ? p.face : flip ? -1 : 1;
  const sx = Math.sign(fx || 1) * Math.max(0.06, Math.abs(fx));
  const tf = `translate(${x} ${y}) scale(${sx * sc * wide} ${sc * tall}) translate(-200 ${-1545 + bob})`;
  const dy = motion?.dy ?? {stand: 0, short: 0, seat: 230, kneel: 315, stoop: 80}[robe];
  const U = `rotate(${bend} 290 ${905 + dy}) translate(0 ${dy})`;
  const H = `${U} rotate(${head} 220 330) translate(200 330) scale(${hs * (motion?.headWidth ?? 1)} ${hs}) translate(-200 -330)`;
  const lit = p.face !== undefined ? (p.face >= 0 ? 1 : -1) * Math.sign(p.lit ?? 1) : (p.lit ?? 1);
  const c = MET[m];
  const op = o * (1 - 0.62 * dim);
  const hand = handPt(p);
  const fr = 46 * sw, bk = 30 * Math.sin(ph - 0.7) * wa, fl = 14 * Math.max(0, sw), bl = 10 * Math.max(0, -sw);
  const LOW_WALK = `M64,860 C62,1100 ${58 + bk * 0.5},1300 ${58 + bk},1440 C${58 + bk},1494 ${84 + bk},${1516 - bl} ${126 + bk},${1516 - bl} L${304 + fr},${1516 - fl} C${340 + fr},${1516 - fl} ${356 + fr},1494 ${352 + fr * 0.8},1452 C340,1250 322,1050 306,860 Z`;
  const lower = walking && robe === 'stand' ? LOW_WALK : {stand: S.LOW_STAND, short: LOW_SHORT, seat: S.LOW_SEAT, kneel: S.LOW_KNEEL, stoop: S.LOW_STOOP}[robe];
  let backFill: string | null = null;
  if (bend) {
    const t = (bend * Math.PI) / 180;
    const R = (px: number, py: number) => [290 + (px - 290) * Math.cos(t) - (py - 905) * Math.sin(t), 905 + dy + (px - 290) * Math.sin(t) + (py - 905) * Math.cos(t)];
    const B = R(70, 520), Cc = R(70, 905);
    const back = robe === 'kneel' ? [-4, 1420] : robe === 'stoop' ? [40, 1200] : [64, 1120];
    const mid = [back[0] + (robe === 'kneel' ? 30 : 10), B[1] + (robe === 'kneel' ? 40 : 60)];
    backFill = `M${back[0]},${back[1]} Q${mid[0]},${mid[1]} ${B[0]},${B[1]} L${Cc[0]},${Cc[1]} L300,${905 + dy} L300,${back[1]} Z`;
  }
  const line = (d: string, a: number, t = '') => <path key={d.slice(0, 18) + a} d={d} transform={t} fill="none" stroke={c[2]} strokeWidth={2.8} opacity={a} strokeLinecap="round" />;
  const hl: React.ReactNode[] = [];
  if (hair === 'cloth') hl.push(line(S.BAND, 0.6), line('M143,192 L143,264', 0.45));
  if (beard !== 'none') hl.push(line(S.CHEEK, 0.55));
  if (beard === 'short') hl.push(line(S.BEARD_LINES, 0.4));
  if (beard === 'long') hl.push(line('M232,260 C228,330 230,400 238,460 M256,250 C252,330 254,400 262,456 M276,246 C274,320 276,390 282,440', 0.4));
  if (hair === 'long' || hair === 'veil') hl.push(line('M104,180 C100,320 102,460 106,600', 0.3));
  if (hair === 'helmet') hl.push(line('M74,190 L282,170', 0.6));
  const propTop = prop === 'spear' ? -140 : prop === 'crook' ? 110 : 40;
  const X = hand[0];
  return (
    <g opacity={op} transform={motion ? `scale(${motion.rimUnit})` : undefined}>
      {bench ? <Cut m={m} lit={lit} tf={tf}><path d={S.BENCH} /></Cut> : null}
      {prop ? (
        <Cut m={m} lit={lit} tf={tf}>
          <path d={`M${X - 9},1545 L${X - 9},${propTop} L${X + 9},${propTop} L${X + 9},1545 Z`} />
          {prop === 'crook' ? <path d={`M${X - 9},${propTop + 8} C${X - 9},${propTop - 96} ${X + 112},${propTop - 106} ${X + 116},${propTop - 22} C${X + 118},${propTop + 30} ${X + 72},${propTop + 42} ${X + 52},${propTop + 12} L${X + 66},${propTop + 3} C${X + 80},${propTop + 24} ${X + 100},${propTop + 18} ${X + 100},${propTop - 18} C${X + 98},${propTop - 76} ${X + 9},${propTop - 72} ${X + 9},${propTop + 8} Z`} /> : null}
          {prop === 'spear' ? <path d={`M${X - 28},${propTop + 10} L${X},${propTop - 96} L${X + 28},${propTop + 10} Z`} /> : null}
        </Cut>
      ) : null}
      {motion ? <Cut m={m} lit={lit} tf={tf}><g transform={U}><MotionArm pose={motion.far}/></g></Cut> : arm2 ? <Cut m={m} lit={lit} tf={tf}><g transform={U}><Arm a={arm2} k={p.reach2 ?? 1} /></g></Cut> : null}
      <Cut m={m} lit={lit} tf={tf}>
        {P(motion ? movingRobe(motion) : lower)}
        {motion?.feet.map(([fx,fy],i)=><g key={i} transform={`translate(${fx-244} ${fy-1545})`}><path d="M203,1481 Q227,1485 255,1481 L266,1519 L204,1519Z"/>{P(S.SHOE)}</g>)}
        {robe === 'short' ? <>{P(LEG_B)}{P(LEG_F)}{P(SHOE_B)}{P(S.SHOE)}</> : null}
        {!motion && (robe === 'stoop' || (robe === 'stand' && !walking)) ? P(S.SHOE) : null}
        {robe === 'stand' && walking ? <><g transform={`translate(${-40 - 46 * sw} ${-bob})`}>{P(S.SHOE)}</g><g transform={`translate(${46 * sw} ${-bob})`}>{P(S.SHOE)}</g></> : null}
        {robe === 'seat' ? P(S.FOOT_SEAT) : null}
        {backFill ? P(backFill) : null}
        <g transform={U}>{P(S.TORSO)}{mantle ? P(MANTLE) : null}</g>
        <g transform={H}>
          {P(S.NECK)}{P(beard === 'none' ? S.FACE_YOUNG : S.JAW)}
          {beard === 'short' ? P(S.BEARD) : null}{beard === 'long' ? P(S.BEARD_LG) : null}
          {hair === 'cloth' ? P(S.CLOTH) : null}{hair === 'long' ? P(S.HAIR_L) : null}{hair === 'veil' ? P(VEIL) : null}
          {hair === 'cap' ? P(S.CAP_C) : null}{hair === 'helmet' ? <>{P(S.HELM)}{P(S.CREST_H)}</> : null}
          {crown ? P(S.CROWN) : null}
        </g>
        <g transform={U}>{motion ? <MotionArm pose={motion.near}/> : <Arm a={arm} k={p.reach ?? 1}/>}</g>
      </Cut>
      <g transform={tf}>
        <g transform={U}>
          {line('M69,634 L283,634', 0.8)}{line('M68,662 L287,662', 0.8)}{line('M112,326 L222,428', 0.55)}
          {mantle ? line('M70,380 C120,420 200,520 300,640', 0.5) : null}
          {motion ? <MotionArm pose={motion.near} detail={c[1]}/> : <g transform={`translate(240 350) rotate(${arm[0]})`}><g transform={`scale(1 ${p.reach ?? 1})`}><path d="M-38,0 C-38,-48 38,-48 38,0 L50,338 M-48,334 L-38,0" fill="none" stroke={c[1]} strokeWidth={4.5} opacity={0.65} strokeLinecap="round" /></g></g>}
        </g>
        {motion ? <>
          <g opacity={1-motion.kneel}>{line(`M${60+motion.hemBack},1468 C150,1474 260,1474 ${348+motion.hemFront},1466`,.45)}{line(`M122,${880+motion.dy} L${82+motion.hemBack},1458`,.22)}{line(`M214,${880+motion.dy} L${244+motion.hemFront},1462`,.22)}</g>
          <g opacity={motion.kneel}>{line('M300,1180 C340,1260 380,1360 420,1500',.25)}</g>
        </> : robe === 'stand' ? <>{line(`M${60 + bk},${1468 - bl} C150,1474 260,1474 ${348 + fr},${1466 - fl}`, 0.45)}{line(`M122,880 L${82 + bk},1458`, 0.22)}{line(`M214,880 L${244 + fr * 0.8},1462`, 0.22)}</> : null}
        {robe === 'short' ? line('M64,1240 C150,1248 260,1248 340,1238', 0.45) : null}
        {robe === 'seat' ? line('M300,1040 C340,1070 380,1090 420,1150', 0.25) : null}
        {robe === 'kneel' ? line('M300,1180 C340,1260 380,1360 420,1500', 0.25) : null}
        <g transform={H}>{hl}<ellipse cx={245} cy={140} rx={9} ry={4} fill={c[0]} /></g>
      </g>
    </g>
  );
};

/* ---------------- animals ---------------- */
type AP = {x: number; y: number; m?: Metal; s?: number; flip?: boolean; lit?: number; o?: number; dim?: number};
const at = (p: AP) => `translate(${p.x} ${p.y}) scale(${(p.flip ? -1 : 1) * (p.s || 1)} ${p.s || 1})`;

export const Sheep: React.FC<AP & {graze?: boolean; lamb?: boolean}> = (p) => {
  const m = p.m || 'bronze', c = MET[m];
  const head = p.graze ? 'translate(52 -60) rotate(48) translate(-52 60)' : '';
  const body = p.lamb ? 'scale(0.82 0.9)' : '';
  return (
    <g opacity={(p.o ?? 1) * (1 - 0.62 * (p.dim || 0))}>
      <Cut m={m} lit={p.lit ?? 1} tf={at(p)}>
        <g transform={body}>
          {P('M-46,-36 L-49,0 L-41,0 L-38,-36 Z')}{P('M-28,-36 L-29,0 L-21,0 L-20,-36 Z')}{P('M22,-36 L22,0 L30,0 L30,-36 Z')}{P('M38,-36 L41,0 L49,0 L46,-36 Z')}
          {P('M-70,-58 C-74,-86 -50,-100 -18,-102 C14,-104 46,-98 58,-82 C66,-68 62,-44 44,-36 C20,-30 -24,-30 -48,-34 C-64,-38 -70,-46 -70,-58 Z')}
        </g>
        <g transform={head}>
          {P('M48,-84 C56,-98 76,-102 88,-92 C97,-84 98,-70 92,-63 C84,-56 70,-60 62,-66 C54,-71 48,-77 48,-84 Z')}
          {P('M60,-92 C53,-102 43,-102 41,-96 C45,-89 53,-89 60,-92 Z')}
        </g>
      </Cut>
      <g transform={at(p) + ' ' + head}><ellipse cx={81} cy={-83} rx={3.2} ry={1.7} fill={c[0]} /></g>
    </g>
  );
};

export const Lion: React.FC<AP> = (p) => {
  const m = p.m || 'bronze', c = MET[m];
  return (
    <g opacity={p.o ?? 1}>
      <Cut m={m} lit={p.lit ?? 1} tf={at(p)}>
        {P('M-128,-78 C-132,-108 -108,-124 -70,-126 L70,-128 C96,-128 112,-116 116,-100 L112,-62 C104,-56 92,-54 84,-54 L-96,-54 C-112,-56 -124,-64 -128,-78 Z')}
        {P('M76,-60 L74,0 L92,0 L96,-62 Z')}{P('M48,-58 L48,0 L66,0 L66,-58 Z')}{P('M-70,-58 L-74,0 L-56,0 L-50,-58 Z')}{P('M-104,-62 L-106,0 L-88,0 L-84,-60 Z')}
        {P('M-126,-92 C-150,-96 -168,-80 -176,-60 C-180,-52 -176,-46 -170,-48 C-160,-66 -146,-80 -126,-80 Z')}
        {P('M-178,-62 C-186,-60 -190,-50 -184,-44 C-176,-42 -170,-48 -170,-54 Z')}
        {P('M84,-118 C78,-160 112,-184 146,-176 C176,-170 194,-146 192,-118 C190,-92 176,-70 152,-62 C122,-60 96,-80 84,-118 Z')}
        {P('M150,-150 C168,-158 190,-152 200,-136 L214,-120 L206,-112 C208,-104 204,-96 196,-94 L192,-80 C180,-76 166,-80 158,-90 Z')}
      </Cut>
      <g transform={at(p)}><ellipse cx={186} cy={-130} rx={4.5} ry={2.2} fill={c[0]} /></g>
    </g>
  );
};

export const Wolf: React.FC<AP> = (p) => {
  const m = p.m || 'bronze', c = MET[m];
  return (
    <g opacity={p.o ?? 1}>
      <Cut m={m} lit={p.lit ?? 1} tf={at(p)}>
        {P('M-110,-74 C-112,-98 -90,-108 -60,-108 L60,-112 C84,-114 98,-104 102,-90 L96,-62 C88,-56 78,-54 70,-54 L-84,-54 C-100,-56 -108,-62 -110,-74 Z')}
        {P('M64,-60 L58,0 L74,0 L82,-60 Z')}{P('M36,-58 L38,0 L54,0 L52,-58 Z')}{P('M-64,-58 L-70,0 L-54,0 L-48,-58 Z')}{P('M-92,-60 L-98,0 L-82,0 L-78,-60 Z')}
        {P('M-108,-86 C-134,-84 -150,-60 -156,-30 C-158,-20 -150,-16 -144,-22 C-136,-46 -124,-64 -106,-70 Z')}
        {P('M88,-100 C98,-126 124,-136 146,-128 L196,-108 C204,-104 204,-96 196,-94 L150,-86 C134,-74 108,-70 92,-78 Z')}
        {P('M118,-128 L124,-160 L138,-130 Z')}{P('M132,-130 L142,-158 L150,-126 Z')}
      </Cut>
      <g transform={at(p)}><ellipse cx={154} cy={-114} rx={4} ry={2} fill={c[0]} /></g>
    </g>
  );
};

/* ---------------- line art (architecture, furniture, nature) ---------------- */
export const Line: React.FC<{d: string; o?: number; w?: number; c?: string; dash?: number; p?: number; u?: boolean}> = ({d, o = 1, w = 2.2, c = 'url(#goldLine)', p = 1, u = false}) => (
  <path d={d} fill="none" stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" opacity={o} filter={u ? "url(#lglowU)" : "url(#lglow)"} pathLength={1} strokeDasharray={p < 1 ? '1 1' : undefined} strokeDashoffset={p < 1 ? 1 - p : undefined} />
);
const LC = '#E3B465';

/** colonnade with lotus capitals, like a sanctuary/palace front. x = centre, y = ground */
export const Colonnade: React.FC<{x: number; y: number; w?: number; h?: number; n?: number; o?: number; p?: number; door?: boolean; c?: string}> = ({x, y, w = 360, h = 440, n = 2, o = 1, p = 1, door = false, c}) => {
  const L = x - w / 2, cols = Array.from({length: n}, (_, i) => L + (n === 1 ? w / 2 : (i * w) / (n - 1)));
  let d = `M${L - 40},${y - h} L${L + w + 40},${y - h} M${L - 30},${y - h + 16} L${L + w + 30},${y - h + 16}`;
  for (const cx of cols) {
    d += ` M${cx - 18},${y} L${cx - 18},${y - h + 70} M${cx + 18},${y} L${cx + 18},${y - h + 70}`;
    d += ` M${cx - 6},${y} L${cx - 6},${y - h + 74} M${cx + 6},${y} L${cx + 6},${y - h + 74}`;
    d += ` M${cx - 18},${y - h + 70} C${cx - 40},${y - h + 50} ${cx - 44},${y - h + 26} ${cx - 34},${y - h + 16} M${cx + 18},${y - h + 70} C${cx + 40},${y - h + 50} ${cx + 44},${y - h + 26} ${cx + 34},${y - h + 16}`;
    d += ` M${cx - 26},${y - h + 36} L${cx + 26},${y - h + 36} M${cx - 22},${y - 16} L${cx + 22},${y - 16}`;
  }
  if (door) d += ` M${x - 70},${y} L${x - 70},${y - h * 0.62} L${x + 70},${y - h * 0.62} L${x + 70},${y}`;
  return <g opacity={o}><Line d={d} p={p} c={c} /></g>;
};

export const House: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => {
  let d = `M-90,0 L-90,-150 L90,-150 L90,0 M-104,-150 L104,-150 M-30,0 L-30,-80 L30,-80 L30,0`;
  for (let r = 1; r < 6; r++) for (let k = 0; k < 4; k++) { const yy = -r * 24, xx = -78 + k * 44 + (r % 2) * 18; if (Math.abs(xx) < 40 && yy > -82) continue; d += ` M${xx},${yy} L${xx + 22},${yy}`; }
  return <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}><Line d={d} p={p} w={2 / s} /></g>;
};

export const Tent: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <Line w={2 / s} p={p} d="M-240,0 C-200,-60 -120,-150 0,-170 C120,-150 200,-60 240,0 M0,-170 L0,0 M-120,-140 C-120,-90 -110,-40 -100,0 M120,-140 C120,-90 110,-40 100,0 M-40,0 L-20,-80 L20,-80 L40,0" />
  </g>
);

export const Pyramids: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <Line w={2 / s} p={p} d="M-300,0 L-120,-230 L60,0 M-120,-230 L-80,0 M10,0 L150,-170 L290,0 M150,-170 L180,0" />
  </g>
);

export const Ladder: React.FC<{x: number; y: number; h: number; o?: number; p?: number; rungs?: number}> = ({x, y, h, o = 1, p = 1, rungs = 7}) => {
  let d = `M${x - 70},${y} L${x - 70},${y - h} M${x + 70},${y} L${x + 70},${y - h}`;
  for (let i = 1; i <= rungs; i++) d += ` M${x - 70},${y - (i * h) / (rungs + 1)} L${x + 70},${y - (i * h) / (rungs + 1)}`;
  return <g opacity={o}><Line d={d} p={p} /></g>;
};

export const Throne: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <Line w={2.2 / s} p={p} d="M-110,0 L-110,-330 C-110,-356 -78,-356 -78,-330 L-78,-150 L120,-150 L120,0 M-78,-150 L-78,0 M-120,-150 L130,-150 M-120,-130 L130,-130 M-90,-330 L-90,-160 M90,-130 L90,0" />
  </g>
);

export const Bed: React.FC<{x: number; y: number; w?: number; o?: number; p?: number}> = ({x, y, w = 420, o = 1, p = 1}) => (
  <g opacity={o}><Line p={p} d={`M${x},${y} L${x},${y - 90} L${x + w},${y - 90} L${x + w},${y} M${x - 6},${y - 90} L${x + w + 6},${y - 90} M${x - 6},${y - 110} L${x + w + 6},${y - 110} M${x - 6},${y - 90} L${x - 6},${y - 110} M${x + w + 6},${y - 90} L${x + w + 6},${y - 110}`} /></g>
);

export const Table: React.FC<{x: number; y: number; w?: number; o?: number; p?: number}> = ({x, y, w = 520, o = 1, p = 1}) => (
  <g opacity={o}><Line p={p} d={`M${x - w / 2},${y - 120} L${x + w / 2},${y - 120} M${x - w / 2},${y - 132} L${x + w / 2},${y - 132} M${x - w / 2 + 30},${y - 120} L${x - w / 2 + 30},${y} M${x + w / 2 - 30},${y - 120} L${x + w / 2 - 30},${y}`} /></g>
);

export const Hills: React.FC<{y: number; o?: number; p?: number; x0?: number; x1?: number}> = ({y, o = 0.55, p = 1, x0 = 0, x1 = 1920}) => (
  <g opacity={o}><Line w={1.4} p={p} d={`M${x0},${y - 20} C${x0 + 300},${y - 110} ${x0 + 520},${y - 40} ${x0 + 760},${y - 90} C${x0 + 1000},${y - 140} ${x0 + 1240},${y - 50} ${x0 + 1500},${y - 100} C${x0 + 1700},${y - 130} ${x1 - 120},${y - 60} ${x1},${y - 80}`} /></g>
);

export const Stalks: React.FC<{x0: number; x1: number; y: number; n?: number; o?: number; seed?: number}> = ({x0, x1, y, n = 14, o = 0.45, seed = 3}) => {
  let s = seed; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  let d = '';
  for (let i = 0; i < n; i++) { const x = x0 + ((x1 - x0) * (i + r() * 0.6)) / n, h = 70 + r() * 60; d += ` M${x},${y} L${x + 2},${y - h} M${x + 2},${y - h} c-5,-8 -5,-24 0,-30 c5,6 5,22 0,30`; }
  return <g opacity={o}><Line w={1.3} d={d} /></g>;
};

export const Sun: React.FC<{x: number; y: number; r?: number; o?: number; t?: number}> = ({x, y, r = 26, o = 1, t = 0}) => {
  let d = '';
  for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2 + t * 0.002; d += ` M${x + Math.cos(a) * (r + 8)},${y + Math.sin(a) * (r + 8)} L${x + Math.cos(a) * (r + 20)},${y + Math.sin(a) * (r + 20)}`; }
  return (
    <g opacity={o}>
      <circle cx={x} cy={y} r={r * 6} fill="url(#halo)" opacity={0.7} />
      <circle cx={x} cy={y} r={r} fill="#F3D08A" opacity={0.9} filter="url(#soft3)" />
      <circle cx={x} cy={y} r={r * 0.9} fill="#FFE6B0" />
      <path d={d} stroke="#F3D08A" strokeWidth={2.4} strokeLinecap="round" filter="url(#lglow)" />
    </g>
  );
};
export const Moon: React.FC<{x: number; y: number; r?: number; o?: number}> = ({x, y, r = 34, o = 1}) => (
  <g opacity={o}>
    <circle cx={x} cy={y} r={r * 5} fill="url(#halo)" opacity={0.5} />
    <path d={`M${x},${y - r} A${r},${r} 0 1 0 ${x},${y + r} A${r * 1.3},${r * 1.3} 0 0 1 ${x},${y - r} Z`} fill="#F1DDB0" filter="url(#lglow)" />
  </g>
);
export const Star: React.FC<{x: number; y: number; r?: number; o?: number; f?: number}> = ({x, y, r = 30, o = 1, f = 0}) => {
  const k = 1 + 0.08 * Math.sin(f / 9);
  const R = r * k;
  return (
    <g opacity={o}>
      <circle cx={x} cy={y} r={R * 4} fill="url(#halo)" opacity={0.8} />
      <path d={`M${x},${y - R} Q${x + R * 0.16},${y - R * 0.16} ${x + R},${y} Q${x + R * 0.16},${y + R * 0.16} ${x},${y + R} Q${x - R * 0.16},${y + R * 0.16} ${x - R},${y} Q${x - R * 0.16},${y - R * 0.16} ${x},${y - R} Z`} fill="#FFE8B8" filter="url(#lglow)" />
    </g>
  );
};
export const Fire: React.FC<{x: number; y: number; s?: number; o?: number; f: number}> = ({x, y, s = 1, o = 1, f}) => {
  const w = (k: number) => Math.sin(f / 4 + k) * 6;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
      <ellipse cx={0} cy={-30} rx={130} ry={100} fill="url(#halo)" opacity={0.9} />
      <path d={`M-30,0 C-40,-30 -20,-50 ${-14 + w(1)},-86 C0,-60 10,-56 ${8 + w(2)},-110 C30,-70 44,-40 30,0 Z`} fill="#F6C46E" filter="url(#lglow)" opacity={0.95} />
      <path d={`M-14,0 C-18,-20 -6,-34 ${-2 + w(3)},-56 C10,-36 18,-24 12,0 Z`} fill="#FFF0C8" />
      <Line w={2} d="M-50,4 L40,-8 M-40,-8 L50,4" />
    </g>
  );
};
export const Eyes: React.FC<{x: number; y: number; o?: number}> = ({x, y, o = 1}) => (
  <g opacity={o}>
    <ellipse cx={x - 12} cy={y} rx={6} ry={3} fill="#F2C46E" filter="url(#lglow)" />
    <ellipse cx={x + 12} cy={y} rx={6} ry={3} fill="#F2C46E" filter="url(#lglow)" />
  </g>
);
export const Glow: React.FC<{x: number; y: number; r: number; o?: number; c?: string}> = ({x, y, r, o = 1, c = '#7A5526'}) => (
  <circle cx={x} cy={y} r={r} fill="url(#halo)" opacity={o} />
);

export {ActingFigure, plantedWalk, solveArm} from "./acting";
export type {ActingPose, HandPose, Stance} from "./acting";
