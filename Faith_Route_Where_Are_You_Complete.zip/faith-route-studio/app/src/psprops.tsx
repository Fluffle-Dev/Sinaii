import React from 'react';
import {Line, Cut, Metal, TXT} from './fig';
import {win, fi, ramp, eio, eout, rng, clamp} from './lib';

const G = (x: number, y: number, s = 1) => `translate(${x} ${y}) scale(${s})`;

/* ============ the southern corner of the temple: x = corner, top = wall top ============ */
export const PIN = {x: 1180, top: 480};
export const Pinnacle: React.FC<{x?: number; top?: number; w?: number; o?: number; p?: number; f?: number; wing?: number}> = ({x = PIN.x, top = PIN.top, w = 1100, o = 1, p = 1, f = 0, wing = 0}) => {
  if (o <= 0.001) return null;
  const L = x - w, B = 1120, rows = Math.ceil((B - top) / 46);
  let joints = '';
  for (let r = 0; r < rows; r++) {
    const yy = top + 30 + r * 46;
    joints += ` M${L},${yy} L${x},${yy}`;
    for (let k = 0; k < 14; k++) { const xx = L + ((k + (r % 2) * 0.5) * w) / 13; if (xx < x - 8) joints += ` M${xx},${yy} L${xx},${yy + 46}`; }
  }
  let cols = `M${L},${top - 150} L${x - 70},${top - 150} M${L},${top - 162} L${x - 60},${top - 162}`;
  for (let xx = L + 30; xx < x - 90; xx += 64) cols += ` M${xx},${top} L${xx},${top - 150}`;
  return (
    <g opacity={o}>
      <path d={`M${L},${top} L${x},${top} L${x + 70},${top + 40} L${x + 70},${B} L${L},${B} Z`} fill="#110c07" opacity={0.96} />
      <path d={`M${x},${top} L${x + 70},${top + 40} L${x + 70},${B} L${x},${B} Z`} fill="#070503" opacity={0.9} />
      <Line w={1.1} p={p} o={0.32} c="#B98A45" d={joints} />
      <Line w={2.6} p={p} d={`M${L},${top} L${x},${top} L${x + 70},${top + 40} M${x},${top} L${x},${B} M${x + 70},${top + 40} L${x + 70},${B}`} />
      <Line w={1.8} p={p} o={0.75} d={cols} />
      {/* the corner platform: the little wing */}
      <path d={`M${x - 90},${top} L${x - 90},${top - 56} L${x + 6},${top - 56} L${x + 6},${top} Z`} fill="#160f08" />
      <Line w={2.4} p={p} d={`M${x - 96},${top - 56} L${x + 12},${top - 56} M${x - 90},${top - 56} L${x - 90},${top} M${x + 6},${top - 56} L${x + 6},${top}`} />
      {wing > 0 ? <g opacity={wing}><ellipse cx={x - 40} cy={top - 70} rx={220} ry={120} fill="url(#halo)" opacity={0.8} /><Line w={2.2} d={`M${x - 40},${top - 70} C${x - 120},${top - 190} ${x - 260},${top - 210} ${x - 330},${top - 150} C${x - 270},${top - 140} ${x - 210},${top - 110} ${x - 180},${top - 70} M${x - 60},${top - 90} C${x - 140},${top - 150} ${x - 220},${top - 150} ${x - 270},${top - 115}`} c="#F3D9A0" u /></g> : null}
      {/* the valley falling away below the corner */}
      <Line w={1.6} p={p} o={0.5} d={`M${x + 70},${B - 120} C${x + 200},${B - 60} ${x + 420},${B - 20} 1940,${B - 30} M${x + 70},${B - 240} C${x + 260},${B - 170} ${x + 520},${B - 130} 1940,${B - 140}`} />
    </g>
  );
};
/** standing point on top of the corner platform */
export const pinTop = (x = PIN.x, top = PIN.top) => ({x: x - 42, y: top - 56});

/* ============ looking straight down from the pinnacle ============ */
export const LookDown: React.FC<{f: number; o?: number; p?: number; zoom?: number}> = ({f, o = 1, p = 1, zoom = 0}) => {
  if (o <= 0.001) return null;
  const r = rng(91);
  const ppl = Array.from({length: 120}, () => ({x: 380 + r() * 1160, y: 700 + r() * 330, s: 0.8 + r() * 0.8}));
  const s = 1 + 0.12 * zoom;
  let grid = '';
  for (let i = 0; i <= 12; i++) { const xb = 200 + i * 126, xt = 760 + i * 33; grid += ` M${xt},560 L${xb},1080`; }
  for (let j = 0; j < 7; j++) { const t = j / 6, yy = 560 + 520 * t * t, hw = 200 + 760 * t * t; grid += ` M${960 - hw},${yy} L${960 + hw},${yy}`; }
  return (
    <g opacity={o}>
      <g transform={`translate(960 760) scale(${s}) translate(-960 -760)`}>
        <path d="M560,560 L1360,560 L1760,1080 L160,1080 Z" fill="#1a130b" opacity={0.9} />
        <Line w={1} o={0.35} p={p} c="#B98A45" d={grid} />
        {ppl.map((q, i) => <ellipse key={i} cx={q.x} cy={q.y} rx={4 * q.s} ry={3 * q.s} fill={i % 3 ? '#9C6A3E' : '#C08A52'} opacity={0.7 * p} />)}
      </g>
      {/* the wall falling away: converging edges */}
      <path d="M0,0 L1920,0 L1920,250 L1360,560 L560,560 L0,250 Z" fill="#0d0905" />
      <Line w={1.4} o={0.5} p={p} d="M0,250 L560,560 M1920,250 L1360,560 M200,140 L640,500 M1720,140 L1280,500 M560,560 L1360,560" />
      <path d="M0,0 L1920,0 L1920,110 L0,110 Z" fill="#160f08" />
      <Line w={2.6} d="M0,110 L1920,110" c="#E3B465" />
    </g>
  );
};

/* ============ Psalm 91 column: the recurring diagram ============ */
export const LABELS = [
  'THE SHELTER OF THE MOST HIGH', 'MY REFUGE AND MY FORTRESS', 'THE FOWLER’S SNARE', 'UNDER HIS WINGS', 'THE TERROR OF NIGHT', 'THE PLAGUE AT MIDDAY',
  'A THOUSAND MAY FALL', 'YOU WILL ONLY OBSERVE', 'THE MOST HIGH YOUR DWELLING', 'NO HARM WILL OVERTAKE YOU', 'HIS ANGELS CONCERNING YOU', 'LIFTED UP IN THEIR HANDS',
  'THE LION AND THE SERPENT', 'BECAUSE HE LOVES ME', 'I WILL BE WITH HIM IN TROUBLE', 'MY SALVATION',
];
export type RS = {c?: string; o?: number; strike?: number; glow?: number};
export const C = {ivory: '#ECE3D0', gold: '#E9BE6E', ember: '#E2785A', dim: '#7E725F'};
/** rows(v) gives each verse's look; ways = the 'in all your ways' half of v11; stop = the devil's bookmark under v12 */
export const PsalmCol: React.FC<{f: number; o: number; x?: number; y?: number; rows?: (v: number) => RS; ways?: RS; stop?: number; stopLab?: number; rh?: number; title?: number}> = ({f, o, x = 960, y = 200, rows = (): RS => ({}), ways, stop = 0, stopLab = 0, rh = 46, title = 1}) => {
  if (o <= 0.001) return null;
  const W = 1180, x0 = x - W / 2;
  const H = rh * 16 + 70;
  const tl = (s: string) => s.length * 22;
  return (
    <g opacity={o}>
      <rect x={x0 - 30} y={y - 66} width={W + 60} height={H + 30} fill="#000" opacity={0.42} />
      <rect x={x0 - 30} y={y - 66} width={W + 60} height={H + 30} fill="none" stroke="url(#goldLine)" strokeWidth={1.6} filter="url(#lglow)" />
      <text x={x} y={y - 22} textAnchor="middle" fill={C.gold} fontFamily="Cinzel" fontSize={36} letterSpacing={10} opacity={title}>PSALM 91</text>
      {LABELS.map((lab, i) => {
        const v = i + 1, st = rows(v), yy = y + 30 + i * rh;
        const col = st.c ?? C.ivory, op = st.o ?? 0.55;
        const main = v === 11 ? 'HIS ANGELS CONCERNING YOU ·' : lab;
        const w1 = tl(main);
        return (
          <g key={v}>
            {st.glow ? <rect x={x0 - 14} y={yy - 30} width={W + 28} height={rh - 2} fill={col} opacity={0.12 * st.glow} /> : null}
            <text x={x0 + 34} y={yy} textAnchor="end" fill={C.gold} fontFamily="Cinzel" fontSize={26} opacity={0.4 + 0.6 * op}>{v}</text>
            <text x={x0 + 62} y={yy} fill={col} fontFamily="Cinzel" fontSize={30} letterSpacing={2} textLength={w1} lengthAdjust="spacingAndGlyphs" opacity={op}>{main}</text>
            {st.strike ? <path d={`M${x0 + 56},${yy - 9} L${x0 + 62 + (w1 + 8) * st.strike},${yy - 9}`} stroke={C.ember} strokeWidth={3} opacity={op + 0.3} /> : null}
            {v === 11 ? (() => {
              const ws: RS = ways ?? {c: col, o: op};
              const wx = x0 + 62 + w1 + 14, w2 = tl('IN ALL YOUR WAYS');
              return <>
                {ws.glow ? <rect x={wx - 8} y={yy - 30} width={w2 + 16} height={rh - 2} fill={ws.c ?? col} opacity={0.18 * ws.glow} /> : null}
                <text x={wx} y={yy} fill={ws.c ?? col} fontFamily="Cinzel" fontSize={30} letterSpacing={2} textLength={w2} lengthAdjust="spacingAndGlyphs" opacity={ws.o ?? op}>IN ALL YOUR WAYS</text>
                {ws.strike ? <path d={`M${wx - 6},${yy - 9} L${wx - 6 + (w2 + 12) * ws.strike},${yy - 9}`} stroke={C.ember} strokeWidth={3.4} /> : null}
              </>;
            })() : null}
          </g>
        );
      })}
      {stop > 0 ? (() => {
        const yy = y + 30 + 11 * rh + 14;
        return <g>
          <path d={`M${x0 - 20},${yy} L${x0 - 20 + (W + 40) * stop},${yy}`} stroke={C.ember} strokeWidth={3} strokeDasharray="14 8" />
          <text x={x0 + W + 24} y={yy - 10} textAnchor="end" fill={C.ember} fontFamily="Cinzel" fontSize={26} letterSpacing={4} opacity={stopLab}>HE STOPPED HERE</text>
        </g>;
      })() : null}
    </g>
  );
};

/* ============ serpent: a sinuous cut-out, head at the right ============ */
export const Serpent: React.FC<{x: number; y: number; s?: number; f?: number; o?: number; m?: Metal; rear?: number; crush?: number; flip?: boolean; lit?: number; L?: number; eye?: number}> = ({x, y, s = 1, f = 0, o = 1, m = 'shadow', rear = 0, crush = 0, flip = false, lit = 1, L = 520, eye = 1}) => {
  if (o <= 0.001) return null;
  const N = 40, A = 24 * (1 - 0.55 * crush), th = 30;
  const top: string[] = [], bot: string[] = [];
  let hx = 0, hy = 0;
  for (let i = 0; i <= N; i++) {
    const t = i / N, xx = t * L;
    const lift = rear * 170 * Math.pow(clamp((t - 0.62) / 0.38), 1.6);
    const yy = -th / 2 - A * Math.sin(t * Math.PI * 2.4 + f / 14) * (1 - 0.7 * clamp((t - 0.7) / 0.3)) - lift;
    const w = th * (0.12 + 0.88 * Math.sin(Math.min(1, t * 1.25) * Math.PI / 2)) * (1 - 0.35 * crush);
    top.push(`${xx},${yy - w / 2}`); bot.unshift(`${xx},${yy + w / 2}`);
    if (i === N) { hx = xx; hy = yy; }
  }
  const hr = 1.5 * (1 - 0.55 * crush);
  const d = `M${top.join(' L')} L${bot.join(' L')} Z`;
  const head = `M${hx - 10},${hy - 15 * hr} C${hx + 20},${hy - 26 * hr} ${hx + 76},${hy - 16 * hr} ${hx + 92},${hy - 2 * hr} C${hx + 76},${hy + 12 * hr} ${hx + 20},${hy + 20 * hr} ${hx - 10},${hy + 15 * hr} Z`;
  const tf = `translate(${x} ${y}) scale(${(flip ? -1 : 1) * s} ${s})`;
  return (
    <g opacity={o}>
      <Cut m={m} lit={lit} tf={tf}><path d={d} /><path d={head} /></Cut>
      {eye > 0 && crush < 0.6 ? <g transform={tf}><ellipse cx={hx + 50} cy={hy - 6 * hr} rx={8} ry={4} fill="#FF7A48" opacity={0.6 * eye} filter="url(#lglow)" /><ellipse cx={hx + 50} cy={hy - 6 * hr} rx={4} ry={2} fill="#FFD9B8" opacity={eye} /></g> : null}
    </g>
  );
};

/* ============ dot grid: forty years / forty days ============ */
export const DotGrid: React.FC<{f: number; a: number; b?: number; x: number; y: number; n?: number; cols?: number; gap?: number; r?: number; c?: string; dur?: number; label?: string; sub?: string; dim?: number}> = ({f, a, b, x, y, n = 40, cols = 10, gap = 44, r = 12, c = C.gold, dur = 60, label, sub, dim = 0}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const rowsN = Math.ceil(n / cols), w = (cols - 1) * gap;
  return (
    <g opacity={o * (1 - 0.55 * dim)}>
      {Array.from({length: n}, (_, i) => {
        const cx = x - w / 2 + (i % cols) * gap, cy = y + Math.floor(i / cols) * gap;
        const t = fi(f, a + (i * dur) / n, 8);
        return <g key={i}><circle cx={cx} cy={cy} r={r} fill="none" stroke={c} strokeWidth={1.4} opacity={0.35} /><circle cx={cx} cy={cy} r={r * 0.78 * t} fill={c} opacity={0.9} /></g>;
      })}
      {label ? <text x={x} y={y + rowsN * gap + 40} textAnchor="middle" fill={c} fontFamily="Cinzel" fontSize={40} letterSpacing={8}>{label}</text> : null}
      {sub ? <text x={x} y={y + rowsN * gap + 88} textAnchor="middle" fill={C.ivory} fontFamily="Corm" fontStyle="italic" fontSize={40}>{sub}</text> : null}
    </g>
  );
};

/* ============ shield that turns into bait ============ */
export const Shield: React.FC<{x: number; y: number; s?: number; o?: number; flip?: number; f?: number}> = ({x, y, s = 1, o = 1, flip = 0, f = 0}) => {
  if (o <= 0.001) return null;
  const k = Math.cos(Math.PI * flip), turned = flip > 0.5;
  const sh = 'M0,-170 C60,-150 110,-150 150,-160 C156,-40 120,80 0,170 C-120,80 -156,-40 -150,-160 C-110,-150 -60,-150 0,-170 Z';
  const sway = turned ? Math.sin(f / 22) * 4 : 0;
  return (
    <g opacity={o}>
      {turned ? <Line w={2.4} c={C.ember} o={eout(ramp(flip, 0.6, 0.4))} d={`M${x},${y - 170 * s - 380} L${x},${y - 170 * s} M${x - 30},${y - 170 * s - 380} L${x + 30},${y - 170 * s - 380}`} u /> : null}
      <g transform={`translate(${x} ${y}) rotate(${sway}) scale(${Math.max(0.05, Math.abs(k)) * s} ${s})`}>
        <Cut m={turned ? 'shadow' : 'gold'} lit={1}><path d={sh} /></Cut>
        <Line w={3 / s} c={turned ? C.ember : '#F3D9A0'} o={0.8} d="M0,-120 L0,120 M-90,-40 L90,-40" u />
      </g>
    </g>
  );
};

/* ============ road with stones, drawn in perspective ============ */
export const PathRoad: React.FC<{p?: number; o?: number; y?: number; lit?: number}> = ({p = 1, o = 1, y = 860, lit = 1}) => {
  if (o <= 0.001) return null;
  const r = rng(33);
  const st = Array.from({length: 18}, () => ({x: 120 + r() * 1680, y: y + 10 + r() * 60, s: 0.25 + r() * 0.35}));
  return (
    <g opacity={o}>
      <Line w={2} p={p} d={`M0,${y + 70} C500,${y + 20} 1300,${y + 20} 1920,${y + 70}`} />
      <Line w={1.4} p={p} o={0.6} d={`M0,${y + 6} C600,${y - 18} 1300,${y - 18} 1920,${y + 6}`} />
      {st.map((q, i) => <ellipse key={i} cx={q.x} cy={q.y} rx={34 * q.s} ry={14 * q.s} fill="#7a5a34" opacity={0.6 * p * lit} />)}
    </g>
  );
};

/* ============ safety net under a leap ============ */
export const Net: React.FC<{x: number; y: number; w?: number; p?: number; o?: number}> = ({x, y, w = 700, p = 1, o = 1}) => {
  if (o <= 0.001) return null;
  let d = `M${x - w / 2},${y} Q${x},${y + 160} ${x + w / 2},${y}`;
  for (let i = 1; i < 10; i++) { const t = i / 10, xx = x - w / 2 + w * t, yy = y + 160 * 2 * t * (1 - t); d += ` M${xx},${yy} L${xx + (t - 0.5) * 40},${y - 30}`; }
  d += ` M${x - w / 2},${y - 30} Q${x},${y + 110} ${x + w / 2},${y - 30}`;
  return <g opacity={o}><Line w={2} c={C.ember} p={p} d={d} u /></g>;
};

/* ============ ivory plaque frame (rounded top) ============ */
export const Plaque: React.FC<{x: number; y: number; w?: number; h?: number; p?: number; o?: number}> = ({x, y, w = 560, h = 720, p = 1, o = 1}) => {
  if (o <= 0.001) return null;
  const L = x - w / 2, R = x + w / 2, T = y - h, B = y;
  return (
    <g opacity={o}>
      <path d={`M${L},${B} L${L},${T + w / 2} A${w / 2},${w / 2} 0 0 1 ${R},${T + w / 2} L${R},${B} Z`} fill="#1d150c" opacity={0.92} />
      <Line w={3} p={p} d={`M${L},${B} L${L},${T + w / 2} A${w / 2},${w / 2} 0 0 1 ${R},${T + w / 2} L${R},${B} Z M${L + 22},${B - 22} L${L + 22},${T + w / 2} A${w / 2 - 22},${w / 2 - 22} 0 0 1 ${R - 22},${T + w / 2} L${R - 22},${B - 22} Z`} />
    </g>
  );
};

/* ============ twelve legions: faint ranks of angels ============ */
export const Legions: React.FC<{f: number; o?: number; y?: number; n?: number}> = ({f, o = 1, y = 330, n = 12}) => {
  if (o <= 0.001) return null;
  return (
    <g opacity={o}>
      <ellipse cx={960} cy={y} rx={900} ry={200} fill="url(#halo)" opacity={0.5} />
      {Array.from({length: n}, (_, i) => {
        const t = i / (n - 1), x = 200 + t * 1520, yy = y + Math.sin(t * Math.PI) * -80 + 40;
        return <g key={i} opacity={fi(f, i * 3, 20)}>
          <path transform={`translate(${x} ${yy})`} d="M0,-10 C-40,-60 -100,-70 -130,-40 C-100,-34 -70,-20 -50,0 C-80,-4 -100,4 -110,14 C-70,22 -30,16 0,6 C30,16 70,22 110,14 C100,4 80,-4 50,0 C70,-20 100,-34 130,-40 C100,-70 40,-60 0,-10 Z" fill="#F0D69C" opacity={0.55} filter="url(#lglow)" />
          <ellipse cx={x} cy={yy - 24} rx={12} ry={14} fill="#F6E4B8" opacity={0.6} />
          <path d={`M${x - 16},${yy - 6} L${x + 16},${yy - 6} L${x + 22},${yy + 70} L${x - 22},${yy + 70} Z`} fill="#F0D69C" opacity={0.45} />
        </g>;
      })}
    </g>
  );
};

/* ============ cave + jars (Qumran) ============ */
export const Qumran: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <path d="M-520,0 L-420,-260 L-300,-360 L-120,-420 L80,-400 L260,-330 L420,-200 L520,0 Z" fill="#120c07" />
    <path d="M-150,0 C-160,-120 -100,-210 -10,-214 C90,-218 150,-130 140,0 Z" fill="#050302" />
    <Line w={2.4 / s} p={p} d="M-520,0 L-420,-260 L-300,-360 L-120,-420 L80,-400 L260,-330 L420,-200 L520,0 M-150,0 C-160,-120 -100,-210 -10,-214 C90,-218 150,-130 140,0 M-380,-170 L-300,-200 M200,-280 L300,-240" />
  </g>
);
export const ScrollJar: React.FC<{x: number; y: number; s?: number; o?: number; lid?: number}> = ({x, y, s = 1, o = 1, lid = 0}) => (
  <g opacity={o}>
    <Cut m="bronze" lit={1} tf={G(x, y, s)}>
      <path d="M-50,0 C-70,-40 -72,-150 -52,-200 L52,-200 C72,-150 70,-40 50,0 Z" />
      <path d={`M-58,${-200 - 60 * lid} L58,${-200 - 60 * lid} L50,${-226 - 60 * lid} L-50,${-226 - 60 * lid} Z`} />
    </Cut>
    {lid > 0 ? <g transform={G(x, y, s)} opacity={lid}><rect x={-16} y={-280 - 60 * lid} width={32} height={110} rx={10} fill="#E8D3A4" /><Line w={1.4 / s} c="#7a5a34" d={`M-8,${-262 - 60 * lid} L8,${-262 - 60 * lid} M-8,${-240 - 60 * lid} L8,${-240 - 60 * lid}`} /></g> : null}
  </g>
);
