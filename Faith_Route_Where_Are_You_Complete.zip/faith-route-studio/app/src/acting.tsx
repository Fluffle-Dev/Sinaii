import React from 'react';
import {Fig, type Metal, type FigP} from './fig';

export type Point = [number, number];
export const mix = (a: number, b: number, t: number) => a + (b - a) * t;
export const blend = (a: Point, b: Point, t: number): Point => [mix(a[0], b[0], t), mix(a[1], b[1], t)];
export const ease = (t: number) => {
  const u = Math.max(0, Math.min(1, t));
  return u * u * (3 - 2 * u);
};
export const beat = (f: number, a: number, b: number) => ease((f - a) / (b - a));
const between = (a: Point, b: Point) => Math.hypot(b[0] - a[0], b[1] - a[1]);
export type Stance = {x: number; feet: [Point, Point]; lift: number};
// Coordinates are stage units. Only the swinging shoe advances during each step.
export function plantedWalk(
  f: number,
  from: number,
  to: number,
  start: number,
  end: number,
  steps: number,
): Stance {
  const phase = Math.max(0, Math.min(steps, ((f - start) / (end - start)) * steps));
  const stride = (to - from) / steps,
    sign = Math.sign(stride) || 1;
  const feet: [Point, Point] = [
    [from - 10 * sign, 0],
    [from + 10 * sign, 0],
  ];
  const stops = [from],
    landings = [feet[0][0], feet[1][0]];
  for (let n = 0; n < steps; n++) {
    const leg = n % 2,
      t = Math.max(0, Math.min(1, phase - n));
    const target =
      n === steps - 1 ? to + 10 * sign : n === steps - 2 ? to - 10 * sign : from + (n + 1) * stride + 10 * sign;
    landings[leg] = target;
    stops.push((landings[0] + landings[1]) / 2);
    feet[leg] = [mix(feet[leg][0], target, ease(t)), -11 * Math.sin(Math.PI * t) ** 2];
  }
  const i = Math.min(steps - 1, Math.floor(phase)),
    t = phase - i,
    t2 = t * t,
    t3 = t2 * t;
  const v0 = i ? (stops[i + 1] - stops[i - 1]) / 2 : 0;
  const v1 = i + 2 <= steps ? (stops[i + 2] - stops[i]) / 2 : 0;
  const x =
    (2 * t3 - 3 * t2 + 1) * stops[i] + (t3 - 2 * t2 + t) * v0 + (-2 * t3 + 3 * t2) * stops[i + 1] + (t3 - t2) * v1;
  return {x, feet, lift: 2.3 * Math.sin(Math.PI * phase) ** 2};
}
// Two-link solve in drawing units. Targets beyond the limb's reach are clamped.
export function solveArm(root: Point, target: Point, a = 42, b = 42): {elbow: Point; wrist: Point} {
  const distance = between(root, target),
    d = Math.min(a + b - 0.001, Math.max(Math.abs(a - b) + 0.001, distance));
  const ux = distance ? (target[0] - root[0]) / distance : 0,
    uy = distance ? (target[1] - root[1]) / distance : 1;
  const along = (a * a - b * b + d * d) / (2 * d),
    normal = Math.sqrt(Math.max(0, a * a - along * along));
  return {
    elbow: [root[0] + ux * along - uy * normal, root[1] + uy * along + ux * normal],
    wrist: [root[0] + ux * d, root[1] + uy * d],
  };
}
export type HandPose = {point: Point; angle: number}; // stage contact point; palm angle in facing-local degrees
export type ActingPose = {
  x: number;
  floor: number;
  scale: number;
  facing: 1 | -1;
  metal: Metal;
  dress: 'mantle' | 'veil';
  costume?: Pick<FigP, 'hair' | 'beard' | 'mantle' | 'crown'>;
  /** Screen-space light side. +1 illuminates the right contour; -1 the left. */
  lightSide?: 1 | -1;
  /** SVG viewBox width; use 1920 for a full-size studio scene. */
  stageWidth?: number;
  feet: [Point, Point]; // stage x and vertical displacement from floor
  kneel: number;
  lean: number;
  shoulder: number;
  look: number;
  nod: number;
  lift?: number;
  near: HandPose;
  far: HandPose;
};
// Use the original 600 × 1560 figure coordinates for both body art and inverse kinematics.
export type ArmPlacement = {root: Point; elbow: Point; wrist: Point; palmAngle: number};
export type NativeMotion = {
  rimUnit: number;
  near: ArmPlacement;
  far: ArmPlacement;
  dy: number;
  kneel: number;
  headWidth: number;
  feet: Point[];
  hemBack: number;
  hemFront: number;
};
function rotate([x, y]: Point, degrees: number): Point {
  const a = (degrees * Math.PI) / 180;
  return [x * Math.cos(a) - y * Math.sin(a), x * Math.sin(a) + y * Math.cos(a)];
}
export function nativeActingPose(p: ActingPose): FigP & {motion: NativeMotion} {
  const sc = p.scale * 0.152,
    k = Math.max(0, Math.min(1, p.kneel));
  const dy = k * 315 - (p.lift ?? 0) / sc;
  const bend = p.lean * 0.58;
  // Inverse of the figure's stage transform and torso rotation.
  const local = (point: Point): Point => [
    200 + (point[0] - p.x) / (p.facing * sc),
    1545 + (point[1] - p.floor) / sc,
  ];
  const unbend = (point: Point): Point => {
    const [x, y] = local(point),
      [u, v] = rotate([x - 290, y - 905 - dy], -bend);
    return [290 + u, 905 + v];
  };
  function place(hand: HandPose, far: boolean): ArmPlacement {
    const root: Point = [
      240 + p.shoulder / sc - (far ? 50 + 22 * (1 - Math.abs(p.look)) : 0),
      350 + (far ? 14 : 0),
    ];
    const contact = unbend(hand.point),
      angle = hand.angle - bend;
    const pad = rotate([8, 38], angle - 90);
    const goal: Point = [contact[0] - pad[0], contact[1] - pad[1]];
    const extension = Math.max(1, between(root, goal) / 494);
    const {elbow, wrist} = solveArm(root, goal, 350 * extension, 146 * extension);
    return {root, elbow, wrist, palmAngle: angle - 90};
  }
  const feet = p.feet.map(([x, off]) => local([x, p.floor + off]));
  const rimUnit = (p.stageWidth ?? 960) / 1920;
  const motion: NativeMotion = {
    rimUnit,
    near: place(p.near, false),
    far: place(p.far, true),
    dy,
    kneel: k,
    headWidth: 0.8 + 0.2 * Math.min(1, Math.abs(p.look)),
    feet,
    hemBack: Math.min(0, Math.min(...feet.map((pt) => pt[0])) - 142) * (1 - k),
    hemFront: Math.max(0, Math.max(...feet.map((pt) => pt[0])) - 258) * (1 - k),
  };
  return {
    x: p.x / rimUnit,
    y: p.floor / rimUnit,
    sc: sc / rimUnit,
    flip: p.facing < 0,
    m: p.metal,
    lit: p.lightSide ?? 1,
    head: p.nod,
    bend,
    robe: 'stand',
    hair: p.dress === 'veil' ? 'veil' : 'long',
    beard: p.dress === 'veil' ? 'none' : 'long',
    mantle: p.dress === 'mantle',
    ...p.costume,
    motion,
  };
}
export function ActingFigure(p: ActingPose) {
  return <Fig acting={p} />;
}

// Pair homologous hem points from LOW_STAND and LOW_KNEEL, keeping their cubic contours.
export function movingRobe({kneel: t, dy, hemBack: b, hemFront: f}: NativeMotion) {
  const xy = (x: number, y: number, kx: number, ky: number) => mix(x, kx, t) + ',' + mix(y, ky, t);
  const top = dy - 315 * t;
  return (
    'M' +
    xy(64, 860 + top, 72, 1140 + top) +
    ' C' +
    xy(62, 1100, 30, 1210) +
    ' ' +
    xy(58 + b * 0.5, 1300, -14, 1320) +
    ' ' +
    xy(58 + b, 1440, -18, 1420) +
    ' C' +
    xy(58 + b, 1494, -22, 1500) +
    ' ' +
    xy(84 + b, 1516, 6, 1540) +
    ' ' +
    xy(126 + b, 1516, 56, 1540) +
    ' L' +
    xy(304 + f, 1516, 480, 1540) +
    ' C' +
    xy(340 + f, 1516, 512, 1540) +
    ' ' +
    xy(354 + f, 1494, 522, 1514) +
    ' ' +
    xy(350 + f, 1452, 506, 1490) +
    ' C' +
    xy(344 + f * 0.6, 1351, 470, 1430) +
    ' ' +
    xy(337 + f * 0.4, 1240, 420, 1330) +
    ' ' +
    xy(331 + f * 0.2, 1137, 366, 1266) +
    ' C' +
    xy(322, 1030, 336, 1232) +
    ' ' +
    xy(313, 930, 312, 1206) +
    ' ' +
    xy(306, 860 + top, 302, 1170 + top) +
    'Z'
  );
}
