import React from 'react';

// Original courtyard, drawn in the same 960 × 540 stage space as the performance.
export function Courtyard() {
  const arch = 'M99,424 V211 C99,91 226,33 388,26 C520,21 674,50 717,117 Q737,147 737,191 V424Z';
  return (
    <>
      <defs>
        <radialGradient id="evening" cx=".56" cy=".65" r=".78">
          <stop stopColor="#986d39" />
          <stop offset=".52" stopColor="#634729" />
          <stop offset="1" stopColor="#282019" />
        </radialGradient>
        <linearGradient id="wall" x2="1" y2=".8">
          <stop stopColor="#17130f" />
          <stop offset=".43" stopColor="#3b2b19" />
          <stop offset=".76" stopColor="#2d2116" />
          <stop offset="1" stopColor="#100e0d" />
        </linearGradient>
        <linearGradient id="ground" x1="0" y1="0" x2="0" y2="1">
          <stop stopColor="#4a3521" />
          <stop offset=".38" stopColor="#302319" />
          <stop offset="1" stopColor="#120f0c" />
        </linearGradient>
        <radialGradient id="wash">
          <stop stopColor="#d19b58" stopOpacity=".36" />
          <stop offset="1" stopColor="#ae7a3b" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="beamFloor" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#a47d4d" stopOpacity=".19" />
          <stop offset="1" stopColor="#be8c4b" stopOpacity="0" />
        </linearGradient>
        <clipPath id="archOpening">
          <path d={arch} />
        </clipPath>
        <radialGradient id="edgeShade" r=".74">
          <stop offset=".44" stopColor="#110f0d" stopOpacity="0" />
          <stop offset="1" stopColor="#100d0a" stopOpacity=".53" />
        </radialGradient>
      </defs>
      <rect width="960" height="540" fill="url(#wall)" />
      <g clipPath="url(#archOpening)">
        <rect width="800" height="425" fill="url(#evening)" />
        <path
          d="M60 324 Q145 297 189 265 Q216 252 238 259 Q264 259 306 229 Q351 193 380 198 Q416 190 446 209 Q478 229 501 223 Q550 214 578 199 Q625 170 657 179 Q696 192 767 200 V440 H60Z"
          fill="#5f492f"
        />
        <path
          d="M60 331 Q130 309 195 313 Q253 318 313 282 Q369 252 429 265 Q485 270 515 258 Q555 242 604 244 Q691 256 765 221 V440 H60Z"
          fill="#503d28"
        />
        <path
          d="M60 352 Q160 333 229 339 Q317 356 393 321 Q440 300 484 308 Q561 333 603 299 Q663 262 755 265 V440 H60Z"
          fill="#3a2e20"
        />
        <g fill="#4c3c29" stroke="#b08a53" strokeWidth=".55" opacity=".82">
          {[
            [159, 308, 20, 12],
            [180, 304, 13, 20],
            [194, 309, 24, 13],
            [217, 311, 21, 10],
            [234, 309, 11, 13],
            [600, 280, 21, 16],
            [620, 277, 25, 19],
            [645, 269, 13, 24],
            [657, 272, 24, 18],
            [682, 264, 11, 17],
          ].map(([x, y, w, h]) => (
            <path key={x} d={`M${x},${y + h} v-${h} h${w} v${h}`} />
          ))}
        </g>
        <g stroke="#4b3927" strokeWidth="1.05" fill="#57422b" opacity=".92">
          {[
            [123, 321, 0.79],
            [135, 319, 0.48],
            [256, 313, 0.74],
            [271, 310, 0.49],
            [583, 300, 0.81],
            [596, 300, 0.64],
            [702, 268, 0.91],
            [712, 269, 0.49],
          ].map(([x, y, s]) => (
            <g transform={`translate(${x} ${y}) scale(${s})`} key={x}>
              <path d="M0,4 L0,-12 M0,-8 l-4,-6" />
              <path d="M0,-31 Q-2,-24 -3,-21 Q-6,-14 -4,-10 Q-3,-7 0,-7 Q5,-8 4,-14 Q3,-23 0,-31Z" />
            </g>
          ))}
        </g>
        <g opacity=".19" stroke="#cba36e" fill="none" strokeWidth=".64">
          <path d="M156 292 q25 -21 39 -22 q20 -2 43 -7 M324 227 q29 -23 49 -24 q14 -1 31 3 M525 220 q47 -22 71 -31 M592 261 q22 -9 48 -10 M247 322q36 -4 53 -15 M351 345q27 -6 55 -17" />
        </g>
        <path
          d="M95 367 Q191 348 275 372 Q343 383 413 358 Q505 331 600 350 Q685 357 740 322 L740 426 H95Z"
          fill="#2d251a"
        />
      </g>
      <path d={arch} fill="none" stroke="#18140f" strokeWidth="11" />
      <path d={arch} fill="none" stroke="#c99a56" strokeWidth="1.25" opacity=".74" />
      <path
        d="M83 424 V208 C83 75 224 16 385 11 C558 5 700 49 739 126 Q751 155 751 190 V424"
        fill="none"
        stroke="#8f6940"
        opacity=".65"
      />
      <g fill="none" stroke="#936e45" strokeWidth="1" opacity=".33">
        <path d="M104 133l-16 -8 M153 79l-11 -11 M237 41l-7 -14 M336 23l-3 -14 M450 24l2 -13 M554 38l6 -14 M651 66l8 -11 M710 115l13 -7 M733 165l15 -2 M0 187h88 M0 194h91 M754 190h206 M755 196h205 M751 291h209 M771 196v95 M880 291v71 M3 280h79 M12 358h75" />
      </g>
      <path d="M0 402 Q122 396 245 397 Q417 398 589 394 Q782 384 960 393 V540 H0Z" fill="url(#ground)" />
      <path d="M99 397 Q355 383 735 388 L916 514 Q501 464 152 521Z" fill="url(#beamFloor)" />
      <ellipse cx="474" cy="431" rx="314" ry="52" fill="url(#wash)" opacity=".53" />
      <g fill="none" stroke="#b38750" strokeWidth=".7" opacity=".28">
        <path d="M83 400q97 -3 154 -2 M271 399l112 -2 M641 393l88 -1 M113 443l117 -5 68 3 M643 453l112 -5 M536 481l89 -3 M326 463l47 -3 M5 495l134 -7 M796 410l99 -3" />
      </g>
      <g stroke="#513d2a" fill="#211a14">
        <path d="M767 -8h69v402q-33 9 -69 2Z" />
        <path d="M760 389h84v10h-84z M754 400h99v8h-99z" />
        <path d="M768 -5h7v387h-7z" fill="#5f472b" />
      </g>
      <g transform="translate(838 400)" stroke="#79583b" strokeWidth="1.3" fill="#271e17">
        <path d="M-18 -72 Q0 -77 17 -72 L13 -54 Q42 -31 29 -8 Q26 1 11 2 H-11 Q-30 1 -30 -17 Q-35 -39 -13 -54Z" />
        <path d="M14 -58 Q43 -65 34 -39 Q33 -32 26 -30" fill="none" strokeWidth="3" />
        <path d="M-17 -70q17 3 34 0" fill="none" />
      </g>
      <rect width="960" height="540" fill="url(#edgeShade)" />
    </>
  );
}
