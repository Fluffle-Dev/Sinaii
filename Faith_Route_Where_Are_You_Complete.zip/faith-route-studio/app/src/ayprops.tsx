import React from 'react';
import {Line, TXT} from './fig';
import {win, fi, ramp, eio} from './lib';

const STATIONS = [
  {ref: 'GEN 3:9', label: 'ADAM'},
  {ref: 'GEN 4:9', label: 'CAIN'},
  {ref: 'GEN 16:8', label: 'HAGAR'},
  {ref: '1 KGS 19:9', label: 'ELIJAH'},
];

/** Recurring 4-station Question Tracker below the ground line (y = 964) */
export const QuestionTrack: React.FC<{active: number; o?: number}> = ({active, o = 1}) => {
  if (active <= 0 || o <= 0.001) return null;
  const xs = [420, 780, 1140, 1500];
  const y = 964;
  return (
    <g opacity={o}>
      {xs.map((cx, i) => {
        const lit = i < active;
        const cur = i === active - 1;
        return (
          <React.Fragment key={cx}>
            {i < 3 ? (
              <line
                x1={cx + 122}
                y1={y}
                x2={xs[i + 1] - 122}
                y2={y}
                stroke={i < active - 1 ? '#E3B465' : '#6b532f'}
                strokeWidth={i < active - 1 ? 2 : 1.2}
                strokeDasharray={i < active - 1 ? undefined : '6 6'}
                opacity={i < active - 1 ? 0.85 : 0.4}
              />
            ) : null}
            <rect
              x={cx - 118}
              y={y - 34}
              width={236}
              height={68}
              rx={4}
              fill={cur ? '#2a1e10' : '#120e09'}
              fillOpacity={cur ? 0.92 : 0.72}
              stroke={lit ? '#E9BE6E' : '#7b6138'}
              strokeWidth={cur ? 2 : 1.2}
              strokeDasharray={lit ? undefined : '6 5'}
              opacity={lit ? 1 : 0.45}
            />
            <text x={cx} y={y - 7} textAnchor="middle" fill={lit ? TXT.gold : TXT.dim} fontFamily="Cinzel" fontSize={16} letterSpacing={4}>
              {STATIONS[i].ref}
            </text>
            <text x={cx} y={y + 20} textAnchor="middle" fill={lit ? TXT.ivory : TXT.dim} fontFamily="Cinzel" fontSize={22} letterSpacing={5}>
              {STATIONS[i].label}
            </text>
          </React.Fragment>
        );
      })}
    </g>
  );
};

/** Patriarchal nomad tent for Abraham & Sarah's encampment */
export const Tent: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <path d="M-340,0 L-220,-210 L0,-290 L220,-210 L340,0 Z" fill="#18120c" />
    <path d="M-70,0 L-45,-190 L55,-190 L75,0 Z" fill="#090705" />
    <Line w={2.4 / s} p={p} d="M-340,0 L-220,-210 L0,-290 L220,-210 L340,0 M0,-290 L-45,-190 M0,-290 L55,-190 M-220,-210 L-290,0 M220,-210 L290,0" />
    <Line w={1.4 / s} p={p} o={0.55} d="M-220,-210 L-400,0 M220,-210 L400,0" />
  </g>
);

/** Desert oasis spring with animated concentric water ripples & reeds */
export const Spring: React.FC<{x: number; y: number; f: number; s?: number; o?: number}> = ({x, y, f, s = 1, o = 1}) => {
  const r1 = 38 + ((f * 1.1) % 130);
  const r2 = 38 + ((f * 1.1 + 65) % 130);
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
      <ellipse cx={0} cy={12} rx={230} ry={28} fill="#0b0d0e" stroke="#C89B52" strokeWidth={1.8} />
      <ellipse cx={0} cy={12} rx={r1} ry={r1 * 0.11} fill="none" stroke="#E9BE6E" strokeWidth={1.5} opacity={Math.max(0, 1 - r1 / 170) * 0.8} />
      <ellipse cx={0} cy={12} rx={r2} ry={r2 * 0.11} fill="none" stroke="#E9BE6E" strokeWidth={1.5} opacity={Math.max(0, 1 - r2 / 170) * 0.8} />
      <Line w={1.8} o={0.75} d="M-215,10 C-222,-42 -236,-88 -248,-120 M-202,10 C-204,-35 -210,-72 -218,-98 M208,10 C216,-40 228,-82 242,-112 M195,10 C198,-30 206,-65 215,-90" />
    </g>
  );
};

/** Curved golden connector arc linking two Scripture cards */
export const ArcLink: React.FC<{f: number; a: number; b?: number; x1: number; x2: number; y: number; lift?: number}> = ({f, a, b, x1, x2, y, lift = 115}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const p = eio(ramp(f, a, 32));
  const mx = (x1 + x2) / 2;
  return (
    <g opacity={o}>
      <Line d={`M${x1},${y} Q${mx},${y - lift} ${x2},${y}`} p={p} w={2.6} c="#E9BE6E" />
      <circle cx={x1} cy={y} r={5} fill="#E9BE6E" opacity={p} />
      <circle cx={x2} cy={y} r={5} fill="#E9BE6E" opacity={fi(f, a + 24, 10)} />
    </g>
  );
};

/** Sweeping wind streaks across Mount Horeb */
export const WindLines: React.FC<{f: number; o?: number}> = ({f, o = 1}) => {
  if (o <= 0.001) return null;
  const ys = [260, 350, 440, 530, 620, 710, 780];
  return (
    <g opacity={o}>
      {ys.map((y, i) => {
        const x = ((f * (28 + (i % 3) * 7) + i * 310) % 2300) - 380;
        const len = 180 + (i % 3) * 90;
        return (
          <path
            key={y}
            d={`M${x},${y} Q${x + len * 0.5},${y - 18} ${x + len},${y - 8}`}
            fill="none"
            stroke="#E9BE6E"
            strokeWidth={2.2}
            strokeLinecap="round"
            opacity={0.45 + (i % 2) * 0.25}
          />
        );
      })}
    </g>
  );
};

/** Jagged rock cracks for earthquake beat */
export const QuakeCracks: React.FC<{p: number; o?: number}> = ({p, o = 1}) => (
  <g opacity={o}>
    <Line d="M410,320 L510,430 L460,540 L570,670 L530,840" p={p} w={3} c="#E3B465" />
    <Line d="M1510,300 L1410,420 L1465,535 L1360,680 L1410,845" p={p} w={3} c="#E3B465" />
    <Line d="M720,860 L820,835 L910,858 L1040,832 L1180,860" p={p} w={2.4} c="#E2785A" />
  </g>
);

/** Crimson ground pulse ripples for Abel's blood crying out */
export const BloodPulse: React.FC<{x: number; y: number; f: number; o?: number}> = ({x, y, f, o = 1}) => {
  if (o <= 0.001) return null;
  return (
    <g opacity={o}>
      {[0, 1, 2].map((i) => {
        const r = ((f * 3.4 + i * 95) % 285);
        return (
          <ellipse
            key={i}
            cx={x}
            cy={y}
            rx={r * 1.9}
            ry={r * 0.22}
            fill="none"
            stroke="#D65A3E"
            strokeWidth={2.2}
            opacity={Math.max(0, 1 - r / 285) * 0.8}
          />
        );
      })}
    </g>
  );
};

/** Hagar's two-box half-answer overlay (HTML) */
export const HalfAnswer: React.FC<{f: number; a: number; aBlank: number; b?: number}> = ({f, a, aBlank, b}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const oR = fi(f, aBlank, 16);
  return (
    <div style={{position: 'absolute', left: 210, top: 82, width: 1500, display: 'flex', gap: 56, opacity: o}}>
      <div style={{flex: 1, padding: '28px 32px', border: '2px solid #E9BE6E', background: 'rgba(18,13,8,0.84)', textAlign: 'center'}}>
        <div style={{fontFamily: 'Cinzel', fontSize: 22, letterSpacing: '0.24em', color: TXT.gold, marginBottom: 12}}>WHERE HAVE YOU COME FROM?</div>
        <div style={{fontFamily: 'Corm', fontStyle: 'italic', fontSize: 44, color: TXT.ivory}}>“I am running away from my mistress Sarai.”</div>
      </div>
      <div style={{flex: 1, padding: '28px 32px', border: '2px dashed rgba(233,190,110,0.45)', background: 'rgba(12,9,6,0.72)', textAlign: 'center', opacity: 0.35 + 0.65 * oR}}>
        <div style={{fontFamily: 'Cinzel', fontSize: 22, letterSpacing: '0.24em', color: TXT.dim, marginBottom: 12}}>WHERE ARE YOU GOING?</div>
        <div style={{fontFamily: 'Cinzel', fontSize: 64, color: 'rgba(233,190,110,0.42)', marginTop: 4}}>?</div>
      </div>
    </div>
  );
};

/** Ayekah -> bare consonants -> Eichah HTML morph card */
export const VowelMorph: React.FC<{f: number; a: number; aBare: number; aSwap: number; b?: number}> = ({f, a, aBare, aSwap, b}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const bare = fi(f, aBare, 18);
  const swap = fi(f, aSwap, 18);
  return (
    <div style={{position: 'absolute', left: 160, top: 68, width: 1600, textAlign: 'center', opacity: o}}>
      <div style={{fontFamily: 'Cinzel', fontSize: 26, letterSpacing: '0.32em', color: TXT.gold, marginBottom: 12}}>
        {swap > 0.5 ? 'LAMENTATIONS 1:1  ·  NEW VOWELS' : bare > 0.5 ? 'FOUR UNVOCALIZED CONSONANTS' : 'GENESIS 3:9  ·  ONE HEBREW WORD'}
      </div>
      <div style={{position: 'relative', height: 158}}>
        <div style={{position: 'absolute', inset: 0, fontFamily: 'Heb', fontSize: 132, color: TXT.gold, direction: 'rtl', opacity: 1 - bare, textShadow: '0 0 28px rgba(233,190,110,0.45)'}}>
          אַיֶּכָּה
        </div>
        <div style={{position: 'absolute', inset: 0, fontFamily: 'Heb', fontSize: 132, color: TXT.ivory, direction: 'rtl', letterSpacing: '0.25em', opacity: bare * (1 - swap), textShadow: '0 0 28px rgba(233,190,110,0.35)'}}>
          א י כ ה
        </div>
        <div style={{position: 'absolute', inset: 0, fontFamily: 'Heb', fontSize: 132, color: TXT.ember, direction: 'rtl', opacity: swap, textShadow: '0 0 28px rgba(226,120,90,0.45)'}}>
          אֵיכָה
        </div>
      </div>
      <div style={{fontFamily: 'Corm', fontStyle: 'italic', fontSize: 46, color: TXT.ivory, marginTop: 8}}>
        {swap > 0.5 ? 'Eichah — “How could this happen?”' : bare > 0.5 ? 'Alef  ·  Yod  ·  Kaf  ·  He' : 'Ayekah — “Where are you?”'}
      </div>
    </div>
  );
};
