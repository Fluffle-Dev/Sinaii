import React from 'react';
import {staticFile} from 'remotion';
import {win, fi, ramp, eout} from './lib';
import {TXT} from './fig';

export const Fonts: React.FC = () => (
  <style>{`
  @font-face{font-family:Cinzel;src:url(${staticFile('fonts/cinzel-latin-500-normal.woff2')}) format('woff2')}
  @font-face{font-family:Corm;font-style:italic;src:url(${staticFile('fonts/cormorant-garamond-latin-500-italic.woff2')}) format('woff2')}
  @font-face{font-family:Heb;src:url(${staticFile('fonts/noto-serif-hebrew-hebrew-500-normal.woff2')}) format('woff2')}
  @font-face{font-family:Grk;src:url(${staticFile('fonts/noto-serif-greek-500-normal.woff2')}) format('woff2')}
  @font-face{font-family:Grk;font-style:italic;src:url(${staticFile('fonts/noto-serif-greek-400-italic.woff2')}) format('woff2')}
  `}</style>
);

const glow = (c: string, a = 0.35) => `0 0 18px ${c}${Math.round(a * 255).toString(16).padStart(2, '0')}`;
const abs = (x: number, y: number, w = 1600): React.CSSProperties => ({position: 'absolute', left: x - w / 2, top: y, width: w, textAlign: 'center'});

/** small spaced capitals: references, titles */
export const Ref: React.FC<{f: number; a: number; b?: number; x?: number; y?: number; size?: number; c?: string; children: React.ReactNode}> = ({f, a, b, x = 960, y = 92, size = 26, c = TXT.gold, children}) => (
  <div style={{...abs(x, y), fontFamily: 'Cinzel', fontSize: size * 1.3, letterSpacing: '0.32em', color: c, opacity: win(f, a, b, 16), textShadow: glow('#C9A15A', 0.3)}}>{children}</div>
);

/** big Cinzel statement / number */
export const Big: React.FC<{f: number; a: number; b?: number; x?: number; y?: number; size?: number; c?: string; ls?: number; children: React.ReactNode}> = ({f, a, b, x = 960, y = 470, size = 92, c = TXT.ivory, ls = 0.12, children}) => {
  const t = fi(f, a, 18);
  return (
    <div style={{...abs(x, y - size * 0.62), fontFamily: 'Cinzel', fontSize: size, letterSpacing: `${ls}em`, color: c, opacity: win(f, a, b, 18), filter: `blur(${(1 - t) * 6}px)`, textShadow: glow('#E2B868', 0.4)}}>{children}</div>
  );
};

/** italic note line */
export const Note: React.FC<{f: number; a: number; b?: number; x?: number; y?: number; size?: number; c?: string; children: React.ReactNode}> = ({f, a, b, x = 960, y = 300, size = 34, c = TXT.ivory, children}) => (
  <div style={{...abs(x, y), fontFamily: 'Corm', fontStyle: 'italic', fontSize: size * 1.3, color: c, opacity: win(f, a, b, 16)}}>{children}</div>
);

/** Hebrew or English name label under a figure */
export const Name: React.FC<{f: number; a: number; b?: number; x: number; y?: number; heb?: string; grk?: string; en: string; c?: string}> = ({f, a, b, x, y = 885, heb, grk, en, c = TXT.gold}) => (
  <div style={{...abs(x, y, 900), opacity: win(f, a, b, 16)}}>
    {heb ? <div style={{fontFamily: 'Heb', fontSize: 38, color: c, direction: 'rtl', textShadow: glow('#C9A15A', 0.3), lineHeight: 1.2}}>{heb}</div> : null}
    {grk ? <div style={{fontFamily: 'Grk', fontSize: 32, color: c, lineHeight: 1.3}}>{grk}</div> : null}
    <div style={{fontFamily: 'Cinzel', fontSize: 25, letterSpacing: '0.26em', color: TXT.ivory, marginTop: 4}}>{en}</div>
  </div>
);

/**
 * Verse: reference, original-language line revealed word by word (right to left for Hebrew),
 * then the English, with key words turning gold at the moment they are spoken.
 * eng uses *word* markers; keys gives the frame for each marker in order.
 */
export const Verse: React.FC<{
  f: number; a: number; b?: number; e?: number; refText: string; orig: string; lang?: 'heb' | 'grk'; origKey?: number[];
  eng: string; keys?: number[]; y?: number; x?: number; small?: boolean;
}> = ({f, a, b, e, refText, orig, lang = 'heb', origKey = [], eng, keys = [], y = 70, x = 960, small = false}) => {
  const ow = orig.split(' ');
  const span = Math.max(20, ((e ?? a + 90) - a) * 0.55);
  const vis = win(f, a, b, 16);
  const engA = a + Math.min(24, span * 0.4);
  let ki = 0;
  const parts = eng.split(/(\*[^*]+\*)/).filter(Boolean).map((s, i) => {
    if (s.startsWith('*')) {
      const kf = keys[ki++] ?? a;
      const t = eout(ramp(f, kf, 10));
      return <span key={i} style={{color: t > 0.5 ? TXT.gold : TXT.ivory, textShadow: t > 0.5 ? glow('#E9BE6E', 0.55) : 'none'}}>{s.slice(1, -1)}</span>;
    }
    return <span key={i}>{s}</span>;
  });
  const keyOn = keys.length ? eout(ramp(f, keys[0], 10)) : eout(ramp(f, a + span, 10));
  return (
    <div style={{...abs(x, y, 1700), opacity: vis}}>
      <div style={{fontFamily: 'Cinzel', fontSize: small ? 28 : 30, letterSpacing: '0.32em', color: TXT.gold, textShadow: glow('#C9A15A', 0.3)}}>{refText}</div>
      <div style={{fontFamily: lang === 'heb' ? 'Heb' : 'Grk', fontSize: small ? 48 : 54, color: TXT.ivory, direction: lang === 'heb' ? 'rtl' : 'ltr', marginTop: 10, lineHeight: 1.35}}>
        {ow.map((w, i) => {
          const t = fi(f, a + (i * span) / ow.length, 12);
          const gold = origKey.includes(i) && keyOn > 0.5;
          return <span key={i} style={{opacity: t, color: gold ? TXT.gold : TXT.ivory, textShadow: gold ? glow('#E9BE6E', 0.5) : 'none', marginLeft: 10, marginRight: 10, filter: `blur(${(1 - t) * 4}px)`}}>{w}</span>;
        })}
      </div>
      <div style={{fontFamily: 'Corm', fontStyle: 'italic', fontSize: small ? 40 : 44, color: TXT.ivory, marginTop: 6, opacity: fi(f, engA, 18), padding: '0 120px'}}>{parts}</div>
    </div>
  );
};

/** thin gold frame panel with a title, drawn on */
export const Panel: React.FC<{f: number; a: number; b?: number; x: number; y: number; w: number; h: number; title?: string}> = ({f, a, b, x, y, w, h, title}) => {
  const p = eout(ramp(f, a, 26));
  const o = win(f, a, b, 16);
  return (
    <g opacity={o}>
      <rect x={x - w / 2} y={y - h / 2} width={w} height={h} fill="#000" opacity={0.35} />
      <rect x={x - w / 2} y={y - h / 2} width={w} height={h} fill="none" stroke="url(#goldLine)" strokeWidth={1.6} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - p} filter="url(#lglow)" />
      <rect x={x - w / 2 + 8} y={y - h / 2 + 8} width={w - 16} height={h - 16} fill="none" stroke="#B8873E" strokeWidth={0.8} opacity={0.5 * p} />
      {title ? <text x={x} y={y - h / 2 + 40} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={20} letterSpacing={6} opacity={fi(f, a + 10)}>{title}</text> : null}
    </g>
  );
};
