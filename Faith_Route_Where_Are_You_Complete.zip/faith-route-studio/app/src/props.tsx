import React from 'react';
import {Line, Cut, Metal, TXT} from './fig';

type LP = {x: number; y: number; s?: number; o?: number; p?: number};
const G = (x: number, y: number, s = 1) => `translate(${x} ${y}) scale(${s})`;
const L: React.FC<LP & {d: string; w?: number}> = ({x, y, s = 1, o = 1, p = 1, d, w = 2.2}) => (
  <g transform={G(x, y, s)} opacity={o}><Line w={w / s} p={p} d={d} /></g>
);

/** open codex / book, x,y = centre of spine bottom */
export const Book: React.FC<LP & {lines?: number}> = ({lines = 1, ...r}) => {
  let d = 'M0,0 C-80,-24 -200,-24 -260,-4 L-260,-250 C-200,-270 -80,-270 0,-246 C80,-270 200,-270 260,-250 L260,-4 C200,-24 80,-24 0,0 Z M0,0 L0,-246';
  const n = Math.round(9 * lines);
  for (let i = 0; i < n; i++) { const yy = -220 + i * 22; d += ` M-226,${yy} L-36,${yy + 2} M36,${yy + 2} L226,${yy}`; }
  return <L {...r} d={d} />;
};

/** rolled scroll / letter */
export const Scroll: React.FC<LP> = (r) => (
  <L {...r} d="M-160,-200 L160,-200 L160,40 L-160,40 Z M-176,-212 L-176,-188 C-176,-180 -144,-180 -144,-188 L-144,-212 C-144,-220 -176,-220 -176,-212 Z M144,52 L144,28 C144,20 176,20 176,28 L176,52 C176,60 144,60 144,52 Z M-120,-160 L120,-160 M-120,-130 L110,-130 M-120,-100 L120,-100 M-120,-70 L80,-70 M-120,-40 L120,-40 M-120,-10 L60,-10" />
);

/** small church with a cross, x = centre, y = ground */
export const Church: React.FC<LP> = (r) => (
  <L {...r} d="M-160,0 L-160,-200 L0,-320 L160,-200 L160,0 M-180,-190 L0,-330 L180,-190 M0,-330 L0,-420 M-30,-390 L30,-390 M-40,0 L-40,-110 C-40,-150 40,-150 40,-110 L40,0 M-120,-150 L-80,-150 L-80,-90 L-120,-90 Z M80,-150 L120,-150 L120,-90 L80,-90 Z" />
);

/** shelf with a box gathering dust (static specks) */
export const Shelf: React.FC<LP> = (r) => (
  <L {...r} d="M-300,0 L300,0 M-300,14 L300,14 M-280,14 L-280,60 M280,14 L280,60 M-120,0 L-120,-130 L120,-130 L120,0 M-120,-130 L-90,-150 L150,-150 L120,-130 M150,-150 L150,-20 L120,0" />
);

/** stone well with a rope and beam */
export const Well: React.FC<LP> = (r) => (
  <L {...r} d="M-130,0 L-130,-120 M130,0 L130,-120 M-150,-120 C-150,-150 150,-150 150,-120 C150,-96 -150,-96 -150,-120 M-150,-120 L-150,-104 M150,-120 L150,-104 M-130,-40 L130,-40 M-130,-80 L130,-80 M-60,0 L-60,-40 M50,-40 L50,-80 M-20,-80 L-20,-118 M-150,-130 L-150,-300 M150,-130 L150,-300 M-170,-300 L170,-300 M0,-300 L0,-190 M-16,-190 L16,-190 L12,-160 L-12,-160 Z" />
);

/** rope bridge between two cliff edges; p = how much of the deck is drawn */
export const Bridge: React.FC<{y: number; x0: number; x1: number; o?: number; p?: number}> = ({y, x0, x1, o = 1, p = 1}) => {
  const mid = (x0 + x1) / 2, sag = 70;
  let d = `M0,${y} L${x0},${y} L${x0 - 40},${y + 260} M${x1},${y} L1920,${y} M${x1},${y} L${x1 + 40},${y + 260}`;
  d += ` M${x0},${y} Q${mid},${y + sag * 2} ${x1},${y} M${x0},${y - 70} Q${mid},${y - 70 + sag * 2} ${x1},${y - 70} M${x0},${y} L${x0},${y - 90} M${x1},${y} L${x1},${y - 90}`;
  const n = 16;
  for (let i = 1; i < n; i++) {
    const t = i / n, xx = x0 + (x1 - x0) * t, yy = y + sag * 2 * 2 * t * (1 - t) * 0.5 * 2 / 2 * 2, y2 = yy - 70;
    d += ` M${xx},${yy} L${xx},${y2}`;
  }
  return (
    <g opacity={o}>
      <Line w={2} p={p} d={d} />
      <path d={`M0,${y} L${x0},${y} L${x0 - 40},${y + 260} L0,${y + 260} Z M1920,${y} L${x1},${y} L${x1 + 40},${y + 260} L1920,${y + 260} Z`} fill="#000" opacity={0.12} />
    </g>
  );
};
/** y of the bridge deck at x */
export const deckY = (x: number, y: number, x0: number, x1: number) => {
  if (x <= x0 || x >= x1) return y;
  const t = (x - x0) / (x1 - x0);
  return y + 70 * 2 * 2 * t * (1 - t);
};

/** roof held up by pillars (aman = firm) */
export const Roof: React.FC<LP & {n?: number; w?: number; h?: number}> = ({n = 4, w = 700, h = 380, ...r}) => {
  let d = `M${-w / 2 - 60},${-h} L0,${-h - 120} L${w / 2 + 60},${-h} Z M${-w / 2 - 40},${-h} L${w / 2 + 40},${-h} M${-w / 2 - 40},${-h + 16} L${w / 2 + 40},${-h + 16}`;
  for (let i = 0; i < n; i++) { const cx = -w / 2 + (i * w) / (n - 1); d += ` M${cx - 18},0 L${cx - 18},${-h + 16} M${cx + 18},0 L${cx + 18},${-h + 16} M${cx - 28},0 L${cx + 28},0 M${cx - 28},${-h + 30} L${cx + 28},${-h + 30}`; }
  return <L {...r} d={d} />;
};

/** fixed starfield, never moves or twinkles */
export const Stars: React.FC<{o?: number; seed?: number; n?: number; y1?: number}> = ({o = 1, seed = 5, n = 90, y1 = 640}) => {
  let s = seed; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const pts = Array.from({length: n}, () => ({x: r() * 1920, y: r() * y1, k: r()}));
  return <g opacity={o}>{pts.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={0.9 + p.k * 1.8} fill="#F4DDAE" opacity={0.35 + p.k * 0.5} />)}</g>;
};

/** bronze snake on a pole (cut-out) */
export const SnakePole: React.FC<{x: number; y: number; s?: number; o?: number; lit?: number}> = ({x, y, s = 1, o = 1, lit = 1}) => (
  <g opacity={o}>
    <Cut m="bronze" lit={lit} tf={G(x, y, s)}>
      <path d="M-8,0 L-8,-520 L8,-520 L8,0 Z M-70,-520 L70,-520 L70,-504 L-70,-504 Z" />
      <path d="M0,-504 C60,-470 60,-430 0,-400 C-60,-370 -60,-330 0,-300 C50,-276 52,-240 14,-216 L4,-226 C34,-244 32,-268 -6,-288 C-74,-322 -74,-378 -6,-412 C44,-436 44,-466 -6,-494 Z" />
      <path d="M-6,-494 C-20,-512 -10,-532 10,-530 C26,-528 26,-512 14,-504 Z" />
    </Cut>
  </g>
);

/** rock tomb with a round stone; roll 0..1 moves the stone aside */
export const Tomb: React.FC<LP & {roll?: number}> = ({roll = 0, ...r}) => (
  <g transform={G(r.x, r.y, r.s ?? 1)} opacity={r.o ?? 1}>
    <path d="M-340,0 C-340,-200 -240,-340 -40,-360 C160,-370 300,-260 340,0 Z" fill="#000" opacity={0.3} />
    <Line w={2.2} p={r.p ?? 1} d="M-340,0 C-340,-200 -240,-340 -40,-360 C160,-370 300,-260 340,0 M-90,0 L-90,-170 C-90,-230 70,-230 70,-170 L70,0 M-300,-120 L-240,-140 M180,-260 L240,-220 M-200,-280 L-150,-300" />
    <path d="M-90,0 L-90,-170 C-90,-230 70,-230 70,-170 L70,0 Z" fill="#050403" opacity={0.85} />
    <g transform={`translate(${-10 + roll * 190} 0) rotate(${roll * 90} 0 -110)`}>
      <circle cx={0} cy={-110} r={112} fill="#0b0906" />
      <Line w={2.4} d="M0,-222 A112,112 0 1 1 -0.1,-222 M0,-180 A70,70 0 1 1 -0.1,-180" />
    </g>
  </g>
);

/** cross on a hill, line art */
export const CrossHill: React.FC<LP> = (r) => (
  <L {...r} d="M-500,0 C-300,-60 -140,-120 0,-130 C140,-120 300,-60 500,0 M-10,-130 L-10,-560 L10,-560 L10,-130 M-140,-460 L140,-460 L140,-440 L-140,-440 Z" />
);

/** fishing boat with a net hanging */
export const Boat: React.FC<LP> = (r) => (
  <L {...r} d="M-260,-60 C-200,10 200,10 260,-60 L230,-60 C180,-20 -180,-20 -230,-60 Z M-260,-60 L260,-60 M0,-60 L0,-360 M0,-340 L170,-90 M0,-330 L-140,-100 M-140,-100 L170,-90" />
);
export const Waves: React.FC<{y: number; o?: number; x0?: number; x1?: number}> = ({y, o = 0.6, x0 = 0, x1 = 1920}) => {
  let d = '';
  for (let k = 0; k < 3; k++) { let row = `M${x0},${y + k * 26}`; for (let x = x0; x < x1; x += 80) row += ` q20,-10 40,0 q20,10 40,0`; d += row; }
  return <g opacity={o}><Line w={1.3} d={d} /></g>;
};

/** pool of Siloam: steps and water */
export const Pool: React.FC<LP> = (r) => (
  <L {...r} d="M-420,0 L420,0 M-380,-24 L380,-24 M-340,-48 L340,-48 M-300,-72 L300,-72 M-260,30 C-120,48 120,48 260,30 M-200,56 C-80,70 80,70 200,56" />
);

/** wooden door of a synagogue / room */
export const Doorway: React.FC<LP> = (r) => (
  <L {...r} d="M-110,0 L-110,-300 C-110,-370 110,-370 110,-300 L110,0 M-140,0 L-140,-310 C-140,-400 140,-400 140,-310 L140,0 M0,-360 L0,0 M30,-160 L30,-140" />
);

/** mustard seed growing into a small tree; g = growth 0..1 */
export const Mustard: React.FC<{x: number; y: number; g: number; o?: number}> = ({x, y, g, o = 1}) => (
  <g opacity={o}>
    <circle cx={x} cy={y - 6} r={5} fill="#F3D08A" filter="url(#lglow)" opacity={1 - g * 0.6} />
    <g transform={`translate(${x} ${y}) scale(${Math.max(0.01, g)})`}>
      <Line w={2.2 / Math.max(0.2, g)} d="M0,0 C-6,-80 6,-160 0,-260 M0,-120 C-40,-150 -90,-160 -130,-200 M0,-160 C40,-190 90,-200 130,-240 M0,-220 C-30,-250 -60,-270 -80,-310 M0,-260 C20,-290 40,-310 50,-340 M-130,-200 C-150,-230 -120,-250 -100,-230 M130,-240 C150,-270 120,-290 100,-270" />
    </g>
  </g>
);

/** bread loaves in a shop window frame */
export const Window: React.FC<LP> = (r) => (
  <L {...r} d="M-260,0 L-260,-300 L260,-300 L260,0 Z M-276,0 L276,0 M0,-300 L0,0 M-260,-150 L260,-150" />
);

/** badge / medal */
export const Badge: React.FC<LP> = (r) => (
  <L {...r} d="M-40,-200 L-70,-300 M40,-200 L70,-300 M-70,-300 L-20,-300 L0,-230 M70,-300 L20,-300 L0,-230 M0,-200 A70,70 0 1 1 -0.1,-200 M0,-170 A40,40 0 1 1 -0.1,-170" />
);

/** chest of drawers with one drawer sliding shut (sh 0..1) */
export const Drawer: React.FC<LP & {sh?: number}> = ({sh = 1, ...r}) => (
  <g transform={G(r.x, r.y, r.s ?? 1)} opacity={r.o ?? 1}>
    <Line w={2.2} d="M-200,0 L-200,-280 L200,-280 L200,0 Z M-200,-190 L200,-190 M-200,-95 L200,-95 M-20,-45 L20,-45 M-20,-235 L20,-235" />
    <Line w={2.2} d={`M${-200},-190 L${-200},-95 M${-180 + 0},-190 L${-180},-95`} o={0} />
    <g transform={`translate(${(1 - sh) * 0} ${0})`}>
      <Line w={2.2} d={`M-170,${-190} L${-170 + (1 - sh) * 0},-190 M-200,-190 L-200,-95 L${200 + (1 - sh) * 140},-95 L${200 + (1 - sh) * 140},-190 L-200,-190 M${-20 + (1 - sh) * 140},-142 L${20 + (1 - sh) * 140},-142`} />
    </g>
  </g>
);

/** distance road with a dashed path */
export const Road: React.FC<{x0: number; x1: number; y: number; p?: number; o?: number}> = ({x0, x1, y, p = 1, o = 1}) => (
  <g opacity={o}>
    <Line w={2.4} p={p} d={`M${x0},${y} C${x0 + (x1 - x0) * 0.3},${y - 90} ${x0 + (x1 - x0) * 0.7},${y + 70} ${x1},${y}`} />
    <circle cx={x0} cy={y} r={9} fill="#F3D08A" filter="url(#lglow)" />
    <circle cx={x1} cy={y} r={9} fill="#F3D08A" filter="url(#lglow)" opacity={p >= 0.98 ? 1 : 0.3} />
  </g>
);

/** big Greek / Hebrew word as an SVG text with glow */
export const Word: React.FC<{x: number; y: number; t: string; size?: number; o?: number; heb?: boolean; c?: string}> = ({x, y, t, size = 90, o = 1, heb = false, c = TXT.gold}) => (
  <text x={x} y={y} textAnchor="middle" fill={c} fontFamily={heb ? 'Heb' : 'Grk'} fontSize={size} opacity={o} filter="url(#lglow)" direction={heb ? 'rtl' : 'ltr'}>{t}</text>
);

/** a mitten hand, palm out, with a gold wound mark */
export const HandMark: React.FC<{x: number; y: number; s?: number; o?: number; m?: Metal; mark?: number}> = ({x, y, s = 1, o = 1, m = 'gold', mark = 1}) => (
  <g opacity={o}>
    <Cut m={m} lit={1} tf={G(x, y, s)}>
      <path d="M-70,200 L-60,-20 C-66,-60 -60,-110 -30,-130 C0,-150 40,-140 58,-110 C76,-80 76,-30 70,-10 L80,200 Z" />
      <path d="M58,-40 C90,-70 120,-70 130,-50 C138,-30 110,-6 70,20 Z" />
    </Cut>
    <circle cx={x} cy={y - 40 * s} r={9 * s} fill="#FFE6B0" opacity={mark} filter="url(#lglow)" />
  </g>
);

/** olive tree (Gethsemane) */
export const Olive: React.FC<LP> = (r) => (
  <L {...r} d="M-20,0 C-30,-80 10,-140 -10,-220 M20,0 C30,-90 -10,-150 20,-230 M-10,-220 C-120,-220 -200,-280 -170,-340 C-140,-400 -40,-380 0,-420 C60,-460 160,-420 180,-350 C200,-280 120,-230 20,-230" />
);

/** a simple medallion counter ring */
export const Ring: React.FC<{x: number; y: number; r: number; p: number; o?: number}> = ({x, y, r, p, o = 1}) => (
  <g opacity={o}>
    <circle cx={x} cy={y} r={r} fill="none" stroke="#5A4120" strokeWidth={2} />
    <circle cx={x} cy={y} r={r} fill="none" stroke="url(#goldLine)" strokeWidth={3} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - p} transform={`rotate(-90 ${x} ${y})`} filter="url(#lglow)" />
  </g>
);
