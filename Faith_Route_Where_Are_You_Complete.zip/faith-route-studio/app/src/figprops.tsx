import React from 'react';
import {Line, Cut} from './fig';
import {rng} from './lib';

/** fig leaf shape (3 lobes) centred at 0,0 pointing up, ~1 unit = 1px at s=1 */
const LEAF = 'M0,0 C-6,-8 -22,-6 -26,-18 C-30,-30 -18,-30 -14,-36 C-20,-46 -8,-54 0,-44 C8,-54 20,-46 14,-36 C18,-30 30,-30 26,-18 C22,-6 6,-8 0,0 Z';

/**
 * Fig tree. leaf 0..1 = how many leaves, fruit 0..1 early figs, wither 0..1 droops + darkens.
 * x = trunk base, y = ground.
 */
export const FigTree: React.FC<{x: number; y: number; s?: number; leaf?: number; fruit?: number; wither?: number; o?: number; p?: number; seed?: number}> = ({x, y, s = 1, leaf = 1, fruit = 0, wither = 0, o = 1, p = 1, seed = 7}) => {
  const r = rng(seed);
  const droop = wither * 60;
  const br = [
    [0, -170, -150, -300, -230, -330 + droop],
    [0, -190, 140, -310, 240, -340 + droop],
    [0, -240, -60, -380, -110, -440 + droop * 0.7],
    [0, -250, 70, -400, 120, -450 + droop * 0.7],
    [-150, -300, -260, -300, -300, -260 + droop * 1.2],
    [140, -310, 270, -310, 310, -270 + droop * 1.2],
  ];
  let d = `M-16,0 C-10,-80 -14,-150 0,-250 M16,0 C10,-80 14,-150 0,-250 M-40,0 C-24,-6 24,-6 40,0`;
  for (const [x0, y0, cx, cy, x1, y1] of br) d += ` M${x0},${y0} Q${cx},${cy} ${x1},${y1}`;
  const ends = br.map((b) => [b[4], b[5]]).concat([[-190, -360 + droop], [200, -370 + droop], [0, -470 + droop * 0.5], [-60, -420 + droop * 0.6], [70, -420 + droop * 0.6], [0, -390 + droop * 0.5], [-110, -350 + droop * 0.8], [110, -360 + droop * 0.8], [-30, -330 + droop * 0.6], [40, -340 + droop * 0.6]]);
  const leaves = Array.from({length: 60}, (_, i) => {
    const e = ends[i % ends.length];
    return {x: e[0] + (r() - 0.5) * 120, y: e[1] + (r() - 0.5) * 90, a: (r() - 0.5) * 80, k: r(), sc: 0.8 + r() * 0.6};
  });
  const figs = Array.from({length: 14}, (_, i) => {
    const e = ends[(i * 3) % ends.length];
    return {x: e[0] + (r() - 0.5) * 90, y: e[1] + 20 + (r() - 0.5) * 60, k: r()};
  });
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o * (1 - 0.35 * wither)}>
      <Line w={2.6 / s} p={p} d={d} />
      {leaves.map((l, i) => (l.k < leaf ? (
        <g key={i} transform={`translate(${l.x} ${l.y + wither * 30}) rotate(${l.a + wither * 120}) scale(${l.sc * (1 - 0.4 * wither)})`}>
          <path d={LEAF} fill="#1a1309" stroke="url(#goldLine)" strokeWidth={1.6 / s} opacity={1 - wither * 0.8} />
          <path d="M0,0 L0,-40 M0,-16 L-14,-28 M0,-16 L14,-28" stroke="#9C6E2C" strokeWidth={1 / s} fill="none" opacity={1 - wither} />
        </g>
      ) : null))}
      {figs.map((g, i) => (g.k < fruit ? <circle key={'f' + i} cx={g.x} cy={g.y} r={7} fill="#FFD9A0" filter="url(#lglow)" opacity={0.9} /> : null))}
    </g>
  );
};

/** coins scattered (static positions, t = scatter progress) */
export const Coins: React.FC<{x: number; y: number; t: number; o?: number}> = ({x, y, t, o = 1}) => {
  const r = rng(3);
  const c = Array.from({length: 14}, () => ({dx: (r() - 0.5) * 360, dy: -r() * 60, k: r()}));
  return <g opacity={o}>{c.map((k, i) => <ellipse key={i} cx={x + k.dx * t} cy={y + k.dy * (1 - t) + 0} rx={9} ry={4} fill="#E8B455" filter="url(#lglow)" />)}</g>;
};

/** table that tips over: tip 0..1 */
export const TipTable: React.FC<{x: number; y: number; tip: number; o?: number}> = ({x, y, tip, o = 1}) => (
  <g opacity={o} transform={`rotate(${tip * 82} ${x + 150} ${y})`}>
    <Line w={2.4} d={`M${x - 150},${y - 120} L${x + 150},${y - 120} M${x - 160},${y - 132} L${x + 160},${y - 132} M${x - 130},${y - 120} L${x - 130},${y} M${x + 130},${y - 120} L${x + 130},${y}`} />
  </g>
);

/** clay jar that breaks into shards: b 0..1 */
export const BreakJar: React.FC<{x: number; y: number; b: number; s?: number; o?: number}> = ({x, y, b, s = 1, o = 1}) => {
  const parts = [
    'M-40,-120 L-20,-150 L0,-120 L-10,-80 Z', 'M0,-120 L20,-150 L40,-120 L20,-80 Z', 'M-50,-80 L-10,-80 L-20,-20 L-50,-30 Z',
    'M-10,-80 L20,-80 L50,-80 L50,-30 L10,-20 Z', 'M-50,-30 L-20,-20 L-30,0 L-40,0 Z', 'M10,-20 L50,-30 L40,0 L0,0 Z',
  ];
  const off = [[-60, 100, -50], [70, 100, 60], [-120, 110, -80], [110, 90, 70], [-90, 30, -40], [80, 30, 30]];
  return (
    <g opacity={o} transform={`translate(${x} ${y}) scale(${s})`}>
      {parts.map((p, i) => (
        <g key={i} transform={`translate(${off[i][0] * b} ${off[i][1] * b * b}) rotate(${off[i][2] * b})`}>
          <path d={p} fill="#1a1309" stroke="url(#goldLine)" strokeWidth={2} filter="url(#lglow)" />
        </g>
      ))}
    </g>
  );
};

/** vine with branches growing from it; fr = fruit 0..1 */
export const Vine: React.FC<{x: number; y: number; s?: number; p?: number; fr?: number; o?: number}> = ({x, y, s = 1, p = 1, fr = 0, o = 1}) => {
  const d = 'M0,0 C-10,-120 20,-220 0,-330 M0,-110 C-80,-130 -170,-120 -260,-170 M0,-180 C90,-200 180,-190 260,-240 M0,-260 C-70,-290 -140,-300 -200,-350 M0,-300 C60,-330 120,-350 170,-400 M-260,-170 C-280,-190 -300,-200 -320,-190 M260,-240 C280,-260 300,-270 320,-260';
  const clusters = [[-240, -150], [240, -220], [-190, -330], [160, -380], [-120, -120], [120, -190]];
  return (
    <g opacity={o} transform={`translate(${x} ${y}) scale(${s})`}>
      <Line w={2.6 / s} p={p} d={d} />
      {clusters.map(([cx, cy], i) => (
        <g key={i} opacity={Math.max(0, Math.min(1, fr * 6 - i))}>
          {[[0, 0], [-10, 12], [10, 12], [0, 24], [-6, 34], [6, 34]].map(([dx, dy], k) => <circle key={k} cx={cx + dx} cy={cy + dy} r={7} fill="#FFD9A0" filter="url(#lglow)" />)}
        </g>
      ))}
    </g>
  );
};

/** gardener's spade */
export const Spade: React.FC<{x: number; y: number; rot?: number; o?: number}> = ({x, y, rot = 0, o = 1}) => (
  <g opacity={o} transform={`rotate(${rot} ${x} ${y})`}>
    <Line w={2.4} d={`M${x},${y} L${x},${y - 220} M${x - 20},${y - 220} L${x + 20},${y - 220} M${x - 22},${y} L${x + 22},${y} L${x + 16},${y + 50} C${x + 8},${y + 66} ${x - 8},${y + 66} ${x - 16},${y + 50} Z`} />
  </g>
);

/** mound of fresh soil around roots */
export const Soil: React.FC<{x: number; y: number; p?: number; o?: number}> = ({x, y, p = 1, o = 1}) => (
  <g opacity={o}><Line w={2} p={p} d={`M${x - 180},${y} C${x - 120},${y - 40} ${x - 60},${y - 46} ${x},${y - 46} C${x + 60},${y - 46} ${x + 120},${y - 40} ${x + 180},${y} M${x - 120},${y - 18} L${x - 100},${y - 22} M${x + 70},${y - 26} L${x + 92},${y - 22} M${x - 30},${y - 34} L${x - 10},${y - 36}`} /></g>
);

/** three-panel "sandwich" frame: tree / temple / tree */
export const Panels: React.FC<{p: number; o?: number; hl?: number}> = ({p, o = 1, hl = -1}) => (
  <g opacity={o}>
    {[0, 1, 2].map((i) => {
      const x = 260 + i * 500;
      return <g key={i} opacity={hl < 0 || hl === i ? 1 : 0.4}><Line u w={2} p={p} d={`M${x},300 L${x + 400},300 L${x + 400},820 L${x},820 Z`} /></g>;
    })}
  </g>
);

/** little dove cut-out (static) */
export const CageDoves: React.FC<{x: number; y: number; o?: number}> = ({x, y, o = 1}) => (
  <g opacity={o}>
    <Line w={2} d={`M${x - 70},${y} L${x + 70},${y} L${x + 70},${y - 110} C${x + 70},${y - 160} ${x - 70},${y - 160} ${x - 70},${y - 110} Z M${x - 35},${y} L${x - 35},${y - 140} M${x},${y} L${x},${y - 150} M${x + 35},${y} L${x + 35},${y - 140}`} />
  </g>
);

export {Cut};
