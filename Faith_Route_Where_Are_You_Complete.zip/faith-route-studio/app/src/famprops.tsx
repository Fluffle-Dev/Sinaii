import React from 'react';
import {Line, Cut, Fig, TXT, FigP} from './fig';
import {fi, ramp, eio, clamp} from './lib';

const G = (x: number, y: number, s = 1) => `translate(${x} ${y}) scale(${s})`;

/** line-art goat standing, facing right */
export const Goat: React.FC<{x: number; y: number; s?: number; o?: number; p?: number; flip?: boolean}> = ({x, y, s = 1, o = 1, p = 1, flip = false}) => (
  <g opacity={o} transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
    <path d="M-90,-70 C-90,-110 -40,-120 20,-118 C50,-117 70,-110 80,-100 L110,-130 C120,-140 132,-132 128,-118 L118,-92 C116,-80 104,-74 92,-78 L84,-60 C70,-50 40,-48 20,-50 L-60,-52 C-80,-54 -90,-60 -90,-70 Z" fill="#0c0905" />
    <Line w={2.2 / s} p={p} d="M-90,-70 C-90,-110 -40,-120 20,-118 C50,-117 70,-110 80,-100 L110,-130 C120,-140 132,-132 128,-118 L118,-92 C116,-80 104,-74 92,-78 L84,-60 C70,-50 40,-48 20,-50 L-60,-52 C-80,-54 -90,-60 -90,-70 Z M-70,-54 L-74,0 M-50,-52 L-46,0 M40,-50 L36,0 M64,-54 L68,0 M108,-128 C100,-160 80,-170 66,-160 M114,-130 C112,-158 96,-172 84,-168 M-90,-80 C-104,-90 -108,-100 -100,-110 M120,-92 C118,-80 124,-70 130,-74" />
  </g>
);

/** Joseph's ornate robe: long, ankle-length, long sleeves, coloured bands */
const ROBE_D = 'M-34,-380 L0,-350 L34,-380 L78,-366 L136,-170 L100,-158 L82,-280 L122,0 L-122,0 L-82,-280 L-100,-158 L-136,-170 L-78,-366 Z';
export const Robe: React.FC<{x: number; y: number; s?: number; o?: number; stain?: number; m?: 'gold' | 'silver' | 'bronze'}> = ({x, y, s = 1, o = 1, stain = 0, m = 'gold'}) => {
  const id = `robe${Math.round(x)}${Math.round(y)}${Math.round(s * 100)}`;
  const cols = ['#E8B455', '#C67D41', '#C9CCD1', '#9C6E2C', '#FFD9A0', '#C67D41', '#E8B455'];
  return (
    <g opacity={o}>
      <Cut m={m} lit={1} tf={G(x, y, s)}><path d={ROBE_D} /></Cut>
      <g transform={G(x, y, s)}>
        <clipPath id={id}><path d={ROBE_D} /></clipPath>
        <g clipPath={`url(#${id})`}>
          {cols.map((c, i) => <path key={i} d={`M-200,${-300 + i * 48} L200,${-330 + i * 48} L200,${-312 + i * 48} L-200,${-282 + i * 48} Z`} fill={c} opacity={0.55} />)}
          <path d="M-120,0 L120,0 L120,-120 C60,-90 -10,-150 -120,-110 Z" fill="#6a160d" opacity={0.85 * stain} />
        </g>
        <path d="M-34,-360 L0,-330 L34,-360" stroke="#FFE9B4" strokeWidth={3} fill="none" opacity={0.7} />
      </g>
    </g>
  );
};

/** dry pit: dark ellipse with stone rim */
export const Pit: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <ellipse cx={0} cy={0} rx={180} ry={40} fill="#030201" />
    <Line w={2.2 / s} p={p} d="M-180,0 C-180,-24 -90,-42 0,-42 C90,-42 180,-24 180,0 C180,24 90,42 0,42 C-90,42 -180,24 -180,0 M-150,-26 L-120,-34 M60,-40 L100,-36 M-40,38 L0,40 M120,28 L150,20" />
  </g>
);

/** prison window bars */
export const Bars: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <Line w={2.4 / s} p={p} d="M-160,0 L-160,-260 L160,-260 L160,0 Z M-100,0 L-100,-260 M-40,0 L-40,-260 M40,0 L40,-260 M100,0 L100,-260 M-160,-130 L160,-130" />
  </g>
);

/** two stone tablets */
export const Tablets: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <path d="M-170,0 L-170,-220 C-170,-280 -10,-280 -10,-220 L-10,0 Z M10,0 L10,-220 C10,-280 170,-280 170,-220 L170,0 Z" fill="#0c0905" />
    <Line w={2.4 / s} p={p} d="M-170,0 L-170,-220 C-170,-280 -10,-280 -10,-220 L-10,0 Z M10,0 L10,-220 C10,-280 170,-280 170,-220 L170,0 Z M-140,-200 L-40,-200 M-140,-160 L-40,-160 M-140,-120 L-40,-120 M-140,-80 L-40,-80 M-140,-40 L-40,-40 M40,-200 L140,-200 M40,-160 L140,-160 M40,-120 L140,-120 M40,-80 L140,-80 M40,-40 L140,-40" />
  </g>
);

/** grain sacks */
export const Sacks: React.FC<{x: number; y: number; s?: number; o?: number}> = ({x, y, s = 1, o = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    {[-60, 0, 60].map((dx, i) => (
      <g key={i}>
        <path d={`M${dx - 30},0 C${dx - 40},-50 ${dx - 20},-80 ${dx - 10},-90 L${dx + 10},-90 C${dx + 20},-80 ${dx + 40},-50 ${dx + 30},0 Z`} fill="#0c0905" />
        <Line w={2 / s} d={`M${dx - 30},0 C${dx - 40},-50 ${dx - 20},-80 ${dx - 10},-90 L${dx + 10},-90 C${dx + 20},-80 ${dx + 40},-50 ${dx + 30},0 Z M${dx - 12},-90 L${dx - 16},-104 M${dx + 12},-90 L${dx + 16},-104`} />
      </g>
    ))}
  </g>
);

/** slow-rising smoke wisps inside a house */
export const Smoke: React.FC<{x: number; y: number; f: number; o?: number}> = ({x, y, f, o = 1}) => (
  <g opacity={o}>
    {[0, 1, 2, 3].map((k) => {
      const t = ((f / 120 + k / 4) % 1);
      const yy = y - t * 260, xx = x + Math.sin(t * 4 + k) * 30 + (k - 1.5) * 60;
      return <path key={k} d={`M${xx},${yy} c-20,-30 20,-50 0,-80 c-20,-30 20,-50 0,-70`} stroke="#8E826E" strokeWidth={6} fill="none" opacity={0.35 * Math.sin(t * Math.PI)} strokeLinecap="round" />;
    })}
  </g>
);

/** swaddled baby glow */
export const Baby: React.FC<{x: number; y: number; s?: number; o?: number}> = ({x, y, s = 1, o = 1}) => (
  <g opacity={o}>
    <circle cx={x} cy={y} r={90 * s} fill="url(#halo)" />
    <Cut m="gold" lit={1} tf={G(x, y, s)}>
      <path d="M-44,10 C-50,-10 -30,-24 0,-22 C30,-20 50,-6 44,12 C36,26 -36,28 -44,10 Z" />
      <circle cx={-46} cy={-6} r={14} />
    </Cut>
  </g>
);

const PORTRAIT: Record<string, Partial<FigP>> = {
  abr: {m: 'gold', beard: 'long', hair: 'cloth'}, sar: {m: 'gold', beard: 'none', hair: 'veil'},
  isa: {m: 'gold', beard: 'short', hair: 'cloth'}, reb: {m: 'gold', beard: 'none', hair: 'veil'},
  esa: {m: 'bronze', beard: 'long', hair: 'long', wide: 1.1}, jac: {m: 'gold', beard: 'short', hair: 'cloth'},
  rac: {m: 'gold', beard: 'none', hair: 'veil'}, lea: {m: 'bronze', beard: 'none', hair: 'veil'},
  bro: {m: 'bronze', beard: 'long', hair: 'cloth'}, jos: {m: 'gold', beard: 'none', hair: 'cloth'},
};
export type LNode = {k: string; x: number; y: number; name: string; heb?: string; m?: 'gold' | 'silver' | 'bronze'};
export const NODES: LNode[] = [
  {k: 'abr', x: 820, y: 210, name: 'ABRAHAM'}, {k: 'sar', x: 1100, y: 210, name: 'SARAH'},
  {k: 'isa', x: 820, y: 420, name: 'ISAAC'}, {k: 'reb', x: 1100, y: 420, name: 'REBEKAH'},
  {k: 'esa', x: 560, y: 630, name: 'ESAU'}, {k: 'jac', x: 820, y: 630, name: 'JACOB'}, {k: 'rac', x: 1100, y: 630, name: 'RACHEL'}, {k: 'lea', x: 1340, y: 630, name: 'LEAH'},
  {k: 'bro', x: 600, y: 840, name: 'HIS BROTHERS'}, {k: 'jos', x: 960, y: 840, name: 'JOSEPH'},
];
const N = (k: string) => NODES.find((n) => n.k === k)!;
const LINKS: [string, string, number][] = [['abr', 'sar', 0], ['abr', 'isa', 1], ['isa', 'reb', 1], ['isa', 'jac', 2], ['isa', 'esa', 2], ['jac', 'rac', 2], ['jac', 'lea', 2], ['jac', 'jos', 3], ['jac', 'bro', 3]];

/**
 * The family tree that recurs through the video.
 * gen: how many generations drawn (0..4, fractional animates), hl: highlighted node keys,
 * cracks: generations (1..3) whose descent link shows a crack, heal 0..1 turns cracks into clean light,
 * tags: [{k, t, o}] small labels beside nodes.
 */
export const Lineage: React.FC<{gen: number; hl?: string[]; cracks?: number; heal?: number; o?: number; tags?: {k: string; t: string; o: number; c?: string}[]; dim?: number}> = ({gen, hl = [], cracks = 0, heal = 0, o = 1, tags = [], dim = 0}) => {
  const genOf = (k: string) => (['abr', 'sar'].includes(k) ? 0 : ['isa', 'reb'].includes(k) ? 1 : ['esa', 'jac', 'rac', 'lea'].includes(k) ? 2 : 3);
  return (
    <g opacity={o}>
      {LINKS.map(([a, b, g], i) => {
        const A = N(a), B = N(b), pr = clamp(gen - g);
        if (pr <= 0) return null;
        const horiz = A.y === B.y;
        const d = horiz ? `M${A.x + 48},${A.y} L${B.x - 48},${B.y}` : `M${A.x},${A.y + 90} C${A.x},${(A.y + B.y) / 2 + 40} ${B.x},${(A.y + B.y) / 2 + 20} ${B.x},${B.y - 48}`;
        const cracked = !horiz && ((a === 'abr' && b === 'isa' && cracks >= 1) || (a === 'isa' && b === 'jac' && cracks >= 2) || (a === 'jac' && b === 'jos' && cracks >= 3));
        return (
          <g key={i}>
            <Line u={horiz} w={2} p={eio(pr)} d={d} o={horiz ? 0.6 : 0.9} />
            {cracked ? (
              <g opacity={1 - heal}>
                <path d={`M${(A.x + B.x) / 2 - 18},${(A.y + B.y) / 2 - 16} l12,10 l-8,8 l14,8 l-6,10`} stroke="#F2C27A" strokeWidth={3} fill="none" filter="url(#lglowU)" />
              </g>
            ) : null}
          </g>
        );
      })}
      {NODES.map((n) => {
        const pr = clamp(gen - genOf(n.k) + 0.0001 >= 0 ? (gen - genOf(n.k)) * 3 : 0);
        if (pr <= 0) return null;
        const on = hl.includes(n.k);
        return (
          <g key={n.k} opacity={pr * (on || hl.length === 0 ? 1 : 1 - dim)}>
            {on ? <circle cx={n.x} cy={n.y} r={110} fill="url(#halo)" /> : null}
            <circle cx={n.x} cy={n.y} r={46} fill="#120d07" />
            <clipPath id={`cp${n.k}`}><circle cx={n.x} cy={n.y} r={45} /></clipPath>
            <g clipPath={`url(#cp${n.k})`}>
              <Fig x={n.x - 0.5 * 30} y={n.y + 2 + 0.5 * 1340} sc={0.5} lit={1} m="gold" {...PORTRAIT[n.k]} />
            </g>
            <circle cx={n.x} cy={n.y} r={46} fill="none" stroke="url(#goldLine)" strokeWidth={on ? 3.5 : 2.2} filter="url(#lglowU)" />
            <text x={n.x} y={n.y + 76} textAnchor="middle" fill={on ? TXT.gold : TXT.ivory} fontFamily="Cinzel" fontSize={26} letterSpacing="3">{n.name}</text>
          </g>
        );
      })}
      {tags.map((t, i) => {
        const n = N(t.k);
        return t.o > 0 ? <text key={i} x={n.x + (n.x < 960 ? -70 : 70)} y={n.y + 6} textAnchor={n.x < 960 ? 'end' : 'start'} fill={t.c ?? '#F2C27A'} fontFamily="Cinzel" fontSize={24} letterSpacing="3" opacity={t.o}>{t.t}</text> : null;
      })}
      <circle cx={960} cy={840} r={260} fill="url(#halo)" opacity={0.7 * heal} />
    </g>
  );
};

export {fi, ramp};
