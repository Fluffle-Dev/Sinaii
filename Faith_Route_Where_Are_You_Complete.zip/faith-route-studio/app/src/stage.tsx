import React from 'react';
import {Fig, FigP, Sheep, MET} from './fig';
import {win, fi, rng} from './lib';

export type SceneOut = {svg: React.ReactNode; html?: React.ReactNode};
export type Scene = {start: number; render: (f: number) => SceneOut};
export const CUES: number[] = [];
export const cue = (fr: number) => { CUES.push(fr); return fr; };

export const GY = 860;
export const sgn = (v: number) => (v >= 0 ? 1 : -1);

/** figure that fades in (with a small settle) at a and out at b */
export const FX = (f: number, a: number, b: number | undefined, p: FigP, k?: string) => (
  <Fig key={k} {...p} o={(p.o ?? 1) * win(f, a, b, 16)} y={p.y + (1 - fi(f, a, 18)) * 10} />
);
export const SX = (f: number, a: number, b: number | undefined, p: React.ComponentProps<typeof Sheep>, k?: string) => (
  <Sheep key={k} {...p} o={(p.o ?? 1) * win(f, a, b, 16)} />
);

export const Spot: React.FC<{id: string; x: number; y: number; r: number; a?: number; c?: string}> = ({id, x, y, r, a = 0.6, c = '#8C6431'}) => (
  <>
    <defs>
      <radialGradient id={id} cx={x} cy={y} r={r} gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor={c} stopOpacity={a} />
        <stop offset="0.5" stopColor={c} stopOpacity={a * 0.35} />
        <stop offset="1" stopColor={c} stopOpacity={0} />
      </radialGradient>
    </defs>
    <rect width={1920} height={1080} fill={`url(#${id})`} />
  </>
);

export const Ground: React.FC<{id: string; y?: number; o?: number; cx?: number}> = ({id, y = GY, o = 1, cx = 960}) => {
  const r = rng(Math.round(y) + 7);
  const marks = Array.from({length: 46}, () => ({x: r() * 1920, y: y + 14 + r() * 50, l: 10 + r() * 26, a: (r() - 0.5) * 0.5}));
  return (
    <g opacity={o}>
      <defs>
        <linearGradient id={id} gradientUnits="userSpaceOnUse" x1={0} y1={y} x2={1920} y2={y}>
          <stop offset="0" stopColor="#3a2a16" stopOpacity={0} />
          <stop offset={Math.max(0.05, cx / 1920 - 0.32)} stopColor="#7d5c30" stopOpacity={0.6} />
          <stop offset={cx / 1920} stopColor="#E0AE60" stopOpacity={0.95} />
          <stop offset={Math.min(0.95, cx / 1920 + 0.32)} stopColor="#7d5c30" stopOpacity={0.6} />
          <stop offset="1" stopColor="#3a2a16" stopOpacity={0} />
        </linearGradient>
      </defs>
      <path d={`M0,${y} L1920,${y}`} stroke={`url(#${id})`} strokeWidth={1.6} />
      <path d={`M0,${y} L1920,${y}`} stroke={`url(#${id})`} strokeWidth={6} opacity={0.3} filter="url(#lglow)" />
      {marks.map((m, i) => {
        const near = 1 - Math.min(1, Math.abs(m.x - cx) / 900);
        return <path key={i} d={`M${m.x},${m.y} l${m.l * Math.cos(m.a)},${m.l * Math.sin(m.a)}`} stroke="#9a7442" strokeWidth={1.2} opacity={0.1 + near * 0.3} strokeLinecap="round" />;
      })}
    </g>
  );
};

/** floating dust motes, like the reference */
export const Dust: React.FC<{f: number}> = ({f}) => {
  const r = rng(99);
  const pts = Array.from({length: 38}, () => ({x: r() * 1920, y: r() * 1080, s: 0.6 + r() * 1.4, v: 0.1 + r() * 0.25, ph: r() * 6}));
  return (
    <g>
      {pts.map((p, i) => (
        <circle key={i} cx={(p.x + Math.sin(f / 90 + p.ph) * 20) % 1920} cy={(p.y - f * p.v + 1080 * 4) % 1080} r={p.s} fill="#E8C98A" opacity={0.13} />
      ))}
    </g>
  );
};

/** crown / crook icons as lit cut-outs (for ladder, comparisons) */
import {Cut} from './fig';
export const CrownIcon: React.FC<{x: number; y: number; s?: number; m?: 'gold' | 'silver' | 'bronze'; lit?: number; o?: number}> = ({x, y, s = 1, m = 'silver', lit = 1, o = 1}) => (
  <Cut m={m} lit={lit} o={o} tf={`translate(${x} ${y}) scale(${s})`}><path d="M-60,20 L-60,-30 L-36,-6 L-14,-46 L0,-14 L14,-46 L36,-6 L60,-30 L60,20 Q0,8 -60,20 Z" /></Cut>
);
export const CrookIcon: React.FC<{x: number; y: number; s?: number; m?: 'gold' | 'silver' | 'bronze'; lit?: number; o?: number}> = ({x, y, s = 1, m = 'gold', lit = 1, o = 1}) => (
  <Cut m={m} lit={lit} o={o} tf={`translate(${x} ${y}) scale(${s})`}>
    <path d="M-5,120 L-5,-60 C-5,-120 66,-126 68,-74 C69,-44 42,-36 30,-54 L38,-60 C46,-48 58,-52 58,-74 C56,-110 5,-106 5,-60 L5,120 Z" />
  </Cut>
);
export {MET};
