import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import {Defs} from './fig';
import {Fonts} from './text';
import {Scene} from './stage';
import {END, fi, fo, ramp, eio} from './lib';

import {AY1} from './scenes/ay1';
import {AY2} from './scenes/ay2';

export const SCENES: Scene[] = [...AY1, ...AY2];
export const DURATION = END;
const XF = 18;

export const Main: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: '#15110c', overflow: 'hidden'}}>
      <Fonts />
      <Audio src={staticFile('voice.wav')} />
      <svg width={0} height={0} style={{position: 'absolute'}}><Defs /></svg>
      {SCENES.map((sc, i) => {
        const next = SCENES[i + 1]?.start;
        if (f < sc.start - 1 || (next !== undefined && f > next + XF + 1)) return null;
        const o = (i === 0 ? 1 : fi(f, sc.start, XF)) * fo(f, next, XF) * (i === SCENES.length - 1 ? 1 - ramp(f, END - 40, 34) : 1);
        const out = sc.render(f);
        return (
          <AbsoluteFill key={i} style={{opacity: o}}>
            <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute'}}><g transform={`translate(960 600) scale(${1 + 0.035 * eio(ramp(f, sc.start, Math.max(60, (next ?? END) - sc.start + XF)))}) translate(-960 -600)`}>{out.svg}</g></svg>
            {out.html}
          </AbsoluteFill>
        );
      })}
      {/* no dust, no grain: nothing that twinkles */}
    </AbsoluteFill>
  );
};
