import React from 'react';
import {Line, Cut, TXT} from './fig';
import {win, fi, ramp, eio, eout, rng, clamp} from './lib';

const G = (x: number, y: number, s = 1) => `translate(${x} ${y}) scale(${s})`;
const glow = (c: string, a = 0.35) => `0 0 18px ${c}${Math.round(a * 255).toString(16).padStart(2, '0')}`;

/** soft vertical beam of light from above: God's presence */
export const Beam: React.FC<{x: number; w?: number; o?: number; bottom?: number; f?: number}> = ({x, w = 260, o = 1, bottom = 860, f = 0}) => {
  if (o <= 0.001) return null;
  const br = 0.94 + 0.06 * Math.sin(f / 45);
  return (
    <g opacity={o * br}>
      <defs>
        <linearGradient id="bmG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#F1CD86" stopOpacity="0.42" />
          <stop offset="0.7" stopColor="#D9A955" stopOpacity="0.16" />
          <stop offset="1" stopColor="#C99A4A" stopOpacity="0.05" />
        </linearGradient>
      </defs>
      <path d={`M${x - w * 0.34},0 L${x + w * 0.34},0 L${x + w * 0.62},${bottom} L${x - w * 0.62},${bottom} Z`} fill="url(#bmG)" filter="url(#soft)" />
      <path d={`M${x - w * 0.1},0 L${x + w * 0.1},0 L${x + w * 0.2},${bottom} L${x - w * 0.2},${bottom} Z`} fill="url(#bmG)" opacity={0.8} filter="url(#soft)" />
      <ellipse cx={x} cy={bottom} rx={w * 0.9} ry={26} fill="url(#halo)" opacity={0.9} />
    </g>
  );
};

/** outlined word card (like the reference's boxed word rows) */
export const Card: React.FC<{f: number; a: number; b?: number; x: number; y: number; w?: number; h?: number; top?: string; heb?: string; grk?: string; en?: string; big?: string; hl?: number}> = ({f, a, b, x, y, w = 420, h = 200, top, heb, grk, en, big, hl = 0}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const p = eout(ramp(f, a, 24));
  const rows: [string, number, string, number, string][] = [];
  if (top) rows.push(['Cinzel', 32, TXT.gold, 0.2, top]);
  if (heb) rows.push(['Heb', 72, TXT.gold, 0, heb]);
  if (grk) rows.push(['Grk', 66, TXT.gold, 0.02, grk]);
  if (big) rows.push(['Cinzel', 50, TXT.ivory, 0.1, big]);
  if (en) rows.push(['Corm', 44, TXT.ivory, 0, en]);
  return (
    <g opacity={o}>
      <rect x={x - w / 2} y={y - h / 2} width={w} height={h} fill="#000" opacity={0.42} />
      {hl > 0 ? <rect x={x - w / 2} y={y - h / 2} width={w} height={h} fill="#C99A4A" opacity={0.1 * hl} /> : null}
      <rect x={x - w / 2} y={y - h / 2} width={w} height={h} fill="none" stroke="url(#goldLine)" strokeWidth={2 + hl} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - p} filter="url(#lglow)" />
      {rows.map((r, i) => {
        const yy = y - h / 2 + (h * (i + 0.5)) / rows.length + r[1] * 0.34;
        return (
          <text key={i} x={x} y={yy} textAnchor="middle" fill={r[2]} fontFamily={r[0]} fontStyle={r[0] === 'Corm' ? 'italic' : undefined} fontSize={r[1]} letterSpacing={r[3] * r[1]} opacity={fi(f, a + 8 + i * 6, 16)} direction={r[0] === 'Heb' ? 'rtl' : undefined}>{r[4]}</text>
        );
      })}
    </g>
  );
};

/** quote: reference + English, *marked* words turn gold at their keys */
export const Q: React.FC<{f: number; a: number; b?: number; refText: string; eng: string; keys?: number[]; y?: number; size?: number; w?: number}> = ({f, a, b, refText, eng, keys = [], y = 70, size = 52, w = 1640}) => {
  const vis = win(f, a, b, 16);
  if (vis <= 0.001) return null;
  let ki = 0;
  const parts = eng.split(/(\*[^*]+\*)/).filter(Boolean).map((s, i) => {
    if (s.startsWith('*')) {
      const t = eout(ramp(f, keys[ki++] ?? a + 30, 10));
      return <span key={i} style={{color: t > 0.5 ? TXT.gold : TXT.ivory, textShadow: t > 0.5 ? glow('#E9BE6E', 0.55) : 'none'}}>{s.slice(1, -1)}</span>;
    }
    return <span key={i}>{s}</span>;
  });
  return (
    <div style={{position: 'absolute', left: 960 - w / 2, top: y, width: w, textAlign: 'center', opacity: vis}}>
      <div style={{fontFamily: 'Cinzel', fontSize: 34, letterSpacing: '0.3em', color: TXT.gold, textShadow: glow('#C9A15A', 0.3)}}>{refText}</div>
      <div style={{fontFamily: 'Corm', fontStyle: 'italic', fontSize: size, lineHeight: 1.25, color: TXT.ivory, marginTop: 10, opacity: fi(f, a + 8, 18)}}>{parts}</div>
    </div>
  );
};

/* ---------------- the covenant arch: recurring diagram ---------------- */
export type StoneK = 'adam' | 'noah' | 'abr' | 'new' | 'david' | 'phin' | 'sinai';
export const STONES: {k: StoneK; t: string; s: string}[] = [
  {k: 'adam', t: 'ADAM', s: 'EDEN'},
  {k: 'noah', t: 'NOAH', s: 'RAINBOW'},
  {k: 'abr', t: 'ABRAHAM', s: 'FIRE'},
  {k: 'new', t: 'NEW', s: 'JESUS'},
  {k: 'david', t: 'DAVID', s: 'THRONE'},
  {k: 'phin', t: 'PHINEHAS', s: 'PRIEST'},
  {k: 'sinai', t: 'SINAI', s: 'LAW'},
];
const P = (cx: number, cy: number, r: number, deg: number) => [cx + r * Math.cos((deg * Math.PI) / 180), cy - r * Math.sin((deg * Math.PI) / 180)];
/**
 * n: per-stone placement 0..1, hl: highlighted stone, crack: cracked adam stone, shake: collapse wobble,
 * scatter: 0..1 stones scattered apart, lab: label opacity, sub: sign label opacity
 */
export const Arch: React.FC<{f: number; cx?: number; cy?: number; R?: number; r?: number; n: Partial<Record<StoneK, number>>; hl?: StoneK | null; scatter?: number; shake?: number; lab?: number; sub?: number; o?: number; dimOthers?: number; crack?: number}> = ({f, cx = 960, cy = 860, R = 560, r = 370, n, hl = null, scatter = 0, shake = 0, lab = 1, sub = 1, o = 1, dimOthers = 0, crack = 1}) => {
  if (o <= 0.001) return null;
  const rr = rng(41);
  const step = 180 / 7, gap = 0.9;
  return (
    <g opacity={o}>
      {STONES.map((st, i) => {
        const v = clamp(n[st.k] ?? 0);
        const sc = [(rr() - 0.5) * 900, (rr() - 0.3) * 380, (rr() - 0.5) * 70];
        if (v <= 0.001) return null;
        const a1 = 180 - i * step - gap, a0 = 180 - (i + 1) * step + gap;
        const [x1, y1] = P(cx, cy, R, a1), [x2, y2] = P(cx, cy, R, a0), [x3, y3] = P(cx, cy, r, a0), [x4, y4] = P(cx, cy, r, a1);
        const d = `M${x1},${y1} A${R},${R} 0 0 1 ${x2},${y2} L${x3},${y3} A${r},${r} 0 0 0 ${x4},${y4} Z`;
        const [mx, my] = P(cx, cy, (R + r) / 2, (a0 + a1) / 2);
        const drop = eout(v);
        const wob = shake * Math.sin(f / 3 + i * 2) * 3;
        const tf = `translate(${sc[0] * scatter + wob} ${-(1 - drop) * 220 + sc[1] * scatter + (shake ? Math.abs(wob) : 0)}) rotate(${sc[2] * scatter} ${mx} ${my})`;
        const isH = hl === st.k;
        const dim = hl && !isH ? 1 - 0.55 * dimOthers : 1;
        const key = st.k === 'new';
        return (
          <g key={st.k} transform={tf} opacity={eio(clamp(v * 1.4)) * dim}>
            {isH ? <circle cx={mx} cy={my} r={170} fill="url(#halo)" opacity={0.9} /> : null}
            <path d={d} fill={isH ? '#2a1d0c' : '#0e0a06'} opacity={0.94} />
            <path d={d} fill="none" stroke="url(#goldLine)" strokeWidth={isH ? 3.4 : key ? 3 : 2.2} filter="url(#lglow)" />
            {st.k === 'adam' && crack > 0 ? <path d={`M${mx - 30},${my - 52} L${mx - 6},${my - 18} L${mx - 22},${my + 6} L${mx + 6},${my + 44}`} fill="none" stroke="#C67D41" strokeWidth={2} opacity={0.8 * crack} /> : null}
            <text x={mx} y={my + (sub > 0 ? 2 : 10)} textAnchor="middle" fill={isH || key ? TXT.gold : TXT.ivory} fontFamily="Cinzel" fontSize={st.t.length > 7 ? 27 : 32} letterSpacing={2} opacity={lab}>{st.t}</text>
            <text x={mx} y={my + 34} textAnchor="middle" fill={TXT.gold} fontFamily="Cinzel" fontSize={19} letterSpacing={4} opacity={sub * 0.85}>{st.s}</text>
          </g>
        );
      })}
    </g>
  );
};

/** animal cut in two: two halves pulled apart by gap */
export const Halves: React.FC<{id: string; x: number; y: number; gap: number; o?: number; children: (dx: number) => React.ReactNode}> = ({id, x, y, gap, o = 1, children}) => (
  <g opacity={o}>
    <defs>
      <clipPath id={id + 'L'}><rect x={x - 400} y={y - 400} width={400} height={420} /></clipPath>
      <clipPath id={id + 'R'}><rect x={x} y={y - 400} width={400} height={420} /></clipPath>
    </defs>
    <g transform={`translate(${-gap} 0)`}><g clipPath={`url(#${id}L)`}>{children(0)}</g></g>
    <g transform={`translate(${gap} 0)`}><g clipPath={`url(#${id}R)`}>{children(0)}</g></g>
  </g>
);

/** heifer / ram silhouettes (gold-rim cut-outs), facing right; x = centre, y = ground */
export const Beast: React.FC<{x: number; y: number; s?: number; kind?: 'heifer' | 'ram' | 'goat'; o?: number; m?: 'gold' | 'bronze'}> = ({x, y, s = 1, kind = 'heifer', o = 1, m = 'bronze'}) => {
  const body: Record<string, string> = {
    heifer: 'M-150,-120 C-150,-170 -90,-186 0,-184 C70,-183 110,-176 128,-160 L160,-176 C178,-186 196,-176 194,-158 L186,-120 C182,-104 166,-98 150,-104 L134,-92 C120,-74 80,-72 40,-74 L-110,-76 C-140,-78 -150,-96 -150,-120 Z M-128,-80 L-132,0 L-108,0 L-104,-80 Z M-70,-78 L-66,0 L-44,0 L-48,-78 Z M60,-76 L56,0 L80,0 L84,-76 Z M108,-80 L114,0 L136,0 L130,-82 Z M-150,-130 C-170,-120 -176,-90 -168,-60 L-162,-60 C-166,-88 -160,-112 -148,-120 Z',
    ram: 'M-110,-90 C-116,-140 -60,-156 10,-152 C60,-150 90,-140 100,-126 L120,-140 C140,-152 160,-140 156,-120 L148,-96 C144,-84 130,-80 118,-84 L104,-74 C90,-58 50,-58 20,-60 L-80,-62 C-104,-64 -110,-76 -110,-90 Z M-92,-64 L-96,0 L-76,0 L-72,-64 Z M-46,-62 L-42,0 L-24,0 L-28,-62 Z M44,-62 L40,0 L60,0 L64,-62 Z M84,-66 L88,0 L106,0 L102,-66 Z M118,-146 C96,-176 128,-196 150,-180 C166,-168 160,-146 146,-144 C140,-158 128,-162 122,-150 Z',
    goat: 'M-90,-70 C-90,-110 -40,-120 20,-118 C50,-117 70,-110 80,-100 L110,-130 C120,-140 132,-132 128,-118 L118,-92 C116,-80 104,-74 92,-78 L84,-60 C70,-50 40,-48 20,-50 L-60,-52 C-80,-54 -90,-60 -90,-70 Z M-74,-56 L-78,0 L-62,0 L-58,-56 Z M-50,-54 L-46,0 L-32,0 L-36,-54 Z M38,-52 L34,0 L48,0 L52,-52 Z M62,-56 L66,0 L80,0 L76,-56 Z M108,-128 C100,-160 80,-170 66,-160 L72,-154 C84,-160 96,-152 100,-126 Z',
  };
  return <Cut m={m} lit={1} o={o} tf={G(x, y, s)}><path d={body[kind]} /></Cut>;
};

/** small bird silhouette lying on the ground */
export const Bird: React.FC<{x: number; y: number; s?: number; o?: number}> = ({x, y, s = 1, o = 1}) => (
  <Cut m="bronze" lit={1} o={o} tf={G(x, y, s)}>
    <path d="M-40,-4 C-36,-24 -10,-30 14,-26 L30,-36 C40,-40 46,-32 40,-24 L30,-16 C26,-4 10,0 -10,0 L-40,0 Z M-40,-4 L-60,-10 L-58,0 Z" />
  </Cut>
);

/** firepot with a blazing torch, smoke rising: x,y = base */
export const Firepot: React.FC<{x: number; y: number; f: number; s?: number; o?: number}> = ({x, y, f, s = 1, o = 1}) => {
  if (o <= 0.001) return null;
  const w = (k: number) => Math.sin(f / 5 + k) * 7;
  return (
    <g opacity={o} transform={G(x, y, s)}>
      <ellipse cx={0} cy={-120} rx={210} ry={190} fill="url(#halo)" opacity={1} />
      {[0, 1, 2].map((k) => {
        const t = (f / 90 + k / 3) % 1;
        return <path key={k} d={`M${Math.sin(t * 5 + k) * 18},${-150 - t * 240} c-24,-30 24,-50 0,-80 c-24,-30 24,-50 0,-70`} stroke="#9E8E74" strokeWidth={9} fill="none" opacity={0.32 * Math.sin(t * Math.PI)} strokeLinecap="round" />;
      })}
      <path d="M-48,-70 C-60,-40 -50,-6 -30,0 L30,0 C50,-6 60,-40 48,-70 Z" fill="#0c0905" />
      <Line w={2.4 / s} d="M-48,-70 C-60,-40 -50,-6 -30,0 L30,0 C50,-6 60,-40 48,-70 Z M-56,-72 L56,-72" />
      <path d={`M-30,-74 C-40,-104 -20,-124 ${-14 + w(1)},-158 C0,-132 10,-128 ${8 + w(2)},-184 C30,-140 42,-110 30,-74 Z`} fill="#F6C46E" filter="url(#lglow)" />
      <path d={`M-14,-74 C-18,-94 -6,-108 ${-2 + w(3)},-128 C10,-108 18,-96 12,-74 Z`} fill="#FFF0C8" />
      <g transform="translate(70 -70) rotate(18)">
        <rect x={-6} y={-130} width={12} height={130} fill="#0c0905" />
        <Line w={2 / s} d="M-6,0 L-6,-130 L6,-130 L6,0" />
        <path d={`M-14,-130 C-20,-150 -8,-166 ${-4 + w(4)},-196 C8,-170 18,-150 12,-130 Z`} fill="#F6C46E" filter="url(#lglow)" />
      </g>
    </g>
  );
};

/** rainbow arcs (gold tones), p = draw */
export const Rainbow: React.FC<{x: number; y: number; R?: number; p?: number; o?: number}> = ({x, y, R = 620, p = 1, o = 1}) => (
  <g opacity={o}>
    {[0, 1, 2, 3, 4].map((k) => {
      const r = R - k * 26;
      const c = ['#F4D9A0', '#E8B455', '#D49A4A', '#C07F3E', '#A8723C'][k];
      return <path key={k} d={`M${x - r},${y} A${r},${r} 0 0 1 ${x + r},${y}`} fill="none" stroke={c} strokeWidth={18} opacity={0.42} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - p} filter="url(#soft3)" />;
    })}
    <path d={`M${x - R - 12},${y} A${R + 12},${R + 12} 0 0 1 ${x + R + 12},${y}`} fill="none" stroke="url(#goldLine)" strokeWidth={2} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - p} filter="url(#lglow)" />
  </g>
);

/** warrior's bow with string; rot in degrees */
export const Bow: React.FC<{x: number; y: number; s?: number; rot?: number; o?: number; p?: number; arrow?: number}> = ({x, y, s = 1, rot = 0, o = 1, p = 1, arrow = 1}) => (
  <g opacity={o} transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <Line w={3 / s} p={p} d="M-20,-260 C120,-200 120,200 -20,260" />
    <Line w={1.4 / s} p={p} d="M-20,-260 L-20,260" o={0.8} />
    {arrow > 0 ? <g opacity={arrow}><Line w={2 / s} d="M-20,0 L200,0 M200,0 L176,-14 M200,0 L176,14 M-20,0 L-44,-14 M-20,0 L-44,14" /></g> : null}
  </g>
);

/** cup / chalice */
export const Cup: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <ellipse cx={0} cy={-90} rx={90} ry={80} fill="url(#halo)" opacity={0.8} />
    <path d="M-44,-140 C-44,-90 -20,-70 -6,-66 L-6,-16 C-6,-8 -34,-6 -34,0 L34,0 C34,-6 6,-8 6,-16 L6,-66 C20,-70 44,-90 44,-140 Z" fill="#0c0905" />
    <Line w={2.4 / s} p={p} d="M-44,-140 C-44,-90 -20,-70 -6,-66 L-6,-16 C-6,-8 -34,-6 -34,0 L34,0 C34,-6 6,-8 6,-16 L6,-66 C20,-70 44,-90 44,-140 Z M-44,-140 L44,-140" />
  </g>
);

/** heart: stone (cracked, grey) to flesh (gold, glowing) by t */
export const Heart: React.FC<{x: number; y: number; s?: number; t?: number; o?: number; p?: number}> = ({x, y, s = 1, t = 0, o = 1, p = 1}) => {
  const d = 'M0,90 C-40,60 -120,10 -120,-50 C-120,-100 -60,-120 0,-70 C60,-120 120,-100 120,-50 C120,10 40,60 0,90 Z';
  return (
    <g opacity={o} transform={G(x, y, s)}>
      <circle cx={0} cy={-10} r={200} fill="url(#halo)" opacity={t} />
      <path d={d} fill={t > 0 ? '#2a1a08' : '#0c0905'} />
      <path d={d} fill="#E8B455" opacity={0.35 * t} />
      <Line w={2.6 / s} p={p} d={d} c={t > 0.5 ? 'url(#goldLine)' : '#8E826E'} />
      <path d="M-60,-80 L-30,-30 L-60,0 L-20,40 M40,-90 L20,-40 L50,-10" fill="none" stroke="#8E826E" strokeWidth={2 / s} opacity={0.8 * (1 - t)} />
    </g>
  );
};

/** small city skyline (Ur), line art: x = centre, y = ground */
export const City: React.FC<{x: number; y: number; s?: number; o?: number; p?: number}> = ({x, y, s = 1, o = 1, p = 1}) => (
  <g opacity={o} transform={G(x, y, s)}>
    <Line w={2 / s} p={p} d="M-420,0 L-420,-110 L-330,-110 L-330,0 M-320,0 L-320,-160 L-220,-160 L-220,0 M-200,0 L-200,-120 L-140,-120 L-140,0 M-110,0 L-110,-150 L110,-150 L110,0 M-80,-150 L-80,-210 L80,-210 L80,-150 M-50,-210 L-50,-260 L50,-260 L50,-210 M140,0 L140,-130 L230,-130 L230,0 M250,0 L250,-100 L340,-100 L340,0 M360,0 L360,-140 L430,-140 L430,0 M-20,0 L-20,-60 L20,-60 L20,0" />
  </g>
);

/** chains between two points (simple oval links) */
export const Chain: React.FC<{x0: number; y0: number; x1: number; y1: number; o?: number}> = ({x0, y0, x1, y1, o = 1}) => {
  const n = Math.max(2, Math.round(Math.hypot(x1 - x0, y1 - y0) / 22));
  const ang = (Math.atan2(y1 - y0, x1 - x0) * 180) / Math.PI;
  return <g opacity={o}>{Array.from({length: n}, (_, i) => { const t = i / (n - 1); return <ellipse key={i} cx={x0 + (x1 - x0) * t} cy={y0 + (y1 - y0) * t} rx={13} ry={7} fill="none" stroke="#C9CCD1" strokeWidth={2.4} transform={`rotate(${ang + (i % 2) * 90 * 0.6} ${x0 + (x1 - x0) * t} ${y0 + (y1 - y0) * t})`} />; })}</g>;
};

/** circle arrow cycle diagram with labels */
export const Cycle: React.FC<{f: number; a: number; b?: number; x: number; y: number; r?: number; labels: string[]; spin?: number}> = ({f, a, b, x, y, r = 200, labels, spin = 0}) => {
  const o = win(f, a, b, 16);
  if (o <= 0.001) return null;
  const n = labels.length;
  return (
    <g opacity={o}>
      <circle cx={x} cy={y} r={r} fill="none" stroke="url(#goldLine)" strokeWidth={2} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - eout(ramp(f, a, 40))} filter="url(#lglow)" transform={`rotate(-90 ${x} ${y})`} />
      {labels.map((t, i) => {
        const ang = -Math.PI / 2 + (i / n) * Math.PI * 2;
        const lx = x + Math.cos(ang) * r, ly = y + Math.sin(ang) * r;
        const hl = Math.floor(spin) % n === i;
        const aa = ang + 0.5;
        const ax = x + Math.cos(aa) * r, ay = y + Math.sin(aa) * r;
        const td = (aa + Math.PI / 2) * 180 / Math.PI;
        return (
          <g key={i} opacity={fi(f, a + 10 + i * 8)}>
            <path d={`M${ax - 12},${ay - 10} L${ax + 4},${ay} L${ax - 12},${ay + 10}`} fill="none" stroke="url(#goldLine)" strokeWidth={2.4} transform={`rotate(${td} ${ax} ${ay})`} />
            <rect x={lx - 130} y={ly - 32} width={260} height={64} fill="#0c0905" stroke={hl ? '#F1CD86' : '#9C6E2C'} strokeWidth={hl ? 2.6 : 1.6} />
            <text x={lx} y={ly + 12} textAnchor="middle" fill={hl ? TXT.gold : TXT.ivory} fontFamily="Cinzel" fontSize={30} letterSpacing={3}>{t}</text>
          </g>
        );
      })}
    </g>
  );
};

/** simple thin arrow */
export const Arrow: React.FC<{x0: number; y0: number; x1: number; y1: number; p?: number; o?: number}> = ({x0, y0, x1, y1, p = 1, o = 1}) => {
  const a = Math.atan2(y1 - y0, x1 - x0);
  const ex = x0 + (x1 - x0) * p, ey = y0 + (y1 - y0) * p;
  return (
    <g opacity={o}>
      <Line u w={2.6} c="#E3B465" d={`M${x0},${y0} L${ex},${ey}`} />
      {p > 0.95 ? <Line u w={2.6} c="#E3B465" d={`M${ex - 20 * Math.cos(a - 0.5)},${ey - 20 * Math.sin(a - 0.5)} L${ex},${ey} L${ex - 20 * Math.cos(a + 0.5)},${ey - 20 * Math.sin(a + 0.5)}`} /> : null}
    </g>
  );
};
